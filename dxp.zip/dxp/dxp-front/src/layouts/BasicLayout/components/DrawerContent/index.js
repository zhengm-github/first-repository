import DrawerContent from "./DrawerContent";

export default DrawerContent;