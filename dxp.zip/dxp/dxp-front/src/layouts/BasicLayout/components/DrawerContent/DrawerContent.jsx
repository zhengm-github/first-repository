import React, { Component } from "react";
import { Icon, Drawer, Switch, List, message, Tooltip, Button } from "antd";
import cs from "classnames";
import { connect } from "react-redux";

import styles from "./DrawerContent.less";
import dark from "./dark.svg";
import light from "./light.svg";
import topMenu from "./topMenu.svg";
import asideMenu from "./asideMenu.svg";

const mapStateToProps = (state) => ({
	settings: state.setting.settings
});

const mapDispatchToProps = (dispatch) => ({
	setSetting: dispatch.setting.setSetting
});

@connect(
	mapStateToProps,
	mapDispatchToProps
)
class sklDrawerContent extends Component {
	/*
	 * collapse 侧边栏是否展开,data数组代表的是固定顶部 侧边栏 顶部是否隐藏等
	 * */
	state = {
		collapse: false,
		data: [],
		initialColor: ""
	};

	/*
	 * 侧边栏是否展示的函数
	 * */
	toggleCollapse = () => {
		const { collapse } = this.state;
		this.setState({
			collapse: !collapse
		});
	};

	/*
	 * 切换菜单结构是位于顶部还是侧边栏
	 * */
	toggleLayout = async (status) => {
		const { layout } = this.props.settings;
		const { setSetting } = this.props;
		if (layout === status) {
			return;
		}
		const obj = { ...this.props.settings, layout: status };
		await setSetting(obj);
		this.loadHeaderConfig();
	};

	/*
	 * 切换主题背景颜色是深还是浅
	 * */
	toggleNavTheme = async (status) => {
		const { navTheme } = this.props.settings;
		const { setSetting } = this.props;
		if (navTheme === status) {
			return;
		}
		const obj = { ...this.props.settings, navTheme: status };
		setSetting(obj);
	};

	/*
	 * 改变switch 触发的事件包含了 顶部固定还有侧边栏固定 顶部隐藏等
	 * */
	onChange = async (checked, event, type) => {
		const { setSetting } = this.props;
		const obj = { ...this.props.settings, [type]: checked };
		await setSetting(obj);
		if (type === "fixedHeader") {
			this.loadHeaderConfig();
		}
	};

	/*
	 * 主题替换颜色
	 * */
	onThemeColor = (color) => {
		const { primaryColor } = this.props.settings;
		const { setSetting } = this.props;
		if (color === primaryColor) {
			return;
		}
		const hideMessage = message.loading("正在切换主题！");
		window.less
			.modifyVars({
				"@primary-color": color
			})
			.then(() => {
				const obj = { ...this.props.settings, primaryColor: color };
				hideMessage.then(() => {
					message.success("主题颜色切换成功");
				});
				setSetting(obj);
			})
			.catch((error) => {
				hideMessage.then(() => {
					message.error("主题颜色切换失败");
				});
				console.log(error);
			});
	};

	loadHeaderConfig = () => {
		const { fixedHeader, fixSiderbar, layout } = this.props.settings;
		if (layout === "sidemenu") {
			this.setState({
				data: [
					{ title: "固定header", checked: fixedHeader, type: "fixedHeader", disabled: false },
					{
						title: "固定侧边菜单",
						checked: fixSiderbar,
						type: "fixSiderbar",
						disabled: false,
						description: "侧边栏菜单布局时可配置"
					}
				]
			});
		} else {
			this.setState({
				data: [
					{ title: "固定header", checked: fixedHeader, type: "fixedHeader", disabled: false },
					{
						title: "固定侧边菜单",
						checked: fixSiderbar,
						type: "fixSiderbar",
						disabled: true,
						description: "侧边栏菜单布局时可配置"
					}
				]
			});
		}
	};

	componentDidMount() {
		this.loadHeaderConfig();
	}

	render() {
		const { navTheme, layout, primaryColor } = this.props.settings;
		const { collapse, data } = this.state;
		const dataColor = [
			"#F5222D",
			"#FA541C",
			"#FA8C16",
			"#FAAD14",
			"#FADB14",
			"#A0D911",
			"#52C41A",
			"#13C2C2",
			"#1890FF",
			"#2F54EB",
			"#722ED1",
			"#EB2F96"
		];
		return (
			<div className={styles.sklDrawerContent}>
				<div
					className={cs(styles.sklSettingIcon, collapse ? styles.display : "")}
					onClick={this.toggleCollapse}
				>
					<Button
						type="primary"
						icon="setting"
						size="large"
						style={{ borderRadius: "4px 0 0 4px" }}
					/>
				</div>
				<div className={collapse ? styles.sklDrawerContentBody : ""}>
					<Drawer
						title="主题设置"
						placement="right"
						onClose={this.toggleCollapse}
						visible={collapse}
						width={300}
					>
						<div
							className={cs(styles.sklDrawerContentClose, collapse ? styles.display : "")}
							onClick={this.toggleCollapse}
						>
							{collapse ? (
								<Button
									type="primary"
									icon="close"
									size="large"
									style={{ borderRadius: "4px 0 0 4px" }}
								/>
							) : (
								<Button
									type="primary"
									icon="setting"
									size="large"
									style={{ borderRadius: "4px 0 0 4px" }}
								/>
							)}
						</div>
						<div style={{ marginBottom: "24px" }}>
							<div className={styles.sklSettingTitle}>整体风格设置</div>
							<div className={styles.sklStyleSetting}>
								<Tooltip placement="top" title="暗色菜单风格">
									<div className={styles.sklStyleSettingImg}>
											<img
												src={dark}
												onClick={() => {
													this.toggleNavTheme("dark");
												}}
												alt="黑色"
											/>
										{navTheme === "dark" ? (
											<Icon type="check" className={styles.sklStyleSettingIcon} />
										) : (
											""
										)}
									</div>
								</Tooltip>
								<Tooltip placement="top" title="亮色菜单风格">
									<div className={styles.sklStyleSettingImg}>
											<img
												src={light}
												onClick={() => {
													this.toggleNavTheme("light");
												}}
												alt="22"
											/>
										{navTheme === "light" ? (
											<Icon type="check" className={styles.sklStyleSettingIcon} />
										) : (
											""
										)}
									</div>
								</Tooltip>
							</div>
						</div>
						<div style={{ marginBottom: "24px" }}>
							<div className={styles.sklSettingTitle}>主题色</div>
							<div className={styles.sklThemeColor}>
								{dataColor.map((item) => {
									return (
										<div
											style={{ background: item }}
											className={styles.sklThemeColorList}
											onClick={() => {
												this.onThemeColor(item);
											}}
											key={item}
										>
											{primaryColor === item ? (
												<Icon type="check" className={styles.sklThemeColorIcon} />
											) : (
												""
											)}
										</div>
									);
								})}
							</div>
						</div>
						<div className={styles.sklDrawerDivider}></div>
						<div style={{ marginBottom: "24px" }}>
							<div className={styles.sklSettingTitle}>导航模式</div>
							<div className={styles.sklStyleSetting}>
								<Tooltip placement="top" title="侧边导航栏模式">
									<div className={styles.sklStyleSettingImg}>
											<img
												src={asideMenu}
												onClick={() => {
													this.toggleLayout("sidemenu");
												}}
												alt="侧边导航栏"
											/>
										{layout === "sidemenu" ? (
											<Icon type="check" className={styles.sklStyleSettingIcon} />
										) : (
											""
										)}
									</div>
								</Tooltip>
								<Tooltip placement="top" title="顶部导航栏模式">
									<div className={styles.sklStyleSettingImg}>
											<img
												src={topMenu}
												onClick={() => {
													this.toggleLayout("topmenu");
												}}
												alt="顶部导航栏"
											/>
										{layout === "topmenu" ? (
											<Icon type="check" className={styles.sklStyleSettingIcon} />
										) : (
											""
										)}
									</div>
								</Tooltip>
							</div>
						</div>
						<List
							className={styles.sklHeaderSetting}
							dataSource={data}
							itemLayout="vertical"
							renderItem={(item) =>
								item.disabled ? (
									<Tooltip placement="left" title={item.description}>
										<List.Item
											className={item.disabled ? styles.sklHeaderSettingHide : ""}
											extra={
												<Switch
													size="small"
													defaultChecked={item.checked}
													disabled={item.disabled}
													onChange={(...arg) => {
														this.onChange(...arg, item.type);
													}}
												/>
											}
										>
											{item.title}
										</List.Item>
									</Tooltip>
								) : (
									<List.Item
										className={item.disabled ? styles.sklHeaderSettingHide : ""}
										extra={
											<Switch
												size="small"
												defaultChecked={item.checked}
												disabled={item.disabled}
												onChange={(...arg) => {
													this.onChange(...arg, item.type);
												}}
											/>
										}
									>
										{item.title}
									</List.Item>
								)
							}
						/>
					</Drawer>
				</div>
			</div>
		);
	}
}

export default sklDrawerContent;
