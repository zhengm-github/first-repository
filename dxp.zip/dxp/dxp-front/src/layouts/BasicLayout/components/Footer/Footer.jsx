
import React, { PureComponent } from 'react';
import { Layout} from 'antd';
import styles from './Footer.less';

export default class Footer extends PureComponent {
    render() {
        return (
            <Layout.Footer
                type={null}
                className={styles.sklLayoutFooter}
            >
                <div>
                    © 2019 Theme designed by sunyard
                </div>
          </Layout.Footer>
        );
    }
 }
