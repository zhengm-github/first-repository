import React, { PureComponent } from "react";
import { Layout } from "antd";
import { connect } from "react-redux";
import cs from "classnames";
import Logo from "../Logo";
import styles from "./Aside.less";
import BaseMenu from "../BaseMenu";

const mapStateToProps = (state) => ({
	collapsed: state.collaps.collapsed,
	settings: state.setting.settings
});

@connect(
	mapStateToProps,
	{}
)
class Aside extends PureComponent {
	render() {
		const {
			collapsed,
			settings: { navTheme, fixSiderbar }
		} = this.props;
		return (
			<Layout.Sider
				trigger={null}
				collapsible
				className={cs(styles.sklAside, fixSiderbar ? styles.sklAsideFixed : "")}
				theme={navTheme}
				width={240}
				collapsed={collapsed}
			>
				<Logo />
				<BaseMenu mode="inline" className={styles.sklMenu} />
			</Layout.Sider>
		);
	}
}

export default Aside;
