import BaseMenu from "./BaseMenu";
export default BaseMenu;
