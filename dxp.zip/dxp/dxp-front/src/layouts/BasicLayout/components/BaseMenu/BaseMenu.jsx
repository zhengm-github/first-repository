import React, { PureComponent } from "react";
import { Icon, Menu } from "antd";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { withRouter } from "react-router";
import SklIcon from "@/components/SklIcon";
let pIds = [];
let system;
if (process.env.FRAME_WORK === "moon") {
	system = "children";
} else {
	system = "childMenuVos";
}

const getParentsIds = (data, path) => {
	for (let i = 0; i < data.length; i++) {
		let temp = data[i];
		if (path === temp.menuAction) {
			pIds.push(temp.menuId);
			return 1;
		}
		if (temp && temp[system] && temp[system].length) {
			let t = getParentsIds(temp[system], path);
			if (t === 1) {
				pIds.push(temp.menuId);
				return 1;
			}
		}
	}
};
const getIcon = (icon) => {
	if (typeof icon === "string") {
		if (icon.startsWith("icon-")) {
			return <SklIcon type={icon} />;
		}
		return <Icon type={icon} />;
	}
	return "";
};

const mapStateToProps = (state) => ({
	menuList: state.asideMenu.menuList,
	collapsed: state.collaps.collapsed,
	settings: state.setting.settings
});
const mapDispatchToProps = (dispatch) => ({
	getMenuData: dispatch.asideMenu.getMenuData
});

@withRouter
@connect(
	mapStateToProps,
	mapDispatchToProps
)
class BaseMenu extends PureComponent {
	state = {
		//默认展开项
		openKeys: []
	};

	/*
	 * 获取当前展开的菜单项
	 */
	getSelectKeys = (path) => {
		const { menuList } = this.props;
		pIds = [];
		let urllist = path.split("/").filter((i) => i);
		urllist = urllist.map((urlItem, index) => `/${urllist.slice(0, index + 1).join("/")}`);
		menuList.length && getParentsIds(menuList, urllist[urllist.length - 1]);
		return pIds;
	};

	isMainMenu = (key) => {
		const { menuList } = this.props;
		return menuList.some((item) => {
			if (key) {
				return item.menuId === key;
			}
			return false;
		});
	};

	/*
	 *submenu展开时的回调
	 */

	handleOpenChange = (openKeys) => {
		//过滤掉无效opnekey，如:"/"
		const moreThanOne = openKeys.filter((openKey) => this.isMainMenu(openKey)).length > 1;
		this.setState({
			openKeys: moreThanOne ? [openKeys.pop()] : [...openKeys]
		});
	};

	/*
	 * 渲染菜单项
	 */
	getMenuItems = (menuData) => {
		if (Array.isArray(menuData) && menuData.length > 0) {
			return menuData.map((item) => {
				const { menuName } = item;
				if (item.isEnable) {
					if (item[system] && item[system].length > 0) {
						return (
							<Menu.SubMenu
								key={item.menuId}
								title={
									item.menuIcon ? (
										<span>
											{getIcon(item.menuIcon)}
											<span>{menuName}</span>
										</span>
									) : item.menuLevel === 1 ? (
										<span>
											{getIcon("icon-image")}
											<span>{menuName}</span>
										</span>
									) : (
										menuName
									)
								}
							>
								{this.getMenuItems(item[system])}
							</Menu.SubMenu>
						);
					} else {
						const linkProps = {};
						if (/^(https|http)?:\/\//.test(item.menuAction)) {
							if (item.newWindow) {
								linkProps.target = "_blank";
							}
							linkProps.href = item.menuAction;
							return (
								<Menu.Item key={item.menuId}>
									{item.menuIcon ? (
										<a {...linkProps}>
											{getIcon(item.menuIcon)}
											<span>{item.menuName}</span>
										</a>
									) : item.menuLevel === 1 ? (
										<a {...linkProps}>
											{getIcon("icon-image")}
											<span>{item.menuName}</span>
										</a>
									) : (
										<a {...linkProps}>{item.menuName}</a>
									)}
								</Menu.Item>
							);
						}
						linkProps.to = item.menuAction || " ";
						return (
							<Menu.Item key={item.menuId}>
								{item.menuIcon ? (
									<Link {...linkProps}>
										{getIcon(item.menuIcon)}
										<span>{item.menuName}</span>
									</Link>
								) : item.menuLevel === 1 ? (
									<Link {...linkProps}>
										{getIcon("icon-image")}
										<span>{item.menuName}</span>
									</Link>
								) : (
									<Link {...linkProps}>{item.menuName}</Link>
								)}
							</Menu.Item>
						);
					}
				} else {
					return null;
				}
			});
		} else {
			return null;
		}
	};

	componentDidMount() {
		//初始化菜单数据
		const { getMenuData } = this.props;
		getMenuData();
	}

	render() {
		const {
			collapsed,
			menuList,
			location,
			settings: { navTheme, layout }
		} = this.props;
		const { openKeys } = this.state;
		const selectKeys = this.getSelectKeys(location.pathname);
		let defaultProps = {};
		if (!collapsed && layout === 'sidemenu') {
			defaultProps = {
				openKeys: openKeys.length === 0 ? selectKeys : openKeys
			};
		}
		if (layout === 'topmenu') {
			defaultProps = {
				...defaultProps,
				getPopupContainer:(triggerNode) => triggerNode.parentElement
			}
		}
		return (
			<Menu
				theme={navTheme}
				mode={this.props.mode}
				selectedKeys={selectKeys}
				onOpenChange={this.handleOpenChange}
				{...defaultProps}
				style={this.props.style}
				className={this.props.className}
			>
				{this.getMenuItems(menuList)}
			</Menu>
		);
	}
}

export default BaseMenu;
