import React, { PureComponent } from "react";
import { Link } from "react-router-dom";
import styles from "./Logo.less";
import dxp from "./logo.png";
import cs from "classnames";
import { connect } from "react-redux";

const mapStateToProps = (state) => ({
	settings: state.setting.settings
});

@connect(mapStateToProps)
class Logo extends PureComponent {
	render() {
		const { navTheme } = this.props.settings;
		return (
			<div className={cs(styles.sklLogo, navTheme === "dark" ? styles.dark : styles.light)}>
				<Link to="/home">
					<img src={dxp} alt="logo" />
					<h1 className={navTheme === "dark" ? styles.dark : styles.light}>数据交换平台</h1>
				</Link>
			</div>
		);
	}
}

export default Logo;
