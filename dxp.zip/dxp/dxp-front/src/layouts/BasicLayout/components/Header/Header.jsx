import React, { PureComponent } from "react";
import { Layout, Menu, Icon, Avatar, message, Modal, Dropdown, Tooltip } from "antd";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import cs from "classnames";
import { Link } from "react-router-dom";
import CustomForm from "@/components/CustomForm";
import { operateOneParam, modifyPassword, logout } from "@/api/conversion";
import styles from "./Header.less";
import dxp from "../Logo/logo.png";
import BaseMenu from "../BaseMenu";

const mapStateToProps = (state) => ({
	collapsed: state.collaps.collapsed,
	settings: state.setting.settings
});

const mapDispatchToProps = (dispatch) => ({
	toggleCollaps: (status) => dispatch.collaps.toggleCollaps(status)
});

@withRouter
@connect(
	mapStateToProps,
	mapDispatchToProps
)
class HeaderView extends PureComponent {
	state = {
		//默认展开项
		openKeys: [],
		confirmDirty: false,
		visible: false,
		isRole: true,
		config: [
			{
				component: "Input",
				id: "oldPassWord",
				label: "输入原密码:",
				colSpan: 24,
				config: {
					initialValue: "",
					rules: [{ required: true, message: "原密码不能为空" }]
				},
				componentProps: {
					placeholder: "请输入登录密码",
					type: "password"
				}
			},
			{
				component: "Input",
				id: "newPassWord",
				label: "输入新密码:",
				colSpan: 24,
				config: {
					initialValue: "",
					rules: [{ required: true, message: "新密码不能为空" }]
				},
				componentProps: {
					placeholder: "请输入新登录密码",
					type: "password"
				}
			},
			{
				component: "Input",
				id: "newPassWordOne",
				label: "再次输入新密码:",
				colSpan: 24,
				config: {
					initialValue: "",
					rules: [
						{ required: true, message: "新密码不能为空" },
						{
							validator: (rule, value, callback) => {
								const { form } = this.formRef.props;
								if (value && value !== form.getFieldValue("newPassWord")) {
									callback("两次输入的密码不一致");
								} else {
									callback();
								}
							}
						}
					]
				},
				componentProps: {
					placeholder: "请输入新登录密码",
					type: "password"
				}
			}
		]
	};
	/*收起，展示侧边栏*/
	toggle = (status) => {
		this.props.toggleCollaps(!status);
	};

	/*跳转指定路由*/
	handleExitClick = async () => {
		let params;
		if (process.env.FRAME_WORK === "moon") {
			params = {
				access_token: localStorage.getItem("moonToken")
			};
		}
		const res = await logout(params);
		if (res.success) {
			if (process.env.FRAME_WORK === "moon") {
				localStorage.removeItem("moonToken");
			}
			sessionStorage.clear();
			this.props.history.push("/login");
			message.success("退出登录成功", 2);
		}
	};

	handleColorChange = (color) => {
		window.less
			.modifyVars({
				"@primary-color": color
			})
			.then(() => {})
			.catch(() => {
				message.error("切换失败");
			});
	};

	/*
	 * 修改密码弹框取消
	 * */
	handleCancel = () => {
		this.setState({
			visible: false
		});
	};

	/*
	 * 修改密码弹框确定
	 * @param method oldPasswd passwd id
	 * */
	handleSubmit = () => {
		this.formRef.props.form.validateFields(async (err, values) => {
			if (!err) {
				const params = {
					oldPasswd: values.oldPassWord,
					passwd: values.newPassWord
				};
				const res = await modifyPassword(params);
				if (res.success) {
					message.success("密码修改成功");
					this.setState({
						visible: false
					});
				}
			}
		});
	};

	saveFormRef = (ref) => {
		this.formRef = ref;
	};

	/*
	 * 修改密码
	 * @param paramType
	 * */
	modifyPassword = async () => {
		this.setState({
			visible: true
		});
		let regular;
		if (process.env.FRAME_WORK === 'fap') {
			regular = {
				passwordRex:"password.regex",
				passwordMsg: "password.regex.msg"
			}
		} else if (process.env.FRAME_WORK === 'moon') {
			regular = {
				passwordRex:"user.password.regex",
				passwordMsg: "user.password.regex.msg"
			}
		}
		const res = await operateOneParam({}, regular.passwordRex, "GET");
		if (res.success) {
			const { config } = this.state;
			const obj = {};
			obj["pattern"] = res.result.paramVal;
			const resResult = await operateOneParam({}, regular.passwordMsg, "GET");
			obj["message"] = resResult.result.paramVal;
			config[1].config.rules.unshift(obj);
			this.setState({
				config: [...config]
			});
		}
	};

	isRole = async () => {
		const resultMode = await operateOneParam({}, "user.bind.auth.mode");
		const resultType = await operateOneParam({}, "user.bind.role.type");
		const resultActive = await operateOneParam({}, "position.manager.active");
		if (resultMode.success && resultType.success && resultActive.success) {
			resultMode.result.paramVal === "mixed" &&
			resultType.result.paramVal === "position" &&
			resultActive.result.paramVal === "true"
				? this.setState({
					isRole: false
				})
				: this.setState({
					isRole: true
				});
		}
	}

	componentDidMount() {
		const { primaryColor } = this.props.settings;
		this.handleColorChange(primaryColor);
		this.isRole();
	}

	render() {
		const { fixedHeader, layout, navTheme } = this.props.settings;
		const { collapsed } = this.props;
		const { config, visible, isRole } = this.state;
		const loginInfo = sessionStorage.getItem("lunaLoginInfo")
			? JSON.parse(sessionStorage.getItem("lunaLoginInfo"))
			: {};
		const formItemLayout = {
			labelCol: {
				xs: { span: 24 },
				sm: { span: 6 }
			},
			wrapperCol: {
				xs: { span: 24 },
				sm: { span: 18 }
			}
		};
		return layout === "sidemenu" ? (
			<Layout.Header
				id="sklNavSide"
				className={cs(
					styles.sklHeader,
					styles.light,
					fixedHeader ? styles.fixHeader : "",
					collapsed && fixedHeader ? styles.sklCollapse : ""
				)}
			>
				<span
					className={styles.sklHeaderCollapsed}
					onClick={() => {
						this.toggle(collapsed);
					}}
				>
					<Icon className="trigger" type={collapsed ? "menu-unfold" : "menu-fold"} />
				</span>
				<div className={styles.sklHeaderNav}>
					{sessionStorage.getItem("lunaUserId") ? (
						<Dropdown
							getPopupContainer={() => document.getElementById("sklNavSide")}
							overlay={
								<Menu style={{ marginTop: "20px", overflow: "hidden", maxWidth: "208px" }}>
									<Menu.Item key="setting:5" onClick={this.modifyPassword}>
										<div style={{ display: "flex", justifyContent: "space-between" }}>
											<span style={{ paddingRight: "8px" }}>个人信息</span>
											<a
												title="修改密码"
												dangerouslySetInnerHTML={{ __html: "密码修改" }}
											/>
										</div>
									</Menu.Item>
									<Menu.Item key="setting:1"  style={{ display: "flex" }}>
										<span>用户：</span>
										<span style={{
											overflow: "hidden",
											textOverflow: "ellipsis"
										}}><Tooltip
											placement="topLeft"
											title={loginInfo.name}
										>
												<span>
													{loginInfo.name}
												</span>
											</Tooltip></span>
									</Menu.Item>
									<Menu.Item key="setting:2">
										<span>柜员号：</span> {loginInfo.code}
									</Menu.Item>
									<Menu.Item key="setting:3" style={{ display: "flex" }}>
										<span>机构：</span>
										<span
											style={{
												overflow: "hidden",
												textOverflow: "ellipsis"
											}}
										>
											<Tooltip
												placement="topLeft"
												title={
													loginInfo.organization
														? loginInfo.organization.orgName
														: ""
												}
											>
												<span>
													{loginInfo.organization
														? loginInfo.organization.orgName
														: ""}
												</span>
											</Tooltip>
										</span>
									</Menu.Item>
									<Menu.Item key="setting:4" style={{ display: "flex" }}>
										{isRole ? <span>角色：</span> : <span>岗位：</span>}
										<div>
											{loginInfo.roleList.length
												? loginInfo.roleList.map((item) => {
													return <div key={item.roleId}>{item.roleName}</div>;
												})
												: null}
										</div>
									</Menu.Item>
								</Menu>
							}
						>
							<span className={styles.sklHeaderUser}>
								<Avatar style={{ backgroundColor: "#87d068" }} icon="user" />
								<span className={styles.userName}>{loginInfo ? loginInfo.name : null}</span>
							</span>
						</Dropdown>
					) : (
						""
					)}
					<span className={styles.logout} onClick={this.handleExitClick}>
						<Icon
							type="logout"
							style={{
								fontSize: "18px",
								verticalAlign: "middle"
							}}
						/>
						<span>退出</span>
					</span>
				</div>
				<Modal
					visible={visible}
					title="修改密码"
					onCancel={this.handleCancel}
					onOk={this.handleSubmit}
					afterClose={() => {
						if (this.formRef) {
							this.formRef.props.form.resetFields();
						}
					}}
				>
					<CustomForm
						config={config}
						showBtn={false}
						wrappedComponentRef={this.saveFormRef}
						formItemLayout={formItemLayout}
					/>
				</Modal>
			</Layout.Header>
		) : (
			<Layout.Header
				id="sklNav"
				className={cs(
					styles.sklTopMenu,
					fixedHeader ? styles.fixHeader : "",
					navTheme === "dark" ? styles.dark : styles.light
				)}
			>
				<div className={styles.sklHeaderLeft}>
					<div style={{ width: "150px" }}>
						<Link to="/home">
							<img src={dxp} alt="logo" />
							<h1 className={navTheme === "dark" ? styles.dark : styles.light}>数据交换平台</h1>
						</Link>
					</div>
					<BaseMenu
						mode="horizontal"
						className={styles.sklMenuHeight}
						style={{ lineHeight: "64px", marginLeft: "20px", maxWidth: "660px" }}
					/>
				</div>
				<div className={styles.sklHeaderNav}>
					{sessionStorage.getItem("lunaUserId") ? (
						<Dropdown
							getPopupContainer={() => document.getElementById("sklNav")}
							overlay={
								<Menu style={{ marginTop: "20px", overflow: "hidden", maxWidth: "208px" }}>
									<Menu.Item key="setting:5" onClick={this.modifyPassword}>
										<div style={{ display: "flex", justifyContent: "space-between" }}>
											<span style={{ paddingRight: "8px" }}>个人信息</span>
											<a
												title="修改密码"
												dangerouslySetInnerHTML={{ __html: "密码修改" }}
											/>
										</div>
									</Menu.Item>
									<Menu.Item key="setting:1"  style={{ display: "flex" }}>
										<span>用户：</span>
										<span style={{
											overflow: "hidden",
											textOverflow: "ellipsis"
										}}><Tooltip
											placement="topLeft"
											title={loginInfo.name}
										>
												<span>
													{loginInfo.name}
												</span>
											</Tooltip></span>
									</Menu.Item>
									<Menu.Item key="setting:2">
										<span>柜员号：</span> {loginInfo.code}
									</Menu.Item>
									<Menu.Item key="setting:3" style={{ display: "flex" }}>
										<span>机构：</span>
										<span
											style={{
												overflow: "hidden",
												textOverflow: "ellipsis"
											}}
										>
											<Tooltip
												placement="topLeft"
												title={
													loginInfo.organization
														? loginInfo.organization.orgName
														: ""
												}
											>
												<span>
													{loginInfo.organization
														? loginInfo.organization.orgName
														: ""}
												</span>
											</Tooltip>
										</span>
									</Menu.Item>
									<Menu.Item key="setting:4" style={{ display: "flex" }}>
										{isRole ? <span>角色：</span> : <span>岗位：</span>}
										<div>
											{loginInfo.roleList.length
												? loginInfo.roleList.map((item) => {
													return <div key={item.roleId}>{item.roleName}</div>;
												})
												: null}
										</div>
									</Menu.Item>
								</Menu>
							}
						>
							<span className={styles.sklHeaderUser}>
								<Avatar style={{ backgroundColor: "#87d068" }} icon="user" />
								<span className={styles.userName}>{loginInfo ? loginInfo.name : null}</span>
							</span>
						</Dropdown>
					) : (
						""
					)}
					<span className={styles.logout} onClick={this.handleExitClick}>
						<Icon
							type="logout"
							style={{
								fontSize: "18px",
								verticalAlign: "middle"
							}}
						/>
						<span>退出</span>
					</span>
				</div>
				<Modal title="修改密码" onCancel={this.handleCancel} onOk={this.handleSubmit} visible={visible} afterClose={() => {
					if (this.formRef) {
						this.formRef.props.form.resetFields();
					}
				}}>
					<CustomForm
						config={config}
						showBtn={false}
						wrappedComponentRef={this.saveFormRef}
						formItemLayout={formItemLayout}
					/>
				</Modal>
			</Layout.Header>
		);
	}
}
export default HeaderView;
