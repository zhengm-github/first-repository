import React, { Component, Suspense } from "react";
import { lazy } from "react";
import { Switch, Redirect } from "react-router-dom";

import AuthRouter from "@/components/AuthRouter";
import NotFound from "@/components/NotFound";
import PageLoading from "@/components/PageLoading";
import routerData from "@/routerconfig";

//首页
const Home = lazy(() => import("@/pages/Home"));
class MainRoutes extends Component {
	/**
	 * 渲染路由组件
	 */
	renderNormalRoute = (item, index) => {
		return item.component ? (
			<AuthRouter
				key={index}
				path={item.path}
				component={item.component}
				exact={item.exact}
				authCode={item.authCode}
			/>
		) : null;
	};

	filterRouter = () => {
		const loginInfo = JSON.parse(sessionStorage.getItem("lunaLoginInfo"));
		let hasRouterData = [];
		if (loginInfo) {
			if (loginInfo.code === "admin") {
				hasRouterData = routerData;
			} else {
				hasRouterData = routerData.filter((item) => {
					return loginInfo.authCodeInfoList.some((items) => items.code === item.authCode);
				});
			}
		} else {
			hasRouterData = routerData;
		}
		return hasRouterData
	}

	render() {
		const hasRouterData = this.filterRouter();
		return (
			<Suspense fallback={<PageLoading />}>
				<Switch>
					{/*渲染路由表*/}
					{hasRouterData.map(this.renderNormalRoute)}

					{/*根路由默认重定向到 /login*/}
					<Redirect from="/" exact to="/login" />
					<AuthRouter exact path={"/home"} component={Home} />
					{/*未匹配到的路由重定向到 NotFound*/}
					<AuthRouter component={NotFound} />
				</Switch>
			</Suspense>
		);
	}
}

export default MainRoutes;
