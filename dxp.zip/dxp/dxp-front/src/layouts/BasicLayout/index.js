import React, { PureComponent } from "react";
import { Layout } from "antd";
import cs from "classnames";
import { connect } from "react-redux";
import MainRoutes from "./MainRoutes";
import Header from "./components/Header";
import Aside from "./components/Aside";
/*import Footer from "./components/Footer";*/
import DrawerContent from "./components/DrawerContent";
import styles from "./index.less";

const { Content } = Layout;

const mapStateToProps = (state) => ({
	collapsed: state.collaps.collapsed,
	settings: state.setting.settings
});

@connect(mapStateToProps)
class BasicLayout extends PureComponent {
	render() {
		const { fixedHeader, fixSiderbar, layout } = this.props.settings;
		const { collapsed } = this.props;
		return (
			<Layout className={styles.sklLayout}>
				{layout === "sidemenu" ? <Aside /> : ""}
				<Layout
					className={cs(
						styles.sklLayoutRight,
						collapsed && fixSiderbar && layout === "sidemenu" ? styles.sklFixLayout : "",
						!collapsed && fixSiderbar && layout === "sidemenu" ? styles.sklCollapsedLayout : ""
					)}
				>
					<Header />
					<Content
						className={cs({ [styles.sklLayoutContent]: true, [styles.fixHeader]: fixedHeader })}
					>
						<MainRoutes />
						<DrawerContent />
					</Content>
					{/*	<Footer />*/}
				</Layout>
			</Layout>
		);
	}
}

export default BasicLayout;
