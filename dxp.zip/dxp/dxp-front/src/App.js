import React, { lazy, Suspense } from "react";
import { HashRouter, Switch, Route } from "react-router-dom";
import { withRouter } from "react-router";
import PageLoading from "./components/PageLoading";
import { ConfigProvider } from "antd";
import zhCN from "antd/es/locale/zh_CN";
import moment from "moment";
import "moment/locale/zh-cn";
moment.locale("en");

/*异步加载分包*/
const BasicLayout = lazy(() => import("./layouts/BasicLayout"));
const UserLogin = lazy(() => import("./pages/Login"));

const App = () => (
	<ConfigProvider locale={zhCN}>
		<HashRouter>
			<Suspense fallback={<PageLoading />}>
				<Switch>
					<Route path="/login" exact component={withRouter(UserLogin)} />
					<Route path="/" component={withRouter(BasicLayout)} />
				</Switch>
			</Suspense>
		</HashRouter>
	</ConfigProvider>
);

export default App;
