//功能列表  删除
import Mock from "mockjs";




Mock.mock(RegExp("/deleteTree.*"),{
	"result": null,
	"success": true,
	"error": "0000",
	"message": "测试---删除失败"
});
