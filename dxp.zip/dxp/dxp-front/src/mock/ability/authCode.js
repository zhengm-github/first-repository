//功能列表  权限列表
import Mock from "mockjs";




Mock.mock("/authCodes/all",{
	"result":  [
		{
			"authCodeId": "@id",
			"code": "BIZLOG_MANAGER",
			"authType": "type.system",
			"authName": "权限",
			"authDesc": "权限",
			"isScope": false,
			"belongtosys": "Luna",
			"isGeneral": false,
			"maskCode": "xrwa",
			"disabled": false,
			"children": [
				{
					"authCodeId": "@id",
					"code": "BIZLOG_MANAGER",
					"authType": "type.system",
					"authName": "数字客户管理系统模块",
					"authDesc": "数字客户管理系统模块",
					"isScope": false,
					"belongtosys": "Luna",
					"isGeneral": false,
					"maskCode": "xrwa",
					"disabled": false,
					"children": [
						{
							"authCodeId": "@id",
							"code": "BIZLOG_MANAGER",
							"authType": "type.system",
							"authName": "标签分类体系上传",
							"authDesc": "标签分类体系上传",
							"isScope": false,
							"belongtosys": "Luna",
							"isGeneral": false,
							"maskCode": "xrwa",
							"disabled": false,
						},
						{
							"authCodeId": "@id",
							"code": "BIZLOG_MANAGER",
							"authType": "type.system",
							"authName": "配置标签参数",
							"authDesc": "配置标签参数",
							"isScope": false,
							"belongtosys": "Luna",
							"isGeneral": false,
							"maskCode": "xrwa",
							"disabled": false,
						},
						{
							"authCodeId": "@id",
							"code": "BIZLOG_MANAGER",
							"authType": "type.system",
							"authName": "删除标签名和标签值",
							"authDesc": "删除标签名和标签值",
							"isScope": false,
							"belongtosys": "Luna",
							"isGeneral": false,
							"maskCode": "xrwa",
							"disabled": false,
						},
						{
							"authCodeId": "@id",
							"code": "BIZLOG_MANAGER",
							"authType": "type.system",
							"authName": "查询标签名和覆盖数",
							"authDesc": "查询标签名和覆盖数",
							"isScope": false,
							"belongtosys": "Luna",
							"isGeneral": false,
							"maskCode": "xrwa",
							"disabled": false,
						},
						{
							"authCodeId": "@id",
							"code": "BIZLOG_MANAGER",
							"authType": "type.system",
							"authName": "编剧群组",
							"authDesc": "编剧群组",
							"isScope": false,
							"belongtosys": "Luna",
							"isGeneral": false,
							"maskCode": "xrwa",
							"disabled": false,
						},
						{
							"authCodeId": "@id",
							"code": "BIZLOG_MANAGER",
							"authType": "type.system",
							"authName": "分析维度列表",
							"authDesc": "分析维度列表",
							"isScope": false,
							"belongtosys": "Luna",
							"isGeneral": false,
							"maskCode": "xrwa",
							"disabled": false,
						},
					]
				}
			]
		}
	],
	"success": true
});
