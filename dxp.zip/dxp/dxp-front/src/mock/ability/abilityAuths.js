//功能列表  权限功能
import Mock from "mockjs";




Mock.mock(RegExp("/functions/auths.*"),{
	"result": null,
	"success|1":[ true, false ],
	"error": "0000",
	"message": "测试---权限配置失败"
});
