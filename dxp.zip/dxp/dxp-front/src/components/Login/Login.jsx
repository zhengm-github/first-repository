import React, { PureComponent } from "react";
import { Input, Button, Form, message, Checkbox } from "antd";
import { getLoginInfo, login } from "@/api/conversion";
import styles from "./Login.less";
import PropTypes from "prop-types";
import logo from "./logo.png";

const formItemLayout = {
	labelCol: {
		span: 5
	},
	wrapperCol: {
		span: 19
	},
};
@Form.create()
class Login extends PureComponent {
  state = {
    config: [
      {
        id: "username",
		  label: "账 号",
        config: [
          {
            initialValue: "",
            rules: [{ required: true, message: "账号不能为空", whitespace: true }]
          }
        ],
        props: {
          placeholder: "请输入账号"
        }
      },
      {
        id: "password",
        config: [
          {
            initialValue: "",
            rules: [{ required: true, message: "密码不能为空", whitespace: true }]
          }
        ],
		  label: "密 码",
        props: {
          placeholder: "请输入密码",
          type: "password"
        }
      }
    ],
    loading: false
  };

  /*
   * 登录按钮
   * @param loginName password
   **/

  submit = (e) => {
    e.preventDefault();
    this.props.form.validateFields(async (err, values) => {
      if (!err) {
        values.remember ? localStorage.setItem("username", values.username) : localStorage.setItem("username", "");
        const params = {
          loginName: values.username ? values.username.trim() : values.username,
          password: values.password ? values.password.trim() : values.password
        };
        try {
          this.setState({
            loading: true
          });
          const res = await login(params);
          this.setState({
            loading: false
          });
          if (res.success) {
            if (process.env.FRAME_WORK === "moon") {
              localStorage.setItem("moonToken", res.access_token);
              const resResult = await getLoginInfo();
              if (resResult.success) {
                message.success("登录成功");
                sessionStorage.setItem("lunaUserId", resResult.result.userId);
                resResult.result.roleList = resResult.result.roles;
                resResult.result.authCodeInfoList = resResult.result.authorities;
                sessionStorage.setItem("lunaLoginInfo", JSON.stringify(resResult.result));
              }
            } else {
              message.success("登录成功");
              sessionStorage.setItem("lunaUserId", res.result.userId);
              sessionStorage.setItem("lunaLoginInfo", JSON.stringify(res.result));
            }
            this.props.onSuccess();
          }
        } catch {
          this.setState({
            loading: false
          });
        }
      }
    });
  };

  componentDidMount() {
    const strName = localStorage.getItem("username");
    if (strName) {
      this.setState({
        config: [
          {
            id: "username",
			  label: "账 号",
            config: [
              {
                initialValue: strName,
                rules: [{ required: true, message: "账号不能为空", whitespace: true }]
              }
            ],
            props: {
              placeholder: "请输入账号"
            }
          },
          {
			  id: "password",
			  label: "密 码",
            config: [
              {
                initialValue: "",
                rules: [{ required: true, message: "密码不能为空", whitespace: true }]
              }
            ],
            props: {
              placeholder: "请输入密码",
				type: "password",
            }
          }
        ]
      });
    }
  }

  render() {
    const { config, loading } = this.state;
    // const { logo, title } = this.props;
    const { getFieldDecorator } = this.props.form;
    return (
        <div className={styles.sklLoginContainer}>
          <div className={styles.sklTitle}>
            <img src={logo} alt="logo"/>
            <span>数据交换平台</span>
          </div>
          <Form onSubmit={this.submit}  {...formItemLayout}>
            {config.map((item) => {
              return (
				  <Form.Item key={item.id} label={item.label} labelAlign='left'>
                    {getFieldDecorator(item.id, ...item.config)(<Input {...item.props} />)}
                  </Form.Item>
              );
            })}
            <Form.Item key="remember">
              {getFieldDecorator("remember", {
                valuePropName: "checked",
                initialValue: true
              })(<Checkbox>记住账号</Checkbox>)}
            </Form.Item>
            <Button type="primary" htmlType="submit" style={{ width: "100%" }} loading={loading}>
              登录
            </Button>
          </Form>
        </div>
    );
  }
}


Login.propTypes = {
  onSuccess: PropTypes.func.isRequired
};
Login.defaultProps = {
  onSuccess: () => {
  }
};
export default Login;

