import React from 'react';
import { Spin } from 'antd';

/*
*组件加载指示器
 */
export default () => (
    <div style={{ paddingTop: 100, textAlign: 'center' }}>
        <Spin size="large" />
    </div>
);