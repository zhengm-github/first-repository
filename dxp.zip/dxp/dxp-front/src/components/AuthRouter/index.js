import AuthRouter from "./AuthRouter";

export default AuthRouter;