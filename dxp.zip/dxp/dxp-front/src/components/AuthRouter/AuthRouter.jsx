import { Redirect, Route } from "react-router-dom";
import React from "react";

const AuthRouter = ({ component: Component, noMatch = "/login", ...otherProps }) => {
	const isLogin = sessionStorage.getItem("lunaUserId");
	return (
		<Route
			{...otherProps}
			render={(props) => {
				return isLogin ? <Component {...props} /> : <Redirect to={noMatch} />;
			}}
		/>
	);
};
export default AuthRouter;
