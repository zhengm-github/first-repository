import ReactDOM from "react-dom";
let flag = true;
class CustomModal {
	//限制只弹窗一次
	show = (component) => {
		if (flag) {
			window.modalDiv = document.createElement("div");
			ReactDOM.render(component, window.modalDiv);
			flag = false;
		}
	};

	destroy = () => {
		ReactDOM.unmountComponentAtNode(window.modalDiv);
		window.modalDiv = null;
		flag = true;
	};
}

export default CustomModal;
