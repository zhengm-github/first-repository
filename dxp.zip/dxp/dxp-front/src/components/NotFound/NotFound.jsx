import React from "react";
import styles from "./NotFound.less";

//无状态组件
export default () => {
	return (
		<div className={styles.exceptionContent}>
			<img
				src={require("./images/404.jpg")}
				className={styles.imgException}
				alt="页面不存在"
			/>
			<div>
				<h3 className={styles.title}>抱歉，你访问的页面不存在</h3>
				<p className={styles.description}>
					您要找的页面没有找到，请返回
					<a href="#/home">首页</a>
					继续浏览
				</p>
			</div>
		</div>
	);
};
