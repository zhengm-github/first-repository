import { Col, Row, Form, Input, Radio, Select, TreeSelect, Checkbox, Button, DatePicker, Switch } from "antd";
import React from "react";
import styles from "./CustomForm.less";
import PropTypes from "prop-types";

const { RangePicker } = DatePicker;

class CustomForm extends React.Component {

	//提交
	handleSubmit = (e) => {
		const { validateFields } = this.props.form;
		e.preventDefault();
		validateFields((errors, values) => {
			this.props.submit(errors, values);
		});
	};

	//重置
	handleReset = (e) => {
		const { resetFields } = this.props.form;
		e.preventDefault();
		resetFields();
		this.props.reset();
	};

	//input输入框
	renderInput = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 12} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<Input placeholder="请输入" {...item.componentProps} />
					)}
				</Form.Item>
			</Col>
		);
	};

	//单选框
	renderRadio = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 12} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<Radio.Group {...item.componentProps}>
							{item.options.map((option) => (
								<Radio
									key={option.value}
									value={option.value}
									disabled={option.disable ? true : false}
								>
									{option.text}
								</Radio>
							))}
						</Radio.Group>
					)}
				</Form.Item>
			</Col>
		);
	};

	//下拉选择
	renderSelect = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 12} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<Select placeholder="请选择" {...item.componentProps}>
							{item.options}
						</Select>
					)}
				</Form.Item>
			</Col>
		);
	};

	//多选
	renderCheckBox = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 12} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<Checkbox.Group {...item.componentProps}>
							{item.options.map((option) => (
								<Checkbox key={option.value} value={option.value}>
									{option.text}
								</Checkbox>
							))}
						</Checkbox.Group>
					)}
				</Form.Item>
			</Col>
		);
	};

	//文本域
	renderTextArea = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 24} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<Input.TextArea {...item.componentProps} />
					)}
				</Form.Item>
			</Col>
		);
	};

	// 树选择
	renderTreeSelect = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 24} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						item.async ? (
							<TreeSelect
								loadData={this.onLoadData}
								dropdownStyle={{
									maxHeight: 300,
									overflow: "auto"
								}}
								{...item.componentProps}
							>
								{this.renderTreeNodes(item.treeData)}
							</TreeSelect>
						) : (
								<TreeSelect
									dropdownStyle={{
										maxHeight: 300,
										overflow: "auto"
									}}
									{...item.componentProps}
									treeData={item.treeData}
								/>
							)
					)}
				</Form.Item>
			</Col>
		);
	};

	onLoadData = (treeNode) =>
		new Promise(async (resolve) => {
			await this.props.onLoadData(treeNode);
			resolve();
		});

	renderTreeNodes = (data) =>
		data.map((item) => {
			if (item.children) {
				return (
					<TreeSelect.TreeNode {...item} dataRef={item}>
						{this.renderTreeNodes(item.children)}
					</TreeSelect.TreeNode>
				);
			}
			return <TreeSelect.TreeNode {...item} dataRef={item} />;
		});

	// 日期选择器
	renderDatePicker = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 24} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<DatePicker {...item.componentProps} />
					)}
				</Form.Item>
			</Col>
		);
	};

	// 日期范围选择器
	renderRangePicker = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 24} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<RangePicker {...item.componentProps} />
					)}
				</Form.Item>
			</Col>
		);
	};

	//渲染switch
	renderSwitch = (item) => {
		const { getFieldDecorator } = this.props.form;
		return (
			<Col span={item.colSpan ? item.colSpan : 24} key={item.id}>
				<Form.Item label={item.label}>
					{getFieldDecorator(item.id, item.config ? item.config : {})(
						<Switch {...item.componentProps} />
					)}
				</Form.Item>
			</Col>
		);
	}
	//根据类型加载不同的输入框
	renderFromItem = (formConfig) => {
		return formConfig.map((item) => {
			if (item.component === "Input") {
				return this.renderInput(item);
			}
			if (item.component === "Checkbox") {
				return this.renderCheckBox(item);
			}
			if (item.component === "Select") {
				return this.renderSelect(item);
			}
			if (item.component === "Radio") {
				return this.renderRadio(item);
			}
			if (item.component === "TextArea") {
				return this.renderTextArea(item);
			}
			if (item.component === "TreeSelect") {
				return this.renderTreeSelect(item);
			}
			if (item.component === "DatePicker") {
				return this.renderDatePicker(item);
			}
			if (item.component === "RangePicker") {
				return this.renderRangePicker(item);
			} if (item.component === "Switch") {
				return this.renderSwitch(item);
			}
			return null;
		});
	};

	render() {
		const { showBtn, config, extraContent, formItemLayout } = this.props;
		return (
			<Form className={styles.customForm} {...formItemLayout}>
				<Row gutter={16}>
					{this.renderFromItem(config)}
					{showBtn ? (
						<Col span={8} className={styles.btnGroup}>
							<Button
								type="primary"
								htmlType="submit"
								className={styles.btnSubmit}
								onClick={this.handleSubmit}
							>
								查询
							</Button>
							<Button htmlType="reset" onClick={this.handleReset}>
								重置
							</Button>
						</Col>
					) : null}
					{extraContent}
				</Row>
			</Form>
		);
	}
}

CustomForm.propTypes = {
	config: PropTypes.array.isRequired,
	submit: PropTypes.func,
	reset: PropTypes.func,
	extraContent: PropTypes.element,
	showBtn: PropTypes.bool
};

CustomForm.defaultProps = {
	extraContent: null,
	reset: () => { },
	submit: () => { },
	showBtn: true,
	config: []
};

export default Form.create()(CustomForm);
