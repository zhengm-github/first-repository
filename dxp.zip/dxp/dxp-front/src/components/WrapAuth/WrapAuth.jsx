import { Component } from "react";

const wrapAuth = (authCode, authType) =>
	class extends Component {
		render() {
			const loginInfo = JSON.parse(sessionStorage.getItem("lunaLoginInfo"));
			const { children } = this.props;
			if (loginInfo.code === 'admin') {
				return children;
			}
			const arr = loginInfo.authCodeInfoList.filter((item) => item.code === authCode);
			if (arr.length) {
				return arr[0].isGeneral || arr[0].general ? (arr[0].maskCode === "----" || arr[0].maskCode.indexOf(authType) > -1 ? children : null) : children;
			}
			return null;
		}
	}
export default wrapAuth;