import WrapAuth from "./WrapAuth";

export default WrapAuth;