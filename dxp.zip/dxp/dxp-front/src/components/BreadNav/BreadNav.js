import { Breadcrumb } from "antd";
import React from "react";
import { Link } from "react-router-dom";
import styles from "./BreadNav.less";
import PropTypes from "prop-types";

const BreadNav = (props) => {
	const { navs } = props;
	return (
		<Breadcrumb {...props} className={styles.breadcrumb}>
			<Breadcrumb.Item>
				<Link to="/home">首页</Link>
			</Breadcrumb.Item>
			{navs.map((item, index) => {
				return (
					<Breadcrumb.Item key={index}>
						{item.path ? <Link to={item.path}>{item.name}</Link> : <span>{item.name}</span>}
					</Breadcrumb.Item>
				);
			})}
		</Breadcrumb>
	);
};
BreadNav.propTypes = {
	navs: PropTypes.array.isRequired
};

BreadNav.defaultProps = {
	navs: []
};
export default BreadNav;
