import { Icon } from "antd";

const SklIcon = Icon.createFromIconfontCN({
	scriptUrl: "iconfont.js" // 在 iconfont.cn 上生成
});

export default SklIcon;
