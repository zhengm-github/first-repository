import SetRequestResponse from "./SetRequestResponse";

export default SetRequestResponse;