import React, { PureComponent } from "react";
import { Modal } from "antd";
import ManageTable from "./components/ManageTable";
import PlanManage from "./components/PlanManage";
import { getMessagesById, getPlanDetailById, getRulesListById } from "@/api/dxp";

class SetRequestResponse extends PureComponent {
	state = {
		step: "attribute",
		loading: false,
		planLoading: false,
		isEditing: false,
		modifyingId: "",
		expandedRowKeys: [],
		planDetail: {},
		dataSource: []
	};

	// 递归删除空的子节点
	deleteEmpty = (result) => {
		const { step } = this.state;
		const child = step === "attribute" ? "childProperties" : "childRules";
		for (let val of result) {
			if (val[child] && val[child].length === 0) {
				delete val[child];
				continue;
			} else if (val[child] && val[child].length) {
				this.deleteEmpty(val[child]);
			}
		}
	};

	// 添加同级结果/子结果
	addChild = (id) => {
		const { step, dataSource, expandedRowKeys, planDetail } = this.state;
		const { svcBundleId, messageType, serviceType } = this.props;

		let newItem;
		if (step === "attribute") {
			newItem = {
				dataPropertyId: Date.now(),
				parentId: id,
				name: "",
				memo: "",
				optional: undefined,
				dataType: undefined,
				signObj: undefined,
				ord: "",
				exp: "",
				isAdd: true
			};
			if (serviceType === "in") {
				newItem.inSvcBundleId = svcBundleId;
			} else {
				newItem.outSvcBundleId = svcBundleId;
			}
		} else {
			newItem = {
				procotolResolveRuleId: Date.now(),
				procotolResolvePlanId: planDetail.procotolResolvePlanId,
				parentId: id,
				name: "",
				detailName: "",
				memo: "",
				separatorChar: "",
				beginIndex: "",
				endIndex: "",
				lineNum: "",
				ruleType: "",
				dataKind: messageType === "req" ? "REQ" : "RSP",
				isAdd: true
			};
		}

		const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";

		if (!id) {
			const data = [...dataSource, newItem];
			this.setState({ dataSource: data }, () => {
				this.edit(newItem[valueId]);
			});
			return;
		}

		const data = [...dataSource];
		this.findAndAddItem(data, id, newItem);

		const keys = [...expandedRowKeys];
		keys.push(id);
		this.setState({ dataSource: data, expandedRowKeys: keys }, () => {
			this.edit(newItem[valueId]);
		});
	};

	// 递归查找并添加
	findAndAddItem = (data, id, newItem) => {
		const { step } = this.state;
		const child = step === "attribute" ? "childProperties" : "childRules";
		const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";
		for (let val of data) {
			if (val[valueId] === id) {
				if (!(child in val)) {
					val[child] = [];
				}
				val[child].push(newItem);
				return;
			} else {
				if (val[child] && val[child].length) {
					this.findAndAddItem(val[child], id, newItem);
				}
			}
		}
	};

	// 删除新增项
	deleteNewItem = (id) => {
		const { dataSource } = this.state;
		const data = [...dataSource];
		this.findAndDeleteItem(data, id);
		this.setState({ dataSource: data }, () => {
			this.cancelEdit();
		});
	};

	// 递归查找并删除
	findAndDeleteItem = (data, id) => {
		const { step } = this.state;
		const child = step === "attribute" ? "childProperties" : "childRules";
		const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";
		for (let val of data) {
			const index = data.findIndex((item) => item[valueId] === id);
			if (index > -1) {
				data.splice(index, 1);
				return true;
			} else {
				if (val[child] && val[child].length) {
					const shouldDelete = this.findAndDeleteItem(val[child], id);
					if (shouldDelete && val[child].length === 0) {
						delete val[child];
					}
				}
			}
		}
	};

	// 展开的行变化
	onExpandedRowsChange = (expandedRows) => {
		this.setState({ expandedRowKeys: expandedRows });
	};

	// 查询报文
	getMessages = async (id, serviceType, messageType, shouldClear = true) => {
		try {
			this.setState({ loading: true });
			const data = await getMessagesById(id, serviceType, messageType);
			if (data.success) {
				let result = data.result;
				this.deleteEmpty(result);
				this.setState({
					dataSource: result
				});
				// 关闭弹窗再次打开后会展开之前的展开项
				if (shouldClear) {
					this.setState({ expandedRowKeys: [] });
				}
			}
		} catch (error) {
			console.log(error);
		} finally {
			this.setState({ loading: false });
		}
	};

	// 查询解析规则
	getRulesList = async (id) => {
		try {
			this.setState({ loading: true });
			const data = await getRulesListById(id);
			if (data.success) {
				let result = data.result;
				this.deleteEmpty(result);
				this.setState({
					dataSource: result
				});
			}
		} catch (error) {
			console.log(error);
		} finally {
			this.setState({ loading: false });
		}
	};

	updateList = () => {
		const { step, planDetail } = this.state;
		const { svcBundleId, serviceType, messageType } = this.props;
		if (step === "attribute") {
			this.getMessages(svcBundleId, serviceType, messageType, false);
		} else {
			this.getRulesList(planDetail.procotolResolvePlanId);
		}
	};

	setPlanLoading = (bool) => {
		this.setState({
			planLoading: bool
		});
	};

	updatePlanDetail = async () => {
		const { svcBundleId, messageType, serviceType } = this.props;
		const params = {
			dataKind: messageType === "req" ? "REQ" : "RSP"
		};
		try {
			const planData = await getPlanDetailById(params, svcBundleId, serviceType);
			if (planData.success) {
				this.setState({
					planDetail: planData.result || {}
				});
			}
		} catch (error) {
			console.log(error);
		} finally {
			this.setState({
				planLoading: false
			});
		}
	};

	// 弹窗确定按钮
	handleOk = async () => {
		const { step } = this.state;
		const { svcBundleId, messageType, serviceType } = this.props;

		if (step === "attribute") {
			this.setState({
				loading: true,
				planLoading: true,
				step: "protocol",
				dataSource: []
			});

			this.cancelEdit();

			try {
				const params = {
					dataKind: messageType === "req" ? "REQ" : "RSP"
				};
				const planData = await getPlanDetailById(params, svcBundleId, serviceType);

				if (planData.success) {
					this.setState({
						planDetail: planData.result || {},
						planLoading: false
					});

					if (planData.result) {
						await this.getRulesList(planData.result.procotolResolvePlanId);
					}
				}
			} catch (error) {
				console.log(error);
			} finally {
				this.setState({
					loading: false,
					planLoading: false
				});
			}
		} else {
			this.handleCancel();
		}
	};

	// 规划编辑
	setEditStatus = (bool) => {
		this.setState({
			isEditing: bool
		});
	};

	// 规则编辑
	edit = (id) => {
		this.setState({ modifyingId: id });
	};

	// 取消编辑
	cancelEdit = () => {
		this.edit("");
	};

	// 弹窗取消按钮
	handleCancel = () => {
		const { closeModal } = this.props;
		closeModal("requestResponseVisible");
	};

	render() {
		const {
			dataSource,
			loading,
			step,
			expandedRowKeys,
			planDetail,
			planLoading,
			isEditing,
			modifyingId
		} = this.state;
		const { requestResponseVisible, messageType, svcBundleId, serviceType } = this.props;
		const text = messageType === "req" ? "请求" : "响应";
		const title = step === "attribute" ? `${text}报文管理` : `${text}报文协议解析配置`;
		return (
			<Modal
				width={1300}
				title={title}
				visible={requestResponseVisible}
				onOk={this.handleOk}
				onCancel={this.handleCancel}
				afterClose={() => {
					this.setState({ step: "attribute", expandedRowKeys: [], planDetail: {}, dataSource: [] });
					this.cancelEdit();
				}}
			>
				{step !== "attribute" && (
					<PlanManage
						isEditing={isEditing}
						modifyingId={modifyingId}
						planDetail={planDetail}
						loading={planLoading}
						messageType={messageType}
						svcBundleId={svcBundleId}
						serviceType={serviceType}
						setEditStatus={this.setEditStatus}
						setPlanLoading={this.setPlanLoading}
						updatePlanDetail={this.updatePlanDetail}
					/>
				)}

				<ManageTable
					messageType={messageType}
					serviceType={serviceType}
					step={step}
					dataSource={dataSource}
					loading={loading}
					expandedRowKeys={expandedRowKeys}
					planDetail={planDetail}
					isPlanEditing={isEditing}
					modifyingId={modifyingId}
					edit={this.edit}
					cancelEdit={this.cancelEdit}
					addChild={this.addChild}
					onExpandedRowsChange={this.onExpandedRowsChange}
					deleteNewItem={this.deleteNewItem}
					updateList={this.updateList}
				/>
			</Modal>
		);
	}
}

export default SetRequestResponse;
