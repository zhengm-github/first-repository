import ManageTable from "./ManageTable";

export default ManageTable;
