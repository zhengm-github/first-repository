import React, { PureComponent } from "react";
import { Table, Divider, Popconfirm, Form, Input, Select, message } from "antd";
import styles from "./ManageTable.less";
import cs from "classnames";
import {
	getFunctionLibrary,
	addMessage,
	modifyMessage,
	deleteMessage,
	addProcRule,
	modifyProcRule,
	deleteProcRule
} from "@/api/dxp";

const { Option } = Select;
const EditableContext = React.createContext();

class EditableCell extends PureComponent {
	renderCell = ({ getFieldDecorator }) => {
		const { ...props } = this.props;
		return <td {...props}></td>;
	};

	render() {
		return <EditableContext.Consumer>{this.renderCell}</EditableContext.Consumer>;
	}
}

@Form.create()
class ManageTable extends PureComponent {
	state = {
		functionLibrary: []
	};

	attributeColumns = [
		{
			title: "名称",
			dataIndex: "name",
			key: "name",
			ellipsis: true,
			width: 300,
			// fixed: "left",
			className: styles.formColumn,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={cs(styles.formItem, styles.formItemName)}>
							{getFieldDecorator("name", {
								initialValue: text || "",
								rules: [{ required: true, message: "请输入名称", whitespace: true }]
							})(<Input placeholder={"请输入名称"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "备注",
			dataIndex: "memo",
			key: "memo",
			width: 120,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("memo", {
								initialValue: text || "",
								rules: [{ required: true, message: "请输入备注", whitespace: true }]
							})(<Input placeholder={"请输入备注"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "类型",
			dataIndex: "dataType",
			key: "dataType",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				const options = [
					{ name: "数字", key: "number" },
					{ name: "日期", key: "date" },
					{ name: "字符串", key: "string" }
				];
				const option = options.find((item) => item.key === text);
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("dataType", {
								initialValue: text ? text : undefined,
								rules: [{ required: true, message: "请选择类型" }]
							})(
								<Select placeholder="选择类型" className={styles.formItemSelectShort}>
									{options.map((item) => (
										<Option key={item.key}>{item.name}</Option>
									))}
								</Select>
							)}
						</Form.Item>
					);
				}
				return (option && option.name) || undefined;
			}
		},
		{
			title: "可选",
			dataIndex: "optional",
			key: "optional",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				const options = [
					{ name: "必选", key: true },
					{ name: "非必选", key: false }
				];
				const option = options.find((item) => item.key === text);
				let initialValue = String(text);
				if (initialValue !== "true" && initialValue !== "false") {
					initialValue = "true";
				}
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("optional", {
								initialValue: initialValue,
								rules: [{ required: true, message: "请选择是否可选" }]
							})(
								<Select placeholder="是否可选" className={styles.formItemSelectShort}>
									{options.map((item) => (
										<Option key={item.key}>{item.name}</Option>
									))}
								</Select>
							)}
						</Form.Item>
					);
				}
				return (option && option.name) || undefined;
			}
		},
		{
			title: "是否签名项",
			dataIndex: "signObj",
			key: "signObj",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				const options = [
					{ name: "是", key: true },
					{ name: "否", key: false }
				];
				const option = options.find((item) => item.key === text);
				let initialValue = String(text);
				if (initialValue !== "true" && initialValue !== "false") {
					initialValue = "false";
				}
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("signObj", {
								initialValue: initialValue,
								rules: [{ required: true, message: "请选择是否签名项" }]
							})(
								<Select placeholder="是否签名项" className={styles.formItemSelectShort}>
									{options.map((item) => (
										<Option key={item.key}>{item.name}</Option>
									))}
								</Select>
							)}
						</Form.Item>
					);
				}
				return (option && option.name) || undefined;
			}
		},
		{
			title: "顺序号",
			dataIndex: "ord",
			key: "ord",
			width: 70,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator, getFieldValue, resetFields } = this.props.form;
				const disabled = getFieldValue("signObj") === "false";
				if (disabled && getFieldValue("ord")) {
					setTimeout(() => {
						resetFields(["ord"]);
					}, 0);
				}
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("ord", {
								initialValue: text || ""
							})(<Input placeholder={"请输入签名顺序号"} disabled={disabled} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "签名表达式",
			dataIndex: "exp",
			key: "exp",
			width: 100,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { functionLibrary } = this.state;
				const { getFieldDecorator, getFieldValue, resetFields } = this.props.form;
				const option = functionLibrary.find((item) => item.expCode === text);
				const disabled = getFieldValue("signObj") === "false";
				if (disabled) {
					setTimeout(() => {
						resetFields(["exp"]);
					}, 0);
				}
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("exp", {
								initialValue: text ? text : undefined,
								rules: [{ required: !disabled, message: "请选择签名表达式" }]
							})(
								<Select
									placeholder="选择签名表达式"
									className={styles.formItemSelect}
									disabled={disabled}
								>
									{functionLibrary.map((item) => (
										<Option key={item.expCode}>{item.expName}</Option>
									))}
								</Select>
							)}
						</Form.Item>
					);
				}
				return (option && option.expName) || undefined;
			}
		},
        {
            title: "表达式参数",
            dataIndex: "expParams",
            key: "expParams",
            width: 100,
            ellipsis: true,
            render: (text, record) => {
                const isEditing = this.isEditing(record);
                const { getFieldDecorator, getFieldValue, resetFields } = this.props.form;
                const disabled = getFieldValue("signObj") === "false";
                if (disabled && getFieldValue("expParams")) {
                    setTimeout(() => {
                        resetFields(["expParams"]);
                    }, 0);
                }
                if (isEditing) {
                    return (
                        <Form.Item className={styles.formItem}>
                            {getFieldDecorator("expParams", {
                                initialValue: text || ""
                            })(<Input placeholder={"请输入签名长度"} disabled={disabled} />)}
                        </Form.Item>
                    );
                }
                return text;
            }
        },
		{
			title: "操作",
			dataIndex: "operation",
			key: "operation",
			width: 210,
			// fixed: "right",
			className: styles.formColumn,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { step, modifyingId, edit } = this.props;
				const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";
				return (
					<>
						{isEditing ? (
							<>
								<a onClick={() => this.save(record)}>保存</a>
								<Divider type="vertical" />
								<a onClick={() => this.cancelEdit(record)}>取消</a>
							</>
						) : (
							<>
								<a
									disabled={modifyingId !== ""}
									onClick={() => this.addChild(record.parentId)}
								>
									添加同级
								</a>
								<Divider type="vertical" />
								<a
									disabled={modifyingId !== ""}
									onClick={() => this.addChild(record[valueId])}
								>
									添加子级
								</a>
								<Divider type="vertical" />
								<a disabled={modifyingId !== ""} onClick={() => edit(record[valueId])}>
									编辑
								</a>
								<Divider type="vertical" />
								<Popconfirm
									title="确认删除吗？"
									onConfirm={() => this.delete(record[valueId])}
								>
									<a disabled={modifyingId !== ""}>删除</a>
								</Popconfirm>
							</>
						)}
					</>
				);
			}
		}
	];

	protocolColumns = [
		{
			title: "名称",
			dataIndex: "name",
			key: "name",
			width: 290,
			ellipsis: true,
			// fixed: "left",
			className: styles.formColumn,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator, getFieldValue } = this.props.form;
				const detailName = getFieldValue("detailName") && getFieldValue("detailName").trim();
				const disabled = !!detailName;
				if (isEditing) {
					return (
						<Form.Item className={cs(styles.formItem, styles.formItemName)}>
							{getFieldDecorator("name", {
								initialValue: text || "",
								rules: [{ validator: this.checkName }]
							})(<Input placeholder={"请输入名称"} disabled={disabled} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "明细名称",
			dataIndex: "detailName",
			key: "detailName",
			width: 120,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator, getFieldValue } = this.props.form;
				const name = getFieldValue("name") && getFieldValue("name").trim();
				const disabled = !!name;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("detailName", {
								initialValue: text || "",
								rules: [{ validator: this.checkDetailName }]
							})(<Input placeholder={"请输入明细名称"} disabled={disabled} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "备注",
			dataIndex: "memo",
			key: "memo",
			width: 120,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("memo", {
								initialValue: text || "",
								rules: [{ max: 512, message: "备注不能超过512位" }]
							})(<Input placeholder={"请输入备注"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "规则类型",
			dataIndex: "ruleType",
			key: "ruleType",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				const options = [
					{ name: "文件", key: "file" },
					{ name: "报文", key: "pack" }
				];
				const option = options.find((item) => item.key === text);
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("ruleType", {
								initialValue: text ? text : undefined,
								rules: [{ required: true, message: "请选择规则类型" }]
							})(
								<Select placeholder="选择规则类型" className={styles.formItemSelectShort}>
									{options.map((item) => (
										<Option key={item.key}>{item.name}</Option>
									))}
								</Select>
							)}
						</Form.Item>
					);
				}
				return (option && option.name) || undefined;
			}
		},
		{
			title: "分隔符",
			dataIndex: "separatorChar",
			key: "separatorChar",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("separatorChar", {
								initialValue: text || "",
								rules: [{ max: 32, message: "分隔符不能超过32位" }]
							})(<Input placeholder={"请输入分隔符"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "起始位置",
			dataIndex: "beginIndex",
			key: "beginIndex",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("beginIndex", {
								initialValue: text || "",
								rules: [{ max: 32, message: "起始位置不能超过32位" }]
							})(<Input placeholder={"请输入起始位置"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "结束位置",
			dataIndex: "endIndex",
			key: "endIndex",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("endIndex", {
								initialValue: text || "",
								rules: [{ max: 32, message: "结束位置不能超过32位" }]
							})(<Input placeholder={"请输入结束位置"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "行数",
			dataIndex: "lineNum",
			key: "lineNum",
			width: 80,
			ellipsis: true,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { getFieldDecorator } = this.props.form;
				if (isEditing) {
					return (
						<Form.Item className={styles.formItem}>
							{getFieldDecorator("lineNum", {
								initialValue: text || "",
								rules: [{ validator: this.checkLineNum }]
							})(<Input placeholder={"请输入行数"} />)}
						</Form.Item>
					);
				}
				return text;
			}
		},
		{
			title: "操作",
			dataIndex: "operation",
			key: "operation",
			width: 210,
			// fixed: "right",
			className: styles.formColumn,
			render: (text, record) => {
				const isEditing = this.isEditing(record);
				const { step, edit } = this.props;
				const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";
				return (
					<>
						{isEditing ? (
							<>
								<a onClick={() => this.save(record)}>保存</a>
								<Divider type="vertical" />
								<a onClick={() => this.cancelEdit(record)}>取消</a>
							</>
						) : (
							<>
								<a
									disabled={this.isDisabled()}
									onClick={() => this.addChild(record.parentId)}
								>
									添加同级
								</a>
								<Divider type="vertical" />
								<a
									disabled={this.isDisabled()}
									onClick={() => this.addChild(record[valueId])}
								>
									添加子级
								</a>
								<Divider type="vertical" />
								<a disabled={this.isDisabled()} onClick={() => edit(record[valueId])}>
									编辑
								</a>
								<Divider type="vertical" />
								<Popconfirm
									title="确认删除吗？"
									onConfirm={() => this.delete(record[valueId])}
								>
									<a disabled={this.isDisabled()}>删除</a>
								</Popconfirm>
							</>
						)}
					</>
				);
			}
		}
	];

	isDisabled = () => {
		const { modifyingId, step, isPlanEditing } = this.props;
		return modifyingId !== "" || (step === "protocol" && isPlanEditing);
	};

	// 校验名称
	checkName = (rule, value, callback) => {
		const val = value.trim();
		if (val.length > 256) {
			callback("名称不能超过256位");
		}
		const { getFieldValue } = this.props.form;
		const detailName = getFieldValue("detailName").trim();
		if (!val && !detailName) {
			callback("请输入名称");
		}
		callback();
	};

	// 校验明细名称
	checkDetailName = (rule, value, callback) => {
		const val = value.trim();
		if (val.length > 32) {
			callback("明细名称不能超过32位");
		}
		callback();
	};

	// 校验行数
	checkLineNum = (rule, value, callback) => {
		const val = value && value.trim();
		if (!val) {
			callback();
			return;
		}
		const reg = /^(\d)*$/;
		if (!reg.test(val) || val.length > 11) {
			callback("请输入0-11位数字");
		}
		callback();
	};

	isEditing = (record) => {
		const { step, modifyingId } = this.props;
		const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";
		return record[valueId] === modifyingId;
	};

	// 添加同级结果/子结果
	addChild = (parentId) => {
		this.props.addChild(parentId);
	};

	// 保存
	save = (record) => {
		const { form, messageType, serviceType, step, updateList, cancelEdit } = this.props;
		form.validateFields(async (error, values) => {
			if (error) {
				console.log(error);
				return;
			}

			try {
				let params = {
					...record,
					...values
				};
				let data;
				if (record.isAdd) {
					if (step === "attribute") {
						delete params.dataPropertyId;
						data = await addMessage(params, serviceType, messageType);
					} else {
						delete params.procotolResolveRuleId;
						data = await addProcRule(params);
					}
				} else {
					if (step === "attribute") {
						delete params.childProperties;
						data = await modifyMessage(params, serviceType, messageType, record.dataPropertyId);
					} else {
						delete params.childRules;
						data = await modifyProcRule(params, record.procotolResolveRuleId);
					}
				}

				if (data.success) {
					message.success(`${record.isAdd ? "新增" : "修改"}成功`);
					updateList();
					cancelEdit();
				}
			} catch (error) {
				console.log(error);
			}
		});
	};

	// 编辑
	edit = (id) => {
		this.props.edit(id);
	};

	// 取消编辑
	cancelEdit = (record) => {
		if (record.isAdd) {
			const { step } = this.props;
			const valueId = step === "attribute" ? "dataPropertyId" : "procotolResolveRuleId";
			this.props.deleteNewItem(record[valueId]);
		} else {
			this.props.cancelEdit();
		}
	};

	// 删除
	delete = async (id) => {
		try {
			const { messageType, serviceType, step } = this.props;
			let data;
			if (step === "attribute") {
				data = await deleteMessage(serviceType, messageType, id);
			} else {
				data = await deleteProcRule(id);
			}
			if (data.success) {
				message.success("删除成功");
				this.props.updateList();
			}
		} catch (error) {
			console.log(error);
		}
	};

	// 展开的行变化
	onExpandedRowsChange = (expandedRows) => {
		this.props.onExpandedRowsChange(expandedRows);
	};

	// 查询函数库
	getFunctionLibrary = async () => {
		try {
			const data = await getFunctionLibrary();
			if (data.success) {
				this.setState({
					functionLibrary: data.result
				});
			}
		} catch (error) {
			console.log(error);
		}
	};

	componentDidMount = () => {
		this.getFunctionLibrary();
	};

	render() {
		const { form, dataSource, loading, expandedRowKeys, messageType, step, planDetail } = this.props;
		const text = messageType === "req" ? "请求" : "响应";

		const components = {
			body: {
				cell: EditableCell
			}
		};

		const tableColumns = step === "attribute" ? this.attributeColumns : this.protocolColumns;
		const columns = tableColumns.map((col) => {
			if (col.key === "operation") {
				return col;
			}
			return {
				...col,
				onCell: (record) => ({
					record,
					title: col.title
				})
			};
		});

		return (
			<>
				<div className={styles.title}>
					{step === "attribute" ? <span>{text}报文属性管理</span> : <span>规则配置</span>}
					{dataSource.length === 0 && (
						<a
							className={styles.addBtn}
							onClick={() => this.addChild(null)}
							disabled={step === "protocol" && !planDetail.procotolResolvePlanId}
						>
							添加结果
						</a>
					)}
				</div>
				{step === "protocol" && (
					<div className={styles.tip}>提示！名称和明细名称必填其一，有且只有一个</div>
				)}

				<EditableContext.Provider value={form}>
					<Table
						className={styles.formContainer}
						rowKey={(record) =>
							step === "attribute" ? record.dataPropertyId : record.procotolResolveRuleId
						}
						childrenColumnName={step === "attribute" ? "childProperties" : "childRules"}
						components={components}
						columns={columns}
						dataSource={dataSource}
						loading={loading}
						rowClassName={styles.editableRow}
						expandedRowKeys={expandedRowKeys}
						onExpandedRowsChange={this.onExpandedRowsChange}
						// scroll={{ x: 1300 }}
						pagination={false}
					/>
				</EditableContext.Provider>
			</>
		);
	}
}

export default ManageTable;
