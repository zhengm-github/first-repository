import React, { PureComponent } from "react";
import { Form, Input, Spin, message, Divider } from "antd";
import styles from "./PlanManage.less";
import { createProcPlan, modifyProcPlan } from "@/api/dxp";
import cs from "classnames";

@Form.create()
class PlanManage extends PureComponent {
	// 编辑
	edit = () => {
		this.props.setEditStatus(true);
	};

	// 保存
	save = () => {
		const { form } = this.props;
		form.validateFields(async (error, values) => {
			if (error) {
				console.log(error);
				return;
			}

			const {
				planDetail,
				messageType,
				svcBundleId,
				serviceType,
				updatePlanDetail,
				setPlanLoading
			} = this.props;
			setPlanLoading(true);
			let data;
			let params = {
				...values,
				dataKind: messageType === "req" ? "REQ" : "RSP"
			};
			if (serviceType === "in") {
				params.inBoundSvcId = svcBundleId;
			} else {
				params.outBoundSvcId = svcBundleId;
			}
			try {
				if (planDetail.procotolResolvePlanId) {
					data = await modifyProcPlan(params, planDetail.procotolResolvePlanId);
				} else {
					data = await createProcPlan(params);
				}
				if (data.success) {
					message.success("保存成功");
					updatePlanDetail();
					this.props.setEditStatus(false);
				} else {
					setPlanLoading(false);
				}
			} catch (error) {
				console.log(error);
				setPlanLoading(false);
			}
		});
	};

	// 取消编辑
	cancelEidt = () => {
		this.props.setEditStatus(false);
		this.props.form.resetFields();
	};

	render() {
		const { form, planDetail, loading, isEditing, modifyingId } = this.props;
		const { getFieldDecorator } = form;
		const detailItems = [
			{
				key: "name",
				label: "名称",
				text: planDetail.name
			},
			{
				key: "memo",
				label: "备注",
				text: planDetail.memo
			},
			{
				key: "separatorChar",
				label: "分隔符",
				text: planDetail.separatorChar
			}
		];
		return (
			<div className={styles.planManageContainer}>
				<div className={styles.title}>
					<span>规划配置</span>
					{isEditing ? (
						<>
							<a className={styles.btn} onClick={this.save}>
								保存
							</a>
							<Divider type="vertical" />
							<a onClick={this.cancelEidt}>取消</a>
						</>
					) : (
						<a className={styles.btn} disabled={modifyingId !== ""} onClick={this.edit}>
							编辑
						</a>
					)}
				</div>
				<Spin spinning={loading}>
					{isEditing ? (
						<Form className={styles.formContainer}>
							<Form.Item label="名称" className={styles.formItem}>
								{getFieldDecorator("name", {
									initialValue: planDetail.name,
									rules: [
										{ required: true, message: "请输入名称", whitespace: true },
										{ max: 256, message: "名称不能超过256位" }
									]
								})(<Input placeholder={"请输入名称"} className={styles.formItemInput} />)}
							</Form.Item>
							<Form.Item label="备注" className={styles.formItem}>
								{getFieldDecorator("memo", {
									initialValue: planDetail.memo,
									rules: [{ max: 512, message: "备注不能超过512位" }]
								})(<Input placeholder={"请输入备注"} />)}
							</Form.Item>
							<Form.Item label="分隔符" className={styles.formItem}>
								{getFieldDecorator("separatorChar", {
									initialValue: planDetail.separatorChar,
									rules: [{ max: 32, message: "分隔符不能超过32位" }]
								})(<Input placeholder={"请输入分隔符"} />)}
							</Form.Item>
						</Form>
					) : (
						<div className={cs(styles.formContainer, styles.staticContainer)}>
							{detailItems.map((item) => {
								return (
									<div className={styles.item} key={item.key}>
										<div className={styles.label}>{item.label}</div>
										<div className={styles.text}>{item.text}</div>
									</div>
								);
							})}
						</div>
					)}
				</Spin>
			</div>
		);
	}
}

export default PlanManage;
