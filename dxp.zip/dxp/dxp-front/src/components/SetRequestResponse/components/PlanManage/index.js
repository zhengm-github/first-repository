import PlanManage from "./PlanManage";

export default PlanManage;
