import React, { Component } from "react";
import PropTypes from "prop-types";
import { Input } from "antd";

import styles from "./CustomAside.less";

const { Search } = Input;

class CustomAside extends Component {

	state = {
		collapse: false,
	};

	/*
	*模糊匹配搜索
	* */
	onChange = async (value) => {
		const { onChange } = this.props;
		onChange(value);
	};

	/*
	*收起或者展开
	*/
	toggleCollapse = (collapse) => {
		this.setState({
			collapse: !collapse
		});
	};


	render() {
		const { collapse } = this.state;
		return (
			<div className={styles.customAside}>
				<div className={collapse ? styles.customLeftCollapse : styles.customLeft}>
					<div className={styles.customWrapper}>
						<div className={styles.customSearch}>
							<Search
								placeholder="输入关键字筛选"
								allowClear
								onSearch={this.onChange}
								className={styles.customSearchInput}
							/>
						</div>
						<div className={styles.customContent}>
							{this.props.children}
						</div>
					</div>
				</div>
				<div className={styles.customSquare} onClick={() => this.toggleCollapse(collapse)}>
					<div className={collapse ? styles.customLeftTriangle : styles.customRightTriangle}></div>
				</div>
			</div>
		);
	}
}

CustomAside.propTypes = {
	onChange: PropTypes.func.isRequired,
};

CustomAside.defaultProps = {
	onChange: () => {
	}
};


export default CustomAside;