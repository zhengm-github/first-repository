import request from "./request";
const paramUrl = "param"; //参数
const dicUrl = "dictionary"; //字典
const menuUrl = "menu"; // 菜单
const userUrl = "user"; // 用户
const logUrl = "bizlog"; // 日志
const authUrl = "authority"; // 权限
const centerUrl = "authcenter"; // 认证中心
const bordUrl = "combine"; // 边界

// 查询日志
export const getBizLogsHandle = async (params) => {
	const callBack = () => {
		const { operateDate, ...param } = params;
		return request(`${logUrl}/bizlogs`, param, "POST");
	};
	const resultHandle = (res) => {
		res.pagingTools = {
			items: JSON.parse(JSON.stringify(res.result.items))
		};
		res.result = res.result.pageData;
		return res;
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 根据id查询日志
export const getBizLogDetailHandle = (id) => request(`${logUrl}/bizlogs/detail/id/${id}`, {}, "GET");

//请求权限菜单
export const getAuthMenusHandle = () => request(`${bordUrl}/menus-users/children/ROOT`, {}, "GET");

// 请求菜单接口
export const menusHandle = async (params) => {
	const callBack = () => {
		const param = {
			key: params.parent_id ? params.parent_id : "ROOT",
			pattern: "id"
		};
		return request(`${menuUrl}/menus/allchildren/${param.pattern}/${param.key}`, {}, "GET");
	};

	const res = await callBack();
	return res;
};

// 删除菜单
export const deleteMenusHandle = (id) => request(`${menuUrl}/menus/${id}`, {}, "DELETE");

// 启用禁用菜单
export const enableMenusHandle = async (params) => {
	const callBack = () => {
		const param = {
			isEnable: params.enable,
			menuIds: params.menuId
		};
		return request(
			`${menuUrl}/menus/enable-state?menuIds=${param.menuIds}&isEnable=${param.isEnable}`,
			{},
			"PATCH"
		);
	};
	const res = await callBack();
	return res;
};

// 菜单排序
export const dragMenusHandle = async (params) => {
	const callBack = () => {
		const param = {
			menuIds: params.order,
			parentId: params.parentId ? params.parentId : "ROOT"
		};
		return request(
			`${menuUrl}/menus/reorder?menuIds=${param.menuIds}&parentId=${param.parentId}`,
			{},
			"PATCH"
		);
	};

	const res = await callBack();
	return res;
};

// 根据id查询菜单详情
export const getMenuInfoHandle = (id) => request(`${menuUrl}/menus/detail/id/${id}`, {}, "GET");

// 新增菜单
export const addMenusHandle = async (params) => {
	const callBack = () => {
		let { module, ...param } = params;
		if (!param.parentId) {
			const { parentId, ...otherParam } = param;
			param = otherParam;
		}
		return request(`${menuUrl}/menus`, param, "POST");
	};
	const res = await callBack();
	return res;
};

// 编辑菜单
export const editMenusHandle = async (params) => {
	const callBack = () => {
		const id = params.menuId;
		const { menuId, module, ...param } = params;
		return request(`${menuUrl}/menus/${id}`, param, "PUT");
	};
	const res = await callBack();
	return res;
};

//查询用户列表
export const getUserListHandle = async (params) => {
	const callBack = () => {
		if (params.lock !== undefined) {
			const isLock = params.lock === "" ? null : params.lock;
			const isEnable = params.isEnable === "" ? null : params.isEnable;
			const { roleIdStr, lock, ...parma } = {
				...params,
				isLock: isLock,
				isEnable: isEnable,
				roleIds: params.roleIdStr
			};
			return request(`${bordUrl}/users-roles/list`, parma, "POST");
		}
		return request(`${bordUrl}/users-roles/list`, params, "POST");
	};
	const formateRole = (data) => {
		return data.map((item) => {
			let roleString = [];
			if (item.roles.length) {
				item.roles.map((i) => {
					roleString.push(i.roleId + "##" + i.roleName);
					return i.roleId;
				});
			}
			item.roleString = roleString.join(",");
			item.sexuality = item.sex ? "1" : "0";
			return item;
		});
	};

	const resultHandle = (res) => {
		const { ...result } = {
			...res,
			pagingTools: {
				page: res.result.page ? res.result.page : 0,
				itemsPerPage: res.result.itemsPerPage ? res.result.itemsPerPage : 0,
				items: res.result.items ? res.result.items : 0
			},
			result: formateRole(res.result.pageData)
		};
		return result;
	};
	const res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};

//根据ID获取用户信息
export const getUserByIdHandle = async (key) => {
	const callBack = () => {
		const param = {
			pattern: "id",
			key: key
		};
		return request(`${bordUrl}/users-roles/detail/${param.pattern}/${param.key}`, {}, "GET");
	};
	const formateRole = (data) => {
		let roleString = [];
		let scopeString = [];
		data.roles.map((item) => {
			roleString.push(item.roleId + "##" + item.roleName);
			return item.roleId;
		});
		data.scopeGroups.map((item) => {
			scopeString.push(item.scopeGroupId + "##" + item.name);
			return item.scopeGroupId;
		});
		roleString = roleString.join(",");
		scopeString = scopeString.join(",");
		const { roles, scopeGroups, ...result } = {
			...data,
			roleString: roleString,
			sexuality: data.sex ? 1 : 0,
			scopeGroupString: scopeString
		};
		return result;
	};
	const resultHandle = (res) => {
		const { ...result } = { ...res, result: formateRole(res.result) };
		return result;
	};
	const res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};

//新增用户
export const addUserHandle = async (params) => {
	const callBack = () => {
		const { roleString, ...param } = {
			...params,
			roleIds: params.roleString,
			sex: params.sex ? true : false
		};
		return request(`${bordUrl}/users-roles`, param, "POST");
	};

	const res = await callBack();
	return res;
};

//修改用户
export const modifyUserHandle = async (params) => {
	const callBack = () => {
		const { scopeGroupString, roleString, ...param } = {
			...params,
			roleIds: params.roleString,
			bizType: "coreBank",
			sex: params.sex ? true : false,
			scopeGroupIdStr: params.scopeGroupString
		};
		return request(`${bordUrl}/users-roles/${param.userId}`, param, "POST");
	};

	const res = await callBack();
	return res;
};

//用户停用/启用
export const userIsEnableHandle = async (params, key) => {
	const callBack = () => {
		const { roleString, ...param } = params;
		return request(`${userUrl}/users/enable-state/${key}?isEnable=${param.isEnable}`, {}, "PATCH");
	};

	const res = await callBack();
	return res;
};

//用户解锁
export const unlockUserHandle = async (key) => {
	const callBack = () => {
		const param = {
			isLock: "false"
		};
		return request(`${userUrl}/users/lock-state/${key}?isLock=${param.isLock}`, {}, "PATCH");
	};
	const res = await callBack();
	return res;
};

//用户激活
export const activateUserHandle = (params, key) =>
	request(`${userUrl}/users/active-state/${key}`, params, "PATCH");

//用户自动匹配
export const userAutoMatchHandle = (key,param) => request(`${bordUrl}/users/match/value/${key}`, param, "POST");

//密码重置
export const resetPasswordHandle = async (key) => {
	const callBack = () => {
		const param = {
			pattern: "reset"
		};
		return request(`${userUrl}/users/passwd/${key}`, param, "PATCH");
	};
	const res = await callBack();
	return res;
};

//获取机构列表
export const getOrganizationsListHandle = async (params) => {
	const callBack = () => {
		const { parentId, ...param } = params;
		return request(`${bordUrl}/combine-organizations/children/${parentId}`, param, "POST");
	};
	const resultHandle = (res) => {
		const { ...result } = {
			...res,
			pagingTools: {
				page: res.result.page ? res.result.page : 0,
				itemsPerPage: res.result.itemsPerPage ? res.result.itemsPerPage : 0,
				items: res.result.items ? res.result.items : 0
			},
			result: res.result.pageData
		};
		return result;
	};
	const res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};

//获取完整机构树
export const getAllOrgHandle = async (params) => {
	const callBack = () => {
		params = {
			manageable: params.manager,
			dataType: "scope",
			...params
		};
		const {manager, ...param} = params;
		return request(`${bordUrl}/organizations/tree`, param, "POST");
	};

	const res = await callBack();
	return res;
};

//根据机构ID获取机构信息
export const getOrgInfoByIdHandle = async (key) => {
	const callBack = () => {
		const param = {
			key: key,
			pattern: "id"
		};
		return request(`${userUrl}/organizations/detail/${param.pattern}/${param.key}`, param, "GET");
	};
	const res = await callBack();
	return res;
};

//修改机构
export const modifyOrgHandle = async (params, key) => {
	const callBack = () => {
		const { parentId, ...param } = params;
		return request(`${bordUrl}/combine-organizations/${key}`, param, "PUT");
	};
	const res = await callBack();
	return res;
};

//新增机构
export const addOrgHandle = async (params) => {
	const callBack = () => {
		params.bizType = "coreBank";
		return request(`${userUrl}/organizations`, params, "POST");
	};
	const res = await callBack();
	return res;
};

//删除机构
export const deleteOrgHandle = (keys) => request(`${bordUrl}/combine-organizations/${keys}`, {}, "DELETE");

//禁用/启用
export const disableOrgHandle = (params, keys) =>
	request(`${userUrl}/organizations/enable-state/${keys}?isEnable=${params.isEnable}`, {}, "PATCH");

//查询一种角色的用户列表
export const getRoleUsersHandle = (keys) => request(`${authUrl}/roles/users/${keys}`, {}, "GET");

//角色批量赋予用户接口
export const addUsersRoleHandle = async (params) => {
	const callBack = () => {
		const param = {
			userIds: params.users,
			roleIds: params.roleId
		};
		return request(`${authUrl}/roles/users`, param, "POST");
	};
	const res = await callBack();
	return res;
};

// 功能注册树结构
export const abilityDomTreeHandle = async (params) => {
	const callBack = () => {
		return request(`${authUrl}/functions/tree`, params, "GET");
	};
	const loop = (arr) => {
		return arr.map((item) => {
			if (item.children) {
				item.childrenVo = loop(item.children);
			} else {
				item.childrenVo = [];
			}
			const { children, ...items } = item;
			return items;
		});
	};
	const resultHandle = (res) => {
		res.result = res.result.map((item) => {
			if (item.children) {
				item.childrenVo = loop(item.children);
			} else {
				item.childrenVo = [];
			}
			const { children, ...items } = item;
			return items;
		});
		return res;
	};
	let res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 功能注册树 查询选中的某个节点
export const abilityTreeHandle = async (params) => {
	const callBack = () => {
		params = {
			...params,
			pageSize: 100,
			pageNum: 1
		};
		return request(`${authUrl}/functions/list`, params, "POST");
	};
	const loop = (arr) => {
		return arr.map((item) => {
			if (item.children) {
				item.childrenVo = loop(item.children);
			} else {
				item.childrenVo = [];
			}
			const { children, ...items } = item;
			return items;
		});
	};
	const resultHandle = (res) => {
		res.result = res.result.pageData;
		res.result = res.result.map((item) => {
			if (item.children) {
				item.childrenVo = loop(item.children);
			} else {
				item.childrenVo = [];
			}
			const { children, ...items } = item;
			return items;
		});
		return res;
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 根据功能ID查找功能
export const searchAbilityHandle = async (id) => request(`${authUrl}/functions/id/${id}`, {}, "GET");

// 功能注册 添加树结构
export const addTreeHandle = async (params) => request(`${authUrl}/functions`, params, "POST");

// 功能注册 删除树结构
export const deleteTreeHandle = async (id) => request(`${authUrl}/functions/${id}`, {}, "DELETE");

// 功能注册 修改树结构
export const editTreeHandle = async (params, id) => {
	const callBack = () => {
		params = { ...params, functionId: id };
		return request(`${authUrl}/functions`, params, "PUT");
	};
	const res = await callBack();
	return res;
};

//功能权限绑定
export const abilityAuthsHandle = async (params) => {
	const callBack = () => {
		const authCodeId = params.authCodeIds.toString();
		const { authCodeIds, ...param } = { ...params, authCodeId };
		return request(`${authUrl}/functions/authcodes`, param, "POST");
	};
	const res = await callBack();
	return res;
};

//查看功能绑定的权限码
export const abilityAuthCodeHandle = async (params, id) => {
	const callBack = () => {
		return request(`${authUrl}/functions/${id}`, {}, "GET");
	};
	const resultHandle = (res) => {
		res.checkedKeys = res.result.filter((item) => {
			return item.checked === true;
		});
		const obj = {};
		for (let i = 0; i < res.result.length; i++) {
			if (res.result[i].authType !== "type.workflow" && res.result[i].authType !== "type.system") {
				res.result[i].authType = "type.other";
			}
		}
		for (let i = 0; i < res.result.length; i++) {
			if (obj[res.result[i].authType]) {
				obj[res.result[i].authType] = [...obj[res.result[i].authType], res.result[i]];
			} else {
				obj[res.result[i].authType] = [res.result[i]];
			}
		}
		res.result = obj;
		return res;
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 查询角色列表
export const getRolesListHandle = async (params) => {
	const callBack = () => {
		if (params.orgCodeLikes === "common") {
			params = {
				...params,
				keyword: params.keyWord,
				searchOrgCode: "000000",
				isIncludeCommon: true
			};
			const { orgCodeLikes, keyWord, ...param } = params;

			return request(`${bordUrl}/roles`, param, "POST");
		} else {
			params = {
				...params,
				keyword: params.keyWord,
				searchOrgCode: params.orgCodeLikes
			};
			const { orgCodeLikes, keyWord, ...param } = params;
			return request(`${bordUrl}/roles`, param, "POST");
		}
	};
	const resultHandle = (res) => {
		const { pageData, page, items, itemsPerPage } = res.result;
		return {
			...res,
			result: pageData,
			pagingTools: { page: page, items: items, itemsPerPage: itemsPerPage }
		};
	};
	const res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};

// 查询拥有角色的机构列表
export const getRoleOrgListHandle = async (params = {}) => {
	const callBack = () => {
		return request(`${bordUrl}/organizations/roles`, params, "GET");
	};
	const res = await callBack();
	return res;
};

// 角色新增
export const addRoleHandle = async (params) => {
	const callBack = () => {
		const rangeType = params.roleCode[params.roleCode.length - 1];
		const orgCode = params.roleCode.slice(0, params.roleCode.length - 1);
		const { roleCode, pilotOrg, ...param } = { ...params, rangeType, orgCode, dataType:false };
		return request(`${authUrl}/roles`, param, "POST");
	};
	const res = await callBack();
	return res;
};

// 角色修改
export const modifyRoleHandle = async (params, id) => {
	const callBack = () => {
		const rangeType = params.roleCode[params.roleCode.length - 1];
		const orgCode = params.roleCode.slice(0, params.roleCode.length - 1);
		const { roleCode, ...param } = { ...params, rangeType, orgCode, roleId: id };
		return request(`${authUrl}/roles`, param, "PUT");
	};
	const res = await callBack();
	return res;
};

// 删除角色
export const delRoleListHandle = async (id) => request(`${authUrl}/roles/${id}`, {}, "DELETE");

// 查询角色权限列表(查询角色的功能列表)
export const getRoleAuthListHandle = async (id) => {
	const callBack = () => {
		return request(`${authUrl}/roles/functions/${id}`, {}, "GET");
	};
	const resultHandle = (res) => {
		res.result.map((item) => {
			return (item.authMaskCode = item.maskCode);
		});
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 根据ID查找角色
export const getRoleHandle = async (id) => request(`${authUrl}/roles/detail/id/${id}`, {}, "GET");

// 查询角色名合法性
export const getRoleNameHandle = async (params, name) => {
	const callBack = () => {
		const { roleType, ...param } = { ...params, roleName: name };
		return request(`${authUrl}/roles/validation/repeat`, param, "GET");
	};
	const res = await callBack();
	return res;
};

// 查询具体某个参数
export const operateOneParamHandle = async (params = {}, name) => {
	const callBack = () => {
		params = {
			...params,
			paramName: name
		};
		return request(`${paramUrl}/params/value`, params, "GET");
	};
	const resultHandle = (res) => {
		res.result = {
			paramVal: res.result
		};
		return res;
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 功能配置树结构
export const abilityConfigTreeHandle = async (params = {}) => {
	const callBack = () => {
		return request(`${authUrl}/functions/auth/tree`, params, "GET");
	};
	const loop = (arr) => {
		arr.map((item) => {
			item.general = item.isGeneral;
			if (item.children) {
				item.childrenVo = loop(item.children);
			} else {
				item.childrenVo = [];
			}
			return item;
		});
		return arr;
	};
	const resultHandle = (res) => {
		res.result.map((item) => {
			item.general = item.isGeneral;
			if (item.children) {
				item.childrenVo = loop(item.children);
			} else {
				item.childrenVo = [];
			}
			return item;
		});
		return res;
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 角色授权
export const postRoleAuthHandle = async (params = {}) =>
	request(`${authUrl}/roles/functions`, params, "POST");

// 修改密码
export const modifyPasswordHandle = async (params = {}) => {
	const callBack = () => {
		const ids = JSON.parse(sessionStorage.getItem("lunaLoginInfo")).userId;
		params = {
			...params,
			pattern: "modify"
		};
		return request(`${userUrl}/users/passwd/${ids}`, params, "PATCH");
	};
	const res = await callBack();
	return res;
};

// 查询角色-权限范围域列表
export const searchAuthScopeRoleHandle = (params = {}) =>
	request(`${authUrl}/authscopes/role/authcode`, params, "GET");

// 获取角色拥有的权限列表(范围域)
export const getAuthRoleListHandle = (id) => request(`${authUrl}/roles/auths-scope/${id}`, {}, "GET");

// 范围域删除
export const deleteAuthRoleHandle = (id) => request(`${authUrl}/authscopes/${id}`, {}, "DELETE");

// 范围域保存
export const saveAuthScopeHandle = async (params = {}) => {
	const callBack = () => {
		if (params.whereFrom === "from_role_manager") {
			params.source = "role";
		} else if (params.whereFrom === "from_scope_group_manager") {
			params.source = "scopeGroup";
		} else if (params.whereFrom === "from_organization_manager") {
			params.source = "org";
		}
		const { whereFrom, ...param } = params;
		return request(`${authUrl}/authscopes`, param, "POST");
	};
	const res = await callBack();
	return res;
};

// 登录
export const loginHandle = async (params = {}) => {
	const callBack = () => {
		params = {
			...params,
			grant_type: "password",
			client_id: "luna",
			client_secret: "luna",
			username: params.loginName
		};
		return request(
			`${centerUrl}/oauth/token?username=${params.loginName}&password=${params.password}&grant_type=password&client_id=luna&client_secret=luna`,
			{},
			"POST"
		);
	};
	const res = await callBack();
	return res;
};

// 获取登录信息
export const getLoginInfoHandle = (params = {}) => request(`${centerUrl}/oauth/user/info`, params, "GET");

//查询机构下角色列表
export const getOrgRoleListHandle = async (orgCode, params = { isIncludeCommon: true }) => {
	const callBack = () => {
		params = {
			...params,
			searchOrgCode: orgCode
		};
		return request(`${bordUrl}/roles/tree`, params, "POST");
	};
	const res = await callBack();
	return res;
};
//查询权限列表
export const getAuthCodesHandle = async (params) => {
	const callBack = () => {
		return request(`${authUrl}/authcodes/list`, params, "POST");
	};
	const resultHandle = (res) => {
		const { pageData, page, items, itemsPerPage } = res.result;
		return {
			...res,
			result: pageData,
			pagingTools: { page: page, items: items, itemsPerPage: itemsPerPage }
		};
	};
	let res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};
//根据id获取权限详情
export const getCodeInfoHandle = async (id) => request(`${authUrl}/authcodes/detail/id/${id}`, {}, "GET");

//新增权限
export const addCodesHandle = async (params) => {
	const callBack = () => {
		const param = { ...params, maskCode: params.maskCode.split(",").join("") };
		return request(`${authUrl}/authcodes`, param, "POST");
	};
	let res = await callBack();
	return res;
};

//权限修改
export const modifyCodesHandle = async (params, id) => {
	const callBack = () => {
		const param = { ...params, authCodeId: id, maskCode: params.maskCode.split(",").join("") };
		return request(`${authUrl}/authcodes`, param, "PUT");
	};
	let res = await callBack();
	return res;
};

//删除权限
export const deleteCodesHandle = (ids) => request(`${authUrl}/authcodes/${ids}`, {}, "DELETE");

//根据key查询系统级字典
export const getDicKeyHandle = async () =>
	request(`${bordUrl}/combine-dictionaries/children`, { dicKey: "auth.code.type" }, "GET");

// 查询参数、新增参数、更新参数    fap查询的传参 paramName: 11  paramLevel: params_level_system
/**
 *
 * @param {发送参数} params
 * @param {请求方式} method
 * @param {查询||更新||新增} opearaType  number 0 查询、1 新增、2 更新
 */
export const operateParamsHandle = async (params, method, opearaType) => {
	let sendata = null,
		sendUrl = "";
	switch (opearaType) {
		case 0:
			const { paramName, ...paramGet } = { ...params, keyword: params.paramName };
			sendata = paramGet;
			sendUrl = `${bordUrl}/combine-params`;
			break;
		case 1:
			sendata = params;
			sendUrl = `${paramUrl}/params`;
			break;
		case 2:
			const { systemParamId, ...paramPut } = { ...params };
			sendata = paramPut;
			sendUrl = `${bordUrl}/combine-params/${params.systemParamId}`;
			break;
		default:
	}
	const callBack = () => {
		return request(sendUrl, sendata, method);
	};
	const res = await callBack();
	return res;
};

// 删除参数
export const deleteParamsHandle = (id) => request(`${paramUrl}/params/${id}`, {}, "DELETE");

// 查询key对应子字典列表
export const dicKeyChildrenHandle = (key) =>
	request(`${bordUrl}/combine-dictionaries/children`, { dicKey: key }, "GET");

// 查询字典
export const getDictionariesHandle = async (params) => {
	const callBack = () => {
		const { dicVal, dicKey, pageNum, pageSize, ...param } = { ...params, keyword: params.dicKey };
		return request(`${bordUrl}/combine-dictionaries`, param, "GET");
	};
	const res = await callBack();
	return res;
};

// 查询子字典
/**
 *
 * @param {发送的参数} params
 * @param {平台} opearaType  1 fap 2 moon
 */
export const getDicChildrenHandle = async (params, opearaType) => {
	let url = "";
	if (opearaType === 1) {
		url = `${bordUrl}/combine-dictionaries/children`;
	} else if (opearaType === 2) {
		url = `${dicUrl}/dictionaries/pid/${params.dictionaryId}`;
	} else {
		url = `${bordUrl}/combine-dictionaries/children`;
	}
	const res = await request(url, params, "GET");
	return res;
};

// 新增字典
export const addDictionaryHandle = async (params) =>
	await request(`${bordUrl}/combine-dictionaries`, params, "POST");

// 删除字典
export const deleteDictionaryHandle = async (id, params) =>
	await request(`${dicUrl}/dictionaries/id/${id}`, params, "DELETE");

// 更新字典
export const updateDictionaryHandle = async (params) => {
	const callBack = () => {
		return request(`${bordUrl}/combine-dictionaries/${params.dictionaryId}`, params, "PUT");
	};
	const res = await callBack();
	return res;
};

// 排序字典
export const dictionarySortHandle = async (params) => {
	const { dicId, ...param } = { ...params, dicIds: params.dicId };
	if (!param.parentId) {
		param.parentId = "ROOT";
	}
	const res = await request(`${dicUrl}/dictionaries/reorder`, param, "PATCH");
	return res;
};

// 查询范围域里的角色列表
export const getRolesScopeListHandle = async (params = {}) => {
	const callBack = () => {
		return request(`${bordUrl}/roles/tree`, params, "POST");
	};
	const resultHandle = (res) => {
		res.result[0].children = res.result;
		res.result[0].children.map((item) => {
			item.id = item.roleId;
			item.name = item.roleName;
			return item;
		});
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

// 查询范围域里的岗位列表
export const getRolePositionsHandle = async (params = {}) => {
	const callBack = () => {
		params = {
			roleType: "P"
		};
		return request(`${bordUrl}/roles/tree`, params, "POST");
	};
	const resultHandle = (res) => {
		res.result.children = res.result;
	};
	const res = await callBack();
	if (res.success) {
		resultHandle(res);
	}
	return res;
};

//用户解绑角色/角色用户关联关系删除
export const deleteUsersRoleHandle = async (params) => {
	const callBack = () => {
		const param = {
			userIds: params.users,
			roleIds: params.roleId
		};
		return request(`${authUrl}/roles/users-cancel`, param, "POST");
	};
	const res = await callBack();
	return res;
};

//查询岗位绑定的角色列表接口
export const getPositionsRolesHandle = (id) => request(`${authUrl}/roles/position/${id}`, {}, "GET");

//岗位绑定角色
export const addPositionsRolesHandle = async (params) => {
	const callBack = () => {
		const param = {
			roleIds: params.roles,
			positionIds: params.position
		};
		return request(`${authUrl}/roles/positions`, param, "POST");
	};
	const res = await callBack();
	return res;
};

//岗位解绑角色
export const delPositionsRolesHandle = async (params) => {
	const callBack = () => {
		const param = {
			roleIds: params.roles,
			positionIds: params.position
		};
		return request(`${authUrl}/roles/positions-cancel`, param, "POST");
	};
	const res = await callBack();
	return res;
};

//查询范围域组的机构列表
export const getScopeGroupOrgHandle = (params = {}) =>
	request(`${bordUrl}/organizations/scopegroups`, params, "GET");

// 查询范围域组列表
export const getScopeGroupListHandle = async (params) => {
	const callBack = () => {
		if (params.orgCode === "common") {
			params = {
				...params,
				keyword: params.keyWord
			};
			const loginInfo = JSON.parse(sessionStorage.getItem("lunaLoginInfo"));
			const isAdmin = loginInfo.code === "admin" ? true : false;
			const { keyWord, ...param } = { ...params, isAdmin };
			return request(`${authUrl}/scopegroups/common`, param, "POST");
		} else {
			params = {
				...params,
				keyword: params.keyWord
			};
			const searchOrgCode = params.orgCode;
			const { keyWord, ...param } = { ...params, searchOrgCode };
			return request(`${bordUrl}/scopegroups`, param, "POST");
		}
	};
	const resultHandle = (res) => {
		const { pageData, page, items, itemsPerPage } = res.result;
		return {
			...res,
			result: pageData,
			pagingTools: { page: page, items: items, itemsPerPage: itemsPerPage }
		};
	};
	const res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};

//范围域组新增
export const addScopeGroupHandle = (params = {}) => request(`${authUrl}/scopegroups`, params, "POST");

//范围域组更新
export const updateScopeGroupHandle = (params = {}) => request(`${authUrl}/scopegroups`, params, "PUT");

//根据ID查询范围域组
export const getScopeGroupIdHandle = (id) => request(`${authUrl}/scopegroups/${id}`, {}, "GET");

//范围域组删除
export const delScopeGroupHandle = (id) => request(`${authUrl}/scopegroups/${id}`, {}, "DELETE");


export const logoutHandle = (params) => request(`${centerUrl}/oauth/logout`, params, "GET");

//查询范围域
export const getScopeHandle = (params) => request(`${authUrl}/authscopes/list`, params, "POST");

//根据机构查询范围域组(包含通用)
export const getAllScopeGroupsByOrgHandle = async (orgCode) => {
	const callBack = () => {
		const params = {
			searchOrgCode: orgCode
		};
		return request(`${bordUrl}/scopegroups/all`, params, "GET");
	};
	const resultHandle = (res) => {
		const { ...result } = { ...res, result: res.result};
		return result;
	};
	const res = await callBack();
	if (res.success) {
		return resultHandle(res);
	}
	return res;
};
//查询机构下的角色（包括通用角色）
export const getAllOrgRoleListHandle = async (orgCode, params = {  roleType: 'R' }) => {
	const callBack = () => {
		params = {
			...params,
			orgCode: orgCode
		};
		return request(`${bordUrl}/roles-org`, params, "GET");
	};
	const res = await callBack();
	return res;
};
//查询范围域组是否重复
export const getScopeRepeatHandle =  (params) =>  request(`${authUrl}/authscopes/validation/repeat`, params, "POST")
