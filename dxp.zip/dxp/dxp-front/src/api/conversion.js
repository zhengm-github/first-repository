import api from "./import";

// 查询日志
export const getBizLogs = async (params) => await api.getBizLogsHandle(params);

// 根据id查询日志
export const getBizLogDetail = async (id) => await api.getBizLogDetailHandle(id);

//权限菜单
export const authMenus = async () => await api.getAuthMenusHandle();

// 请求菜单接口
export const menus = async (params) => await api.menusHandle(params);

//删除菜单
export const deleteMenus = async (params) => await api.deleteMenusHandle(params);

//启用禁用菜单
export const enableMenus = async (params) => await api.enableMenusHandle(params);

//菜单排序
export const dragMenus = async (params) => await api.dragMenusHandle(params);

//根据id查询菜单详情
export const getMenuInfo = async (params) => await api.getMenuInfoHandle(params);

//新增菜单
export const addMenus = async (params) => await api.addMenusHandle(params);

//编辑菜单
export const editMenus = async (params) => await api.editMenusHandle(params);

// 查询用户列表
export const getUsersList = async (params) => await api.getUserListHandle(params);

//根据ID获取用户信息
export const getUserById = async (key) => await api.getUserByIdHandle(key);

//用户新增
export const addUser = async (params) => await api.addUserHandle(params);

//用户修改
export const modifyUser = async (params) => await api.modifyUserHandle(params);

//用户停用启用
export const userIsEnable = async (params, key) => await api.userIsEnableHandle(params, key);

//解锁
export const unlockUser = async (key) => await api.unlockUserHandle(key);

//反激活
export const activateUser = async (params, key) => await api.activateUserHandle(params, key);

//用户自动匹配
export const userAutoMatch = async (key,param) => await api.userAutoMatchHandle(key,param);

// 密码重置
export const resetPassword = async (key) => await api.resetPasswordHandle(key);

// 查询机构列表
export const getOrganizationsList = async (params) => await api.getOrganizationsListHandle(params);

// 查询完整机构列表
export const getAllOrg = async (params) => await api.getAllOrgHandle(params);

// 查询ID查询机构信息
export const getOrgInfoById = async (key) => await api.getOrgInfoByIdHandle(key);

// 修改机构列表
export const modifyOrg = async (params, key) => await api.modifyOrgHandle(params, key);

//新增机构
export const addOrg = async (params) => await api.addOrgHandle(params);

//删除机构
export const deleteOrg = async (keys) => await api.deleteOrgHandle(keys);

//禁用启用机构
export const disableOrg = async (params, keys) => await api.disableOrgHandle(params, keys);

//查询一种角色的用户列表
export const getRoleUsers = async (keys) => await api.getRoleUsersHandle(keys);

// 角色批量赋予用户接口
export const addUsersRole = async (params) => await api.addUsersRoleHandle(params);

// 角色用户关联关系删除
export const deleteUsersRole = async (params) => await api.deleteUsersRoleHandle(params);

//根据key查询系统级字典
export const dicKey = async (key) => await api.getDicKeyHandle(key);

//查询权限列表
export const authCodes = async (params) => await api.getAuthCodesHandle(params);

//根据id获取权限详情
export const codeInfo = async (id) => await api.getCodeInfoHandle(id);

//新增权限
export const addCodes = async (params) => await api.addCodesHandle(params);

//修改权限
export const modifyCodes = async (params, id) => await api.modifyCodesHandle(params, id);

//删除权限
export const deleteCodes = async (ids) => await api.deleteCodesHandle(ids);

//功能注册树结构
export const abilityDomTree = async (params) => await api.abilityDomTreeHandle(params);

//功能注册树 查询选中的某个节点
export const abilityTree = async (params) => await api.abilityTreeHandle(params);

//根据功能ID查找功能
export const searchAbility = async (id) => await api.searchAbilityHandle(id);

//功能注册 添加树结构
export const addTree = async (params) => await api.addTreeHandle(params);

//功能注册 删除树结构
export const deleteTree = async (id) => await api.deleteTreeHandle(id);

//功能注册 修改树结构
export const editTree = async (params, id) => await api.editTreeHandle(params, id);

//功能注册 权限授权(fap)
export const authCodeAll = async (params) => await api.authCodeAllHandle(params);

//功能权限绑定
export const abilityAuths = async (params) => await api.abilityAuthsHandle(params);

//查看功能绑定的权限码
export const abilityAuthCode = async (params, id) => await api.abilityAuthCodeHandle(params, id);

// 查询角色列表
export const getRolesList = async (params) => await api.getRolesListHandle(params);

// 查询拥有角色的机构列表
export const getRoleOrgList = async (params) => await api.getRoleOrgListHandle(params);

// 角色新增
export const addRole = async (params) => await api.addRoleHandle(params);

// 角色修改
export const modifyRole = async (params, id) => await api.modifyRoleHandle(params, id);

// 删除角色
export const delRoleList = async (id) => await api.delRoleListHandle(id);

// 查询角色权限列表(查询角色的功能列表)
export const getRoleAuthList = async (id) => await api.getRoleAuthListHandle(id);

// 根据ID查找角色
export const getRole = async (id) => await api.getRoleHandle(id);

// 查询角色名合法性
export const getRoleName = async (params, name) => await api.getRoleNameHandle(params, name);

// 查询具体某个参数
export const operateOneParam = async (params, name) => await api.operateOneParamHandle(params, name);

//功能配置树结构
export const abilityConfigTree = async (params) => await api.abilityConfigTreeHandle(params);

// 角色授权
export const postRoleAuth = async (params) => await api.postRoleAuthHandle(params);

//修改密码
export const modifyPassword = async (params) => await api.modifyPasswordHandle(params);

// 查询角色-权限范围域列表
export const searchAuthScopeRole = async (params) => await api.searchAuthScopeRoleHandle(params);

// 获取角色拥有的权限列表(范围域)
export const getAuthRoleList = async (id) => await api.getAuthRoleListHandle(id);

// 范围域删除
export const deleteAuthRole = async (id) => await api.deleteAuthRoleHandle(id);

// 范围域保存
export const saveAuthScope = async (params) => await api.saveAuthScopeHandle(params);

// 登录
export const login = async (params) => await api.loginHandle(params);

// 获取登录信息
export const getLoginInfo = async (params) => await api.getLoginInfoHandle(params);

// 查询机构下角色列表
export const getOrgRoleList = async (orgCode, params) => await api.getOrgRoleListHandle(orgCode, params);

// 查询参数、新增参数、更新参数
export const operateParams = async (params, method, opearType) =>
	await api.operateParamsHandle(params, method, opearType);

// 删除参数
export const deleteParams = async (id) => await api.deleteParamsHandle(id);

// 查询key对应子字典列表
export const dicKeyChildren = async (key) => await api.dicKeyChildrenHandle(key);

// 查询字典
export const getDictionaries = async (params) => await api.getDictionariesHandle(params);

// 查询子字典
export const getDicChildren = async (params, opearType) => await api.getDicChildrenHandle(params, opearType);

// 新增字典
export const addDictionary = async (params) => await api.addDictionaryHandle(params);

// 删除字典
export const deleteDictionary = async (id, level) => await api.deleteDictionaryHandle(id, level);

// 部分更新字典
export const updateDictionary = async (params) => await api.updateDictionaryHandle(params);

// 字典排序
export const dictionarySort = async (params) => await api.dictionarySortHandle(params);

// 查询范围域里的角色列表
export const getRolesScopeList = async (params) => await api.getRolesScopeListHandle(params);

//查询范围域里的岗位列表
export const getRolePositions = async (params) => await api.getRolePositionsHandle(params);

//查询岗位绑定的角色列表接口
export const getPositionsRoles = async (id) => await api.getPositionsRolesHandle(id);

//岗位绑定角色
export const addPositionsRoles = async (params) => await api.addPositionsRolesHandle(params);

//岗位解除角色绑定
export const delPositionsRoles = async (params) => await api.delPositionsRolesHandle(params);

//查询某机构下可配置某角色的用户列表接口(/roles/orgs/users)该接口只有fap下有
export const getRoleOrgUsers = async (params) => await api.getRoleOrgUsersHandle(params);

//查询范围域组的机构列表
export const getScopeGroupOrg = async (id) => await api.getScopeGroupOrgHandle(id);

//查询范围域组列表
export const getScopeGroupList = async (params) => await api.getScopeGroupListHandle(params);

//范围域组新增
export const addScopeGroup = async (params) => await api.addScopeGroupHandle(params);

//范围域组更新
export const updateScopeGroup = async (params) => await api.updateScopeGroupHandle(params);

//根据ID查询范围域组
export const getScopeGroupId = async (id) => await api.getScopeGroupIdHandle(id);

//范围域组删除
export const delScopeGroup = async (id) => await api.delScopeGroupHandle(id);

//根据机构查询范围域组(包含通用)
export const getAllScopeGroupsByOrg = async (orgCode) => await api.getAllScopeGroupsByOrgHandle(orgCode);

//登出
export const logout = async (params) => await api.logoutHandle(params);

//查询范围域
export const getScope = async (params) => await api.getScopeHandle(params);

//查询机构下的角色（包括通用角色）
export const getAllOrgRoleList = async (orgCode, params) => await api.getAllOrgRoleListHandle(orgCode, params);

//查询范围域是否重复
export const getScopeRepeat = async (params) => await api.getScopeRepeatHandle(params);