import React from "react";
import axios from "axios";
import { message, Modal } from "antd";
import CustomModal from "@/components/CustomModal";
import Login from "@/components/Login";
const cusModal = new CustomModal();

const NODE_ENV = process.env.NODE_ENV;
if (NODE_ENV === 'production') { //生产环境下读取配置文件的api
	axios.get('./serverConfig.json')
		.then(function (res) {
			axios.defaults.baseURL = res.data.api;
		});
} else {
	//dxp测试地址
	axios.defaults.baseURL = "http://172.1.2.19:6001/rest";

	//dxp准生产
	// axios.defaults.baseURL = "http://172.1.2.19:6006/rest";
}


//默认请求超时配置
axios.defaults.timeout = 20000;

axios.defaults.withCredentials = true;
axios.defaults.headers.common["Content-Type"] = "application/json;charset=UTF-8";

//请求拦截
axios.interceptors.request.use(
	(config) => {
		if (process.env.FRAME_WORK === "moon" && localStorage.getItem("moonToken")) {
			config.headers.Authorization = `Bearer ${localStorage.getItem("moonToken")}`;
		}
		return config;
	},
	(err) => {
		return Promise.reject(err);
	}
);

//响应拦截//
axios.interceptors.response.use(
	(res) => {
		if (res.data && !res.data.success) {
			if (res.data.errorCode === "401" && window.location.href.indexOf("login") === -1) {
				cusModal.show(
					<Modal visible={true} width={440} footer={null} closable={false}>
						<Login
							onSuccess={() => {
								cusModal.destroy();
								window.location.reload();
							}}
						/>
					</Modal>
				);
			} else {
				message.error(res.data.message, 2);
			}
		}
		return res;
	},
	(err) => {
		if (err.code === "ECONNABORTED" && err.message.indexOf("timeout") !== -1) {
			message.warning("数据正在处理中,请稍后重试", 2);
		} else if (err.message === "Network Error") {
			message.error("服务器异常 !!!", 2);
		} else if (err.message.indexOf("403") !== -1) {
			message.error("当前用户无权限访问此接口");
		} else {
			message.error(err.response.data.message, 2);
		}
		return Promise.reject(err);
	}
);

export default axios;
