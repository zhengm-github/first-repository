import request from "./request";

// mock
// import "../mock";

//登录接口
export const login = (params) => request("/logon", params, "POST");

//登出
export const logout = (params) => request("/logout", params, "GET");

//修改密码
export const modifyPassword = (params) => request(`/users/password`, params, "PATCH");

// 密码重置
export const resetPassword = (key) => request(`/users/password/${key}`, {}, "PATCH");


// 查询用户列表
export const getUserList = (params) => request("/users", params, "GET");

// 查询用户列表
export const getUserById = (key) => request(`/users/id/${key}`, {}, "GET");

// 查询完整机构列表
export const getAllOrg = (params) => request("/organizations/tree", params, "GET");

// 查询机构列表
export const getOrganizationsList = (params) => request("/organizations", params, "GET");

// 修改机构列表
export const modifyOrg = (params, key) => request(`/organizations/${key}`, params, "PUT");

// 查询ID查询机构信息
export const getOrgInfoById = (key) => request(`/organizations/id/${key}`, {}, "GET");

//新增机构
export const addOrg = (params) => request("/organizations", params, "POST");

//删除机构
export const deleteOrg = (keys) => request(`/organizations/${keys}`, {}, "DELETE");

//禁用启用机构
export const disableOrg = (params, keys) => request(`/organizations/enable-state/${keys}`, params, "PATCH");

// 查询角色列表
export const getRolesList = (params) => request("/roles", params, "GET");

// 查询范围域里的角色列表
export const getRolesScopeList = (params) => request("/scope-groups/rolelist", params, "GET");

// 查询角色复核列表
export const getRolesAuditList = (params) => request("/roles/audits", params, "GET");

// 根据ID查找角色
export const getRole = (id) => request(`/roles/id/${id}`, {}, "GET");

// 角色新增
export const addRole = (params) => request("/roles", params, "POST");

// 角色新增（提交复核）
export const addRoleAudit = (params) => request("/roles/audits", params, "POST");

// 角色修改
export const modifyRole = (params, id) => request(`/roles/${id}`, params, "PUT");

// 角色修改（提交复核）
export const modifyRoleAudit = (params, id) => request(`/roles/audits/${id}`, params, "PUT");

// 查询机构下角色列表
export const getOrgRoleList = (orgCode) => request(`/roles/orgs/${orgCode}`, {}, "GET");

// 查询角色用户列表
export const getUsersRole = (params) => request("/roles/users", params, "GET");

// 查询拥有角色的机构列表
export const getRoleOrgList = (params) => request("/roles/organizations", params, "GET");

//查询某机构下可配置某角色的用户列表接口(/roles/orgs/users)
export const getRoleOrgUsers = (params) => request("/roles/orgs/users", params, "GET");

// 查询角色名合法性
export const getRoleName = (params, name) => request(`/roles/name/${name}`, params, "GET");

// 角色授权
export const postRoleAuth = (params) => request("/roles-auths/grant/function", params, "POST");

// 查询角色权限列表
export const getRoleAuthList = (id) => request(`/roles-auths/grant/function/list/${id}`, {}, "GET");

// 角色批量赋予用户接口
export const addUsersRole = (params) => request("/roles-users", params, "POST");

// 角色用户关联关系删除
export const deleteUsersRole = (params) => request("/roles-users", params, "DELETE");

// 删除角色
export const delRoleList = (id) => request(`/roles/${id}`, {}, "DELETE");

// 删除角色（复核）
export const delRoleListAudit = (id) => request(`/roles/audits/${id}`, {}, "DELETE");

// 通过角色机构查询用户列表
export const getOrgsUsers = (params) => request("/roles-users", params, "GET");

// 获取角色拥有的权限列表
export const getAuthRoleList = (id) => request(`/roles/${id}/authcodes`, {}, "GET");

// 范围域删除
export const deleteAuthRole = (id) => request(`/authscope/${id}`, {}, "DELETE");

// 范围域保存
export const saveAuthScope = (params) => request("/authscope", params, "POST");

// 查询角色-权限范围域列表
export const searchAuthScopeRole = (params) => request("/authscope/role/authcode", params, "GET");

//用户停用启用
export const userIsEnable = (params, key) => request(`/users/enable-state/${key}`, params, "PATCH");

//用户修改
export const modifyUser = (params) => request("/users", params, "PUT");

//用户新增
export const addUser = (params) => request("/users", params, "POST");

//反激活
export const activateUser = (params, key) => request(`/users/active-state/${key}`, params, "PATCH");

//解锁
export const unlockUser = (key) => request(`/users/lock-state/${key}`, {}, "PATCH");

//用户自动匹配
export const userAutoMatch = (key) => request(`/users/filter-value/${key}`, {}, "GET");

//根据字典建查询
export const dicKey = (key) => request(`/dictionaries/children/key/${key}`, {}, "GET");

//查询权限列表
export const authCodes = (params) => request("/authcodes", params, "GET");

//权限删除
export const deleteCodes = (key) => request(`/authcodes/${key}`, {}, "DELETE");

//权限修改
export const modifyCodes = (params, key) => request(`/authcodes/${key}`, params, "PUT");

//新增权限
export const addCodes = (params) => request("/authcodes", params, "POST");
//根据id获取权限详情
export const codeInfo = (key) => request(`/authcodes/id/${key}`, {}, "GET");

// 查询key对应子字典列表
export const dicKeyChildren = (key) => request(`/dictionaries/children/key/${key}`, {}, "GET");

//功能注册树结构
export const abilityDomTree = (params) => request("/functions/list/top", params, "GET");

//功能注册树 查询选中的某个节点
export const abilityTree = (params) => request("/functions", params, "GET");

//功能配置树结构
export const abilityConfigTree = (params) => request("/functions/list/tops", params, "GET");

//功能注册 添加树结构
export const addTree = (params) => request("/functions", params, "POST");

//功能注册 删除树结构
export const deleteTree = (id) => request(`/functions/${id}`, {}, "DELETE");

//功能注册 修改树结构
export const editTree = (params, id) => request(`/functions/${id}`, params, "PUT");

//功能注册 权限授权
export const authCodeAll = (params) => request("/authcodes/all", params, "GET");

//功能权限绑定
export const abilityAuths = (params) => request("/functions/auths", params, "POST");

//查看功能绑定的权限码
export const abilityAuthCode = (params, id) => request(`/functions/${id}`, params, "GET");

//根据功能ID查找功能
export const searchAbility = (id) => request(`/functions/id/${id}`, {}, "GET");

// 查询参数、新增参数、更新参数
export const operateParams = (params, method) => request("/parameters", params, method);

// 查询具体某个参数
export const operateOneParam = (params, name) => request(`/parameters/name/${name}`, params, "GET");

// 删除参数
export const deleteParams = (id) => request(`/parameters/${id}`, {}, "DELETE");

// 查询日志
export const getBizLogs = (params) => request("/bizlogs", params, "GET");

// 查询日志详情
export const getBizLogDetail = (id) => request(`/bizlogs/${id}`, {}, "GET");

// 查询字典
export const getDictionaries = (params) => request("/dictionaries", params, "GET");

// 根据ID查询字典
export const getDictionaryById = (id) => request(`/dictionaries/${id}`, {}, "GET");

// 新增字典
export const addDictionary = (params) => request("/dictionaries", params, "POST");

// 删除字典
export const deleteDictionary = (id) => request(`/dictionaries/${id}`, {}, "DELETE");

// 部分更新字典
export const updateDictionary = (params) => request("/dictionaries", params, "PATCH");

// 查询子字典
export const getDicChildren = (params) => request("/dictionaries/children", params, "GET");

// 字典排序
export const dictionarySort = (params) => request("/dictionaries/order", params, "POST");

//删除菜单
export const deleteMenus = (id) => request(`/menus/${id}`, {}, "DELETE");

//启用禁用菜单
export const enableMenus = (params) => request("/menus/enable", params, "POST");

//菜单排序
export const dragMenus = (params) => request("/menus/order", params, "POST");

//请求菜单接口
export const menus = (params) => request("/menus", params, "GET");

//请求菜单接口
export const authMenus = () => request("/menus/getchilds", {}, "GET");

//根据id查询菜单详情
export const getMenuInfo = (id) => request(`/menus/id/${id}`, {}, "GET");

//新增菜单

export const addMenus = (params) => request("/menus", params, "POST");

//编辑菜单

export const editMenus = (params) => request("/menus", params, "PUT");

//查询岗位
export const getRolePositions = (params) => request("/roles/positions", params, "GET");