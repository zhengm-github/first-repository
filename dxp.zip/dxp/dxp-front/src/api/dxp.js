import request from "./request";

//查询应用系统列表接口
export const getApps = (params) => request("/apps", params, "GET");

// 查询全部应用系统
export const getAllApps = () => request("/apps/all", {}, "GET");

//根据id/code查询应用系统接口
export const getAppsById = (appId) => request(`/apps/pattern/id/${appId}`, {}, "GET");

//创建应用系统接口
export const addApps = (params) => request("/apps", params, "POST");

//修改应用系统接口
export const modifyApps = (params, appId) => request(`/apps/${appId}`, params, "PUT");

//删除应用系统接口
export const deleteApps = (appIds) => request(`/apps/${appIds}`, {}, "DELETE");

//查询应用系统的公钥列表接口
export const getAppPubkeys = (params) => request("/apps/apppublickeys", params, "GET");

//配置应用公钥接口
export const configAppPubkeys = (params) => request("/apps/apppublickeys", params, "POST");

//修改应用公钥接口
export const modifyAppPubkeys = (params, appPublicKeyId) =>
	request(`/apps/apppublickeys/${appPublicKeyId}`, params, "PUT");

//删除应用公钥接口
export const deleteAppPubkeys = (appPubIds) => request(`/apps/apppublickeys/${appPubIds}`, {}, "DELETE");

/****************** 服务模块 接口 **************************/

// 创建服务模块接口 && 查询服务模块数据
export const createService = (params, method) => request("/svcbundles", params, method);

// 根据id查询服务模块
export const getServiceBundle = (id) => request(`/svcbundles/id/${id}`, {}, "get");

// 删除服务模块 && 修改
export const delServicePort = (id, params, method) => request(`/svcbundles/${id}`, params, method);

// 启用 && 禁用服务模块
export const enableService = (params, ids) => request(`/svcbundles/status/${ids}`, params, "PATCH");

// 查询接入服务接口 && 创建接入服务接口
export const AccessServicePort = (params, method) => request("/svcbundles/inbounds", params, method);

// 删除接入服务接口
export const deleteInterService = (id) => request(`/svcbundles/inbounds/${id}`, {}, "DELETE");

// 根据接入服务接口 id 查询数据
export const searchAccessService = (id) => request(`/svcbundles/inbounds/id/${id}`, {}, "GET");

// 接入服务  绑定
export const serviceBind = (params) => request("/svcbundles/inbounds/bind", params, "POST");

// 接入服务  解绑
export const serviceUnbind = (params) => request("/svcbundles/inbounds/unbind", params, "POST");

// 查询绑定的接入服务接口
export const searchBindPort = (params) => request("/svcbundles/inbounds/part", params, "GET");

// 启用 && 禁用
export const enableOrBan = (params, ids) => request(`/svcbundles/inbounds/status/${ids}`, params, "PATCH");

// 修改接入服务
export const editInterService = (params, id) => request(`/svcbundles/inbounds/${id}`, params, "PUT");

// 查询接入/接出接口请求/响应报文
export const getMessagesById = (id, serviceType, messageType) => {
	return request(
		`/svcbundles/${serviceType}bounds-prop/${messageType}/${serviceType.slice(0, 1)}bsid/${id}`,
		{},
		"GET"
	);
};

// 新增接入/接出接口请求/响应报文
export const addMessage = (params, serviceType, messageType) =>
	request(`/svcbundles/${serviceType}bounds-prop/${messageType}`, params, "POST");

// 修改接入/接出接口请求/响应报文
export const modifyMessage = (params, serviceType, messageType, id) =>
	request(`/svcbundles/${serviceType}bounds-prop/${messageType}/id/${id}`, params, "PUT");

// 删除接入/接出接口请求/响应报文
export const deleteMessage = (serviceType, messageType, id) =>
	request(`/svcbundles/${serviceType}bounds-prop/${messageType}/${id}`, {}, "DELETE");

// 根据接入/接出id查询协议解析规划
export const getPlanDetailById = (params, id, serviceType) =>
	request(`/proc/plan/${serviceType.slice(0, 1)}bs/${id}`, params, "GET");

// 创建协议解析规划
export const createProcPlan = (params) => request(`/proc/plan`, params, "POST");

// 修改协议解析规划
export const modifyProcPlan = (params, id) => request(`/proc/plan/${id}`, params, "PUT");

// 根据规划id查询解析规则
export const getRulesListById = (id) => request(`/proc/rule/plan/${id}`, {}, "GET");

// 新增协议解析规则
export const addProcRule = (params) => request(`/proc/rule`, params, "POST");

// 修改协议解析规则
export const modifyProcRule = (params, id) => request(`/proc/rule/${id}`, params, "PUT");

// 删除协议解析规则
export const deleteProcRule = (id) => request(`/proc/rule/${id}`, {}, "DELETE");

// 创建接出服务 && 查询 接出服务
export const addOutService = (params, method) => request("/svcbundles/outsvcbounds", params, method);

// 修改 接出服务
export const delUpdateOutService = (id, params, method) =>
	request(`/svcbundles/outsvcbounds/${id}`, params, method);

// 审计服务平台接口

// 绑定接出参数
export const bindOutParams = () => request("/svcbundles/parambinds", {}, "POST");

// 绑定接出结果
export const bindOutResult = () => request("/svcbundles/resultbinds", {}, "POST");

// 根据服务ID查询参数绑定列表
export const searchIdParams = (id) => request(`/svcbundles/parambinds/id/${id}`, {}, "GET");

// 根据服务ID查询结果绑定列表
export const searchIdResult = (id) => request(`/svcbundles/resultbinds/id/${id}`, {}, "GET");

// 根据服务模块id查询响应报文绑定列表
export const requestMessages = (id) => request(`/svcbundles/requestmessages/id/${id}`, {}, "GET");

// 根据服务模块id查询响应报文绑定列表
export const responseMessages = (id) => request(`/svcbundles/responsemessages/id/${id}`, {}, "GET");

//请求报文绑定配置接口
export const svcbundlesRequest = (params) => request(`/svcbundles/requestmessages`, params, "POST");

// 响应报文绑定配置接口
export const svcbundlesResponse = (params) => request(`/svcbundles/responsemessages`, params, "POST");

//根据id查询接出服务✅
export const getOutsvcboundsId = (id) => request(`/svcbundles/outsvcbounds/id/${id}`, {}, "GET");

// 启用/禁用接出服务接口
export const enableOutsvcbounds = (params,ids) => request(`/svcbundles/outsvcbounds/status/${ids}`, params, "PATCH");

// 查询接出接口请求报文
export const getOutRequestMessage = (params) => request(`/svcbundles/outbounds-prop/req`, params, "GET");

// 查询接出接口响应报文
export const getOutResponseMessage = (params) => request(`/svcbundles/outbounds-prop/res`, params, "GET");

// 根据接出接口查询请求报文
export const getOutRequestMessageId = (id) => request(`/svcbundles/outbounds-prop/req/obsid/${id}`, {}, "GET");

// 根据接出接口查询响应报文
export const getOutResponseMessageId = (id) => request(`/svcbundles/outbounds-prop/res/obsid/${id}`, {}, "GET");

// 查询接出接口待配置的请求属性
export const getConfigReq = (id) => request(`/svcbundles/outbounds-prop/configreq/obsid/${id}`, {}, "GET");

// 查询接入接口待配置的响应属性
export const getConfigRes = (id) => request(`/svcbundles/inbounds-prop/configres/obsid/${id}`, {}, "GET");
/******************** 结束 *******************************/

//查询应用服务列表接口
export const getAppServers = (params) => request("/appservers", params, "GET");

//根据id/code查询应用服务接口
export const getAppServersById = (appServerId) => request(`/appservers/pattern/id/${appServerId}`, {}, "GET");

//创建应用服务接口
export const addAppServers = (params) => request("/appservers", params, "POST");

// 根据接入接口id 查询服务模块数据
export const portIdSearchData = (id) => request(`/svcbundles/inbounds/svcbound-id/${id}`, {}, "GET");

//修改应用服务接口
export const modifyAppServers = (params, appServerId) => request(`/appservers/${appServerId}`, params, "PUT");

//删除应用服务接口
export const deleteAppServers = (appServerIds) => request(`/appservers/${appServerIds}`, {}, "DELETE");

// 查询服务授权码列表
export const getAccesskeys = (params) => request("accesskeys", params, "GET");

// 根据 id 查询服务授权码
export const getAccesskeyById = (id) => request(`/accesskeys/id/${id}`, {}, "GET");

// 新建服务授权码
export const addAccesskey = (params) => request("accesskeys", params, "POST");

// 修改服务授权码
export const modifyAccesskey = (id, params) => request(`/accesskeys/${id}`, params, "PUT");

// 删除服务授权码
export const deleteAccesskey = (ids) => request(`/accesskeys/${ids}`, {}, "DELETE");

// 根据id查询授权key密文
export const getAccesskeySecret = (id) => request(`/accesskeys/secret/${id}`, {}, "GET");

//根据服务模块ID查询接入服务接口列表
export const getSvcbundlesInbounds = (id) => request(`/svcbundles/inbounds/svcbound-id/${id}`, {}, "GET");

/****************** 单位管理 接口 **************************/
//查询应用服务列表接口
export const getUnits = (params) => request("/units", params, "GET");

//根据id/code查询应用服务接口
export const getUnitsById = (unitsId) => request(`/units/id/${unitsId}`, {}, "GET");

//创建应用服务接口
export const addUnit = (params) => request("/units", params, "POST");

//修改应用服务接口
export const modifyUnit = (params, unitsId) => request(`/units/${unitsId}`, params, "PUT");

//删除应用服务接口
export const deleteUnits = (units) => request(`/units/${units}`, {}, "DELETE");

/****************** 工具库 接口 **************************/
//获取函数
export const getFunctionLibrary = () => request(`/svcbundles/function/library`, {}, "GET");

//获取协议
export const getAgreementLibrary = () => request(`/svcbundles/agreement/library`, {}, "GET");

//表达式解析
export const postExpResolve = (params) => request(`/svcbundles/exp/resolve`, params, "POST");

//表达式组装
export const postExpPack = (params) => request(`/svcbundles/exp/pack`, params, "POST");
// 查询加密库
export const getEncryptLibrary = () => request(`/svcbundles/encrypt/library`, {}, "GET");

// 查询签名库
export const getSignatureLibrary = () => request(`/svcbundles/signature/library`, {}, "GET");

// 查询编码库
export const getEncoderLibrary = () => request(`/svcbundles/encoder/library`, {}, "GET");
/******************  结束 **************************/
