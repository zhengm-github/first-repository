import request from "./request";

// 查询日志
export const getBizLogsHandle = (params) => request("/bizlogs", params, "GET");

// 根据id查询日志
export const getBizLogDetailHandle = (id) => request(`/bizlogs/${id}`, {}, "GET");

// 请求菜单接口
export const menusHandle = (params) => request("/menus", params, "GET");

// 删除菜单
export const deleteMenusHandle = (id) => request(`/menus/${id}`, {}, "DELETE");

// 启用禁用菜单
export const enableMenusHandle = (params) => request("/menus/enable", params, "POST");

// 菜单排序
export const dragMenusHandle = (params) => request("/menus/order", params, "POST");

// 根据id查询菜单详情
export const getMenuInfoHandle = async (id) => request(`/menus/id/${id}`, {}, "GET");

// 新增菜单
export const addMenusHandle = async (params) => request("/menus", params, "POST");

// 编辑菜单
export const editMenusHandle = async (params) => request("/menus", params, "PUT");

// 查询用户列表
export const getUserListHandle = (params) => request("/users", params, "GET");

// 根据ID获取用户信息
export const getUserByIdHandle = (key) => request(`/users/id/${key}`, {}, "GET");

//用户新增
export const addUserHandle = (params) => request("/users", params, "POST");

//用户修改
export const modifyUserHandle = (params) => request("/users", params, "PUT");

//用户停用启用
export const userIsEnableHandle = (params, key) => request(`/users/enable-state/${key}`, params, "PATCH");

//解锁
export const unlockUserHandle = (key) => request(`/users/lock-state/${key}`, {}, "PATCH");

//反激活
export const activateUserHandle = (params, key) => request(`/users/active-state/${key}`, params, "PATCH");

//用户自动匹配
export const userAutoMatchHandle = (key) => request(`/users/filter-value/${key}`, {}, "GET");

// 密码重置
export const resetPasswordHandle = (key) => request(`/users/password/${key}`, {}, "PATCH");

// 查询机构列表
export const getOrganizationsListHandle = (params) => request("/organizations", params, "GET");

// 查询完整机构列表
export const getAllOrgHandle = (params) => request("/organizations/tree", params, "GET");

// 查询ID查询机构信息
export const getOrgInfoByIdHandle = (key) => request(`/organizations/id/${key}`, {}, "GET");

// 修改机构列表
export const modifyOrgHandle = (params, key) => request(`/organizations/${key}`, params, "PUT");

//新增机构
export const addOrgHandle = (params) => request("/organizations", params, "POST");

//删除机构
export const deleteOrgHandle = (keys) => request(`/organizations/${keys}`, {}, "DELETE");

//禁用启用机构
export const disableOrgHandle = (params, keys) => request(`/organizations/enable-state/${keys}`, params, "PATCH");

// 角色批量赋予用户接口
export const addUsersRoleHandle = (params) => request("/roles-users", params, "POST");

// 角色用户关联关系删除
export const deleteUsersRoleHandle = (params) => request("/roles-users", params, "DELETE");

//功能注册树结构
export const abilityDomTreeHandle = (params) => request("/functions/list/top", params, "GET");

//功能注册树 查询选中的某个节点
export const abilityTreeHandle = (params) => request("/functions", params, "GET");

//根据功能ID查找功能
export const searchAbilityHandle = (id) => request(`/functions/id/${id}`, {}, "GET");

//功能注册 添加树结构
export const addTreeHandle = (params) => request("/functions", params, "POST");

//功能注册 删除树结构
export const deleteTreeHandle = (id) => request(`/functions/${id}`, {}, "DELETE");

//功能注册 修改树结构
export const editTreeHandle = (params, id) => request(`/functions/${id}`, params, "PUT");

//功能注册 权限授权
export const authCodeAllHandle = (params) => request("/authcodes/all", params, "GET");

//功能权限绑定
export const abilityAuthsHandle = (params) => request("/functions/auths", params, "POST");

//查看功能绑定的权限码
export const abilityAuthCodeHandle = (params, id) => request(`/functions/${id}`, params, "GET");

// 查询角色列表
export const getRolesListHandle = (params) => {
	if (params.roleType === 'P') {
		return request("/roles/positions", params, "GET");
	} else {
		return request("/roles", params, "GET");
	}
}

// 查询拥有角色的机构列表
export const getRoleOrgListHandle = async (params = {}) => {
	const callBack = () => {
		if(params.roleType === 'P') {
			return request("roles/positions/organizations", {}, "GET");
		} else {
			return request("/roles/organizations", params, "GET");
		}
	}
	const res = await callBack();
	return res;
}

// 角色新增
export const addRoleHandle = (params) => request("/roles", params, "POST");

// 角色修改
export const modifyRoleHandle = (params, id) => request(`/roles/${id}`, params, "PUT");

// 删除角色
export const delRoleListHandle = (id) => request(`/roles/${id}`, {}, "DELETE");

// 查询角色权限列表(查询角色的功能列表)
export const getRoleAuthListHandle = (id) => request(`/roles-auths/grant/function/list/${id}`, {}, "GET");

// 根据ID查找角色
export const getRoleHandle = (id) => request(`/roles/id/${id}`, {}, "GET");

// 查询角色名合法性
export const getRoleNameHandle = (params, name) => request(`/roles/name/${name}`, params, "GET");

// 查询具体某个参数
export const operateOneParamHandle = (params, name) => request(`/parameters/name/${name}`, params, "GET");

//功能配置树结构
export const abilityConfigTreeHandle = (params) => request("/functions/list/tops", params, "GET");

// 角色授权
export const postRoleAuthHandle = (params) => request("/roles-auths/grant/function", params, "POST");

//修改密码
export const modifyPasswordHandle = (params) => request(`/users/password`, params, "PATCH");

// 查询角色-权限范围域列表
export const searchAuthScopeRoleHandle = (params) => request("/authscope/role/authcode", params, "GET");

// 获取角色拥有的权限列表(范围域)
export const getAuthRoleListHandle = (id) => request(`/roles/${id}/authcodes`, {}, "GET");

// 范围域删除
export const deleteAuthRoleHandle = (id) => request(`/authscope/${id}`, {}, "DELETE");

// 范围域保存
export const saveAuthScopeHandle = (params) => request("/authscope", params, "POST");

// 登录
export const loginHandle = (params) => request("/logon", params, "POST");

// 查询机构下角色列表
export const getOrgRoleListHandle = async (orgCode,params = { roleType: 'R' }) => {
	const callBack = () => {
		//查询机构下岗位列表
		if (params.roleType === 'P') {
			return request(`/roles/positions/orgs/${orgCode}`, {}, "GET");
		} else {
			return request(`/roles/orgs/${orgCode}`, {}, "GET");
		}
	}
	const res = await callBack();
	return res;
}

// 查询参数、新增参数、更新参数
export const operateParamsHandle = (params, method) => request("/parameters", params, method);

// 删除参数
export const deleteParamsHandle = (id) => request(`/parameters/${id}`, {}, "DELETE");

//根据字典建查询
export const getDicKeyHandle = (key) => request(`/dictionaries/children/key/${key}`, {}, "GET");

// 查询key对应子字典列表
export const dicKeyChildrenHandle = (key) => request(`/dictionaries/children/key/${key}`, {}, "GET");

// 查询字典
export const getDictionariesHandle = (params) => request("/dictionaries", params, "GET");

// 查询子字典
export const getDicChildrenHandle = (params) => request("/dictionaries/children", params, "GET");

// 新增字典
export const addDictionaryHandle = (params) => request("/dictionaries", params, "POST");

// 删除字典
export const deleteDictionaryHandle = (id) => request(`/dictionaries/${id}`, {}, "DELETE");

// 部分更新字典
export const updateDictionaryHandle = (params) => request("/dictionaries", params, "PATCH");

// 字典排序
export const dictionarySortHandle = (params) => request("/dictionaries/order", params, "POST");

// 查询范围域里的角色列表
export const getRolesScopeListHandle = (params) => request("/scope-groups/rolelist", params, "GET");

//查询范围域里的岗位列表
export const getRolePositionsHandle = (params) => request("/roles/positions", params, "GET");

//查询岗位绑定的角色列表接口
export const getPositionsRolesHandle = (id) => request(`/roles/positions-roles/${id}`,{},"GET");

//岗位绑定角色
export const addPositionsRolesHandle = (params) => request("/roles/positions-roles", params, "POST");

//岗位解除角色绑定
export const delPositionsRolesHandle = (params) => request("/roles/positions-roles", params, "DELETE");

//请求菜单接口
export const getAuthMenusHandle = () => request("/menus/getchilds", {}, "GET");

//查询某机构下可配置某角色的用户列表接口(/roles/orgs/users)
export const getRoleOrgUsersHandle = (params) => request("/roles/orgs/users", params, "GET");

//查询范围域组的机构列表
export const getScopeGroupOrgHandle = (params = {}) => request(`/scope-groups/orglist`, params, "GET");

// 查询范围域组列表
export const getScopeGroupListHandle = (params = {}) => request(`/scope-groups`, params, "GET");

//范围域组新增
export const addScopeGroupHandle = (params = {}) => request(`/scope-groups`, params, "POST");

//范围域组更新
export const updateScopeGroupHandle = (params = {}) => request(`/scope-groups/${params.scopeGroupId}`, params, "PUT");

//根据ID查询范围域组
export const getScopeGroupIdHandle = (id) => request(`/scope-groups/${id}`, {}, "GET");

//范围域组删除
export const delScopeGroupHandle = (id) => request(`/scope-groups/${id}`, {}, "DELETE");

//根据机构查询范围域组(包含通用)
export const getAllScopeGroupsByOrgHandle = (orgCode) => request(`/scope-groups/code/${orgCode}`, {}, "GET");

//登出
export const logoutHandle =(params) => request("/logout", params, "GET");

//查询范围域
export const getScopeHandle = async (params) => {
	const callBack = () => {
		if(params.targetScopeType === 'custom_app') {
			params.targetScopeType = 'custom'
		} else if (params.targetScopeType === 'post') {
			params.targetScopeType = 'position'
		}
		const { source,sourceId,targetScopeType, ...param} = {...params, scopeGroupId:params.sourceId, whereFrom:'from_scope_group_manager'}
		return request(`/authscope/${params.targetScopeType}`, param, "GET");
	}
	const resultHandle = (res) => {
		const { result } = res;
		return {
			...res,
			result: [result]
		}
	}
	const res = await callBack();
	if (res.success && res.result) {
		return resultHandle(res);
	}
	return res;
}
//查询机构下的角色（包括通用角色）
export const getAllOrgRoleListHandle = async (orgCode,params = { roleType: 'R' }) => {
	const callBack = () => {
		//查询机构下岗位列表
		if (params.roleType === 'P') {
			return request(`/roles/positions/orgs/${orgCode}`, {}, "GET");
		} else {
			return request(`/roles/orgs/${orgCode}`, {}, "GET");
		}
	};
	const res = await callBack();
	return res;
};