import * as moon from './moon.js';
import * as fap from './fap.js';

const FRAME_WORK = process.env.FRAME_WORK;
/* 判断是哪个模块 */
const compare = () => {
	if (FRAME_WORK === 'moon') {
		return moon;
	} else if (FRAME_WORK === 'fap') {
		return fap;
	}
}
const version = compare();
export default version;