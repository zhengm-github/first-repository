import axios from "./axios";
import qs from "qs";

export default async (url, params = {}, method = "POST", isUpload = false) => {
	method = method.toUpperCase();
	if (method === "GET" || method === "DELETE") {
		const res = await axios.request({
			url,
			method,
			params
		});
		return res.data;
	} else if (method === "POST" || method === "PATCH" || method === "PUT") {
		let noramal = {
			url,
			method,
			data: params,
			transformRequest: [
				function(data) {
					if(url.indexOf('/svcbundles/exp/pack') > -1) {
						return qs.stringify(data, { arrayFormat: "repeat" });
					}
					return qs.stringify(data, { arrayFormat: "brackets" });
				}
			]
		};
		if (process.env.FRAME_WORK === "moon") {
			const { transformRequest, ...obj } = noramal;
			noramal = obj;
		}
		const upload = {
			url,
			method,
			data: params,
			headers: {
				"Content-Type": "multipart/form-data"
			}
		};
		const res = await axios.request(isUpload ? upload : noramal);
		return res.data;
	}
};
