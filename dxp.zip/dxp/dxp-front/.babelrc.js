const plugindecorators = [
	"@babel/plugin-proposal-decorators",
	{
		legacy: true
	}
];
const pluginConfig = [
	[
		"import",
		{
			libraryName: "antd",
			libraryDirectory: "es",
			style: true
		}
	],
	plugindecorators
];

module.exports = {
	presets: [["@babel/preset-env", { modules: false }], "react-app"],
	env: {
		test: {
			presets: ["@babel/preset-env", "react-app"],
			plugins: [plugindecorators]
		},
		development: {
			plugins: pluginConfig
		},
		production: {
			plugins: pluginConfig
		}
	}
};
