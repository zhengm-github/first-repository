package com.sunyard.dxp.utils;

import com.sunyard.dxp.common.entity.Agreement;
import org.reflections.Reflections;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Thud
 * @date 2020/2/26 13:36
 * 协议初始化
 */
@Configuration
public class InitAgreementLibrary {

    @Bean("agreements")
    public List<Agreement> init() {
        Reflections f = new Reflections("com.sunyard.dxp.message.service.impl");
        Set<Class<?>> set = f.getTypesAnnotatedWith(AgreementLibrary.class);
        List<Agreement> agreements = new ArrayList<>();
        for (Class<?> c : set) {
            AgreementLibrary annotation = c.getAnnotation(AgreementLibrary.class);
            Agreement agreement = new Agreement();
            agreement.setCode(annotation.code());
            agreement.setName(annotation.name());
            agreements.add(agreement);
        }
        return agreements;
    }
}
