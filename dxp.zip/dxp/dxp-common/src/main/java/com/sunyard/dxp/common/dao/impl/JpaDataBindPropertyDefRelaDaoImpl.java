package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.DataBindPropertyDefRelaDao;
import com.sunyard.dxp.common.entity.DataBindPropertyDefRela;
import com.sunyard.dxp.common.qo.DataBindPropertyDefRelaQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 接出数据属性绑定配置 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:44:42 CST 2019
 */
@Repository
public class JpaDataBindPropertyDefRelaDaoImpl  extends JpaBaseDaoImpl<DataBindPropertyDefRela,String,DataBindPropertyDefRelaQo> implements DataBindPropertyDefRelaDao{

    @Override
    public void deleteByPropertyId(String propertyId) {
        this.executeUpdate("delete from DataBindPropertyDefRela as obj where obj.dataPropertyId = ?", propertyId);
    }

    @Override
    public void deleteByPropertyIdAndConfig(String propertyId, String configId) {
        this.executeUpdate(
                "delete from DataBindPropertyDefRela as obj where obj.dataPropertyId = ? and obj.dataBindConfigId = ? "
                , propertyId, configId);
    }

    @Override
    public List<DataBindPropertyDefRela> findByDataBindConfigId(String dataBindConfigId) {
        return this.find("Select obj from DataBindPropertyDefRela as obj where obj.dataBindConfigId = ? ", dataBindConfigId);
    }
}
