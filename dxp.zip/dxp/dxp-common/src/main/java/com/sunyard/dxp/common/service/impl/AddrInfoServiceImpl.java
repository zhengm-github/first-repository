package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.AddrInfoDao;
import com.sunyard.dxp.common.entity.AddrInfo;
import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.dxp.common.service.AddrInfoService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import com.sunyard.frameworkset.util.DateUtil;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * 地址信息管理 service
 * <p>
 * Author: Created by code generator
 * Date: Thu Jun 11 16:10:14 CST 2020
 */
@Service
public class AddrInfoServiceImpl extends BaseServiceImpl< AddrInfo, String, AddrInfoQo > implements AddrInfoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AddrInfoServiceImpl.class);

    @Autowired
    private AddrInfoDao addrInfoDao;

    private String timeFormat = "yyyyMMddHHmmss" ;

    @Override
    @Transactional( rollbackFor = Exception.class )
    public synchronized String findURL(String sendDirect, String busiType) {

        List< AddrInfo > addrInfoList = addrInfoDao.findByDirectAndType(sendDirect, busiType);
        if (CollectionUtils.isNotEmpty(addrInfoList)) {
            // 最久没有被调用的地址
            AddrInfo addrInfo = addrInfoList.get(0);
            addrInfo.setCallTime(DateUtil.date2Str(new Date(), timeFormat));
            addrInfoDao.update(addrInfo);  // 更新当前时间为调用时间
            LOGGER.info("获取到地址：[{}], sendDirect = [{}], busiType = [{}] ", addrInfo.getUrl(), sendDirect, busiType);
            return addrInfo.getUrl();
        }
        LOGGER.info("DXP_ADDR_INFO 表中没有可以使用的地址, sendDirect = [{}], busiType = [{}] ", sendDirect, busiType);
        return "";
    }

    @Override
    @Transactional( rollbackFor = Exception.class )
    public List< AddrInfo > findAllByType(String sendDirect, String busiType) {

        List< AddrInfo > addrInfoList = addrInfoDao.findByDirectAndType(sendDirect, busiType);
        return addrInfoList;
    }
}
