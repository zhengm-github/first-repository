package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.common.qo.ProcotolResolveRuleQo;

import java.util.List;

/**
 * 协议解析规则 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:59 CST 2020
 */
public interface ProcotolResolveRuleService extends BaseService<ProcotolResolveRule, String, ProcotolResolveRuleQo> {

    /**
     * 根据name查询
     * @param name
     * @return
     */
    ProcotolResolveRule findByName(String name) ;

    /**
     * 根据detailName
     * @param detailName
     * @return
     */
    ProcotolResolveRule findByDetailName(String detailName) ;
    /**
     * 通过协议规范planid，获取协议规范
     * @param planId
     */
    List<ProcotolResolveRule> findByPlanId(String planId);

    /**
     * 删除这个节点有关的所有节点，根据parentId
     * @param parentIds
     */
    void deleteByParentIds(String... parentIds);

    /**
     * 根据id查询子级解析规则
     * @param id
     * @return
     */
    List<ProcotolResolveRule> findChildRule(String id);

    /**
     * 获取接入服务的协议规则
     * @param ibsId
     */
    List<ProcotolResolveRule> findByIbsId(String ibsId, String dataKind);

    /**
     * 获取接出服务的协议规则
     * @param obsId
     */
    List<ProcotolResolveRule> findByObsId(String obsId, String dataKind);
}
