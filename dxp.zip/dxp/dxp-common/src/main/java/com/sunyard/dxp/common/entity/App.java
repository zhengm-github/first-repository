package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 应用系统
* Author: Created by code generator
* Date: Tue Dec 24 10:41:41 CST 2019
*/
@Entity
@Table(name = "DXP_APP")
public class App implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8334990525834310834L;

    /** 应用ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "APP_ID")
    private String appId;

    /** 应用编码 */
    @Column( name = "APP_CODE")
    private String appCode;

    /** 应用名称 */
    @Column( name = "APP_NAME")
    private String appName;

    /** 应用备注 */
    @Column( name = "APP_MEMO")
    private String appMemo;

    /** 是否加密 */
    @Column( name = "ENCRYPTED")
    private Boolean encryted;

    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "app")
    private Set<AppPublicKey> appPublicKeys;

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppMemo() {
        return appMemo;
    }

    public void setAppMemo(String appMemo) {
        this.appMemo = appMemo;
    }

    public Boolean getEncryted() {
        return encryted;
    }

    public void setEncryted(Boolean encryted) {
        this.encryted = encryted;
    }

    public Set<AppPublicKey> getAppPublicKeys() {
        return appPublicKeys;
    }

    public void setAppPublicKeys(Set<AppPublicKey> appPublicKeys) {
        this.appPublicKeys = appPublicKeys;
    }

}
