package com.sunyard.dxp.message.service.impl;

import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description 定长报文头+签名域+XML报文
 * @Author zhangxin
 * @Date 2020/1/10 17:27
 * @Version 1.0
 */
@Service( "fixedAndSignAndXmlResolve" )
@AgreementLibrary( code = "fixedAndSignAndXml", name = "定长报文头+签名域+XML报文" )
public class RequestResolveServiceFixedAndSignAndXmlImpl implements RequestResolveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestResolveServiceFixedAndSignAndXmlImpl.class);

    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Autowired
    @Qualifier( "regionSign" )
    private SignService regionSignService;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 3) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        // 拆分报文
        String[] splitMessage = splitMessage(requestResolveDto.getMessage(), requestResolveDto.getEncoding(), ruleList);

        // 解析之前先校验sign (sign 和 xml在一起)
        String xmlBody = regionSignService.validateSign(signDto, splitMessage[ 1 ], "");

        // 定长报文规则
        List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(ruleList.get(0).getChildRules());
        // xml报文规则
        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(ruleList.get(2).getChildRules());
        Map< String, Object > head =
                baseResolveService.execute(headRules, splitMessage[ 0 ], requestResolveDto.getEncoding());
        Map< String, Object > body =
                baseResolveXmlService.execute(bodyRules, xmlBody, requestResolveDto.getEncoding());
        body.putAll(head);
        return body;
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();

        List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(ruleList.get(0).getChildRules());

        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(ruleList.get(2).getChildRules());
        Map< String, Object > fsxMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        Map< String, Object > headResult =
                baseResolveService.mapExecute(headRules, map, requestResolveDto.getEncoding());
        Map< String, Object > bodyResult =
                baseResolveXmlService.mapExecute(bodyRules, map, requestResolveDto.getEncoding());

        String xmlBody = bodyResult.get(MsgKeys.PACKAGE).toString();

        // 组装签名部分
        Map< String, String > dataMap = regionSignService.makeSign(signDto, xmlBody);
        sb.append(headResult.get(MsgKeys.PACKAGE))
                .append(dataMap.get("xmlBody"));
        fsxMap.put(MsgKeys.PACKAGE, sb.toString());
        return fsxMap;
    }

    /**
     * 分割内容
     *
     * @param message
     * @param encoding
     * @param ruleList
     * @return
     */
    public String[] splitMessage(String message, String encoding, List< ProcotolResolveRule > ruleList) {
        String[] result = new String[ 3 ];
        ProcotolResolveRule fixedRule = ruleList.get(0);
        ProcotolResolveRule signRule = ruleList.get(1);
        try {
            if (EncoderEnum.ISO88591.getCode().equals(encoding)) {
                encoding = "GB18030";
            }
            byte[] messageBytes = message.getBytes(encoding);
            int fixedStart = fixedRule.getBeginIndex();
            int fixedLength = fixedRule.getEndIndex() - fixedStart + 1;
            // 定长报文头
            result[ 0 ] = new String(messageBytes, fixedStart, fixedLength, encoding).trim();

            // sign + xml的密文
            int signStart = signRule.getBeginIndex();
            int signLength = messageBytes.length - signStart;
            result[ 1 ] = new String(messageBytes, signStart, signLength, encoding).trim();

        } catch (UnsupportedEncodingException e) {
            LOGGER.info("解析数据失败！message=[{}], e=[{}]", message, e);
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
        }
        return result;
    }
}
