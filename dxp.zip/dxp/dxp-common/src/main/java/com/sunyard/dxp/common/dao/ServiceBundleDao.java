package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.ServiceBundle;
import com.sunyard.dxp.common.qo.ServiceBundleQo;
import com.sunyard.frameworkset.core.dao.BaseDao;


/**
 * 服务模块 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:57:12 CST 2019
 */
public interface ServiceBundleDao extends BaseDao< ServiceBundle, String, ServiceBundleQo > {

    /**
     * 删除服务列表
     * @param serviceBundleId
     */
    void deleteSvcBundleById(String serviceBundleId);

    /**
     * 根据code查询服务列表
     * @param code
     * @return
     */
    ServiceBundle findSvcbundleByCode(String code);
}
