package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
* 接入服务模块中间表
* Author: Created by code generator
* Date: Tue Dec 24 10:49:44 CST 2019
*/
@Entity
@Table(name = "DXP_SVC_MODEL_RELA")
public class SvcModelRela implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7113464830914603887L;

    /** 服务模块ID */
    @Id
    @Column( name = "SERVICE_BUNDLE_ID")
    private String serviceBundleId;

    /** 接入服务接口ID */
    @Id
    @Column( name = "IN_BOUND_SVC_ID")
    private String inBoundSvcId;

    public String getServiceBundleId() {
        return serviceBundleId;
    }

    public void setServiceBundleId(String serviceBundleId) {
        this.serviceBundleId = serviceBundleId;
    }

    public String getInBoundSvcId() {
        return inBoundSvcId;
    }

    public void setInBoundSvcId(String inBoundSvcId) {
        this.inBoundSvcId = inBoundSvcId;
    }

}
