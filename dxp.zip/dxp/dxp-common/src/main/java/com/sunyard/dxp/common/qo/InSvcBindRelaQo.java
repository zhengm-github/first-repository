package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 接入服务数据映射配置 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:55:37 CST 2019
   */
public class InSvcBindRelaQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7838580778570610165L;

    /** 接入模块Id */
    private String inBoundSvcId ;

    public String getInBoundSvcId( ) {
        return inBoundSvcId;
    }

    public void setInBoundSvcId(String inBoundSvcId) {
        this.inBoundSvcId = inBoundSvcId;
    }
}
