package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 业务类型映射
 */
@FunctionLibrary( code = "prtryMapper", name = "业务类型映射(prtry)", expression = "(prtryMapper\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "prtryMapper()", hasProperty = true )
@Component
public class PrtryMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            //表达式参数不准确
            return "" ;
        }
        try {
            return ExpMapper.prtryMap.get(params);
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName()+e);
        }

    }
}
