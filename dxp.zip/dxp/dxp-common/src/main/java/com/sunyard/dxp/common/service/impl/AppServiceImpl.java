package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.AppDao;
import com.sunyard.dxp.common.entity.App;
import com.sunyard.dxp.common.qo.AppQo;
import com.sunyard.dxp.common.service.AppService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 应用系统 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:23 CST 2019
 */
@Service
public class AppServiceImpl extends BaseServiceImpl< App, String, AppQo > implements AppService {
    @Autowired
    private AppDao appDao;

    @Override
    public App findByCode(String code) {
        return appDao.findByCode(code);
    }
}
