package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/3/17 16:58
 */
@FunctionLibrary( code = "subStart", name = "起始截取", expression = "(subStart\\()([\\w,]+\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "subStart(x)", hasProperty = true )
@Component
public class SubStartFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            return "";
        }
        String[] param = params.split(",", -1);
        if (ArrayUtils.isEmpty(param)) {
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }

        String strVal = params.substring(params.indexOf(",") + 1);
        int start;
        try {
            start = Integer.parseInt(param[ 0 ]);
        } catch (NumberFormatException e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        return StringUtils.isNotBlank(strVal) ? strVal.substring(start) : "";
    }
}
