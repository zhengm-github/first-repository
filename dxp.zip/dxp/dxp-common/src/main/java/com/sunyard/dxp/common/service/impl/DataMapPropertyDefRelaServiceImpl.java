package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.DataMapPropertyDefRelaDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.DataMapPropertyDefRelaService;
import com.sunyard.dxp.common.entity.DataMapPropertyDefRela;
import com.sunyard.dxp.common.qo.DataMapPropertyDefRelaQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 请求报文映射配置属性 service
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:25:20 CST 2020
 */
@Service
public class DataMapPropertyDefRelaServiceImpl extends BaseServiceImpl<DataMapPropertyDefRela, String, DataMapPropertyDefRelaQo> implements DataMapPropertyDefRelaService {

    @Autowired
    private DataMapPropertyDefRelaDao dataMapPropertyDefRelaDao;
    @Override
    public void deleteByPropertyId(String propertyId) {
        dataMapPropertyDefRelaDao.deleteByPropertyId(propertyId);
    }

    @Override
    public void deleteByPropertyIdAndConfig(String propertyId, String configId) {
        dataMapPropertyDefRelaDao.deleteByPropertyIdAndConfig(propertyId, configId);
    }
}
