package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 协议解析规则
* Author: Created by code generator
* Date: Tue Jan 07 19:22:59 CST 2020
*/
@Entity
@Table(name = "DXP_PROCOTOL_RESOLVE_RULE")
public class ProcotolResolveRule implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 4694436225570249218L;

    /** 协议解析规则ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "PROCOTOL_RESOLVE_RULE_ID")
    private String procotolResolveRuleId;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** 备注 */
    @Column( name = "MEMO")
    private String memo;

    /** 分隔符 */
    @Column( name = "SEPARATOR_CHAR")
    private String separatorChar;

    /** 起始位置 */
    @Column( name = "BEGIN_INDEX")
    private Integer beginIndex;

    /** 结束位置 */
    @Column( name = "END_INDEX")
    private Integer endIndex;

    /** 明细名称 */
    @Column( name = "DETAIL_NAME")
    private String detailName;

    /** 行数 */
    @Column( name = "LINE_NUM")
    private Integer linNum;

    /** 规则类型 */
    @Column( name = "RULE_TYPE")
    private String ruleType;

    /** 父级协议解析规则 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "PARENT_ID")
    private ProcotolResolveRule parent;

    /** 子级协议解析规则 */
    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.REFRESH}, mappedBy = "parent")
    @OrderBy(value = "beginIndex ASC")
    private Set<ProcotolResolveRule> childRules;

    /** 协议解析规划 */
    @ManyToOne(fetch = FetchType.EAGER, optional = true )
    @JoinColumn(name = "PROCOTOL_RESOLVE_PLAN_ID", referencedColumnName = "PROCOTOL_RESOLVE_PLAN_ID")
    private ProcotolResolvePlan procotolResolvePlan;

    public String getProcotolResolveRuleId() {
        return procotolResolveRuleId;
    }

    public void setProcotolResolveRuleId(String procotolResolveRuleId) {
        this.procotolResolveRuleId = procotolResolveRuleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getSeparatorChar() {
        return separatorChar;
    }

    public void setSeparatorChar(String separatorChar) {
        this.separatorChar = separatorChar;
    }

    public Integer getBeginIndex( ) {
        return beginIndex;
    }

    public void setBeginIndex(Integer beginIndex) {
        this.beginIndex = beginIndex;
    }

    public Integer getEndIndex( ) {
        return endIndex;
    }

    public void setEndIndex(Integer endIndex) {
        this.endIndex = endIndex;
    }

    public String getDetailName() {
        return detailName;
    }

    public void setDetailName(String detailName) {
        this.detailName = detailName;
    }

    public Integer getLinNum() {
        return linNum;
    }

    public void setLinNum(Integer linNum) {
        this.linNum = linNum;
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    public ProcotolResolveRule getParent() {
        return parent;
    }

    public void setParent(ProcotolResolveRule parent) {
        this.parent = parent;
    }

    public Set<ProcotolResolveRule> getChildRules() {
        return childRules;
    }

    public void setChildRules(Set<ProcotolResolveRule> childRules) {
        this.childRules = childRules;
    }

    public ProcotolResolvePlan getProcotolResolvePlan() {
        return procotolResolvePlan;
    }

    public void setProcotolResolvePlan(ProcotolResolvePlan procotolResolvePlan) {
        this.procotolResolvePlan = procotolResolvePlan;
    }

}
