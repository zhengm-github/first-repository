package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.SignConfigSchemaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 签名配置规划 Qct转化类
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:54:44 CST 2020
 */
public class SignConfigSchemaQct extends QueryConditionTransfer<SignConfigSchemaQo> {

    @Override
    public void transNameQuery(SignConfigSchemaQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(SignConfigSchemaQo qo, QueryCondition condition) {
        //
    }

}
