package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 签名配置项 QO
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:49:49 CST 2020
   */
public class SignConfigItemQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7164675452895197025L;

}
