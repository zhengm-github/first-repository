package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.AppDao;
import com.sunyard.dxp.common.entity.App;
import com.sunyard.dxp.common.qo.AppQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.springframework.stereotype.Repository;


/**
 * 应用系统 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:23 CST 2019
 */
@Repository
public class JpaAppDaoImpl extends JpaBaseDaoImpl< App, String, AppQo > implements AppDao {


    @Override
    public App findByCode(String code) {

        return findBySingle(getMainQuery() + " where obj.appCode= ? ", code);
    }
}
