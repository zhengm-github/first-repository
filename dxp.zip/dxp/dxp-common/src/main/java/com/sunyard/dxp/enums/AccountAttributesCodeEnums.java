package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * *
 * User: wuyongzhi
 * Date: 2017/7/11 10:21
 * version $Id: AccessKeyEnum.java, v 0.1 Exp $
 */
public enum AccountAttributesCodeEnums implements EnumAware {
    AA01( "CC00","养老金账户"),
    AA02( "CC01","财政专户"),
    AA03 ("CC02","科目"),
    AA04 ("CC02","其他"),
    ;

    private String code;

    private String name;

    AccountAttributesCodeEnums(String code, String name) {
        this.code = code;
        this.name = name;
    }
    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return null;
    }


    public static String getMapperNameByCode(String code) {
        for (AccountAttributesCodeEnums enums : AccountAttributesCodeEnums.values()) {
            if (enums.code.equals(code)) {
                return enums.name;
            }
        }
        return code;
    }
}
