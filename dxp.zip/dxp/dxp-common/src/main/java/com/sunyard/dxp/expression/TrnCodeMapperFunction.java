package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.dxp.utils.PropUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;

/**
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary(code = "trnCodeMapper",name = "交易代码（单位-平台）",expression = "(trnCodeMapper\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "trnCodeMapper()",hasProperty = true)
@Component
public class TrnCodeMapperFunction implements ParamExpression {
    @Value("${config.path}")
    private String configPath;

    @Override
    public String expCompute(String params) {

        if(StringUtils.isBlank(params) || "".equals(params.trim())){
            return "" ;
        }
        try {
            return PropUtil.getValue(configPath+"common"+ File.separator+"expression"+File.separator+"trncode-mapper.properties", params) ;
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName()+e);
        }
    }
}
