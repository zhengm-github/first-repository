package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 接入服务接口 QO
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:54:51 CST 2019
 */
public class InBoundSvcQo extends PagingOrder {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 7444386973251281686L;

    /**
     * 编号
     */
    private String code;
    /**
     * 状态
     */
    private String status;
    /**
     * 服务性质
     */
    private String kind;
    /**
     * 多个接入接口的id，逗号(,)分隔
     */
    private String inBoundSvcIds;
    /**
     * 是否绑定ServiceBound
     */
    private boolean bind;

    /**
     * 服务模块ID
     */
    private String serviceBundleId;

    /** 接入接口类型 */
    private String inBoundSvcType ;

    public String getInBoundSvcType( ) {
        return inBoundSvcType;
    }

    public void setInBoundSvcType(String inBoundSvcType) {
        this.inBoundSvcType = inBoundSvcType;
    }

    public String getServiceBundleId( ) {
        return serviceBundleId;
    }

    public void setServiceBundleId(String serviceBundleId) {
        this.serviceBundleId = serviceBundleId;
    }

    public boolean isBind( ) {
        return bind;
    }

    public void setBind(boolean bind) {
        this.bind = bind;
    }

    public String getInBoundSvcIds( ) {
        return inBoundSvcIds;
    }

    public void setInBoundSvcIds(String inBoundSvcIds) {
        this.inBoundSvcIds = inBoundSvcIds;
    }

    public String getCode( ) {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStatus( ) {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getKind( ) {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }
}
