package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.ProcotolResolvePlanDao;
import com.sunyard.dxp.common.entity.ProcotolResolvePlan;
import com.sunyard.dxp.common.qo.ProcotolResolvePlanQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 协议解析规划 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:25 CST 2020
 */
@Repository
public class JpaProcotolResolvePlanDaoImpl extends JpaBaseDaoImpl< ProcotolResolvePlan, String, ProcotolResolvePlanQo > implements ProcotolResolvePlanDao {

    @Override
    public ProcotolResolvePlan findByName(String name) {
        return findBySingle(getMainQuery() + " where obj.name = ?", name);
    }

    @Override
    public ProcotolResolvePlan queryBySvcId(String svcId, String dataKind, String svcType) {
        return findBySingle(getMainQuery() +
                String.format(" where obj.dataKind = ? and %s = ?"
                        , "in".equals(svcType) ? "obj.inBoundSvc.inBoundSvcId" : "obj.outBoundSvc.outBoundSvcId"), dataKind, svcId);
    }

    @Override
    public void deleteByInsvcId(String inBoundSvcId) {
        this.executeUpdate("delete from  ProcotolResolvePlan as obj where obj.inBoundSvc.inBoundSvcId =?", inBoundSvcId);
    }

    @Override
    public void deleteByOutsvcId(String outBoundSvcId) {
        this.executeUpdate("delete from  ProcotolResolvePlan as obj where obj.outBoundSvc.outBoundSvcId =?", outBoundSvcId);

    }

    @Override
    public List< ProcotolResolvePlan > findByInsvcId(String inBoundSvcId) {
        return this.find("Select obj from ProcotolResolvePlan as obj where obj.inBoundSvc.inBoundSvcId = ?"
                , inBoundSvcId);
    }

    @Override
    public List< ProcotolResolvePlan > findByOutsvcId(String outBoundSvcId) {
        return this.find("Select obj from ProcotolResolvePlan as obj where obj.outBoundSvc.outBoundSvcId = ?"
                , outBoundSvcId);
    }

    @Override
    public ProcotolResolvePlan queryPlanByObsId(String outBoundSvcId, String dataKind) {
        return this.findBySingle(getMainQuery() + " where obj.outBoundSvc.outBoundSvcId = ? and obj.dataKind = ?"
                , outBoundSvcId, dataKind) ;
    }

    @Override
    public ProcotolResolvePlan queryPlanByIbsId(String inBoundSvcId, String dataKind) {
        return this.findBySingle(getMainQuery() + " where obj.inBoundSvc.inBoundSvcId = ? and obj.dataKind = ?"
                , inBoundSvcId, dataKind) ;
    }
}
