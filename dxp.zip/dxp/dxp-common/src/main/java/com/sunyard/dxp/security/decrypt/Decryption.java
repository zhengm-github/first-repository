package com.sunyard.dxp.security.decrypt;

public interface Decryption {
    String decrypt(String content, String key);
}
