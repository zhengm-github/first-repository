package com.sunyard.dxp.common.vo;

/**
 * @author Thud
 * @date 2020/2/26 15:34
 */
public class ResolveVo {
    //解析id
    private String id ;
    //解析名称
    private String name;
    //解析备注
    private String memo;
    //解析详细名称
    private String showName;
    //关系函数编号
    private String relationFunctionCode;
    //关系函数名称
    private String relationFunctionName;
    //属性函数编号
    private String propertyFunctionCode;
    //属性函数名称
    private String propertyFunctionName;
    //属性名称
    private String propertyFunctionShowName;

    public String getPropertyFunctionShowName() {
        return propertyFunctionShowName;
    }

    public void setPropertyFunctionShowName(String propertyFunctionShowName) {
        this.propertyFunctionShowName = propertyFunctionShowName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public String getRelationFunctionCode() {
        return relationFunctionCode;
    }

    public void setRelationFunctionCode(String relationFunctionCode) {
        this.relationFunctionCode = relationFunctionCode;
    }

    public String getRelationFunctionName() {
        return relationFunctionName;
    }

    public void setRelationFunctionName(String relationFunctionName) {
        this.relationFunctionName = relationFunctionName;
    }

    public String getPropertyFunctionCode() {
        return propertyFunctionCode;
    }

    public void setPropertyFunctionCode(String propertyFunctionCode) {
        this.propertyFunctionCode = propertyFunctionCode;
    }

    public String getPropertyFunctionName() {
        return propertyFunctionName;
    }

    public void setPropertyFunctionName(String propertyFunctionName) {
        this.propertyFunctionName = propertyFunctionName;
    }
}
