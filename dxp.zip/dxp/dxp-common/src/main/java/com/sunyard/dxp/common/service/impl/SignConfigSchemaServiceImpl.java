package com.sunyard.dxp.common.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.sunyard.dxp.common.dao.SignConfigSchemaDao;
import com.sunyard.dxp.enums.VerifyEnum;
import com.sunyard.dxp.security.verify.Verification;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.SignConfigSchemaService;
import com.sunyard.dxp.common.entity.SignConfigSchema;
import com.sunyard.dxp.common.qo.SignConfigSchemaQo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 签名配置规划 service
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:54:44 CST 2020
 */
@Service
public class SignConfigSchemaServiceImpl extends BaseServiceImpl<SignConfigSchema, String, SignConfigSchemaQo> implements SignConfigSchemaService {

    @Autowired
    private SignConfigSchemaDao signConfigSchemaDao ;

    @Override
    public List<SignConfigSchema> getSignConfigSchemaByOutsvcId(String outBoundSvcId) {
        return signConfigSchemaDao.getSignConfigSchemaByOutsvcId(outBoundSvcId);
    }

    @Override
    public List<SignConfigSchema> getSignConfigSchemaByInsvcId(String inBoundSvcId) {
        return signConfigSchemaDao.getSignConfigSchemaByInsvcId(inBoundSvcId);
    }

    @Override
    public void deleteSignConfigSchemaByOutsvcId(String... outBoundSvcIds) {
        if(StringUtils.isNoneBlank(outBoundSvcIds)){
            for(String id: outBoundSvcIds){
                signConfigSchemaDao.deleteSignConfigSchemaByOutsvcId(id);
            }
        }
    }

    @Override
    public void deleteSignConfigSchemaByInsvcId(String... inBoundSvcIds) {
        if(StringUtils.isNoneBlank(inBoundSvcIds)){
            for(String id: inBoundSvcIds){
                signConfigSchemaDao.deleteSignConfigSchemaByInsvcId(id);
            }
        }
    }

    @Override
    public boolean validateSign(String src, String sign, String key, String signAlgol, String documentSrc, String... params) {
        Verification verification = VerifyEnum.getVerifyStrategy(signAlgol);
        if (verification != null) {
            // 校验整体报文
            if (VerifyEnum.MYJ_ALL.getCode().equals(signAlgol)) {
                return verification.verify(documentSrc, sign, key);
            } else if (VerifyEnum.MYJ_PART.getCode().equals(signAlgol)) {
                // 这里的配置需要 不同地区进行区分
                JSONObject jsonObject = new JSONObject();

                // 根据发起机构映射的6位编码
                jsonObject.put(MsgKeys.MYJ_REGION, params[ 0 ]);
                jsonObject.put(MsgKeys.MYJ_ENCODE, "UTF-8");
                jsonObject.put(MsgKeys.MYJ_MESSAGE, src);
                jsonObject.put(MsgKeys.MYJ_VERSION, params[ 1 ]);
                jsonObject.put(MsgKeys.MYJ_ALGORITHM, params[ 2 ]);
                if ("nn".equals(params[ 3 ])) {
                    jsonObject.put("newAPI", "2");
                }else if("sz".equals(params[3])){
                    jsonObject.put("newAPI", "3");
                }

                return verification.verify(jsonObject.toJSONString(), sign, key);
            }
            return verification.verify(src, sign, key);
        }
        return false;
    }
}
