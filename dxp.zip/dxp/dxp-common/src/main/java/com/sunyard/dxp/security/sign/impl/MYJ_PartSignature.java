package com.sunyard.dxp.security.sign.impl;


import com.sunyard.SydApi;
import com.sunyard.dxp.security.sign.Signature;
import com.sunyard.dxp.utils.Constant;
import com.sunyard.dxp.utils.MD5Util;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.dxp.utils.SignatureLibrary;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import com.sunyard.frameworkset.util.JsonUtil;
import com.sunyard.inf.SydPledge;
import org.apache.commons.lang3.ArrayUtils;
import racal.sunyard.main.SydApi4j;

import java.util.Map;

/**
 * 对全报文进行核押
 */
@SignatureLibrary( code = "MYJ_PartSignature", name = "密押机部分字段核押" )
public class MYJ_PartSignature implements Signature {

    private static final Logger LOGGER = LoggerFactory.getLogger(MYJ_PartSignature.class);

    /**
     * @param src
     * @param key
     * @return
     */
    @Override
    public String sign(String src, String key) {

        SydPledge api = null;
        String[] MYJHost = Constant.MYJ_Host.split(",");
        if (ArrayUtils.isEmpty(MYJHost)) {
            LOGGER.info("syd.api.host 没有配置");
            return src;
        }

        LOGGER.info("原文数据:[{}]", src);
        Map< String, Object > msg = JsonUtil.jsonToMap(src);
        // 依次处理 ip
        String ip = "";
        int port;
        String mac = "";  // 赋值原报文
        for (String host : MYJHost) {
            ip = host.split(":")[ 0 ].trim();
            port = Integer.parseInt(host.split(":")[ 1 ].trim());
            try {
                LOGGER.info("尝试连接到 [ip：{},port：{}]密押机服务器", ip, port);
                api = new SydApi4j().connect(ip, port, null, 1000);

                Object isNewAPI = msg.get("newAPI");  // 是否使用密押机的新版api
                if (isNewAPI != null && "1".equals(isNewAPI.toString())) {
                    // 新的密押机 api（宁波）
                    LOGGER.info("新版本API(NINGBO: MIYA_FULL_FORCE + MIYA_MAC_LEN_16)调用中...");
                    mac = api.GenerateMIYA(
                            msg.get(MsgKeys.MYJ_REGION).toString(),
                            Integer.parseInt(msg.get(MsgKeys.MYJ_VERSION).toString()),
                            SydApi.ALG_SM4,
                            msg.get(MsgKeys.MYJ_MESSAGE).toString().getBytes(msg.get(MsgKeys.MYJ_ENCODE).toString()),
                            SydApi.MIYA_FULL_FORCE, SydApi.MIYA_MAC_LEN_16);
                }else if (isNewAPI != null && "2".equals(isNewAPI.toString())) {
                    // 新的密押机 api（广西）
                    LOGGER.info("新版本API(GUANGXI: MIYA_FULL_FORCE + MIYA_MAC_LEN_8)调用中...");
                    mac = api.GenerateMIYA(
                            msg.get(MsgKeys.MYJ_REGION).toString(),
                            Integer.parseInt(msg.get(MsgKeys.MYJ_VERSION).toString()),
                            SydApi.ALG_SM4,
                            msg.get(MsgKeys.MYJ_MESSAGE).toString().getBytes(msg.get(MsgKeys.MYJ_ENCODE).toString()),
                            SydApi.MIYA_FULL_FORCE, SydApi.MIYA_MAC_LEN_8);
                }else if (isNewAPI != null && "3".equals(isNewAPI.toString())) {
                    // 新的密押机 api（苏州）
                    LOGGER.info("新版本API(SUZHOU: MIYA_FULL_WEAK + MIYA_MAC_LEN_8)调用中...");
                    String md5Str = MD5Util.update(msg.get(MsgKeys.MYJ_MESSAGE).toString() + "SUNYARD") ;
                    LOGGER.info("MD5值为：md5Str=[{}]", md5Str);
                    md5Str = md5Str.substring(0, 16) ;
                    LOGGER.info("截取MD5值前16位为：md5Str=[{}]", md5Str);
                    mac = api.GenerateMIYA(
                            msg.get(MsgKeys.MYJ_REGION).toString(),
                            Integer.parseInt(msg.get(MsgKeys.MYJ_VERSION).toString()),
                            SydApi.ALG_SM4,
                            md5Str.getBytes(msg.get(MsgKeys.MYJ_ENCODE).toString()),
                            SydApi.MIYA_FULL_WEAK, SydApi.MIYA_MAC_LEN_8);
                }  else {
                    // 其他地区
                    LOGGER.info("普通版本API调用中...");
                    mac = api.GenerateMIYA(
                            msg.get(MsgKeys.MYJ_REGION).toString(),
                            Integer.parseInt(msg.get(MsgKeys.MYJ_VERSION).toString()),
                            Integer.parseInt(msg.get(MsgKeys.MYJ_ALGORITHM).toString()),
                            msg.get(MsgKeys.MYJ_MESSAGE).toString().getBytes(msg.get(MsgKeys.MYJ_ENCODE).toString()));
                }
                LOGGER.info("密押机产生mac:[{}]", mac);
                ((SydApi) api).disconnect();
                break;  // 成功则直接跳出循环
            } catch (Exception e) {
                LOGGER.info("密押机本次连接失败！[{}]", e.getMessage());
            }
        }

        return mac;
    }
}
