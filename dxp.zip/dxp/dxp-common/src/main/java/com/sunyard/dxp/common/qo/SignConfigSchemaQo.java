package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 签名配置规划 QO
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:54:44 CST 2020
   */
public class SignConfigSchemaQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6524574000345243291L;

}
