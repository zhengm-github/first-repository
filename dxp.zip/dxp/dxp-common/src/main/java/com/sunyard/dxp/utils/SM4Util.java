package com.sunyard.dxp.utils;

import com.sunyard.dxp.message.utils.StringUtils;
import org.bouncycastle.pqc.math.linearalgebra.ByteUtils;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.IOException;

public class SM4Util {

    private static String encode = "GBK";

    private static final int ENCRYPT = 1;

    private static final int DECRYPT = 0;


    /**
     * 本地加密 只需要保证传入的是正常的字符串
     *
     * @param hexKey
     * @param paramStr
     * @return
     * @throws Exception
     */
    public static String encryptEcb(String hexKey, String paramStr) throws Exception {
        byte[] key = hexKey.getBytes(encode);
        byte[] param = paramStr.getBytes(encode);
        byte[] out = new byte[ param.length ];
        SMS4 sm4 = new SMS4();
        sm4.sms4(param, param.length, key, out, ENCRYPT);
        return ByteUtils.toHexString(out);
    }

    /**
     * 本地加密 只需要保证传入的是 字节数组
     *
     * @param hexKey
     * @param paramStr
     * @return
     * @throws Exception
     */
    public static String encryptEcb01(String hexKey, byte[] paramStr) throws Exception {
        byte[] key = hexKey.getBytes(encode);
        byte[] out = new byte[ paramStr.length ];
        SMS4 sm4 = new SMS4();
        sm4.sms4(paramStr, paramStr.length, key, out, ENCRYPT);
        return ByteUtils.toHexString(out);
    }

    /**
     * 解析链路中的 数据，要保证 cipherText 对应的是 字节数据（十六进制表示)的 字符串
     *
     * @param hexKey
     * @param cipherText
     * @return
     * @throws Exception
     */
    public static String decryptEcb(String hexKey, String cipherText) throws Exception {
        byte[] key = hexKey.getBytes(encode);
        byte[] param = ByteUtils.fromHexString(cipherText);
        byte[] out = new byte[ param.length ];
        SMS4 sm4 = new SMS4();
        sm4.sms4(param, param.length, key, out, DECRYPT);
//		return ByteUtils.toHexString(out);
        return new String(out, encode);
    }

    /**
     * 解析链路中的 数据，要保证 cipherText 对应的是 字节数据（十六进制表示)的 字符串
     *
     * @param hexKey
     * @param cipherText
     * @return
     * @throws Exception
     */
    public static String decryptEcb01(String hexKey, String cipherText) throws Exception {
        byte[] key = hexKey.getBytes(encode);
        byte[] param = ByteUtils.fromHexString(cipherText);
        byte[] out = new byte[ param.length ];
        SMS4 sm4 = new SMS4();
        sm4.sms4(param, param.length, key, out, DECRYPT);
        return ByteUtils.toHexString(out);
    }

    /**
     * 保证输入输出的都要是  十六进制的  字符串
     *
     * @param str
     * @return
     */
    public static String base64Encode(String str) {
        if (StringUtils.isEmpty(str)) return "";
        BASE64Encoder base64Encoder = new BASE64Encoder();
        byte[] x = ByteUtils.fromHexString(str);
        try {
            return base64Encoder.encode(x);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 针对明文做base64 加密
     *
     * @param str
     * @return
     */
    public static String base64Encode_see(String str) {
        if (StringUtils.isEmpty(str)) return "";
        BASE64Encoder base64Encoder = new BASE64Encoder();
        try {
            byte[] x = str.getBytes("GBK");
            return base64Encoder.encode(x);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 保证输入输出的都要是  十六进制的  字符串
     *
     * @param str
     * @return
     */
    public static String base64Decode(String str) {
        String result = "";
        if (StringUtils.isEmpty(str)) return result;
        BASE64Decoder base64Decoder = new BASE64Decoder();
        try {
            result = ByteUtils.toHexString(base64Decoder.decodeBuffer(str));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 针对明文做base64 解密
     *
     * @param str
     * @return
     */
    public static String base64Decode_see(String str) {
        String para = "";
        if (StringUtils.isEmpty(str)) return para;
        BASE64Decoder base64Decoder = new BASE64Decoder();
        try {
            para = new String(base64Decoder.decodeBuffer(str), "GBK");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return para;
    }


    public static void main(String[] args) {
        try {
//			String xx = encryptEcb("spcs20190602acct","1234567890123456") ;

            String key = "UmtFNE4wVTJSalF5TVVReQ==";
            String str = "你好啊 , 1111" ;
            System.out.println("key原文:\n" + key);
            System.out.println("key 16进制:\n" + ByteUtils.toHexString(key.getBytes(encode)));
            System.out.println("src原文:\n" + str);
            System.out.println("src 16进制:\n" + ByteUtils.toHexString(str.getBytes(encode)));
            String xx = encryptEcb(key, StringUtil.addTo16(str, "GBK"));
            System.out.println("加密后 16进制内容：" + xx);
            String base64_b = base64Encode(xx);
            System.out.println("加密结果（16进制再 base处理）：" + base64_b);

            base64_b = "lI6Y+4uTuoJxpqR8rYRzcB3ok1UlWl9fJV/hK46qB67ZOOelW9JhNv5F/ejj3fFnjL+FNtiR+1jx\n" +
                    "+5kCJXP6U8/q4UP2Z0+704HTlsVCJv37UljxeOQMl63lLinJ333FbLsTj92b1alFKVdbDOOY8rw4\n" +
                    "81g1ncxXff/RihVHepxoNS9hc9awfs0uObcqY4qM+hjre6+u1VQkbQs9McZUgjUi8HJxMxia9mmz\n" +
                    "XNs0CHs=" ;
//            String base64_a = base64Decode(base64_b);
//            System.out.println("base之后：" + base64_a);
//            String afterStr = decryptEcb01(key, base64_a);  // 16进制
//            System.out.println("解密结果:" + afterStr);
//
//            byte[] out = ByteUtils.fromHexString(afterStr);
//            System.out.println("解密结果全部:" +new String(out, 0,out.length, encode));
//            byte[] x = new byte[32 ];
//            System.arraycopy(out, 0, x, 0, 32);
//
//            System.out.println("解密结果 头(16进制):" +ByteUtils.toHexString(x));
//            System.out.println("解密结果 xml:" +new String(out, 32,out.length-32, encode));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
