package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 宁波专属的单位转到 全国的业务类型（费种代码 转为 费项代码 ）
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary( code = "NBCorpMapper", name = "宁波 单位转业务类型", expression = "(NBCorpMapper\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "NBCorpMapper()", hasProperty = true )
@Component
public class NBCorpMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            //表达式参数不准确
            return "" ;
        }
        try {
            String value = ExpMapper.NBcorpMap.get(params);
            if(StringUtils.isBlank(value)){
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL) ;
            }
            return value ;
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName()+e);
        }

    }
}
