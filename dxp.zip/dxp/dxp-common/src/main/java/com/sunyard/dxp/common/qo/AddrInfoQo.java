package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 地址信息管理 QO
 *
 * Author: Created by code generator
 * Date: Thu Jun 11 16:10:14 CST 2020
   */
public class AddrInfoQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8087491032494175892L;

}
