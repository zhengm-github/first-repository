package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.AppServerQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 应用服务 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:07 CST 2019
 */
public class AppServerQct extends QueryConditionTransfer< AppServerQo > {

    @Override
    public void transNameQuery(AppServerQo qo, QueryCondition condition) {

        if(qo!=null){
            if(StringUtils.isNotBlank(qo.getCode())){
                condition.add(" and obj.code = :code","code",qo.getCode()) ;
            }
            /*关键字模糊查询*/
            if (StringUtils.isNotBlank(qo.getKeyword())) {
                condition.add(" and ( obj.code like :code", "code", qo.getTailBlurKeyword());
                condition.add(" or obj.name like :name", "name", qo.getBlurKeyword());
                condition.add(" or obj.memo like :memo ) ", "memo", qo.getBlurKeyword());
            }
        }
    }

    @Override
    public void transQuery(AppServerQo qo, QueryCondition condition) {
        //
    }

}
