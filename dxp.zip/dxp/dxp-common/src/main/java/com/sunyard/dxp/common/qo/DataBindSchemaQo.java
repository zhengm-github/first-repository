package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 数据绑定模式 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:53 CST 2019
   */
public class DataBindSchemaQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5125268519557367309L;

}
