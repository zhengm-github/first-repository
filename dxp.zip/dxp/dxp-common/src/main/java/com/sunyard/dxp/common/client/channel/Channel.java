package com.sunyard.dxp.common.client.channel;


import java.util.Map;

/**
 * Created by tangjiejie on 2018/3/1.
 */
public interface Channel {
    /**
     *
     * @param url
     * @param requestBody
     * @param send2Center 是否为 发向中心
     * @return
     */
    Map<String, Object> send(String url, Object requestBody, boolean send2Center);
}
