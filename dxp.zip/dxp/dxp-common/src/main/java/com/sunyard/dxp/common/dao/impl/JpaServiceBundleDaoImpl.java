package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.ServiceBundleDao;
import com.sunyard.dxp.common.entity.ServiceBundle;
import com.sunyard.dxp.common.qo.ServiceBundleQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.springframework.stereotype.Repository;

/**
 * 服务模块 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:57:12 CST 2019
 */
@Repository
public class JpaServiceBundleDaoImpl  extends JpaBaseDaoImpl< ServiceBundle,String, ServiceBundleQo > implements ServiceBundleDao {

    @Override
    public void deleteSvcBundleById(String serviceBundleId) {
        String hql="delete from  ServiceBundle as a where a.serviceBundleId=?";
        this.executeUpdate(hql,serviceBundleId);
    }

    @Override
    public ServiceBundle findSvcbundleByCode(String code) {
        String hql = this.getMainQuery() + "where obj.code = ?";
        return this.findBySingle(hql, code);
    }
}
