package com.sunyard.dxp.security.encrypt;

public interface Encryption {
    String encrypt(String content, String key);
}
