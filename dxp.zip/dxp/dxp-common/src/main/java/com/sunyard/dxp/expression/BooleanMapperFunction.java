package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/1/3 8:49
 */
@FunctionLibrary(code = "booleanMapper",name = "布尔值映射(转01)",expression = "(booleanMapper\\()(\\$\\{[\\s\\w]+\\})(\\))" ,type = "boolean",exp = "booleanMapper()",hasProperty = true)
@Component
public class BooleanMapperFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        if(BooleanUtils.isTrue(BooleanUtils.toBoolean(params))){
            return "1";
        }
        return "0";
    }
}
