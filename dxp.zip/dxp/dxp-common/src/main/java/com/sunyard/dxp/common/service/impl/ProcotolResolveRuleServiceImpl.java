package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.ProcotolResolvePlanDao;
import com.sunyard.dxp.common.dao.ProcotolResolveRuleDao;
import com.sunyard.dxp.common.entity.ProcotolResolvePlan;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.ProcotolResolveRuleService;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.common.qo.ProcotolResolveRuleQo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 协议解析规则 service
 * <p>
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:59 CST 2020
 */
@Service
public class ProcotolResolveRuleServiceImpl extends BaseServiceImpl< ProcotolResolveRule, String, ProcotolResolveRuleQo > implements ProcotolResolveRuleService {

    @Autowired
    private ProcotolResolveRuleDao procotolResolveRuleDao;

    @Autowired
    private ProcotolResolvePlanDao planDao;

    @Override
    public ProcotolResolveRule findByName(String name) {
        return procotolResolveRuleDao.findByName(name);
    }

    @Override
    public ProcotolResolveRule findByDetailName(String detailName) {
        return procotolResolveRuleDao.findByDetailName(detailName);
    }

    @Override
    public List< ProcotolResolveRule > findByPlanId(String planId) {
        return procotolResolveRuleDao.findByPlanId(planId);
    }


    @Override
    public void deleteByParentIds(String... parentIds) {
        for (String id : parentIds) {
            List< ProcotolResolveRule > objs = procotolResolveRuleDao.findByParentId(id);
            if (CollectionUtils.isNotEmpty(objs)) {
                for (ProcotolResolveRule obj : objs) {
                    deleteByParentIds(obj.getProcotolResolveRuleId());
                }
            }
            procotolResolveRuleDao.deleteById(id);
            procotolResolveRuleDao.flush();
            procotolResolveRuleDao.clear();
        }
    }

    @Override
    public List< ProcotolResolveRule > findChildRule(String id) {
        return procotolResolveRuleDao.findChildRule(id);
    }

    @Override
    public List<ProcotolResolveRule> findByIbsId(String ibsId, String dataKind){
        ProcotolResolvePlan plan = planDao.queryPlanByIbsId(ibsId, dataKind);
        // 没有规划就是没有规则
        if(plan == null){
            return new ArrayList<>();
        }
        return procotolResolveRuleDao.findByPlanId(plan.getProcotolResolvePlanId());
    }

    @Override
    public List<ProcotolResolveRule> findByObsId(String obsId, String dataKind){
        ProcotolResolvePlan plan = planDao.queryPlanByObsId(obsId, dataKind);
        if(plan == null){
            return new ArrayList<>();
        }
        return procotolResolveRuleDao.findByPlanId(plan.getProcotolResolvePlanId());
    }
}
