package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * @author Thud
 * @date 2020/2/19 14:55
 */
public class SvcRspMsgQo extends PagingOrder {
}
