package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 签名配置规划
* Author: Created by code generator
* Date: Mon Jan 06 10:54:44 CST 2020
*/
@Entity
@Table(name = "DXP_SIGN_CONFIG_SCHEMA")
public class SignConfigSchema implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7345074409616766722L;

    /** 签名配置计划ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "SIGN_CONFIG_SCHEMA_ID")
    private String signConfigSchemaId;

    /** 连接符 */
    @Column( name = "CONNECTOR")
    private String connector;

    /** 接入服务接口 */
    @OneToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "IN_BOUND_SVC_ID", referencedColumnName = "IN_BOUND_SVC_ID")
    private InBoundSvc inBoundSvc;

    /** 接出服务接口 */
    @OneToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "OUT_BOUND_SVC_ID", referencedColumnName = "OUT_BOUND_SVC_ID")
    private OutBoundSvc outBoundSvc;

    /** 签名配置项 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REFRESH}, mappedBy = "signConfigSchema")
    private Set<SignConfigItem> signConfigItems;

    public String getSignConfigSchemaId() {
        return signConfigSchemaId;
    }

    public void setSignConfigSchemaId(String signConfigSchemaId) {
        this.signConfigSchemaId = signConfigSchemaId;
    }

    public String getConnector() {
        return connector;
    }

    public void setConnector(String connector) {
        this.connector = connector;
    }

    public InBoundSvc getInBoundSvc() {
        return inBoundSvc;
    }

    public void setInBoundSvc(InBoundSvc inBoundSvc) {
        this.inBoundSvc = inBoundSvc;
    }

    public OutBoundSvc getOutBoundSvc() {
        return outBoundSvc;
    }

    public void setOutBoundSvc(OutBoundSvc outBoundSvc) {
        this.outBoundSvc = outBoundSvc;
    }

    public Set<SignConfigItem> getSignConfigItems() {
        return signConfigItems;
    }

    public void setSignConfigItems(Set<SignConfigItem> signConfigItems) {
        this.signConfigItems = signConfigItems;
    }
}
