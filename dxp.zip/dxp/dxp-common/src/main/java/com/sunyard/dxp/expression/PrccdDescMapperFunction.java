package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 将平台返回的 prccd 转换成 对应的单位描述
 *
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary( code = "prccdDescMapper", name = "Prccd 转成单位描述", expression = "(prccdDescMapper\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "prccdDescMapper()", hasProperty = true )
@Component
public class PrccdDescMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            //表达式参数不准确
            return "";
        }
        try {
            String value = ExpMapper.prccdCorpMap.get(params);
            if (value != null && value.contains(",")) {
                return value.split(",", -1)[ 1 ]; // 转成 code
            } else {
                return ExpMapper.prccdCorpMap.get("default").split(",")[ 1 ]; // 失败的情况
            }
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
        }

    }
}
