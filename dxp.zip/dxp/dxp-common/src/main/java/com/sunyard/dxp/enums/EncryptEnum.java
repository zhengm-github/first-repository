package com.sunyard.dxp.enums;

import com.sunyard.dxp.security.encrypt.Encryption;
import com.sunyard.dxp.security.encrypt.impl.AESEncryption;
import com.sunyard.dxp.security.encrypt.impl.Base64Encryption;
import com.sunyard.dxp.security.encrypt.impl.RSAPrivateEncryption;
import com.sunyard.dxp.security.encrypt.impl.RSAPublicEncryption;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * @author Thud
 * @date 2019/12/25 16:06
 */
public enum EncryptEnum implements EnumAware {
    AES("AES","AES",new AESEncryption()),
    BASE64("BASE64","BASE64",new Base64Encryption()),
    RSA_PRIVATE("RSA_PRIVATE","RSA_PRIVATE",new RSAPrivateEncryption()),
    RSA_PUBLIC("RSA_PUBLIC","RSA_PUBLIC",new RSAPublicEncryption()),
    ;

    private final String code;
    private final String name;
    private final Encryption encryption;

    EncryptEnum(String code, String name, Encryption encryption) {
        this.code = code;
        this.name = name;
        this.encryption = encryption;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return this.getName();
    }

    public static Encryption getEncryptionStrategy (String code) {
        for (EncryptEnum handler : EncryptEnum.values ()) {
            if (handler.code.equals (code)) {
                return handler.encryption;
            }
        }
        return null;
    }
}
