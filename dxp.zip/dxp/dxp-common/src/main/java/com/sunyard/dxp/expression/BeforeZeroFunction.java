package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 在指定字符串前补0
 */
@FunctionLibrary( code = "beforeZero", name = "字符串前补0", expression = "(beforeZero\\()([0-9]+\\,\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "beforeZero(16)", hasProperty = true )
@Component
public class BeforeZeroFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            params = "";
        }
        if (params.contains(",")) {
            String[] paramArr = params.split(",");
            String strVal = "";
            if (paramArr.length > 1) {
                strVal = params.substring(params.indexOf(",") + 1);
            }
            return StringUtil.formatStr(strVal, Integer.parseInt(paramArr[ 0 ]), "0", true);
        } else {
            return params;
        }
    }
}
