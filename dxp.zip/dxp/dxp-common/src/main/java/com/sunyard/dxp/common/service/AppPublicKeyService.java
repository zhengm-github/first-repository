package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.AppPublicKey;
import com.sunyard.dxp.common.qo.AppPublicKeyQo;
import com.sunyard.frameworkset.core.service.BaseService;

/**
 * 应用公钥 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:44 CST 2019
 */
public interface AppPublicKeyService extends BaseService< AppPublicKey, String, AppPublicKeyQo > {
    /**
     * 根据公钥查询应用公钥
     *
     * @param publicKey
     * @return
     */
    AppPublicKey findByKey(String publicKey);
}
