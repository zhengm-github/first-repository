package com.sunyard.dxp.message.service.impl;

import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * @Description 请求报文完全XML报文解析
 * @Author zhangxin
 * @Date 2020/1/10 9:14
 * @Version 1.0
 */
@Service( "xmlResolve" )
@AgreementLibrary( code = "xml", name = "请求报文完全XML报文解析" )
public class RequestResolveServiceXmlImpl implements RequestResolveService {

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Autowired
    @Qualifier( "regionSign" )
    private SignService regionSignService;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_008);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 1) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_013);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > rules = requestResolveDto.getProcotolResolveRules();
        List< ParamRule > paramRules = RuleConvertUtils.convertXmlRules(rules.get(0).getChildRules());
        Map< String, Object > xmlbody =
                baseResolveXmlService.execute(paramRules, requestResolveDto.getMessage(), requestResolveDto.getEncoding());
        // 获取签名与部分(包括 机构)
        regionSignService.getSign(xmlbody);
        return xmlbody;
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > rules = requestResolveDto.getProcotolResolveRules();
        List< ParamRule > paramRules = RuleConvertUtils.convertXmlRules(rules.get(0).getChildRules());

        // 获取对应的接出或者接入接口
        OutBoundSvc outBoundSvc = rules.get(0).getProcotolResolvePlan().getOutBoundSvc();
        InBoundSvc inBoundSvc = rules.get(0).getProcotolResolvePlan().getInBoundSvc();
        // 添加sign值（1 表示实时业务）
        regionSignService.setSign(map, outBoundSvc == null ? inBoundSvc : outBoundSvc, signDto, "1", "");
        return baseResolveXmlService.mapExecute(paramRules, map, requestResolveDto.getEncoding());
    }


}
