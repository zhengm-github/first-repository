package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;

/**
* 应用服务（用于前置生成流水号）
* Author: Created by code generator
* Date: Tue Dec 24 10:43:18 CST 2019
*/
@Entity
@Table(name = "DXP_APP_SERVER")
public class AppServer implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6760125837919641057L;

    /** 应用服务ID */
    @Id
//    @GeneratedValue( generator = "hibernate-uuid")
//    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "APP_SERVER_ID")
    private String appServerId;

    /** 编号 */
    @Column( name = "CODE")
    private String code;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** 备注 */
    @Column( name = "MEMO")
    private String memo;

    /** 端口 */
    @Column( name = "PORT")
    private String port;

    public String getAppServerId() {
        return appServerId;
    }

    public void setAppServerId(String appServerId) {
        this.appServerId = appServerId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

}
