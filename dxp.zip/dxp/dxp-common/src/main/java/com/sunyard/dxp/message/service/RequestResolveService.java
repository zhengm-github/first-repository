package com.sunyard.dxp.message.service;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;

import java.util.Map;

/**
 * @Description 请求报文解析服务
 * @Author zhangxin
 * @Date 2020/1/10 8:54
 * @Version 1.0
 **/
public interface RequestResolveService {

    /**
     * 请求报文解析入口
     *
     * @param requestResolveDto 请求报文解析Dto<封装DTO防止传输对象变化太快，太多，减少接口改动>
     * @param signDto 验签参数
     * @return java.util.Map<java.lang.String                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               java.lang.Object>
     * @author zhangxin
     * @date 2020/1/10 9:34
     */
    default Map<String, Object> execute(SignDto signDto, RequestResolveDto requestResolveDto) {
        if (requestResolveDto == null) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_009);
        }
        this.validate(requestResolveDto);
        return this.resolve(signDto, requestResolveDto);
    }

    /**
     * 校验传入参数是否合法
     * @date 2020/1/10 9:33
     */
    void validate(RequestResolveDto requestResolveDto);

    /**
     * 解析报文
     *
     * @param requestResolveDto 请求报文解析Dto<封装DTO防止传输对象变化太快，太多，减少接口改动>
     * @return java.util.Map<java.lang.String                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               java.lang.String>
     * @author zhangxin
     * @date 2020/1/10 9:34
     */
    Map<String, Object> resolve(SignDto signDto, RequestResolveDto requestResolveDto);


    /**
     * 组装报文
     * @param map
     * @param signDto
     * @param requestResolveDto
     * @return
     */
    Map<String,Object> mapResolve(Map<String, Object> map, SignDto signDto, RequestResolveDto requestResolveDto);
}