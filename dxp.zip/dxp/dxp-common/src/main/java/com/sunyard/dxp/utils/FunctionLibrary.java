package com.sunyard.dxp.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Thud
 * @date 2020/2/24 15:12
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface FunctionLibrary {
    String code() default "";
    String name() default "";
    //是否是关系函数
    boolean isRelation() default false;
    String type() default "all";
    String expression() default"";
    String exp() default "";
    //是否有属性${}
    boolean hasProperty() default false;
}
