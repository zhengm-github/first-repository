package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 用于现将value 按照分隔符分割，再取数组中第几个数据
 *
 * @author Thud
 * @date 2020/1/2 16:06
 */
@FunctionLibrary( code = "sepNum", name = "分割取值", expression = "(sepNum\\()([\\|\\@0-9\\,]+\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "sepNum(x@y)", hasProperty = true )
@Component
public class SepNumFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        //sepNum(|@2,1|2|3)
        String[] param = params.split("@");

        String sepSign = "|".equals(param[ 0 ]) ? "\\|" : param[ 0 ];  // 数据分隔符
        String[] property = param[ 1 ].split(",");

        String strVal = "" ;
        if(property.length>1){
            strVal = param[1].substring(param[1].indexOf(",")+1) ;
        }

        String[] arr = strVal.split(sepSign);
        return arr[ Integer.parseInt(property[ 0 ]) ];
    }
}
