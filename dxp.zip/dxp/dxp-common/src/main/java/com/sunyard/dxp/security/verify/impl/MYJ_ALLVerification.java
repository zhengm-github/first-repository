package com.sunyard.dxp.security.verify.impl;

import com.sunyard.dxp.security.sign.impl.MYJ_ALLSignature;
import com.sunyard.dxp.security.verify.Verification;

public class MYJ_ALLVerification implements Verification {

    @Override
    public boolean verify(String src, String encryptionSrc,String key) {
        return encryptionSrc.equals(new MYJ_ALLSignature().sign(src,key));
    }
}
