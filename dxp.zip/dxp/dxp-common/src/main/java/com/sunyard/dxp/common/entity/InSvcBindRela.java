package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
* 接入服务数据绑定模式
* Author: Created by code generator
* Date: Tue Dec 24 10:46:50 CST 2019
*/
@Entity
@Table(name = "DXP_IN_SVC_BIND_RELA")
public class InSvcBindRela implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8024562947447808595L;

    /** 数据映射配置规划ID */
    @Id
    @Column( name = "DATA_MAP_SCHEMA_ID")
    private String dataMapSchemaId;

    /** 接入服务接口ID */
    @Id
    @Column( name = "IN_BOUND_SVC_ID")
    private String inBoundSvcId;

    public String getDataMapSchemaId() {
        return dataMapSchemaId;
    }

    public void setDataMapSchemaId(String dataMapSchemaId) {
        this.dataMapSchemaId = dataMapSchemaId;
    }

    public String getInBoundSvcId() {
        return inBoundSvcId;
    }

    public void setInBoundSvcId(String inBoundSvcId) {
        this.inBoundSvcId = inBoundSvcId;
    }

}
