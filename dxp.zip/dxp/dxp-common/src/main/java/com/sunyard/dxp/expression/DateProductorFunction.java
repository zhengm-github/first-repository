package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.frameworkset.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.Date;

/**
 * 用于不同时间格式之间的转换（pattern1 转到 pattern2）
 *
 * @author Thud
 * @date 2020/1/3 14:35
 */
@FunctionLibrary( code = "dateProductor", name = "日期时间转换（P1转成P2）", expression = "(dateProductor\\()([\\sA-Za-z0-9\\-\\|,\\:\\*]*\\$\\{[\\s\\w]+\\})(\\))", type = "date", exp = "dateProductor(yyyyMMdd|yyyy-MM-dd)", hasProperty = true )
@Component
public class DateProductorFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if (StringUtils.isBlank(params) || "".equals(params.trim())) {
            return "";
        }
        //dateProductor(yyyyMMdd|yyyy-MM-dd,20190101)
        String[] param = params.split("\\|");
        if (param.length != 2) {
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        //再次分割 结束规则和 数据
        String[] property = param[ 1 ].split(",", -1);
        if (property.length != 2) {
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        String startP = param[ 0 ];
        String endP = property[ 0 ];
        String endStr = "";
        try {
            Date date = DateUtils.parseDate(property[ 1 ], startP);
            endStr = DateUtil.date2Str(date, endP);
        } catch (ParseException e) {
            endStr = property[ 1 ]; // 有异常则保持原数据
        }
        return endStr;
    }
}
