package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 处理状态和处理码 映射单位的处理码
 */
@FunctionLibrary( code = "PPResult", name = "Prcsts+Prccd 映射单位处理码 ", expression = "(\\$\\{[\\s\\w]+\\})(PPResult)(\\$\\{[\\s\\w]+\\})", type = "all", isRelation = true, exp = "PPResult" )
@Component
public class PPResultFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {

        if (StringUtils.isNotBlank(params) && params.contains("PPResult")) {
            String[] paramArr = params.split("PPResult", -1);
            if (paramArr.length < 2) {
                return "";
            }
            try {
                // prcsts = PR03||Pr05 表成功
                if("PR03".equals(paramArr[ 0 ]) || "PR05".equals(paramArr[ 0 ])){
                    return "0000" ;
                }else if("PR07".equals(paramArr[ 0 ])){
                    return "3005" ;
                }else{
                    String value = ExpMapper.prccdCorpMap.get(paramArr[ 1 ]) ;

                    if (value != null && value.contains(",")) {
                        return value.split(",", -1)[ 0 ];
                    }else{
                        return ExpMapper.prccdCorpMap.get("default").split(",")[ 0 ]; // 默认失败的情况
                    }
                }
            } catch (Exception e) {
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                        DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
            }
        }
        return params;
    }
}
