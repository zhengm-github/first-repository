package com.sunyard.dxp.utils;

import com.sunyard.dxp.common.entity.ExpData;
import com.sunyard.dxp.expression.ParamExpression;
import com.sunyard.dxp.message.factory.ServiceFactory;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Thud
 * @date 2020/2/24 16:28
 * 表达式处理优先处理非关系函数。
 */

public class ParamExp {


    /**
     * 执行定义的函数
     *
     * @param code        函数名
     * @param exp         当前函数的表达式
     * @param paramMapper 本次转换的字段的整体映射（内部全是${xxxx} 表示原字段）
     * @return
     */
    public StringBuffer getExp(String code, ExpData exp, StringBuffer paramMapper) {
        Pattern subPattern = Pattern.compile(exp.getExpression());
        StringBuffer sb = new StringBuffer();
        Matcher subMatcher = subPattern.matcher(paramMapper.toString());
//        关系型函数
        if (exp.isRelation()) {
            return new StringBuffer(ServiceFactory.getBeanStatic(code + "Function", ParamExpression.class).expCompute(paramMapper.toString()));
        } else {
            while (subMatcher.find()) {
                subMatcher.appendReplacement(sb, ServiceFactory.getBeanStatic(code + "Function", ParamExpression.class).
                        expCompute(subMatcher.group(2)));
            }
        }
        return subMatcher.appendTail(sb);
    }


    /**
     * 执行定义的函数
     *
     * @param code        函数名
     * @param exp         当前函数的表达式
     * @param paramMapper 本次转换的字段的整体映射（内部全是${xxxx} 表示原字段）
     * @param uKeyMap     ${xxxx} 对应的值
     * @return
     */
    public StringBuffer getExp(String code, ExpData exp, StringBuffer paramMapper, Map< String, String > uKeyMap) {
        Pattern subPattern = Pattern.compile(exp.getExpression());
        StringBuffer sb = new StringBuffer();
        Matcher subMatcher = subPattern.matcher(paramMapper.toString());
        if (exp.isRelation()) {
            // 这个里面有 ${xxxx} ;
            StringBuffer value = paramMapper;
            if (exp.getExpression().contains("CBSPQuery")
                    || exp.getExpression().contains("NBCBSP")
                    || exp.getExpression().contains("PPResult")|| exp.getExpression().contains("PPDesc")) {

                // 获取属性的值
                value = getPropVal(paramMapper.toString(), uKeyMap);
            }

            return new StringBuffer(ServiceFactory.getBeanStatic(
                    code + "Function", ParamExpression.class).expCompute(value.toString()));
        } else {
            String key = "";
            StringBuffer value = null;
            while (subMatcher.find()) {
                key = subMatcher.group(2);
                // 这个里面有 ${xxxx}， 准换为对应的值 ;
                value = getPropVal(key, uKeyMap);
                subMatcher.appendReplacement(sb,
                        ServiceFactory.getBeanStatic(code + "Function", ParamExpression.class)
                                .expCompute(value.toString()));
            }
            return subMatcher.appendTail(sb);
        }
    }

    /**
     * 根据表达式获取属性对应的具体值，并放在整体表达式中
     *
     * @param paramMapper
     * @param uKeyMap
     */
    public StringBuffer getPropVal(String paramMapper, Map< String, String > uKeyMap) {
        Pattern pattern = Pattern.compile("(\\$\\{)([0-9\\s\\w-]+)(\\})");  // 支持汉字
        StringBuffer sb = new StringBuffer();
        Matcher subMatcher = pattern.matcher(paramMapper);
        String val = "";
        while (subMatcher.find()) {
            val = uKeyMap.get(subMatcher.group(0));
            subMatcher.appendReplacement(sb, Matcher.quoteReplacement(StringUtils.isBlank(val) ? "" : val));
        }
        return subMatcher.appendTail(sb);
    }
}
