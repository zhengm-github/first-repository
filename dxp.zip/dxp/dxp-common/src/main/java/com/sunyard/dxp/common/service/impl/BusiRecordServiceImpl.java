package com.sunyard.dxp.common.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.dao.BusiRecordDao;
import com.sunyard.dxp.common.entity.BusiRecord;
import com.sunyard.dxp.common.entity.SvcRspMsg;
import com.sunyard.dxp.common.qo.BusiRecordQo;
import com.sunyard.dxp.common.service.BusiRecordService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import com.sunyard.frameworkset.util.DateUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.*;

/**
 * 记录业务信息（请求和响应） service
 * <p>
 * Author: Created by code generator
 * Date: Tue Jun 09 17:17:29 CST 2020
 */
@Service
public class BusiRecordServiceImpl extends BaseServiceImpl< BusiRecord, String, BusiRecordQo > implements BusiRecordService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusiRecordServiceImpl.class);

    @Autowired
    private BusiRecordDao busiRecordDao;

    private String TimeFormat = "yyyy-MM-dd HH:mm:ss";

    @Override
    public SvcRspMsg findBySvcCodeAndMsgId(String svcCode, String msgTranId) {

        BusiRecord busiRecord = busiRecordDao.findBySvcCodeAndMsgId(svcCode, msgTranId);
        return transBusiToMsg(busiRecord);
    }

    @Override
    public boolean deleteBySvcCodeAndMsgId(String svcCode, String msgTranId) {
        // 删除之前先查询看下有没有记录
        BusiRecord busiRecord = busiRecordDao.findBySvcCodeAndMsgId(svcCode, msgTranId);
        if (busiRecord == null) {
            return true;  // 查询不到记录，则表示删除成功
        }
        int updateNum = busiRecordDao.deleteBySvcCodeAndMsgId(svcCode, msgTranId);
        if (updateNum > 0) {
            // 删除记录成功
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteBySvcRspMsgId(String svcRspMsgId) {

        int updateNum = busiRecordDao.deleteBySvcRspMsgId(svcRspMsgId);
        if (updateNum > 0) {
            // 删除记录成功
            return true;
        }
        return false;
    }

    @Override
    public List< SvcRspMsg > findByMsgId(String msgTranId) {

        List< BusiRecord > busiRecordList = busiRecordDao.findByMsgId(msgTranId);
        List< SvcRspMsg > svcRspMsgList = null;
        if (CollectionUtils.isNotEmpty(busiRecordList)) {
            svcRspMsgList = new ArrayList<>();
            for (BusiRecord busiRecord : busiRecordList) {
                svcRspMsgList.add(transBusiToMsg(busiRecord));
            }
        }
        return svcRspMsgList;
    }

    @Override
//    @Transactional( propagation = Propagation.REQUIRES_NEW )
    public boolean saveForMap(Map< String, Object > dataMap) {

        // 将dataMap 转换成 busirecord

        JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(dataMap));
        SvcRspMsg svcRspMsg = JSON.toJavaObject(jsonObject, SvcRspMsg.class);
        //查询原有记录
        SvcRspMsg requestMsg = findBySvcCodeAndMsgId(svcRspMsg.getSvcCode(), svcRspMsg.getMsgTranId());
        //请求失败删除记录
        if (requestMsg != null) {
            try {
                // 1、已经请求过
                if (requestMsg.isReqStatus()) {
                    if (!requestMsg.isRspStatus()) {
                        // a、请求成功(没有响应或者响应失败)， 添加响应
                        // 做修改
                        updBusi(requestMsg);
                    } else {
                        // b、请求成功， 切已经响应过。 不作处理
                    }
                } else {
                    // c、请求不成功，删除原请求， 保存新请求
                    updBusi(requestMsg);
                }
            } catch (Exception e) {
                LOGGER.info("记录信息异常！,[{}]", e);
                throw e;
            }
        } else {

            ///2、未产生请求，则记录请求
            busiRecordDao.create(transMsgToBusi(svcRspMsg));
        }
        return true;  // 更新记录成功
    }

    /**
     * 修改记录
     *
     * @param svcRspMsg
     */
    private void updBusi(SvcRspMsg svcRspMsg) {
        BusiRecord busiRecord = busiRecordDao.findBySvcCodeAndMsgId(svcRspMsg.getSvcCode(), svcRspMsg.getMsgTranId());
        if (busiRecord == null) {
            LOGGER.info("对应记录不存在无法修改,[svccode={}, msgTranId={}]",
                    svcRspMsg.getSvcCode(), svcRspMsg.getMsgTranId());
            return;
        }
        BusiRecord newBusiRecord = transMsgToBusi(svcRspMsg);
        newBusiRecord.setBusiId(busiRecord.getBusiId());
        busiRecordDao.update(newBusiRecord);
        LOGGER.info("更新记录完成,[svccode={}, msgTranId={}]",
                svcRspMsg.getSvcCode(), svcRspMsg.getMsgTranId());
    }

    /**
     * 将 BusiRecord 对象转换为 SvcRspMsg
     *
     * @param busiRecord
     * @return
     */
    private SvcRspMsg transBusiToMsg(BusiRecord busiRecord) {

        if (busiRecord == null) {
            return null;
        }
        SvcRspMsg svcRspMsg = new SvcRspMsg();
        // bean 之间转换
        svcRspMsg.setErrorInfo(busiRecord.getErrInfo());
        try {
            svcRspMsg.setGmtRequest(DateUtils.parseDate(busiRecord.getReqTime(), TimeFormat));
            svcRspMsg.setGmtReponse(DateUtils.parseDate(busiRecord.getReqTime(), TimeFormat));
        } catch (ParseException e) {
            LOGGER.info("从 DXP_BUSI_RECORD 表获取的 请求或响应日期转换为Date异常, reqTime=[{}], rspTime=[{}]"
                    , busiRecord.getReqTime(), busiRecord.getRspTime());
        }
        svcRspMsg.setReqStatus("1".equals(busiRecord.getReqStatus()));
        svcRspMsg.setRspStatus("1".equals(busiRecord.getRspStatus()));
        svcRspMsg.setCallbackUrl(busiRecord.getUrl());

        svcRspMsg.setBundleCode(busiRecord.getBundleCode());
        svcRspMsg.setBundleName(busiRecord.getBundleName());
        svcRspMsg.setMsgTranId(busiRecord.getMsgTranId());
        svcRspMsg.setPackTranId(busiRecord.getPackTranId());
        svcRspMsg.setReqMessage(busiRecord.getReqMessage());
        svcRspMsg.setRspMessage(busiRecord.getRspMessage());
        svcRspMsg.setSvcCode(busiRecord.getSvcCode());
        svcRspMsg.setSvcName(busiRecord.getSvcName());
        svcRspMsg.setSvcRspMsgId(busiRecord.getSvcRspMsgId());
        svcRspMsg.setSvcType(busiRecord.getSvcType());
        svcRspMsg.setReqResolveData(busiRecord.getReqResolveData());
        return svcRspMsg;
    }

    /**
     * 将 SvcRspMsg 对象转换为 BusiRecord
     *
     * @param svcRspMsg
     * @return
     */
    private BusiRecord transMsgToBusi(SvcRspMsg svcRspMsg) {

        if (svcRspMsg == null) {
            return null;
        }
        try {
            // bean 之间转换
            BusiRecord busiRecord = new BusiRecord();
            busiRecord.setBusiId(UUIDUtils.getUUID32());
            busiRecord.setErrInfo(svcRspMsg.getErrorInfo());
            Date nowDate = new Date();
            busiRecord.setReqTime(DateUtil.date2Str(nowDate, TimeFormat));
            busiRecord.setRspTime(DateUtil.date2Str(nowDate, TimeFormat));
            busiRecord.setReqStatus(svcRspMsg.isReqStatus() ? "1" : "0");
            busiRecord.setRspStatus(svcRspMsg.isRspStatus() ? "1" : "0");
            busiRecord.setUrl(svcRspMsg.getCallbackUrl());
            busiRecord.setBundleCode(svcRspMsg.getBundleCode());
            busiRecord.setBundleName(svcRspMsg.getBundleName());
            busiRecord.setMsgTranId(svcRspMsg.getMsgTranId());
            busiRecord.setPackTranId(svcRspMsg.getPackTranId());
            busiRecord.setReqMessage(svcRspMsg.getReqMessage());
            busiRecord.setRspMessage(svcRspMsg.getRspMessage());
            busiRecord.setSvcCode(svcRspMsg.getSvcCode());
            busiRecord.setSvcName(svcRspMsg.getSvcName());
            busiRecord.setSvcRspMsgId(svcRspMsg.getSvcRspMsgId());
            busiRecord.setSvcType(svcRspMsg.getSvcType());
            busiRecord.setReqResolveData(svcRspMsg.getReqResolveData());
            return busiRecord;
        } catch (Exception e) {
            LOGGER.info("svcRspMsg 转成 busiRecord 失败！，[{}]", e);
            e.printStackTrace();
        }
        return null;
    }

}
