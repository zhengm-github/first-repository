package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.InSvcBindRelaDao;
import com.sunyard.dxp.common.entity.InSvcBindRela;
import com.sunyard.dxp.common.qo.InSvcBindRelaQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

/**
 * 接入服务数据映射配置 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:55:37 CST 2019
 */
@Repository
public class JpaInSvcBindRelaDaoImpl extends JpaBaseDaoImpl< InSvcBindRela, String, InSvcBindRelaQo > implements InSvcBindRelaDao {

    @Override
    public void deleteByInBoundSvcId(String inBoundSvcId) {

        if (StringUtils.isNotBlank(inBoundSvcId)) {
            this.executeUpdate(" delete from InSvcBindRela as obj where obj.inBoundSvcId = ?", inBoundSvcId) ;
        }
    }

    @Override
    public void deleteByDataMapSchemaId(String dataMapSchemaId) {

        if (StringUtils.isNotBlank(dataMapSchemaId)) {
            this.executeUpdate(" delete from InSvcBindRela as obj where obj.dataMapSchemaId = ?", dataMapSchemaId) ;
        }
    }

    @Override
    public void deleteByDataMapSchemaIdAndInBoundSvcId(String dataMapSchemaId, String inBoundSvcId) {

        if (StringUtils.isNotBlank(dataMapSchemaId) && StringUtils.isNotBlank(inBoundSvcId)) {
            this.executeUpdate(" delete from InSvcBindRela as obj where obj.dataMapSchemaId = ? and obj.inBoundSvcId = ?"
                    , dataMapSchemaId, inBoundSvcId) ;
        }
    }
}
