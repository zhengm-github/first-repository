package com.sunyard.dxp.security.encrypt.impl;

import com.sunyard.dxp.security.encrypt.Encryption;
import com.sunyard.dxp.utils.EncryptionLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;

/**
 * RSA私钥加密
 */
@EncryptionLibrary(code = "RSAPrivateEncryption" , name = "RSA私钥加密")
public class RSAPrivateEncryption implements Encryption {
    private static final Logger LOGGER = LoggerFactory.getLogger( RSAPrivateEncryption.class );

    @Override
    public String encrypt(String content, String key) {
        byte[] bytesContent = content.getBytes();
        byte[] bytesKey = Base64.decodeBase64(key);
        try {
            //取得私钥
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(bytesKey);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            //生成私钥
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
            //数据加密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, privateKey);
            return Base64.encodeBase64String(cipher.doFinal(bytesContent));
        }catch (Exception e){
            LOGGER.error("RSA私钥加密失败");
            throw new FapException("","RSA私钥加密失败");
        }
    }
}
