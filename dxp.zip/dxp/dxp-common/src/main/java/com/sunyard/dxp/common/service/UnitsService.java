package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.Units;
import com.sunyard.dxp.common.qo.UnitsQo;

/**
 * 单位 service 接口
 *
 * Author: Created by code generator
 * Date: Wed Dec 25 19:35:40 CST 2019
 */
public interface UnitsService extends BaseService<Units, String, UnitsQo> {
    /**
     * 根据code查询单位
     * @param code
     * @return
     */
    Units findUnitsByCode(String code);
}
