package com.sunyard.dxp.handler;

import java.util.Map;

/**
 * Created by tangjiejie on 2018/3/1.
 */
public interface DxpClientDataHandler {

    /**
     * doPost 到平台 之前的处理
     * @param data
     * @param extraParams
     * @return
     */
    Object beforeHandle(Map<String, String> data, Map<String, String> extraParams);

    /**
     * doPost到平台 之后的处理
     * @param response
     * @param extraParams
     * @return
     */
    Map<String, Object> afterHandle(Object response, Map<String, String> extraParams);
}
