package com.sunyard.dxp.message.service.impl;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.dxp.utils.StringUtil;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * @Description 定长报文解析基础服务
 * @Author zhangxin
 * @Date 2020/1/9 10:17
 * @Version 1.0
 */
@Service( "baseResolveServiceFixed" )
public class BaseResolveServiceFixedImpl implements BaseResolveService {

    private static final Logger log = LoggerFactory.getLogger(BaseResolveServiceFixedImpl.class);

    @Override
    public Map< String, Object > execute(List< ParamRule > rules, String message, String... resolveParam) {
        if (CollectionUtils.isEmpty(rules)) {
            log.warn("定长报文解析规则为空");
            return null;
        }
        // 获取编码
        String encoding = resolveParam[ 0 ];

        String readType = "byte";  // 默认按照字符位数读取
        if (resolveParam.length > 3) {
            readType = resolveParam[ 3 ];
        }
        return resolveFixedMessage(rules, message, encoding, readType);
    }

    /**
     * 读取定长报文内容， 长度都是字符
     *
     * @param rules
     * @param message
     * @param encoding
     * @return
     */
    private Map< String, Object > resolveFixedMessage(List< ParamRule > rules, String message, String encoding, String readType) {


        Map< String, Object > result = null;

        if ("char".equals(readType)) {
            // 按照字符长度读取
            result = new HashMap<>();
            for (ParamRule paramRule : rules) {
                readText(result, paramRule, message);
            }
        } else {
            // 按照字节数组 位数读取
            try {
                if (EncoderEnum.ISO88591.getCode().equals(encoding)) {
                    encoding = "GB18030";
                }
                byte[] messageBytes = message.getBytes(encoding);
                result = readMessageByte(rules, messageBytes, encoding);
            } catch (UnsupportedEncodingException e) {
                log.error("定长报文编码异常", e);
                throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
            }
        }
        return result;
    }

    /**
     * 将文本转化为字节数组 ，再根据位置读取
     *
     * @param rules
     * @param messageBytes
     * @param encoding
     * @return
     * @throws UnsupportedEncodingException
     */
    private Map< String, Object > readMessageByte(List< ParamRule > rules, byte[] messageBytes, String encoding) throws UnsupportedEncodingException {
        Map< String, Object > result = new HashMap<>();
        for (ParamRule paramRule : rules) {
            readTextByte(result, paramRule, messageBytes, encoding);
        }
        return result;
    }

    /**
     * 将文本转化为字节数组 ，再根据位置读取
     *
     * @param result
     * @param paramRule
     * @param messageBytes
     * @param encoding
     * @throws UnsupportedEncodingException
     */
    private void readTextByte(Map< String, Object > result, ParamRule paramRule, byte[] messageBytes, String encoding) throws UnsupportedEncodingException {
        String value = "";
        if (messageBytes.length >= paramRule.getStart() + paramRule.getLength()) {
            value = new String(messageBytes, paramRule.getStart(), paramRule.getLength(), encoding).trim();
        } else if (messageBytes.length > paramRule.getStart() && paramRule.getStart() + paramRule.getLength() > messageBytes.length) {
            String params = StringUtil.formatStr(
                    new String(messageBytes), paramRule.getStart() + paramRule.getLength(), " ", false);
            byte[] messageByte = params.getBytes(encoding);
            value = new String(messageByte, paramRule.getStart(), paramRule.getLength(), encoding).trim();
        } else {
            value = "";
        }

        // 优先xpath
        result.put(StringUtils.defaultString(paramRule.getXpath(), paramRule.getName()), value);
    }

    /**
     * 将文本 按照字符位置读取
     *
     * @param result
     * @param paramRule
     * @param message
     * @throws UnsupportedEncodingException
     */
    private void readText(Map< String, Object > result, ParamRule paramRule, String message) {

        String value = "";
        if (message.length() >= paramRule.getStart() + paramRule.getLength()) {
            value = message.substring(paramRule.getStart(), paramRule.getStart() + paramRule.getLength());
        } else if (message.length() > paramRule.getStart()
                && paramRule.getStart() + paramRule.getLength() > message.length()) {
            String params = StringUtil.formatStr(
                    message, paramRule.getStart() + paramRule.getLength(), " ", false);
            value = params.substring(paramRule.getStart(), paramRule.getStart() + paramRule.getLength());
        } else {
            value = "";
        }

        // 优先xpath
        result.put(StringUtils.defaultString(paramRule.getXpath(), paramRule.getName()), value);
    }

    @Override
    public Map< String, Object > mapExecute(List< ParamRule > rules, Map< String, Object > map, String... resolveParam) {
        Map< String, Object > fixMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        Map< String, Object > keymap = new HashMap<>();
        if (!rules.isEmpty()) {
            for (ParamRule paramRule : rules) {
                String value = "";
                //系统指定值()
                if ("MesgID".equals(paramRule.getName()) || "MesgRefID".equals(paramRule.getName())) {
                    value = StringUtil.formatStr(String.valueOf(map.get(MsgKeys.TRANID)), paramRule.getLength(), " ", false);
                } else {
                    if (StringUtils.isNotBlank(paramRule.getName())) {
                        value = StringUtil.formatStr(
                                String.valueOf(ObjectUtils.defaultIfNull(map.get(paramRule.getName()), "")), paramRule.getLength(), " ", false);
                    } else {
                        value = StringUtil.formatStr(
                                String.valueOf(ObjectUtils.defaultIfNull(map.get(paramRule.getDetailName()), "")), paramRule.getLength(), " ", false);
                    }
                }
                keymap.put(String.valueOf(paramRule.getStart()), value);
            }
        }

        Set< String > keySet = keymap.keySet();
        //key进行排序按顺序拼接
        String[] keys = getKeySort(keySet);
        for (String key : keys) {
            sb.append(keymap.get(key));
        }
        fixMap.put("package", sb.toString());
        return fixMap;
    }

    /**
     * key 进行排序按顺序进行拼接
     *
     * @param keySet
     * @return
     */
    private String[] getKeySort(Set< String > keySet) {
        List< String > list = new ArrayList<>();

        if (!keySet.isEmpty()) {
            for (String str : keySet) {
                list.add(str);
            }
        }
        String[] keys = list.toArray(new String[ 0 ]);
        for (int i = 0; i < keys.length; i++) {
            for (int j = 0; j < keys.length - 1; j++) {
                if (Integer.valueOf(keys[ j ]) > Integer.valueOf(keys[ j + 1 ])) {
                    String temp = keys[ j + 1 ];
                    keys[ j + 1 ] = keys[ j ];
                    keys[ j ] = temp;
                }
            }
        }
        return keys;
    }

}
