package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.ProcotolResolvePlan;
import com.sunyard.dxp.common.qo.ProcotolResolvePlanQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 协议解析规划 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:25 CST 2020
 */
public interface ProcotolResolvePlanDao extends BaseDao<ProcotolResolvePlan, String, ProcotolResolvePlanQo> {

    /**
     * 根据name查询
     * @param name
     * @return
     */
    ProcotolResolvePlan findByName(String name) ;

    /**
     * 查询接口协议解析配置
     * @param svcId
     * @param dataKind
     * @param svcType
     * @return
     */
    ProcotolResolvePlan queryBySvcId(String svcId, String dataKind, String svcType) ;


    /**
     * 根据接入服务id删除协议解析规划
     * @param inBoundSvcId
     * @return
     */
    void deleteByInsvcId(String inBoundSvcId);

    /**
     * 根据接出服务id删除协议解析规划
     * @param outBoundSvcId
     * @return
     */
    void deleteByOutsvcId(String outBoundSvcId);

    /**
     * 根据接入服务id获取协议解析规划
     * @param inBoundSvcId
     * @return
     */
    List<ProcotolResolvePlan> findByInsvcId(String inBoundSvcId);

    /**
     * 根据接出服务id获取协议解析规划
     * @param outBoundSvcId
     * @return
     */
    List<ProcotolResolvePlan> findByOutsvcId(String outBoundSvcId);

    /**
     *根据接出接口Id查询协议解析规划
     * @param outBoundSvcId
     * @param dataKind 请求或者响应
     * @return
     */
    ProcotolResolvePlan queryPlanByObsId(String outBoundSvcId, String dataKind) ;

    /**
     *根据接入接口Id查询协议解析规划
     * @param inBoundSvcId
     * @param dataKind 请求或者响应
     * @return
     */
    ProcotolResolvePlan queryPlanByIbsId(String inBoundSvcId, String dataKind) ;
}
