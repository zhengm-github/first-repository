package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.DataBindPropertyDefRela;
import com.sunyard.dxp.common.qo.DataBindPropertyDefRelaQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 接出数据属性绑定配置 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:44:42 CST 2019
 */
public interface DataBindPropertyDefRelaDao extends BaseDao<DataBindPropertyDefRela, String, DataBindPropertyDefRelaQo> {

    /**
     * 根据数据属性id接出数据属性绑定配置
     * @param propertyId
     * @return
     */
    void deleteByPropertyId(String propertyId);

    /**
     * 根据数据属性id 和 configId接出数据属性绑定配置
     * @param propertyId
     * @param configId
     * @return
     */
    void deleteByPropertyIdAndConfig(String propertyId, String configId);

    /**
     * 根据数据绑定配置ID接出数据属性绑定配置
     * @param dataBindConfigId
     * @return
     */
    List<DataBindPropertyDefRela> findByDataBindConfigId(String dataBindConfigId);
}
