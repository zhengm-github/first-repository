package com.sunyard.dxp.message.service.impl;

import cn.hutool.core.codec.Base64;
import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.entity.ProcotolResolvePlan;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.*;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.xml.sax.InputSource;

import java.io.*;
import java.util.*;

/**
 * @Description 定长报文头+XML报文体解析
 * @Author zhangxin
 * @Date 2020/1/10 11:02
 * @Version 1.0
 */
@Service( "fixedAndXmlResolve" )
@AgreementLibrary( code = "fixedAndXml", name = "定长报文头+XML报文体" )
public class RequestResolveServiceFixedHeadAndXmlBodyImpl implements RequestResolveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestResolveServiceFixedHeadAndXmlBodyImpl.class);

    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    private String encode = "UTF-8";

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 2) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        try {

            ProcotolResolveRule packHeadRule = ruleList.get(0); // 报文头规则
            ProcotolResolveRule packBodyRule = ruleList.get(1); // 报文体规则
            // 拆分报文
            String[] splitMessage = splitMessage(requestResolveDto.getMessage(), requestResolveDto.getEncoding(), packHeadRule);
            // 定长报文规则
            List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(packHeadRule.getChildRules());
            // xml报文规则
            List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(packBodyRule.getChildRules());
            Map< String, Object > head =
                    baseResolveService.execute(headRules, splitMessage[ 0 ], requestResolveDto.getEncoding());

            // 如果接收到是312的响应则 对cntt部分进行解密  (XmlUtil.removeSign 去除 签名域)
            String xmlBody = getCntt(XmlUtil.removeSign(splitMessage[ 1 ]), packHeadRule.getProcotolResolvePlan());

            String msgType = "pack";  // 表明数据以 String 形式进行解析
            // 723.001.02 报文特殊处理， 需要确保是 723.02
            Object mesgTypeObj = head.get("MesgType");
            if (mesgTypeObj != null && "cbsp.723.001.02".equalsIgnoreCase(mesgTypeObj.toString().trim())) {
                xmlBody = transFixedToXmlDetail(xmlBody);
                msgType = "file";  // 数据以文件形式进行解析
                LOGGER.info("723报文继续处理 ...");
            }

            // 通过file的
            Map< String, Object > body =
                    baseResolveXmlService.execute(
                            bodyRules, xmlBody, new String[] { requestResolveDto.getEncoding(), msgType, MsgKeys.XML_DETAIL });
            if (!CollectionUtils.isEmpty(head)) {
                body.putAll(head);
            }
            return body;
        } catch (DxpCommonException e) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
        }

    }

    /**
     * 723 尽可能是 723.001.02 报文（定长加密明细报文）
     * 需要先解密再转化为 xml 明细，才能被界面配置的规则所解析
     *
     * @param xmlBody
     * @return
     */
    public String transFixedToXmlDetail(String xmlBody) {

        // 直接获取明细中信息
        LOGGER.info("准备将 cbsp.723.001.02 转化为 cbsp.723.001.01 报文 ...");
        try {
            SAXReader reader = new SAXReader();
            InputSource source = new InputSource(
                    new StringReader(XmlUtil.removeNameSpace(xmlBody, "Document")));
            source.setEncoding(encode);
            Document document = reader.read(source);
            Node fixedDetailNode = document.selectSingleNode("//TxDwnldRspnInf/RsltDtls/Dtl");
            if (fixedDetailNode == null) {
                LOGGER.info("723.001.02报文中没有 //TxDwnldRspnInf/RsltDtls 部分 ");
                return xmlBody;
            }

            // 定长明细加压部分(考虑使用文件)
            String gzipInFileName =
                    DateFormatUtils.format(new Date(), "HHmmss") +
                            Thread.currentThread().getName() + "_" + UUIDUtils.getUUID32() + "_723in";
            GzipAndMd5Util.unzipFileNoMd5(Constant.TEMP_FILES_PATH + File.separator + "files",
                    gzipInFileName, fixedDetailNode.getText().getBytes(encode));

            // 看下解析完成的文件存不存在
            String inFile = Constant.TEMP_FILES_PATH + File.separator + "files" + File.separator + gzipInFileName;
            File gzipFile = new File(inFile);
            if (!gzipFile.exists()) {
                LOGGER.info("解压之后的文件不存在，报文不继续处理");
                throw new DxpCommonException(
                        DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002.getCode(), "解压之后的文件不存在，报文不继续处理");
            }
            LOGGER.info("GZIP解压之后明文文件名：files/[{}]", gzipInFileName);
            Element e = (Element) fixedDetailNode;
            e.getParent().getParent().remove(e.getParent());
            XmlUtil xmlReqDoc = XmlUtil.Create(XmlUtil.FROM_BUFF, document.asXML());
            String parentPath = "/Document/TxDwnldRspn/TxDwnldRspnInf/RsltDtls";
            Element rowElement = null;  // 行元素

            String row = "";
            SplitFileReader splitFileReader = new SplitFileReader(inFile, 1024 * 4); // 默认单条数据不超过 4kb
            int index = 1;
            while (!splitFileReader.END.equals(row = splitFileReader.readLSTLine(encode))) {
                // 舍弃第一行
                if (StringUtils.isEmpty(row.trim())) {
                    LOGGER.info("第 {} 笔长度为空串，被舍弃", index++);
                    continue;
                }
                // 生成xml 明细( 公共部分)
                rowElement = xmlReqDoc.addLoopNode(parentPath, "", 0, false);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/TxId", StringUtil.getDefaultStr(row.substring(0, 16), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/RspnInf/PrcSts", StringUtil.getDefaultStr(row.substring(16, 20), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/RspnInf/PrcCd", StringUtil.getDefaultStr(row.substring(20, 28), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/RspnInf/RjctInf", StringUtil.getDefaultStr(row.substring(28, 133), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Dbtr/Id", StringUtil.getDefaultStr(row.substring(133, 165), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/DbtrId", StringUtil.getDefaultStr(row.substring(225, 239), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Dbtr/Nm", StringUtil.getDefaultStr(row.substring(165, 225), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Dbtr/Issr", StringUtil.getDefaultStr(row.substring(225, 239), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Cdtr/Id", StringUtil.getDefaultStr(row.substring(239, 271), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Cdtr/Nm", StringUtil.getDefaultStr(row.substring(271, 331), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Cdtr/Issr", StringUtil.getDefaultStr(row.substring(331, 345), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/CdtrId", StringUtil.getDefaultStr(row.substring(331, 345), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/Amt", StringUtil.getDefaultStr(row.substring(345, 364), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/ComTraId", StringUtil.getDefaultStr(row.substring(364, 428), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/AltDbtrCd", StringUtil.getDefaultStr(row.substring(428, 463), "").trim(), parentPath, rowElement);
                xmlReqDoc.addLoopEleNode(
                        parentPath + "/AltDbtrNm", StringUtil.getDefaultStr(row.substring(463, 523), "").trim(), parentPath, rowElement);

                if (row.length() <= 780) {
                    //申请业务为代收付业务时，本报文定长部分到此结束，附言部分为变长Max256Text
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/AddtlInf", row.substring(523), parentPath, rowElement);
                } else {
                    //申请业务为实时缴款业务时，附言部分为Exact256Text定长，且仍包括实时缴款业务附加域
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/AddtlInf", StringUtil.getDefaultStr(row.substring(523, 779), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/OrgnlTradDt", StringUtil.getDefaultStr(row.substring(779, 789), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/OrgnlBllTradId", StringUtil.getDefaultStr(row.substring(789, 1045), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/BllTrdIdTp", StringUtil.getDefaultStr(row.substring(1045, 1049), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/OrgnlPrtry", StringUtil.getDefaultStr(row.substring(1049, 1054), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/OrgnlBllAmt", StringUtil.getDefaultStr(row.substring(1054, 1073), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/OrgnlTp", StringUtil.getDefaultStr(row.substring(1073, 1077), "").trim(), parentPath, rowElement);
                    xmlReqDoc.addLoopEleNode(
                            parentPath + "/CstmrPmt/BllPrtInf", StringUtil.getDefaultStr(row.substring(1077), "").trim(), parentPath, rowElement);
                }
            }
            LOGGER.info("cbsp.723.001.01 报文生成完成...");
            splitFileReader.close();  // 关闭读取流
//            String x = xmlReqDoc.dumpToBuff(encode);
//            LOGGER.info("cbsp.723.001.02 转化为 cbsp.723.001.01 报文内容为：[{}]", x);
//            return xmlReqDoc.dumpToBuff(encode);
            String fileName_72301 =
                    Constant.TEMP_FILES_PATH + File.separator + "files" + File.separator + gzipInFileName + "_01.dat";
            int is_success = xmlReqDoc.dumpToFile(fileName_72301);
            if (is_success == 0) {
                return fileName_72301;  // 返回的是文件名
            } else {
                LOGGER.info("转换 723.001.02的明细为 723.001.01 的明细文件失败！,xmlBody = [{}], [{}]", xmlBody, e);
                throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
            }
        } catch (Exception e) {
            LOGGER.info("转换 723.001.02的明细为 723.001.01 的明细失败！,xmlBody = [{}], [{}]", xmlBody, e);
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
        }
    }

    /**
     * 将312的cntt密文转换为 明文
     *
     * @param xmlBody
     * @param plan
     */
    private String getCntt(String xmlBody, ProcotolResolvePlan plan) {

        // 判断是否是 312报文（接入）
        InBoundSvc inBoundSvc = plan.getInBoundSvc();
        OutBoundSvc outBoundSvc = plan.getOutBoundSvc();

        // 作为312接入 和 312接出都 需要base处理 Cntt 除非没有Cntt
        if (!((inBoundSvc != null && inBoundSvc.getCode().contains("312"))
                || (outBoundSvc != null && outBoundSvc.getCode().contains("312")))) {
            return xmlBody;
        }
        LOGGER.info("312或313 报文解压.....");
        try {
            SAXReader reader = new SAXReader();
            InputSource source = new InputSource(
                    new StringReader(XmlUtil.removeNameSpace(xmlBody, "Document")));
            source.setEncoding(encode);
            Document document = reader.read(source);

            Node cnttNode = document.selectSingleNode("//AttchmtCntt/Cntt");
            if (cnttNode == null) {
                LOGGER.info("报文中不存在//AttchmtCntt/Cntt， 返回原报文.");
                return xmlBody;
            }
            String seeStr = new String(Base64.decode(cnttNode.getText().getBytes(encode)), encode);
            // 解析出来的明文可能有报文头
            seeStr = seeStr.replaceAll("&lt;", "<")
                    .replaceAll("&gt;", ">")
                    // 去除 xml 头
                    .replaceAll("(\\<\\?xml)(.*)(\\?\\>)", "");

            LOGGER.info("//AttchmtCntt/Cntt 中解压后明文为：[{}]", seeStr);
            cnttNode.setText(seeStr);
            LOGGER.info("312或313 报文解压结束.....");
            return document.asXML()
                    .replaceAll("&lt;", "<").replaceAll("&gt;", ">");
        } catch (Exception e) {
            LOGGER.info("312 报文Cntt 解压失败！[{}]", e);
            return xmlBody;
        }
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto
            requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        try {

            List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(ruleList.get(0).getChildRules());
            List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(ruleList.get(1).getChildRules());
            Map< String, Object > fixAndXmlMap = new HashMap<>();
            StringBuilder sb = new StringBuilder();
            Map< String, Object > headResult =
                    baseResolveService.mapExecute(headRules, map, null);
            Map< String, Object > bodyResult =
                    baseResolveXmlService.mapExecute(bodyRules, map, requestResolveDto.getEncoding());

            sb.append(headResult.get(MsgKeys.PACKAGE)).append(bodyResult.get(MsgKeys.PACKAGE));
            fixAndXmlMap.put(MsgKeys.PACKAGE, sb.toString());
            return fixAndXmlMap;
        } catch (DxpCommonException e) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
        }
    }

    private String[] splitMessage(String message, String encoding, ProcotolResolveRule procotolResolveRule) {
        String[] result = new String[ 2 ];
        try {
            // ISO-8859-1 处理
            if (EncoderEnum.ISO88591.getCode().equals(encoding)) {
                encoding = "GB18030";
            }
            byte[] messageBytes = message.getBytes(encoding);
            if (procotolResolveRule.getBeginIndex() == null) {
                throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
            }
            int start = procotolResolveRule.getBeginIndex();
            int length;
            int xmlStart;
            if (procotolResolveRule.getEndIndex() != null) {
                length = Integer.valueOf(procotolResolveRule.getEndIndex()) - start + 1;
                xmlStart = Integer.valueOf(procotolResolveRule.getEndIndex()) + 1;
            } else {
                length = messageBytes.length - start;
                xmlStart = messageBytes.length;
            }
            int xmlLength = messageBytes.length - length;
            result[ 0 ] = new String(messageBytes, start, length, encoding).trim();
            result[ 1 ] = new String(messageBytes, xmlStart, xmlLength, encoding).trim();
        } catch (UnsupportedEncodingException e) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
        }
        return result;
    }


}
