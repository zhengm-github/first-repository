package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 接入服务接口
* Author: Created by code generator
* Date: Tue Dec 24 10:46:13 CST 2019
*/
@Entity
@Table(name = "DXP_IN_BOUND_SVC")
public class InBoundSvc implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 4615829011477896797L;

    /** 接入服务接口ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "IN_BOUND_SVC_ID")
    private String inBoundSvcId;

    /** 编号 */
    @Column( name = "CODE")
    private String code;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** URL */
    @Column( name = "URL")
    private String url;

    /** 状态 */
    @Column( name = "STATUS")
    private String status;

    /** 服务性质 */
    @Column( name = "KIND")
    private String kind;

    /** 签名算法 */
    @Column( name = "SIGN_ALGOL")
    private String signAlgol;

    /** 加密算法 */
    @Column( name = "ENCRY_ALGOL")
    private String encryAlgol;

    /** 编码 */
    @Column( name = "ENCODE")
    private String encode;

    /** 报文协议 */
    @Column( name = "MSG_PROCOTOL")
    private String msgProcotol;

    /** 接入接口类型,可选：dyna (动态),static (静态) */
    @Column( name = "IN_BOUND_SVC_TYPE")
    private String inBoundSvcType;

    /** 登录帐号 */
    @Column( name = "LOGIN_NAME")
    private String loginName;

    /** 登录密码 */
    @Column( name = "LOGIN_PASSWORD")
    private String loginPassword;

    /** 签名私钥 */
    @Column( name = "SIGN_PRIVATE_KEY")
    private String signPrivateKey;

    /** 加密私钥 */
    @Column( name = "ENCRY_PRIVATE_KEY")
    private String encryPrivateKey;

    /** 数据对象定义 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "inBoundSvc")
    private Set<DataObjDef> dataObjDefs;

    /** 数据绑定模式 */
    @ManyToMany( fetch = FetchType.EAGER,  cascade = CascadeType.REFRESH, mappedBy = "inBoundServices" )
    private Set<DataBindSchema> dataBindSchemas;

    /** 服务模块 */
    @ManyToMany( fetch = FetchType.LAZY, mappedBy = "inBoundSvcs" )
    private Set<ServiceBundle> serviceBundles;

    /** 签名配置计划 */
    @OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "inBoundSvc")
    private SignConfigSchema inSignConfigSchema;

    /** 协议解析规划 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "inBoundSvc")
    private Set<ProcotolResolvePlan> procotolResolvePlans;

    public String getInBoundSvcId() {
        return inBoundSvcId;
    }

    public void setInBoundSvcId(String inBoundSvcId) {
        this.inBoundSvcId = inBoundSvcId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getSignAlgol() {
        return signAlgol;
    }

    public void setSignAlgol(String signAlgol) {
        this.signAlgol = signAlgol;
    }

    public String getEncryAlgol() {
        return encryAlgol;
    }

    public void setEncryAlgol(String encryAlgol) {
        this.encryAlgol = encryAlgol;
    }

    public String getEncode() {
        return encode;
    }

    public void setEncode(String encode) {
        this.encode = encode;
    }

    public String getMsgProcotol() {
        return msgProcotol;
    }

    public void setMsgProcotol(String msgProcotol) {
        this.msgProcotol = msgProcotol;
    }

    public String getInBoundSvcType() {
        return inBoundSvcType;
    }

    public void setInBoundSvcType(String inBoundSvcType) {
        this.inBoundSvcType = inBoundSvcType;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getLoginPassword() {
        return loginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        this.loginPassword = loginPassword;
    }

    public String getSignPrivateKey() {
        return signPrivateKey;
    }

    public void setSignPrivateKey(String signPrivateKey) {
        this.signPrivateKey = signPrivateKey;
    }

    public String getEncryPrivateKey() {
        return encryPrivateKey;
    }

    public void setEncryPrivateKey(String encryPrivateKey) {
        this.encryPrivateKey = encryPrivateKey;
    }

    public Set<DataObjDef> getDataObjDefs() {
        return dataObjDefs;
    }

    public void setDataObjDefs(Set<DataObjDef> dataObjDefs) {
        this.dataObjDefs = dataObjDefs;
    }

    public Set<ServiceBundle> getServiceBundles() {
        return serviceBundles;
    }

    public void setServiceBundles(Set<ServiceBundle> serviceBundles) {
        this.serviceBundles = serviceBundles;
    }

    public Set<DataBindSchema> getDataBindSchemas() {
        return dataBindSchemas;
    }

    public void setDataBindSchemas(Set<DataBindSchema> dataBindSchemas) {
        this.dataBindSchemas = dataBindSchemas;
    }

    public SignConfigSchema getInSignConfigSchema() {
        return inSignConfigSchema;
    }

    public void setInSignConfigSchema(SignConfigSchema inSignConfigSchema) {
        this.inSignConfigSchema = inSignConfigSchema;
    }

    public Set<ProcotolResolvePlan> getProcotolResolvePlans() {
        return procotolResolvePlans;
    }

    public void setProcotolResolvePlans(Set<ProcotolResolvePlan> procotolResolvePlans) {
        this.procotolResolvePlans = procotolResolvePlans;
    }
}
