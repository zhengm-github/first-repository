package com.sunyard.dxp.security.verify.impl;

import com.sunyard.dxp.security.sign.impl.MYJ_PartSignature;
import com.sunyard.dxp.security.verify.Verification;

public class MYJ_PartVerification implements Verification {

    @Override
    public boolean verify(String src, String encryptionSrc,String key) {
        return encryptionSrc.toUpperCase().equals(new MYJ_PartSignature().sign(src,key).toUpperCase());
    }
}
