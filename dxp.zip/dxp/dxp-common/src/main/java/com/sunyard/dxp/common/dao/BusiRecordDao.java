package com.sunyard.dxp.common.dao;


import com.sunyard.dxp.common.entity.BusiRecord;
import com.sunyard.dxp.common.qo.BusiRecordQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 记录业务信息（请求和响应） dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Jun 09 17:17:29 CST 2020
 */
public interface BusiRecordDao extends BaseDao< BusiRecord, String, BusiRecordQo > {

    /**
     * 根据msgTranId 和 svcCode 查询记录 （唯一！！）
     * svcCode 可以是 ibsCode 或 obscode
     * @param msgTranId
     * @param svcCode
     * @return
     */
    BusiRecord findBySvcCodeAndMsgId(String svcCode , String msgTranId) ;

    /**
     * 根据msgTranId 和 svcCode 删除记录 （唯一！！）
     * svcCode 可以是 ibsCode 或 obscode
     * @param msgTranId
     * @param svcCode
     */
    int deleteBySvcCodeAndMsgId(String svcCode, String msgTranId) ;

    /**
     * 根据 svcRspMsgId 删除记录
     * @param svcRspMsgId
     * @return
     */
    int deleteBySvcRspMsgId(String svcRspMsgId) ;

    /**
     * 根据msgTranId 查询记录 （不唯一）
     * @param msgTranId
     * @return
     */
    List<BusiRecord> findByMsgId(String msgTranId) ;

}
