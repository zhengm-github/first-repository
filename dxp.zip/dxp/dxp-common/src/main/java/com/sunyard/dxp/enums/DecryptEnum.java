package com.sunyard.dxp.enums;

import com.sunyard.dxp.security.decrypt.Decryption;
import com.sunyard.dxp.security.decrypt.impl.AESDecryption;
import com.sunyard.dxp.security.decrypt.impl.Base64Decryption;
import com.sunyard.dxp.security.decrypt.impl.RSAPrivateDecryption;
import com.sunyard.dxp.security.decrypt.impl.RSAPublicDecryption;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * 解密枚举
 */
public enum DecryptEnum implements EnumAware {
    AES("AES","AES",new AESDecryption()),
    BASE64("BASE64","BASE64",new Base64Decryption()),
    RSA_PRIVATE("RSA_PRIVATE","RSA_PRIVATE",new RSAPrivateDecryption()),
    RSA_PUBLIC("RSA_PUBLIC","RSA_PUBLIC",new RSAPublicDecryption()),
    ;

    private final String code;
    private final String name;
    private final Decryption decryption;

    DecryptEnum(String code, String name, Decryption decryption) {
        this.code = code;
        this.name = name;
        this.decryption = decryption;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return this.getName();
    }

    public static Decryption getDecryptionStrategy (String code) {
        for (DecryptEnum handler : DecryptEnum.values ()) {
            if (handler.code.equals (code)) {
                return handler.decryption;
            }
        }
        return null;
    }
}
