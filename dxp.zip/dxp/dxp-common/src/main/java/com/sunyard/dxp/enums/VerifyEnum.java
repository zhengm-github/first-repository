package com.sunyard.dxp.enums;

import com.sunyard.dxp.security.verify.Verification;
import com.sunyard.dxp.security.verify.impl.*;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * 验签枚举
 */
public enum  VerifyEnum implements EnumAware {
    MD5("MD5","MD5",new MD5Verification()),
    SHA1("SHA1","SHA1",new SHA1Verification()),
    MYJ_ALL("MYJ_ALLSignature","MYJ_ALLSignature",new MYJ_ALLVerification()),
    MYJ_PART("MYJ_PartSignature","MYJ_PartSignature",new MYJ_PartVerification()),
    SHA1_WITH_RSA("SHA1WITHRSA","SHA1_WITH_RSA",new SHA1WithRSAVerification());

    private final String code;
    private final String name;
    private final Verification verification;

    VerifyEnum(String code, String name, Verification verification) {
        this.code = code;
        this.name = name;
        this.verification = verification;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return this.getName();
    }

    public static Verification getVerifyStrategy (String code) {
        for (VerifyEnum handler : VerifyEnum.values ()) {
            if (handler.code.equals (code)) {
                return handler.verification;
            }
        }
        return null;
    }
}
