package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 将单位处理码 映射成 对应的 prccd
 *
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary( code = "corpPrccdMapper", name = "单位处理码 转 Prccd", expression = "(corpPrccdMapper\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "corpPrccdMapper()", hasProperty = true )
@Component
public class CorpPrccdMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            //表达式参数不准确
            return "";
        }
        try {
            String value = ExpMapper.corpPrccdMap.get(params);
            if (value != null && value.contains(",")) {
                return value.split(",", -1)[ 0 ]; // 转成 code
            } else {
                return "CB2O0201"; // 失败的情况
            }
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
        }

    }
}
