package com.sunyard.dxp.utils;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.util.HexUtil;
import com.sunyard.dxp.enums.EncoderEnum;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * 计算输入inputstream的MD5并压缩
 *
 * @version 1.0
 * @update 【1】【2019/12/28 13:06】【welkin】【创建】
 */
public class GzipAndMd5Util {


    /**
     * 计算md5，并压缩
     *
     * @param in
     * @return 压缩后的base64编码
     */
    private static GzipAndMd5Result DoZipAndMd5(InputStream in) throws Exception {
        GzipAndMd5Result result = null;
        MessageDigest MD5 = MessageDigest.getInstance("MD5");

        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             GZIPOutputStream gos = new GZIPOutputStream(bos)) {
            byte[] buffer = new byte[ 1024 ];
            int len = 0;
            while ((len = in.read(buffer)) != -1) {
                byte[] readed = new byte[ len ];
                System.arraycopy(buffer, 0, readed, 0, len);
                // binaryOutput(readed);
                gos.write(buffer, 0, len);
                MD5.update(buffer, 0, len);
            }
            gos.flush();
            gos.finish();
            gos.close();
            bos.flush();

            // binaryOutput(bos.toByteArray());
            result = new GzipAndMd5Result();
            result.setGzipStr(Base64.encode(bos.toByteArray()));
            result.setMd5Str(HexUtil.encodeHexStr(MD5.digest()));

        }
        return result;
    }

    /**
     * 解压，并计算MD5
     *
     * @throws Exception
     */
    private static GzipAndMd5Result DoUnzipAndMd5(InputStream in) throws Exception {
        GzipAndMd5Result result = null;
        byte[] buffer = new byte[ 1024 ];
        byte[] zipBytes = null;
        int len;

        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {

            //读取base64值
            while ((len = in.read(buffer, 0, 1024)) != -1) {
                bos.write(buffer, 0, len);
            }
            bos.flush();
            bos.close();

            //base64解密
            zipBytes = Base64.decode(bos.toByteArray());
        }

        //解压
        try (GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(zipBytes));
             ByteArrayOutputStream bos = new ByteArrayOutputStream();) {

            MessageDigest MD5 = MessageDigest.getInstance("MD5");

            while ((len = gis.read(buffer, 0, 1024)) != -1) {
                bos.write(buffer, 0, len);
                MD5.update(buffer, 0, len);
            }

            bos.flush();
            bos.close();

            result = new GzipAndMd5Result();
            result.setPlainBytes(bos.toByteArray());
            result.setMd5Str(HexUtil.encodeHexStr(MD5.digest()));
        }

        return result;
    }

    /**
     * 对byte[]并计算md5并压缩
     *
     * @param src
     * @return
     */
    public static GzipAndMd5Result zipBuffer(byte[] src) throws Exception {

        try (ByteArrayInputStream in = new ByteArrayInputStream(src);) {
            return DoZipAndMd5(in);
        } catch (Exception e) {
            throw new Exception(e.getCause());
        }
    }

    /**
     * 对byte[]并计算md5并压缩
     *
     * @param message
     * @return
     */
    public static GzipAndMd5Result zipStr(String message, String encode) throws Exception {

        if (EncoderEnum.ISO88591.getCode().equals(encode)) {
            encode = "GB18030";
        }
        try (ByteArrayInputStream in = new ByteArrayInputStream(message.getBytes(encode));) {
            return DoZipAndMd5(in);
        } catch (Exception e) {
            throw new Exception(e.getCause());
        }
    }

    /**
     * 对文件计算md5并压缩
     *
     * @param baseDir
     * @param filename
     * @return
     */
    public static GzipAndMd5Result zipFile(String baseDir, String filename) throws Exception {

        File file = new File(baseDir + File.separator + filename);

        try (FileInputStream in = new FileInputStream(file)) {
            return DoZipAndMd5(in);
        } catch (Exception e) {
            throw new Exception(e.getCause());
        }
    }

    /**
     * 对byte[]解压并计算md5
     *
     * @param src
     * @return
     */
    public static byte[] unzipBuffer(byte[] src, String md5Str) throws Exception {
        try (ByteArrayInputStream in = new ByteArrayInputStream(src);) {
            GzipAndMd5Result result = DoUnzipAndMd5(in);
            if (!md5Str.equalsIgnoreCase(result.getMd5Str())) {
                throw new Exception("报文md5不匹配, pack=[" + md5Str + "], calc=[" + result.getMd5Str() + "]");
            }

            return result.getPlainBytes();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    /**
     * 解压文件内容，校验md5，并写入文件
     *
     * @param baseDir
     * @param filename
     * @param content
     * @param md5Str
     */
    public static void unzipFile(String baseDir, String filename, byte[] content, String md5Str) throws Exception {
        File file = new File(baseDir + File.separator + filename);
        try (ByteArrayInputStream in = new ByteArrayInputStream(content);
             FileOutputStream fos = new FileOutputStream(file);) {
            GzipAndMd5Result result = DoUnzipAndMd5(in);

            //比对md5
            if (!md5Str.equalsIgnoreCase(result.getMd5Str())) {
                throw new Exception("报文md5不匹配, pack=[" + md5Str + "], calc=[" + result.getMd5Str() + "]");
            }
            //写入文件
            fos.write(result.getPlainBytes());
            fos.flush();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 解压文件内容并写入文件( 不校验MD5)
     *
     * @param baseDir
     * @param filename
     * @param content
     */
    public static void unzipFileNoMd5(String baseDir, String filename, byte[] content) throws Exception {
        File file = new File(baseDir + File.separator + filename);
        try (ByteArrayInputStream in = new ByteArrayInputStream(content);
             FileOutputStream fos = new FileOutputStream(file);) {
            GzipAndMd5Result result = DoUnzipAndMd5(in);
            //写入文件
            fos.write(result.getPlainBytes());
            fos.flush();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 解压文件内容，校验md5，并返回文件内容字符串
     *
     * @param content
     * @param md5Str
     */
    public static String unzipFile2Str(byte[] content, String md5Str, String encode) throws Exception {
        try (ByteArrayInputStream in = new ByteArrayInputStream(content);) {
            GzipAndMd5Result result = DoUnzipAndMd5(in);

            //比对md5
            if (!md5Str.equalsIgnoreCase(result.getMd5Str())) {
                throw new Exception("报文md5不匹配, pack=[" + md5Str + "], calc=[" + result.getMd5Str() + "]");
            }
            //ISO-8859-1 的特殊处理
            if (EncoderEnum.ISO88591.getCode().equals(encode)) {
                return new String(result.getPlainBytes(), "GB18030");
            }
            return new String(result.getPlainBytes(), encode);

        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 解压字节数组，不校验md5，并返回文件内容字符串
     *
     * @param content
     * @param encode
     * @return
     * @throws Exception
     */
    public static String ungzipByteArr(byte[] content, String encode) throws Exception {
        try (ByteArrayInputStream in = new ByteArrayInputStream(content);) {
            GzipAndMd5Result result = DoUnzipAndMd5(in);
            //写入文件
            return new String(result.getPlainBytes(), encode);
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 校验MD5
     *
     * @param bytes
     * @param md5Str
     * @throws Exception
     */
    public static void checkMD5(byte[] bytes, String md5Str) throws Exception {

        MessageDigest MD5 = null;

        //计算md5
        try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes);) {

            int len = -1;
            byte[] buffer = new byte[ 1024 ];

            MD5 = MessageDigest.getInstance("MD5");
            while ((len = bis.read(buffer)) != -1) {
                byte[] readed = new byte[ len ];
                MD5.update(buffer, 0, len);
            }
        } catch (Exception e) {
            throw new Exception("计算md5失败");
        }
        //比对md5
        if (!md5Str.equalsIgnoreCase(HexUtil.encodeHexStr(MD5.digest()))) {
            throw new Exception("报文md5不匹配, pack=[" + md5Str + "], calc=[" + HexUtil.encodeHexStr(MD5.digest()) + "]");
        }
    }

    /**
     * 格式化输出byte[]数组
     *
     * @param array
     */
    public static void binaryOutput(byte[] array) {
        int len = array.length;
        StringBuilder out = new StringBuilder();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            if (i == 0) {
                sb.append(String.format("%04x:", i));
            } else if (i % 15 == 0) {
                //                log.info("{}", sb.toString());
                out.append(sb.toString()).append(";").append("\n");

                sb.delete(0, sb.length());

                sb.append(String.format("%04x:", i));
            }

            sb.append(String.format("%02x ", array[ i ]));
        }

        if (sb.length() > 0) {
            out.append(sb.toString()).append(";").append("\n");
        }

    }

    public static void main(String[] args) {
        String message = "1234567890";

        try {
//            GzipAndMd5Result result = zipFile("d:", "test.txt");
//            System.out.println("gZip = "+ result.getGzipStr());
//            System.out.println("MD5 = "+ result.getMd5Str());
//            String gzipStr = "H4sIAAAAAAAAAH1UzW7TQBA+t09R5QG6u17HsaWtq8RJIUKEqj9CHK1kG0VN7NR2qxbxNrmAOCFA\n" +
//                    "UQ7lgEBAK7VBkFQcQEIVzwDqiZld2zE9YOUwM983uzPfzkSsHw/6K0cyinthsFZiq7S0IoN22OkF3bXS\n" +
//                    "nRqzKaeldXdZ7G7sbLrLS+J+3L3bibYOwF4SO1HghR3pVihlgmQeIltyr9lxKbVN065wG1AdQWz7qO31\n" +
//                    "/Th2TUFyG4EHUa/bC/wkjFyHOhZjFD/ILQDIq7bbcoiOSQ1kOY5TgbPyMHIehtF+3U+ka1CDUsOgguQh\n" +
//                    "VYQMOjK/BwrRvq69DYpA8RSrVrYOxzI6koumDIR1DIQhBWVEK0xkM9gLVWLd2+j7XZcLkloYRMbOyRC1\n" +
//                    "EyR3MqQV/qNdGkK0GceH8lZjixgyNv0TeD0QI3EtgzPOaZnSss0ch1UsqLmAp3RocPb+9dvTkQLTdjWt\n" +
//                    "5gf7t2QuAMiryUCqwwxG4ceBx/HVLG5bguRoRm35A+nOp5Obj+dn316MLmeTT+PvX6aXPybPz99Mri9+\n" +
//                    "X728+nX1dX7x4c94jjF9hkrLzlB3M12UulFz8pK8w0gNotd6JEjmpICSmapwrvi2TJJ+dZC4zAKtVqka\n" +
//                    "hzSk5q0bSTmQQQJKUFS9+OlnYI5hcJPaIHLZhPxFitLyMBqG8aJv7FN39+rmbDZ6iv7pz/Pr+XT6bvTs\n" +
//                    "Ccoy/gxKp2mq9DAaquGBcchtBBrHSeTD4/vo4Ur67X0cPaJ9eK2sDCTvNuu6CUGUrcO13mOwKbWwde1o\n" +
//                    "ALJvzVoW0fi2PIC5ZLTMNG7zMnMqKN+Bnlfg7MKKNOsk9fAhSZ79X90LO4cyZaosdg4IpNAftFTUAou/\n" +
//                    "J0/cBm84jHl13mhsMLPqqRwEcGkXiyqI+ov7C5ZF4/MSBQAA";
//            String md5Str = "3780f3d2cce07a61bfae032ad18892d6";
//            unzipFile("d:","test01.txt",result.getGzipStr().getBytes(), result.getMd5Str()) ;
            StringBuffer sb = new StringBuffer();

            String fileName = "qqq.txt";
            BufferedReader br =
                    new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(new File("D:\\" + fileName))));
            String index = "";
            while (StringUtils.isNotBlank(index = br.readLine())) {
                sb.append(index);
            }
            unzipFileNoMd5("D:\\", "result.txt", sb.toString().getBytes());

            SplitFileReader splitFileReader = new SplitFileReader("D:\\result.txt", 1024 * 4); // 默认单条数据不超过 4kb

            String row = "";

            int count = 1;

//            BigDecimal bigDecimal = new BigDecimal(0) ;
            int countAll = 0 ;
            while (!splitFileReader.END.equals(row = splitFileReader.readLSTLine("UTF-8"))) {


                int i = row.indexOf("CNY") ;
                if(i<=0){
                    System.out.println((count++) + "=" + row);
                }else{
                    String amt = row.substring(i+3, i+19).replace(".","") ;
                    countAll += Integer.parseInt(amt) ;
 //                    System.out.println((count++) + "=" + amt);
//                    bigDecimal = bigDecimal.add(new BigDecimal(amt)) ;
                }
            }
//            System.out.println( "汇总金额 =" + bigDecimal.toString());
            System.out.println( "汇总金额 =" + countAll);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}

