package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.AddrInfo;
import com.sunyard.dxp.common.entity.AppServer;
import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.dxp.common.qo.AppServerQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

/**
 * 应用服务 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:07 CST 2019
 */
public interface AppServerDao extends BaseDao< AppServer, String, AppServerQo > {
    /**
     * 根据应用编号查询应用服务
     *
     * @param code
     * @return
     */
    AppServer findByCode(String code);
}
