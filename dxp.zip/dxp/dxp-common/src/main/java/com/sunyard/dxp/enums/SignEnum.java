package com.sunyard.dxp.enums;

import com.sunyard.dxp.security.sign.Signature;
import com.sunyard.dxp.security.sign.impl.*;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * @author Thud
 * @date 2019/12/25 16:24
 */
public enum  SignEnum implements EnumAware {
    MD5("MD5Signature","MD5Signature",new MD5Signature()),
    MYJ_ALL("MYJ_ALLSignature","MYJ_ALLSignature",new MYJ_ALLSignature()),
    MYJ_PART("MYJ_PartSignature","MYJ_PartSignature",new MYJ_PartSignature()),
    SHA1("SHA1Signature","SHA1Signature",new SHA1Signature()),
    SHA1_WITH_RSA("SHA1WithRSASignature","SHA1WithRSASignature",new SHA1WithRSASignature());

    private final String code;
    private final String name;
    private final Signature signature;

    SignEnum(String code, String name, Signature signature) {
        this.code = code;
        this.name = name;
        this.signature = signature;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return this.getName();
    }

    public static Signature getSignatureStrategy (String code) {
        for (SignEnum handler : SignEnum.values ()) {
            if (handler.code.equals (code)) {
                return handler.signature;
            }
        }
        return null;
    }
}
