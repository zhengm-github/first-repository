package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.AppQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 应用系统 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:23 CST 2019
 */
public class AppQct extends QueryConditionTransfer< AppQo > {

    @Override
    public void transNameQuery(AppQo qo, QueryCondition condition) {

        if (qo != null) {

            if(StringUtils.isNotBlank(qo.getAppCode())){
                condition.add(" and obj.appCode = :appCode", "appCode", qo.getAppCode()) ;
            }
            if (StringUtils.isNotBlank(qo.getKeyword())) {
                condition.add(" and ( obj.appCode like :appCode", "appCode", qo.getTailBlurKeyword());
                condition.add(" or obj.appName like :appName", "appName", qo.getBlurKeyword());
                condition.add(" or obj.appMemo like :appMemo ) ", "appMemo", qo.getBlurKeyword());
            }
        }
    }

    @Override
    public void transQuery(AppQo qo, QueryCondition condition) {
        //
    }

}
