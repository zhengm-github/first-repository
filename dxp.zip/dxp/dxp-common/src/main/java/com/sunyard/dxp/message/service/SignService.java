package com.sunyard.dxp.message.service;

import com.sunyard.dxp.message.dto.SignDto;

import java.util.Map;

/**
 * 为各个地区的报文 解析Sign ， 组装Sign 提供服务
 *
 * @author zhengm
 *
 */
public interface SignService {

    /**
     * 从解析的数据中获取Sign， 并放到 sign 标记中存储在 map中（其他地区）
     * @param dataMap
     * @return
     */
    public String getSign(Map<String, Object> dataMap) ;

    /**
     * 编押到xml报文中
     * @param dataMap
     * @param signDto
     * @param objSvc  代表接入还是接出
     * @param macFlag 是实时还是批量(1-实时， 2-批量)
     * @param fileName 批量的文件名
     * @return
     */
    public String setSign(Map<String, Object> dataMap, Object objSvc, SignDto signDto, String macFlag, String fileName) ;

    /**
     * 在报文解析的时候 对sign进行校验（暂时宁波）
     * 全xml 校验
     * @param signDto 当前接口对应的验签参数
     * @param packSign 对方sign
     * @param xmlBody 我方xml串
     * @return
     */
    public String validateSign(SignDto signDto, String xmlBody, String packSign) ;

    /**
     * 主动产生sign(宁波专用)
     * @param signDto
     * @param xmlBody
     * @return
     */
    public Map<String, String> makeSign(SignDto signDto, String xmlBody) ;

}
