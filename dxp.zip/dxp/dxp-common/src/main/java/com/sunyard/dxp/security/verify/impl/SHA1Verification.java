package com.sunyard.dxp.security.verify.impl;


import com.sunyard.dxp.security.sign.impl.SHA1Signature;
import com.sunyard.dxp.security.verify.Verification;

public class SHA1Verification implements Verification {

    @Override
    public boolean verify(String src, String encryptionSrc,String key) {
        return encryptionSrc.equals(new SHA1Signature().sign(src,key));
    }

}
