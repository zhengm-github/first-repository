package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.AppPublicKeyQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 应用公钥 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:44 CST 2019
 */
public class AppPublicKeyQct extends QueryConditionTransfer< AppPublicKeyQo > {

    @Override
    public void transNameQuery(AppPublicKeyQo qo, QueryCondition condition) {

        if(qo!=null){
            if(StringUtils.isNotBlank(qo.getPublicKey())){
                condition.add(" and obj.publicKey = :publicKey","publicKey",qo.getPublicKey()) ;
            }
            if(StringUtils.isNotBlank(qo.getAppId())){
                condition.add(" and obj.app.appId = :appId","appId",qo.getAppId()) ;
            }
            /*关键字模糊查询*/
            if (StringUtils.isNotBlank(qo.getKeyword())) {
                condition.add(" and ( obj.publicKey like :publicKey", "publicKey", qo.getTailBlurKeyword());
                condition.add(" or obj.name like :name )", "name", qo.getBlurKeyword());
            }
        }
    }

    @Override
    public void transQuery(AppPublicKeyQo qo, QueryCondition condition) {
        //
    }

}
