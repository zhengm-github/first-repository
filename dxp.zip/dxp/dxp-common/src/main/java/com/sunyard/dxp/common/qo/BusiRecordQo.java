package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 记录业务信息（请求和响应） QO
 *
 * Author: Created by code generator
 * Date: Tue Jun 09 17:17:29 CST 2020
   */
public class BusiRecordQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6634510974653630992L;

}
