package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.ProcotolResolvePlanDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.ProcotolResolvePlanService;
import com.sunyard.dxp.common.entity.ProcotolResolvePlan;
import com.sunyard.dxp.common.qo.ProcotolResolvePlanQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 协议解析规划 service
 * <p>
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:25 CST 2020
 */
@Service
public class ProcotolResolvePlanServiceImpl extends BaseServiceImpl< ProcotolResolvePlan, String, ProcotolResolvePlanQo > implements ProcotolResolvePlanService {

    @Autowired
    private ProcotolResolvePlanDao procotolResolvePlanDao;

    @Override
    public ProcotolResolvePlan findByName(String name) {
        return procotolResolvePlanDao.findByName(name);
    }

    @Override
    public ProcotolResolvePlan queryBySvcId(String svcId, String dataKind, String svcType) {
        return procotolResolvePlanDao.queryBySvcId(svcId, dataKind, svcType);
    }

    @Override
    public void deleteByOutsvcId(String outBoundSvcId) {
        procotolResolvePlanDao.deleteByOutsvcId(outBoundSvcId);
    }

    @Override
    public void deleteByInsvcId(String inBoundSvcId) {
        procotolResolvePlanDao.deleteByInsvcId(inBoundSvcId);
    }

    @Override
    public List< ProcotolResolvePlan > findByInsvcId(String inBoundSvcId) {
        return procotolResolvePlanDao.findByInsvcId(inBoundSvcId);
    }

    @Override
    public List< ProcotolResolvePlan > findByOutsvcId(String outBoundSvcId) {
        return procotolResolvePlanDao.findByOutsvcId(outBoundSvcId);
    }

    @Override
    public ProcotolResolvePlan queryPlanByObsId(String outBoundSvcId, String dataKind) {
        return procotolResolvePlanDao.queryPlanByObsId(outBoundSvcId, dataKind);
    }

    @Override
    public ProcotolResolvePlan queryPlanByIbsId(String inBoundSvcId, String dataKind) {
        return procotolResolvePlanDao.queryPlanByIbsId(inBoundSvcId, dataKind);
    }
}
