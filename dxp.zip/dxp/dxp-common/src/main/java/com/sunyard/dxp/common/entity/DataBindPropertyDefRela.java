package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
* 接出数据属性绑定配置
* Author: Created by code generator
* Date: Tue Dec 24 10:44:42 CST 2019
*/
@Entity
@Table(name = "DXP_DATA_BIND_PROPERTY_DEF_RELA")
public class DataBindPropertyDefRela implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7765689033349763846L;

    /** 数据绑定配置ID */
    @Id
    @Column( name = "DATA_BIND_CONFIG_ID")
    private String dataBindConfigId;

    /** 数据结果属性ID */
    @Id
    @Column( name = "DATA_PROPERTY_ID")
    private String dataPropertyId;

    public String getDataBindConfigId() {
        return dataBindConfigId;
    }

    public void setDataBindConfigId(String dataBindConfigId) {
        this.dataBindConfigId = dataBindConfigId;
    }

    public String getDataPropertyId() {
        return dataPropertyId;
    }

    public void setDataPropertyId(String dataPropertyId) {
        this.dataPropertyId = dataPropertyId;
    }

}
