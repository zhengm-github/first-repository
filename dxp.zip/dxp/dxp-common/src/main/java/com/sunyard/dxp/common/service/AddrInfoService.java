package com.sunyard.dxp.common.service;


import com.sunyard.dxp.common.entity.AddrInfo;
import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.frameworkset.core.service.BaseService;

import java.util.List;

/**
 * 地址信息管理 service 接口
 *
 * Author: Created by code generator
 * Date: Thu Jun 11 16:10:14 CST 2020
 */
public interface AddrInfoService extends BaseService< AddrInfo, String, AddrInfoQo > {

    /**
     * 查找合适的地址( 同步轮询， 最久没被调用的地址优先)
     * @param sendDirect   发送方向（CORP 、 CBSP）
     * @param busiType  业务类型 （RT-实时， BT- 批量）
     * @return
     */
    String findURL(String sendDirect, String busiType) ;

    /**
     * 查找条件对应的所有的地址
     * @param sendDirect   发送方向（CORP 、 CBSP）
     * @param busiType  业务类型 （RT-实时， BT- 批量）
     * @return
     */
    List<AddrInfo> findAllByType(String sendDirect, String busiType) ;

}
