package com.sunyard.dxp.security.verify.impl;

import com.sunyard.dxp.security.sign.impl.MD5Signature;
import com.sunyard.dxp.security.verify.Verification;

public class MD5Verification implements Verification {

    @Override
    public boolean verify(String src, String encryptionSrc,String key) {
        return encryptionSrc.equals(new MD5Signature().sign(src,key));
    }
}
