package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.OutSvcParamMapRelaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 接出服务参数映射配置 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:38 CST 2019
 */
public class OutSvcParamMapRelaQct extends QueryConditionTransfer<OutSvcParamMapRelaQo> {

    @Override
    public void transNameQuery(OutSvcParamMapRelaQo qo, QueryCondition condition) {
        //暂未实现
    }

    @Override
    public void transQuery(OutSvcParamMapRelaQo qo, QueryCondition condition) {
        //暂未实现
    }

}
