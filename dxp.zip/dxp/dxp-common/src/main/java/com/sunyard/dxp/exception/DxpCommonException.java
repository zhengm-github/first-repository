package com.sunyard.dxp.exception;

import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * @author Thud
 * @date 2019/12/19 11:00
 */
public class DxpCommonException extends FapException {
    public DxpCommonException(EnumAware enumAware, Throwable e) {
        super(enumAware, e);
    }

    public DxpCommonException(EnumAware enumAware) {
        super(enumAware);
    }

    public DxpCommonException(String errorCode, String errorMsg) {
        super(errorCode, errorMsg);
    }

    public DxpCommonException(String errorCode, String errorMsg, Throwable e) {
        super(errorCode, errorMsg, e);
    }
}
