package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.ServiceBundleQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang.StringUtils;

/**
 * 服务模块 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:57:12 CST 2019
 */
public class ServiceBundleQct extends QueryConditionTransfer< ServiceBundleQo > {

    @Override
    public void transNameQuery(ServiceBundleQo qo, QueryCondition condition) {
        if(StringUtils.isNotEmpty(qo.getCode())){
            condition.add(" And obj.code =:code", "code", qo.getCode());
        }
        if(StringUtils.isNotEmpty(qo.getName())){
            condition.add(" And obj.name =:name", "name", qo.getName());
        }
        if(StringUtils.isNotEmpty(qo.getStatus())){
            condition.add(" And obj.status =:status", "status", qo.getStatus());
        }
        if(StringUtils.isNotEmpty(qo.getCreator())){
            condition.add(" And obj.creator =:creator", "creator", qo.getCreator());
        }
        if(StringUtils.isNotEmpty(qo.getCurrentVersion())){
            condition.add(" And obj.currentVersion =:currentVersion", "currentVersion", qo.getCurrentVersion());
        }
        boolean flag = false;
        if(StringUtils.isNotEmpty(qo.getKeyword())){
            condition.append(" And ( ");
            if(StringUtils.isEmpty(qo.getCode())){
                condition.add(" obj.code like :code", "code", qo.getBlurKeyword());
                flag = true;
            }
            if(StringUtils.isEmpty(qo.getName())){
                flag = isAddOrCondition(condition, flag);
                condition.add(" obj.name like :name", "name", qo.getBlurKeyword());

            }
            if(StringUtils.isEmpty(qo.getStatus())){
                flag = isAddOrCondition(condition, flag);
                condition.add(" obj.status =:status", "status", qo.getBlurKeyword());

            }
            if(StringUtils.isEmpty(qo.getCreator())){
                flag = isAddOrCondition(condition, flag);
                condition.add(" obj.creator like :creator", "creator", qo.getBlurKeyword());
            }
            if(StringUtils.isEmpty(qo.getCurrentVersion())){
                flag = isAddOrCondition(condition, flag);
                condition.add(" obj.currentVersion like:currentVersion", "currentVersion", qo.getBlurKeyword());
            }
            condition.append(")");
        }

        condition.appenOrderBy(" obj.gmtCreate desc");
    }

    private boolean isAddOrCondition(QueryCondition condition, boolean flag) {
        if(flag){
            condition.append(" OR ");
        }
        flag = true;
        return flag;
    }

    @Override
    public void transQuery(ServiceBundleQo qo, QueryCondition condition) {
        //
    }

}
