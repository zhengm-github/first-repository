package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.SignConfigItemDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.SignConfigItemService;
import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.dxp.common.qo.SignConfigItemQo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 签名配置项 service
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:49:49 CST 2020
 */
@Service
public class SignConfigItemServiceImpl extends BaseServiceImpl<SignConfigItem, String, SignConfigItemQo> implements SignConfigItemService {

    @Autowired
    private SignConfigItemDao signConfigItemDao ;

    @Override
    public void deleteByDataPropertyId(String dataPropertyId) {
        signConfigItemDao.deleteByDataPropertyId(dataPropertyId);
    }

    @Override
    public int getMaxOrd(String dataObjDefId) {
        List<SignConfigItem> signConfigItems = signConfigItemDao.findByDataObjDefId(dataObjDefId) ;
        if(CollectionUtils.isNotEmpty(signConfigItems)){
            return signConfigItems.get(0).getOrd() ;
        }
        return 0;
    }
}
