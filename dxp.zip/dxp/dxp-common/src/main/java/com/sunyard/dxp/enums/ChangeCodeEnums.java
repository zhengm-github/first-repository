package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * *
 * User: wuyongzhi
 * Date: 2017/7/11 10:21
 * version $Id: AccessKeyEnum.java, v 0.1 Exp $
 */
public enum ChangeCodeEnums implements EnumAware {
    CC00("CC00","新增"),
    CC01("CC01","变更"),
    CC02 ("CC02","撤销"),
    ;

    private String code;

    private String name;

    ChangeCodeEnums(String code, String name) {
        this.code = code;
        this.name = name;
    }
    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return null;
    }


    public static String getMapperNameByCode(String code) {
        for (ChangeCodeEnums enums : ChangeCodeEnums.values()) {
            if (enums.code.equals(code)) {
                return enums.name;
            }
        }
        return code;
    }
}
