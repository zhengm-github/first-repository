package com.sunyard.dxp.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 用于字段排序
 */
@Target( { ElementType.METHOD, ElementType.FIELD } )
@Retention( RetentionPolicy.RUNTIME )
public @interface OrderBy {


    /**
     * An <code>orderby_list</code>.  Specified as follows:
     *
     * <pre>
     *    orderby_list::= orderby_item [,orderby_item]*
     *    orderby_item::= [property_or_field_name] [ASC | DESC]
     * </pre>
     *
     * <p> If <code>ASC</code> or <code>DESC</code> is not specified,
     * <code>ASC</code> (ascending order) is assumed.
     *
     * <p> If the ordering element is not specified, ordering by
     * the primary key of the associated entity is assumed.
     */
    String value( ) default "";
}
