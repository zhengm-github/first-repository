package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 接出服务接口
* Author: Created by code generator
* Date: Tue Dec 24 10:47:06 CST 2019
*/
@Entity
@Table(name = "DXP_OUT_BOUND_SVC")
public class OutBoundSvc implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8361314089315819436L;

    /** 接出服务接口ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "OUT_BOUND_SVC_ID")
    private String outBoundSvcId;

    /** 编号 */
    @Column( name = "CODE")
    private String code;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** 状态 */
    @Column( name = "STATUS")
    private String status;

    /** 签名算法 */
    @Column( name = "SIGN_ALGOL")
    private String signAlgol;

    /** 签名私钥 */
    @Column( name = "SIGN_PRIVATE_KEY")
    private String signPrivateKey;

    /** 加密算法 */
    @Column( name = "ENCRY_ALGOL")
    private String encryAlgol;

    /** 加密私钥 */
    @Column( name = "ENCRY_PRIVATE_KEY")
    private String encryPrivateKey;

    /** 编码 */
    @Column( name = "ENCODE")
    private String encode;

    /** 报文协议 */
    @Column( name = "MSG_PROCOTOL")
    private String msgProcotol;

    /** 数据绑定模式 */
    @OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "outBoundSvc")
    private DataBindSchema dataBindSchema;

    /** 服务模块 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "SERVICE_BUNDLE_ID", referencedColumnName = "SERVICE_BUNDLE_ID")
    private ServiceBundle serviceBundle;

    /** 数据对象 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "outBoundSvc")
    private Set<DataObjDef> dataObjDefs;

    /** 签名配置计划 */
    @OneToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "outBoundSvc")
    private SignConfigSchema outSignConfigSchema;

    /** 协议解析规划 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "outBoundSvc")
    private Set<ProcotolResolvePlan> procotolResolvePlans;

    public String getOutBoundSvcId() {
        return outBoundSvcId;
    }

    public void setOutBoundSvcId(String outBoundSvcId) {
        this.outBoundSvcId = outBoundSvcId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSignAlgol() {
        return signAlgol;
    }

    public void setSignAlgol(String signAlgol) {
        this.signAlgol = signAlgol;
    }

    public String getSignPrivateKey() {
        return signPrivateKey;
    }

    public void setSignPrivateKey(String signPrivateKey) {
        this.signPrivateKey = signPrivateKey;
    }

    public String getEncryAlgol() {
        return encryAlgol;
    }

    public void setEncryAlgol(String encryAlgol) {
        this.encryAlgol = encryAlgol;
    }

    public String getEncryPrivateKey() {
        return encryPrivateKey;
    }

    public void setEncryPrivateKey(String encryPrivateKey) {
        this.encryPrivateKey = encryPrivateKey;
    }

    public String getEncode() {
        return encode;
    }

    public void setEncode(String encode) {
        this.encode = encode;
    }

    public String getMsgProcotol() {
        return msgProcotol;
    }

    public void setMsgProcotol(String msgProcotol) {
        this.msgProcotol = msgProcotol;
    }

    public DataBindSchema getDataBindSchema() {
        return dataBindSchema;
    }

    public void setDataBindSchema(DataBindSchema dataBindSchema) {
        this.dataBindSchema = dataBindSchema;
    }

    public ServiceBundle getServiceBundle() {
        return serviceBundle;
    }

    public void setServiceBundle(ServiceBundle serviceBundle) {
        this.serviceBundle = serviceBundle;
    }

    public Set<DataObjDef> getDataObjDefs() {
        return dataObjDefs;
    }

    public void setDataObjDefs(Set<DataObjDef> dataObjDefs) {
        this.dataObjDefs = dataObjDefs;
    }

    public SignConfigSchema getOutSignConfigSchema() {
        return outSignConfigSchema;
    }

    public void setOutSignConfigSchema(SignConfigSchema outSignConfigSchema) {
        this.outSignConfigSchema = outSignConfigSchema;
    }

    public Set<ProcotolResolvePlan> getProcotolResolvePlans() {
        return procotolResolvePlans;
    }

    public void setProcotolResolvePlans(Set<ProcotolResolvePlan> procotolResolvePlans) {
        this.procotolResolvePlans = procotolResolvePlans;
    }
}
