package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.InSvcBindRela;
import com.sunyard.dxp.common.qo.InSvcBindRelaQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

/**
 * 接入服务数据映射配置 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:55:37 CST 2019
 */
public interface InSvcBindRelaDao extends BaseDao< InSvcBindRela, String, InSvcBindRelaQo > {

    /**
     * 根据inBoundSvcId 删除
     * @param inBoundSvcId
     */
    void deleteByInBoundSvcId(String inBoundSvcId) ;

    /**
     * 根据dataMapSchemaId删除
     * @param dataMapSchemaId
     */
    void deleteByDataMapSchemaId(String dataMapSchemaId) ;

    /**
     * 根据dataMapSchemaId 和 inBoundSvcId删除
     * @param dataMapSchemaId
     * @param inBoundSvcId
     */
    void deleteByDataMapSchemaIdAndInBoundSvcId(String dataMapSchemaId, String inBoundSvcId) ;

}
