package com.sunyard.dxp.message.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MessageRequest {

    /**
     * 报文
     */
    private String message;

    /**
     * 是否包括文件
     */
    private boolean containFile;

    /**
     * 原文件路径
     * 包括文件时必输
     */
    private String fromFilePath;

    /**
     * 数据格式转换后文件路径
     * 包括文件时必输
     */
    private String toFilePath;
}
