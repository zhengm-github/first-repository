package com.sunyard.dxp.message.service;

import com.sunyard.dxp.message.dto.ParamRule;

import java.util.List;
import java.util.Map;

/**
 * @Description 报文解析基础服务
 * @Author zhangxin
 * @Date 2020/1/9 9:53
 * @Version 1.0
 */
public interface BaseResolveService {

    /**
     * 执行报文解析
     *
     * @param rules        报文解析规则
     * @param message      报文
     * @param resolveParam 报文解析参数(变长参数, [0]-编码  [1]-分隔符/ xmldetail时候的传输方式：file/message [2]-明细保存的key说明 [3]- 定长是字节还是字符)
     * @return java.util.Map<java.lang.String   ,   java.lang.Object>
     * @author zhangxin
     * @date 2020/1/9 10:13
     */
    Map<String, Object> execute(List<ParamRule> rules, String message, String... resolveParam);

    /**
     * 执行报文组装
     * @param rules
     * @param map
     * @param resolveParam [0]-编码
     * @return
     */
    Map<String, Object> mapExecute(List<ParamRule> rules, Map<String,Object> map, String... resolveParam);
}
