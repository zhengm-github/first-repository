package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.DataPropertyDefDao;
import com.sunyard.dxp.common.entity.DataPropertyDef;
import com.sunyard.dxp.common.qo.DataPropertyDefQo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 数据属性定义 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:55 CST 2019
 */
@Repository
public class JpaDataPropertyDefDaoImpl extends JpaBaseDaoImpl< DataPropertyDef, String, DataPropertyDefQo > implements DataPropertyDefDao {

    @Override
    public List< DataPropertyDef > findPropertyDefByResultDefId(String dataObjDefId) {
        return this.find("Select obj from DataPropertyDef as obj where obj.dataObjDef.dataObjDefId = ?", dataObjDefId);
    }

    @Override
    public DataPropertyDef findByName(String name, String dataObjDefId, String parentId) {

        boolean haveParent = StringUtils.isNotBlank(parentId);

        return this.findBySingle(
                String.format(
                        "Select obj from DataPropertyDef as obj where obj.name = ? %s"
                        , haveParent ? " and obj.parent.dataPropertyId = ? " : " and obj.dataObjDef.dataObjDefId = ?")
                , name, haveParent ? parentId : dataObjDefId);
    }

    @Override
    public List< DataPropertyDef > findBySvcId(String dataKind, String svcId, String svcType) {

        StringBuilder svcIdBuilder = new StringBuilder(" where 1=1 ");
        if (StringUtils.isNotBlank(dataKind)) {
            svcIdBuilder.append(" and obj.dataObjDef.dataKind = ?");
        }
        switch (svcType) {
            case "in":
                svcIdBuilder.append(" and obj.dataObjDef.inBoundSvc.inBoundSvcId = ? ");
                break;
            case "out":
                svcIdBuilder.append(" and obj.dataObjDef.outBoundSvc.outBoundSvcId = ? ");
                break;
            default:
                break;
        }
        if (StringUtils.isNotBlank(dataKind)) {
            return find(getMainQuery() + svcIdBuilder.toString(), dataKind, svcId);
        }
        return find(getMainQuery() + svcIdBuilder.toString(), svcId);

    }

    @Override
    public List< DataPropertyDef > findPropertyDefByObjDefId(String dataObjDefId) {
        return this.find("Select obj from DataPropertyDef as obj where obj.dataObjDef.dataObjDefId = ?", dataObjDefId);
    }

    @Override
    public void deletePropertyDefByObjDefId(String dataObjDefId) {
        this.executeUpdate("delete from  DataPropertyDef as obj where obj.dataObjDef.dataObjDefId =?", dataObjDefId);
    }

    @Override
    public List< DataPropertyDef > findPropertyDefByParentId(String parentId) {

        return this.findByQueryString(getMainQuery() + " where obj.parent.dataPropertyId = ? ", parentId);
    }

    @Override
    public List< DataPropertyDef > findInPropByObs(String obsId) {
        return this.find(getMainQuery() + " where obj.dataObjDef.outBoundSvc.outBoundSvcId = ?", obsId);
    }

    @Override
    public List< DataPropertyDef > findInPropByIbs(String ibsId, String dataKind) {
        return this.find(getMainQuery() + " where obj.dataObjDef.inBoundSvc.inBoundSvcId = ? and obj.dataObjDef.dataKind = ?", ibsId, dataKind);
    }

    @Override
    public List< DataPropertyDef > findOutPropByObs(String obsId, String dataKind) {
        return this.find(getMainQuery() + " where obj.dataObjDef.outBoundSvc.outBoundSvcId = ? and obj.dataObjDef.dataKind = ?", obsId, dataKind);
    }

    @Override
    public List< DataPropertyDef > findChild(String id) {
        return this.find(getMainQuery() + " where obj.parent.dataPropertyId = ?", id);
    }
}
