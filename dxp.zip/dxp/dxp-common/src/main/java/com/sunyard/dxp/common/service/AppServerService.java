package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.AppServer;
import com.sunyard.dxp.common.qo.AppServerQo;
import com.sunyard.frameworkset.core.service.BaseService;

/**
 * 应用服务 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:07 CST 2019
 */
public interface AppServerService extends BaseService< AppServer, String, AppServerQo > {
    /**
     * 根据应用编号查询应用服务
     *
     * @param code
     * @return
     */
    AppServer findByCode(String code);

    /**
     * 加锁根据id查询
     * @param id
     * @return
     */
    AppServer findByAppServerId(String id) ;
}
