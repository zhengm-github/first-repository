package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 接入服务模块关系 QO
 *
 * Author: Created by code generator
 * Date: Mon Dec 16 14:26:15 CST 2019
   */
public class SvcModelRelaQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6029485019619055554L;

    /** 服务模块ID */
    private String serviceBundleId ;

    public String getServiceBundleId( ) {
        return serviceBundleId;
    }

    public void setServiceBundleId(String serviceBundleId) {
        this.serviceBundleId = serviceBundleId;
    }
}
