package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.ProcotolResolvePlan;
import com.sunyard.dxp.common.qo.ProcotolResolvePlanQo;

import java.util.List;

/**
 * 协议解析规划 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:25 CST 2020
 */
public interface ProcotolResolvePlanService extends BaseService<ProcotolResolvePlan, String, ProcotolResolvePlanQo> {

    /**
     * 根据name查询
     *
     * @param name
     * @return
     */
    ProcotolResolvePlan findByName(String name);

    /**
     * 查询接口协议解析配置
     * @param svcId
     * @param dataKind
     * @param svcType
     * @return
     */
    ProcotolResolvePlan queryBySvcId(String svcId, String dataKind, String svcType) ;

    /**
     * 根据接出服务id查询数据对象定义表
     * @param outBoundSvcId
     * @return
     */
    void deleteByOutsvcId(String outBoundSvcId);

    /**
     * 根据接入服务id查询数据对象定义表
     * @param inBoundSvcId
     * @return
     */
    void deleteByInsvcId(String inBoundSvcId);

    /**
     * 根据接入服务id获取协议解析规划
     * @param inBoundSvcId
     * @return
     */
    List<ProcotolResolvePlan> findByInsvcId(String inBoundSvcId);

    /**
     * 根据接出服务id获取协议解析规划
     * @param outBoundSvcId
     * @return
     */
    List<ProcotolResolvePlan> findByOutsvcId(String outBoundSvcId);

    /**
     * 根据接出接口Id查询协议解析规划
     * @param outBoundSvcId
     * @param dataKind
     * @return
     */
    ProcotolResolvePlan queryPlanByObsId(String outBoundSvcId, String dataKind) ;

    /**
     * 根据接入接口Id查询协议解析规划
     * @param inBoundSvcId
     * @param dataKind
     * @return
     */
    ProcotolResolvePlan queryPlanByIbsId(String inBoundSvcId, String dataKind) ;

}