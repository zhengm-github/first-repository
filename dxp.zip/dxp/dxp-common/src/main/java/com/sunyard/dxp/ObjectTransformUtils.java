package com.sunyard.dxp;

import com.sunyard.frameworkset.core.exception.FapException;

import java.io.*;

/**
 * @author Thud
 * @date 2019/12/13 16:14
 */
public class ObjectTransformUtils {
    private ObjectTransformUtils(){

    }
    /**
     * 对象转字节数组
     * @param object
     * @return
     */
    public static byte[] objectToBytes(Object object) {
        byte[] bytes = null;
        try (ByteArrayOutputStream bo = new ByteArrayOutputStream();
             ObjectOutputStream oo = new ObjectOutputStream(bo)){
            oo.writeObject(object);
            bytes = bo.toByteArray();
        } catch (IOException e) {
            throw new FapException("","转换失败");
        }
        return bytes;
    }

    public static Object bytesToObject(byte[] bytes) {
        Object object = null;
        try (ByteArrayInputStream bi = new ByteArrayInputStream(bytes);
             ObjectInputStream oi = new ObjectInputStream(bi)){
            object = oi.readObject();
        } catch (Exception e) {
            throw new FapException("","转换失败");
        }
        return object;
    }
}
