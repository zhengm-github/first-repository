package com.sunyard.dxp.exp_enums;

import com.sunyard.dxp.utils.PropUtil;

import java.io.File;
import java.util.*;

/**
 * 模块初始化的时候加载的信息
 *
 * 用于表达式转换
 */
public class ExpMapper {

    /*全国转单位处理代码*/
    public static Map<String, String> cbspResultMap = new HashMap<>() ;

    /*操作类型*/
    public static Map<String, String> changeCodeMap = new HashMap<>() ;

    /*codetype*/
    public static Map<String, String> codeTypeMap = new HashMap<>() ;

    /*单位处理码转 平台 prccd*/
    public static Map<String, String> corpPrccdMap = new HashMap<>() ;

    /*平台 prccd转单位处理码 */
    public static Map<String, String> prccdCorpMap = new HashMap<>() ;

    /*单位转全国处理代码*/
    public static Map<String, String> corpResultMap = new HashMap<>() ;

    /*证件类型转换*/
    public static Map<String, String> idCodeMap = new HashMap<>() ;

    /*证件类型翻译*/
    public static Map<String, String> idTypeCodeMap = new HashMap<>() ;

    /*msgType*/
    public static Map<String, String> msgTypeMap = new HashMap<>() ;

    /*宁波 全国处理码根据交易类型 转换成单位处理码*/
    public static Map<String, String> NBcbspMap = new HashMap<>() ;

    /*宁波 单位（费种代码）转 全国业务类型*/
    public static Map<String, String> NBcorpMap = new HashMap<>() ;

    /*宁波 单位处理码 转成全国 prosts*/
    public static Map<String, String> NBprostsMap = new HashMap<>() ;

    /*业务状态*/
    public static Map<String, String> processCodeMap = new HashMap<>() ;

    /*业务类型映射*/
    public static Map<String, String> prtryMap = new HashMap<>() ;

    /*统一社会信用代码*/
    public static Map<String, String> USocialCodeMap = new HashMap<>() ;

    /*prosts+prccd 映射单位处理码*/
    public static Map<String, String> cbspQueryCodeMap = new HashMap<>() ;


    /**
     * 将表达式的映射文件信息 加载到静态变量中
     * @param configPath
     * @throws Exception
     */
    public static void getExpMapper( String configPath) throws Exception {

        Map< String, Map< String, String > > dataMap = new HashMap<>();
        dataMap.put("cbspresult-mapper.properties", cbspResultMap);
        dataMap.put("changecode-mapper.properties", changeCodeMap);
        dataMap.put("codetype-mapper.properties", codeTypeMap);
        dataMap.put("corpprccd-mapper.properties", corpPrccdMap);
        dataMap.put("prccdcorp-mapper.properties", prccdCorpMap);
        dataMap.put("corpresult-mapper.properties", corpResultMap);
        dataMap.put("idcode-mapper.properties", idCodeMap);
        dataMap.put("idtypecode-mapper.properties", idTypeCodeMap);
        dataMap.put("msgtype-mapper.properties", msgTypeMap);
        dataMap.put("nb-cbsp-mapper.properties", NBcbspMap);
        dataMap.put("nb-corp-mapper.properties", NBcorpMap);
        dataMap.put("nb-prosts-mapper.properties", NBprostsMap);
        dataMap.put("processcode-mapper.properties", processCodeMap);
        dataMap.put("prtry-mapper.properties", prtryMap);
        dataMap.put("unitsocialcode-mapper.properties", USocialCodeMap);
        dataMap.put("cbspquery-mapper.properties", cbspQueryCodeMap);

        Properties p = null;
        Set< String > keySet = dataMap.keySet();
        String itKey = "";
        Map< String, String > valueMap = null;
        for (String dataKey : keySet) {
            p = PropUtil.getProperties(
                    configPath + File.separator+ "common"
                            + File.separator + "expression" + File.separator + dataKey, "UTF-8");
            valueMap = dataMap.get(dataKey) ;
            Iterator< String > it = p.stringPropertyNames().iterator();
            while (it.hasNext()) {
                itKey = it.next();
                valueMap.put(itKey, p.get(itKey).toString()) ;
            }
        }


    }

}
