package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 协议解析规则 QO
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:59 CST 2020
   */
public class ProcotolResolveRuleQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8269536805393723490L;

    /** 名称*/
    private String name ;

    /** 备注*/
    private String memo ;

    public String getName( ) {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo( ) {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
