package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.SvcModelRelaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 接入服务模块关系 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Mon Dec 16 14:26:15 CST 2019
 */
public class SvcModelRelaQct extends QueryConditionTransfer< SvcModelRelaQo > {

    @Override
    public void transNameQuery(SvcModelRelaQo qo, QueryCondition condition) {

        if (qo != null && StringUtils.isNotBlank(qo.getServiceBundleId())) {
            condition.add(" and obj.id.serviceBundleId =:serviceBundleId", "serviceBundleId", qo.getServiceBundleId());
        }
    }

    @Override
    public void transQuery(SvcModelRelaQo qo, QueryCondition condition) {
        //
    }

}
