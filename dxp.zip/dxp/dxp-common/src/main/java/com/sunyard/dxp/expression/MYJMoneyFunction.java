package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * 转金额为 0000000000012300
 */
@FunctionLibrary( code = "MYJMoney", name = "密押机金额处理(元转为分)", expression = "(MYJMoney\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "MYJMoney()", hasProperty = true )
@Component
public class MYJMoneyFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if (StringUtils.isBlank(params) || "".equals(params.trim())) {
            return "0000000000000000";
        }
        String moneyNum = "";
        String moneyValue = "";

        if (params.contains(",")) {
            moneyNum = params.split(",", -1)[ 0 ];
            moneyValue = params.split(",", -1)[ 1 ];
        }


        BigDecimal beforeMoney = new BigDecimal(moneyValue.trim());
        String midMoney = beforeMoney.multiply(BigDecimal.valueOf(100)).toBigInteger().toString();
        return StringUtil.formatStr(midMoney, Integer.parseInt(moneyNum), "0", true);


    }
}
