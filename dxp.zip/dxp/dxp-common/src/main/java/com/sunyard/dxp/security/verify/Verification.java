package com.sunyard.dxp.security.verify;

public interface Verification {

    /**
     * 核押
     * @param src   需要编押的串
     * @param encryptionSrc  对方送过来的sign
     * @param key   秘钥
     * @return
     */
    boolean verify(String src, String encryptionSrc, String key);
}
