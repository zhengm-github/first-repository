package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.DataObjDefDao;
import com.sunyard.dxp.common.entity.DataObjDef;
import com.sunyard.dxp.common.qo.DataObjDefQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 数据对象定义 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:27 CST 2019
 */
@Repository
public class JpaDataObjDefDaoImpl extends JpaBaseDaoImpl< DataObjDef, String, DataObjDefQo > implements DataObjDefDao {

    @Override
    public List< DataObjDef > findByBundleId(String bundleId, String flag, String dataKind) {

        if ("in".equals(flag)) {
            return find(getMainQuery() + " where obj.inBoundSvc.inBoundSvcId = ? and obj.dataKind = ?", bundleId, dataKind);
        } else if ("out".equals(flag)) {
            return find(getMainQuery() + " where obj.outBoundSvc.outBoundSvcId = ? and obj.dataKind = ?", bundleId, dataKind);
        } else {
            return findAll();
        }
    }

    @Override
    public List< DataObjDef > getDataObjDefByOutsvcId(String outBoundSvcId) {
        return this.find("Select obj from DataObjDef as obj where obj.outBoundSvc.outBoundSvcId = ?", outBoundSvcId);
    }

    @Override
    public List< DataObjDef > getDataObjDefByInsvcId(String inBoundSvcId) {
        return this.find("Select obj from DataObjDef as obj where obj.inBoundSvc.inBoundSvcId = ?", inBoundSvcId);
    }

}
