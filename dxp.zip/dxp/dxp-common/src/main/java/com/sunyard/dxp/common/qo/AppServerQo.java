package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 应用服务 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:07 CST 2019
   */
public class AppServerQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5586820169577025012L;

    /** 编号 */
    private String code ;

    public String getCode( ) {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
