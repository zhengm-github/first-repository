package com.sunyard.dxp.message.utils;

import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import sun.security.action.GetPropertyAction;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * @Description 文件相关工具类封装
 * @Author zhangxin
 * @Date 2018/6/26 14:24
 * @Version 1.0
 */
public class FileUtils {

    private static final Logger log = LoggerFactory.getLogger(FileUtils.class);

    public static final int BUFFER = 1024;

    /**
     * 年
     */
    private static final String FORMAT_YEAR = "{yyyy}";

    /**
     * 月
     */
    private static final String FORMAT_MONTH = "{MM}";

    /**
     * 日
     */
    private static final String FORMAT_DAY = "{dd}";

    /**
     * 年月日
     */
    private static final String FORMAT_DATE = "{yyyyMMdd}";

    public static final String LINE_SEPARATOR = java.security.AccessController.doPrivileged(
            new GetPropertyAction("line.separator"));


    /**
     * @return void
     * @author zhangxin
     * @description 下载文件并保存到本地
     * @date 2018/6/26 16:05
     * @params [urlStr, filePath]
     **/
    public static void downloadFromUrl(String urlStr, String filePath) throws IOException {
        // 下载网络文件
        int byteread = 0;
        try(InputStream inStream = downloadStreamFromUrl(urlStr);
            FileOutputStream fs = new FileOutputStream(filePath)) {
            byte[] buffer = new byte[1024];
            while ((byteread = inStream.read(buffer)) != -1) {
                fs.write(buffer, 0, byteread);
            }
            fs.flush();
        }
    }

    /**
     * @return byte[]
     * @author zhangxin
     * @description 下载文件并返回字符数组
     * @date 2018/6/26 16:06
     * @params [urlStr]
     **/
    public static byte[] downloadFromUrl(String urlStr) throws IOException {
        InputStream is = downloadStreamFromUrl(urlStr);
        return readInputStream(is);
    }

    /**
     * @return java.io.InputStream
     * @author zhangxin
     * @description 下载并获取输入流
     * @date 2018/6/26 16:06
     * @params [urlStr]
     **/
    public static InputStream downloadStreamFromUrl(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        URLConnection conn = url.openConnection();
        return conn.getInputStream();
    }

    /**
     * @return byte[]
     * @author zhangxin
     * @description 从输入流中获取字节数组
     * @date 2018/6/26 16:12
     * @params [inputStream]
     **/
    public static byte[] readInputStream(InputStream inputStream) throws IOException {
        byte[] buffer = new byte[1024];
        int len = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while ((len = inputStream.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }
        bos.close();
        return bos.toByteArray();
    }

    /**
     * @return void
     * @author zhangxin
     * @description 将字符串数据写入文件
     * @date 2018/6/26 16:12
     * @params [filePath, data, append]
     **/
    public static void writeStrToFile(String filePath, String data, boolean append) throws IOException {
        File dataFile = new File(filePath);
        // 将对账数据写入文件
        org.apache.commons.io.FileUtils.write(dataFile, data, "GBK", append);
    }

    /**
     * 将字符串写入文件
     * @param filePath 文件全路径
     * @param data 写入的数据
     * @param encoding 写入文件的编码
     * @param append 是否原文件追加
     * @throws IOException
     */
    public static void writeStrToFile(String filePath, String data, String encoding, boolean append) throws IOException {
        File dataFile = new File(filePath);
        // 将对账数据写入文件
        org.apache.commons.io.FileUtils.write(dataFile, data, encoding, append);
    }

    public static void writeStrToFile(String filePath, List<String> fileData) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath)))) {
            for (String row : fileData) {
                bw.write(row);
                bw.newLine();
            }
            bw.flush();
        }
    }

    /**
     * @return void
     * @author zhangxin
     * @description 将字节数组写入文件
     * @date 2018/6/26 16:13
     * @params [filePath, bytes]
     **/
    public static void writeBytesToFile(String filePath, byte[] bytes) throws IOException {
        File file = new File(filePath);
        File parentFile = file.getParentFile();
        boolean result = false;
        if (parentFile != null && !parentFile.exists()) {
            result = parentFile.mkdirs();
        }
        if (!result) {
            throw new DxpCommonException("DIR_CREATE_ERROR","dir create fail");
        }
        try( OutputStream output = new FileOutputStream(file);
             BufferedOutputStream bufferedOutput = new BufferedOutputStream(output)) {

            bufferedOutput.write(bytes);
            bufferedOutput.flush();
        }
    }

    /**
     * @return void
     * @author zhangxin
     * @description 解压文件到指定目录
     * @date 2018/6/26 16:13
     * @params [zipFilePath, destDir]
     **/
    public static void unZip(String zipFilePath, String destDir) throws IOException {
        BufferedInputStream bis = null;
        File file = null;
        File parentFile = null;
        ZipEntry entry = null;
        try(ZipFile zipFile = new ZipFile(zipFilePath, Charset.forName("gbk"))) {

            Enumeration<?> emu = zipFile.entries();
            byte[] cache = new byte[1024];
            while (emu.hasMoreElements()) {
                entry = (ZipEntry) emu.nextElement();
                if (entry.isDirectory()) {
                    boolean result = new File(destDir + entry.getName()).mkdirs();
                    if (!result) {
                        throw new IOException("unzip create dir fail");
                    }
                    continue;
                }
                bis = new BufferedInputStream(zipFile.getInputStream(entry));
                file = new File(destDir + entry.getName());
                parentFile = file.getParentFile();
                boolean result = false;
                if (parentFile != null && (!parentFile.exists())) {
                    result = parentFile.mkdirs();
                }
                if (!result) {
                    throw new IOException("unzip create parent dir fail");
                }
                try(FileOutputStream fos = new FileOutputStream(file);
                    BufferedOutputStream bos = new BufferedOutputStream(fos, 1024)) {

                    int nRead = 0;
                    int len = 1024;
                    while ((nRead = bis.read(cache, 0, len)) != -1) {
                        fos.write(cache, 0, nRead);
                    }
                    bos.flush();
                }
            }
        } finally {
            if (bis != null) {
                bis.close();
            }
        }
    }

    public static void zip(String srcFilePath, String destFilePath) throws FileNotFoundException {

        //创建zip输出流
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(destFilePath));

        //创建缓冲输出流
        BufferedOutputStream bos = new BufferedOutputStream(out);

        File sourceFile = new File(srcFilePath);

        //调用函数
        try {
            compress(out, bos, sourceFile, sourceFile.getName());
        } catch (Exception e) {
        	log.error("异常原因:{}", e);
        } finally {
            try {
                bos.close();
                out.close();
            } catch (IOException e) {
            	log.error("异常原因:{}", e);
            }
        }
    }

    public static void compress(ZipOutputStream out, BufferedOutputStream bos, File sourceFile, String base) throws Exception {
        //如果路径为目录（文件夹）
        if (sourceFile.isDirectory()) {

            //取出文件夹中的文件（或子文件夹）
            File[] flist = sourceFile.listFiles();

            if (flist.length == 0)//如果文件夹为空，则只需在目的地zip文件中写入一个目录进入点
            {
                System.out.println(base + "/");
                out.putNextEntry(new ZipEntry(base + "/"));
            } else//如果文件夹不为空，则递归调用compress，文件夹中的每一个文件（或文件夹）进行压缩
            {
                for (int i = 0; i < flist.length; i++) {
                    compress(out, bos, flist[i], base + "/" + flist[i].getName());
                }
            }
        } else//如果不是目录（文件夹），即为文件，则先写入目录进入点，之后将文件写入zip文件中
        {
            out.putNextEntry(new ZipEntry(base));
            try (FileInputStream fos = new FileInputStream(sourceFile);
                 BufferedInputStream bis = new BufferedInputStream(fos)) {

                int tag;
                System.out.println(base);
                //将源文件写入到zip文件中
                while ((tag = bis.read()) != -1) {
                    bos.write(tag);
                }
            }

        }
    }




    /**
     * 关闭流
     *
     * @param stream
     */
    public static void closeStream(Closeable... stream) {
        for (Closeable close : stream) {
            try {
                if (close != null) {
                    close.close();
                }
            } catch (IOException e) {
                log.error("流关闭时发生错误:", e);
            }
        }
    }

    /**
     * 删除文件夹
     *
     * @param fileDetailPath
     * @return
     */
    public static boolean deleteDir(String fileDetailPath) {
        File file = new File(fileDetailPath);
        if (!file.exists()) {
            return true;
        }
        if (!file.isDirectory()) {
            return file.delete();
        }
        // 文件夹递归调用删除
        String[] files = file.list();
        if (files == null || files.length == 0) {
            return file.delete();
        }
        if (!StringUtils.endsWith(fileDetailPath, File.separator)) {
            fileDetailPath = fileDetailPath + File.separator;
        }
        for (String subFilePath : files) {
            deleteDir(fileDetailPath + subFilePath);
        }
        return file.delete();
    }

    /**
     * 清空指定文件夹
     *
     * @param filePath
     * @return
     */
    public static boolean clearDir(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            return true;
        }
        // 文件夹递归调用删除
        String[] files = file.list();
        if (files == null || files.length == 0) {
            return true;
        }
        if (!StringUtils.endsWith(filePath, File.separator)) {
            filePath = filePath + File.separator;
        }
        for (String subFilePath : files) {
            deleteDir(filePath + subFilePath);
        }
        return true;
    }

    /**
     * 修改文件名称
     *
     * @param filePath
     * @param fileName
     * @param newFileName
     * @return
     */
    public static boolean rename(String filePath, String fileName,
                                 String newFileName) {
        File sourceFile = new File(filePath + fileName);
        File toFile = new File(filePath + newFileName);
        return sourceFile.renameTo(toFile);
    }

    /**
     * 移动并修改名称
     *
     * @param sourceFile
     * @param toPath
     * @param toFileName
     * @return
     */
    public static boolean moveAndRename(File sourceFile, String toPath, String toFileName) {
        File toFile = new File(toPath + toFileName);
        return sourceFile.renameTo(toFile);
    }

    /**
     * 拷贝文件
     *
     * @param sourceFilePath
     * @param toFilePath
     * @return
     */
    public static boolean copyFile(String sourceFilePath, String toFilePath) {
        try {
            org.apache.commons.io.FileUtils.copyFile(new File(sourceFilePath), new File(toFilePath), true);
            return true;
        } catch (IOException e) {
        	log.error("拷贝异常原因:{}", e);
        }
        return false;
    }

    public static boolean createNewFile(String filePath, String fileName) {
        if (StringUtils.isEmpty(filePath) || StringUtils.isEmpty(fileName)) {
            return false;
        }
        // 创建文件目录
        File dir = new File(filePath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        // 创建文件,已存在文件删除
        File file = new File(filePath + fileName);
        if (file.exists() && file.delete()) {
            log.info("文件删除成功！");
        }
        try {
            return file.createNewFile();
        } catch (IOException e) {
            log.error("Error occurred on method createFile:", e);
        }
        return false;
    }

    public static void main(String[] args) {
        createNewFile("E:\\file\\abc\\", "a.txt");
    }
}
