package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.UnitsDao;
import com.sunyard.dxp.common.entity.Units;
import com.sunyard.dxp.common.qo.UnitsQo;
import org.springframework.stereotype.Repository;

/**
 * 单位 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Wed Dec 25 19:35:40 CST 2019
 */
@Repository
public class JpaUnitsDaoImpl  extends JpaBaseDaoImpl<Units,String,UnitsQo> implements UnitsDao{
    @Override
    public Units findUnitsByCode(String code) {
        String hql = this.getMainQuery() + "where obj.code = ?";
        return this.findBySingle(hql, code);
    }
}
