package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 *
 */
@FunctionLibrary(code = "strDefault",name = "字符串默认转换",expression = "(strDefault\\()([\\u4e00-\\u9fa5\\s\\w\\.,]+\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "strDefault(s)",hasProperty = true)
@Component
public class StrDefaultFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            return "" ;
        }
        String[] param = params.split(",",-1);
        if (ArrayUtils.isEmpty(param) ) {
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        //之后一个参数
        if (param.length != 2) {
            return params ;
        }
        if(StringUtils.isBlank(param[1])){
            return param[0] ;
        }
        return param[1];
    }
}
