package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * 用于现将value 按照分隔符分割，再取数组中第几个数据, 再转换为 中心需要的金额 以元做单位
 *
 * @author Thud
 * @date 2020/1/2 16:06
 */
@FunctionLibrary( code = "sepToYUAN", name = "分割取金额并转换", expression = "(sepToYUAN\\()([\\|\\@0-9\\,]+\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "sepToYUAN(x@y)", hasProperty = true )
@Component
public class SepToYUANFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        //sepNumToYUAN(|@2,1|2|3)
        String[] param = params.split("@");

        String sepSign = "|".equals(param[ 0 ]) ? "\\|" : param[ 0 ];  // 数据分隔符
        String[] property = param[ 1 ].split(",");

        String strVal = "" ;
        if(property.length>1){
            strVal = param[1].substring(param[1].indexOf(",")+1) ;
        }

        String[] arr = strVal.split(sepSign);
        String amt = arr[ Integer.parseInt(property[ 0 ]) ];
        return new BigDecimal(amt.trim()).divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_CEILING).toString();
    }
}
