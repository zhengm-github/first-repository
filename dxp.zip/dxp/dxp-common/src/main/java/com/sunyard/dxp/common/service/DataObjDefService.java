package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.DataObjDef;
import com.sunyard.dxp.common.qo.DataObjDefQo;

import java.util.List;

/**
 * 数据对象定义 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:27 CST 2019
 */
public interface DataObjDefService extends BaseService<DataObjDef, String, DataObjDefQo> {

    /**
     * 根据接入Id找结果对象
     * @param inSvcBundleId
     * @param dataKind
     * @return
     */
    List<DataObjDef> findByInBundleId(String inSvcBundleId, String dataKind) ;

    /**
     * 根据接出Id找结果对象
     * @param outSvcBundleId
     * @param dataKind
     * @return
     */
    List<DataObjDef> findByOutBundleId(String outSvcBundleId, String dataKind) ;

    /**
     * 根据接出服务id查询数据对象定义表
     * @param outBoundSvcId
     * @return
     */
    List<DataObjDef> getDataObjDefByOutsvcId(String outBoundSvcId);

    /**
     * 根据接入服务id查询数据对象定义表
     * @param inBoundSvcId
     * @return
     */
    List<DataObjDef> getDataObjDefByInsvcId(String inBoundSvcId);

}
