package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.DataMapPropertyDefRelaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 请求报文映射配置属性 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:25:20 CST 2020
 */
public class DataMapPropertyDefRelaQct extends QueryConditionTransfer<DataMapPropertyDefRelaQo> {

    @Override
    public void transNameQuery(DataMapPropertyDefRelaQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(DataMapPropertyDefRelaQo qo, QueryCondition condition) {
        //
    }

}
