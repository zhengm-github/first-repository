package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.AccessKeyDao;
import com.sunyard.dxp.common.entity.AccessKey;
import com.sunyard.dxp.common.qo.AccessKeyQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * 统一服务授权key jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:26:00 CST 2019
 */
@Repository
public class JpaAccessKeyDaoImpl extends JpaBaseDaoImpl< AccessKey, String, AccessKeyQo > implements AccessKeyDao {

    @Override
    public AccessKey findByIpGroup(String ip) {
        return findBySingle(getMainQuery() + " where obj.accessIpGroup = ?", ip);
    }


    @Override
    public List< AccessKey > findByCode(String code) {
        return find(getMainQuery() + " where obj.appCode= ?", code);
    }

    @Override
    public AccessKey findByAccessKey(String accessKey) {

        AccessKey key = null ;
        if(StringUtils.isNotBlank(accessKey)){
            key = findBySingle(getMainQuery() + " where obj.accessKey= ?", accessKey) ;
        }
        return key ;
    }
}
