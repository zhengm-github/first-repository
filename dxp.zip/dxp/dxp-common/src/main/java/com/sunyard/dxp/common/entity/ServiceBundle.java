package com.sunyard.dxp.common.entity;

import java.util.Date;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 服务模块
* Author: Created by code generator
* Date: Tue Dec 24 10:48:47 CST 2019
*/
@Entity
@Table(name = "DXP_SERVICE_BUNDLE")
public class ServiceBundle implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5489019831103112979L;

    /** 服务模块ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "SERVICE_BUNDLE_ID")
    private String serviceBundleId;

    /** 服务模块编码 */
    @Column( name = "CODE")
    private String code;

    /** 服务模块名称 */
    @Column( name = "NAME")
    private String name;

    /** 当前版本 */
    @Column( name = "CURRENT_VERSION")
    private String currentVersion;

    /** 创建人 */
    @Column( name = "CREATOR")
    private String creator;

    /** 创建时间 */
    @Column( name = "GMT_CREATE")
    private Date gmtCreate;

    /** 修改人 */
    @Column( name = "MODIFIER")
    private String modifier;

    /** 修改时间 */
    @Column( name = "GMT_MODIFY")
    private Date gmtModify;

    /** 状态 */
    @Column( name = "STATUS")
    private String status;

    /** 备注 */
    @Column( name = "MEMO")
    private String memo;

    /** 接出服务接口 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "serviceBundle")
    private Set<OutBoundSvc> outBoundSvcs;

    /** 接入服务接口 */
    @ManyToMany( fetch = FetchType.LAZY )
    @JoinTable( name = "DXP_SVC_MODEL_RELA",
            joinColumns = { @JoinColumn(name = "SERVICE_BUNDLE_ID",referencedColumnName = "SERVICE_BUNDLE_ID") },
            inverseJoinColumns = { @JoinColumn(name = "IN_BOUND_SVC_ID",referencedColumnName = "IN_BOUND_SVC_ID")})
    private Set<InBoundSvc> inBoundSvcs;

    public String getServiceBundleId() {
        return serviceBundleId;
    }

    public void setServiceBundleId(String serviceBundleId) {
        this.serviceBundleId = serviceBundleId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(String currentVersion) {
        this.currentVersion = currentVersion;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Date getGmtModify() {
        return gmtModify;
    }

    public void setGmtModify(Date gmtModify) {
        this.gmtModify = gmtModify;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Set<OutBoundSvc> getOutBoundSvcs() {
        return outBoundSvcs;
    }

    public void setOutBoundSvcs(Set<OutBoundSvc> outBoundSvcs) {
        this.outBoundSvcs = outBoundSvcs;
    }

    public Set<InBoundSvc> getInBoundSvcs() {
        return inBoundSvcs;
    }

    public void setInBoundSvcs(Set<InBoundSvc> inBoundSvcs) {
        this.inBoundSvcs = inBoundSvcs;
    }
}
