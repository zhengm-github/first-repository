
package com.sunyard.dxp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * 读取文件内容，按照 :LST: 换行输出
 * <p>
 * 允许循环读 + 单行逐条 业务处理
 *
 * @author zhengm 20200904
 */
public class SplitFileReader {

    // 一次标志判定文件是否读取完
    public static final String END = ":LST:END";

    // 文件读取操作
    FileInputStream fis = null;
    // 文件读取的字节缓冲区
    byte[] bs = new byte[ 1024 ];
    // 当前数据在缓冲区的位置指针
    int pointer;
    // 保存字节，便于转换为字符串
    // 注意这里最大支持4k的字符串，请根据需要修改
    ByteBuffer bf = ByteBuffer.allocate(4096);

    // 前一个字节代表，用于判断是否为分隔符
    byte beforeByte = 'a';

    /**
     * 指定文件名的构造函数
     *
     * @param filename
     * @param rowSize  单行数据预估大小
     * @throws FileNotFoundException
     */
    public SplitFileReader(String filename, int rowSize) throws FileNotFoundException {

        this(new File(filename));
        bf = ByteBuffer.allocate(rowSize);
    }


    /**
     * 指定文件名
     *
     * @param filename
     * @throws FileNotFoundException
     */
    public SplitFileReader(String filename) throws FileNotFoundException {
        this(new File(filename));
    }

    /**
     * 指定文件的构造函数
     *
     * @param file
     * @throws FileNotFoundException
     */
    public SplitFileReader(File file) throws FileNotFoundException {
        if (!file.exists()) {
            throw new FileNotFoundException();
        }
        fis = new FileInputStream(file);
    }

    int len;
    byte b;

    /**
     * 读取一行数据
     *
     * @return 数据分割好的数组
     * @throws IOException
     */
    public String readLSTLine(String encode) throws IOException {

        String tmpStr = "";
        // 读取数据
        while (pointer < len || (readMore() != -1)) {
            b = bs[ pointer++ ];
            if (b == ':') {
                if (beforeByte == 'T') {
                    tmpStr = new String(bf.array(), 0, bf.position(), encode);
                    bf.clear();
                    beforeByte = 'a';  // 恢复初始
                    return tmpStr.substring(0, tmpStr.lastIndexOf(":LST"));
                } else {
                    beforeByte = ':';
                    bf.put(b);
                }
            } else if (
                    (b == 'L' && beforeByte == ':') || (b == 'S' && beforeByte == 'L')
                            || (b == 'T' && beforeByte == 'S')) {
                beforeByte = b;
                bf.put(b);
            } else {
                bf.put(b);
                beforeByte = 'a';  // 恢复初始
            }
        }

        // 剩下的部分 如果bf有值正常输出
        String lastPart = "";
        if (bf.position() > 0) {
            lastPart = new String(bf.array(), 0, bf.position(), encode);
            bf.clear();
        } else {
            lastPart = END;
        }
        return lastPart;
    }

    /**
     * 关闭
     */
    public void close( ) {
        bs = null;
        bf = null;
        try {
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int readMore( ) throws IOException {
        len = fis.read(bs);
        pointer = 0;
        return len;
    }

    // 测试
    public static void main(String[] args) throws Exception {
        SplitFileReader reader = new SplitFileReader("D:\\test.txt", 4096);
        String row = "";
        int index = 1;
        while (!reader.END.equals(row = reader.readLSTLine("UTF-8"))) {
            System.out.println("第" + (index++) + " 行的内容为：" + row);
        }
        reader.close();
    }
}