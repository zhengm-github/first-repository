package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.qo.OutBoundSvcQo;

import java.util.List;
import java.util.Map;

/**
 * 接出服务接口 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:06 CST 2019
 */
public interface OutBoundSvcService extends BaseService<OutBoundSvc, String, OutBoundSvcQo> {

    /**
     * 通过code获取接出服务
     * @param outBoundSvcCode
     * @return
     */
    List<OutBoundSvc> findOutBoundSvcByCode(String outBoundSvcCode);

    /**
     * 通过outcode 和 serviceBoundCode获取接出服务
     * @param outBoundSvcCode
     * @param svcBundleCode
     * @return
     */
    OutBoundSvc findOutBoundSvcByCodeAndSvcBundle(String outBoundSvcCode, String svcBundleCode);


    /**
     * 根据outBoundSvcIds 组sql查询
     * @param outBoundSvcIds
     * @return
     */
    List<OutBoundSvc> findByOutBoundSvcIds(String[] outBoundSvcIds) ;

    /**
     * 根据服务模块id查询接出服务
     * @param serviceBoundId
     * @return
     */
    List<OutBoundSvc> findOutBoundSvcBySvcId(String serviceBoundId);

    /**
     *
     * 签名数据组装
     * @param outBoundSvc
     * @param resolve
     * @return
     */
    String packSignData(OutBoundSvc outBoundSvc, Map< String, Object > resolve) ;


}
