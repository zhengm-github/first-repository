package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.DataObjDefDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.DataObjDefService;
import com.sunyard.dxp.common.entity.DataObjDef;
import com.sunyard.dxp.common.qo.DataObjDefQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 数据对象定义 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:27 CST 2019
 */
@Service
public class DataObjDefServiceImpl extends BaseServiceImpl<DataObjDef, String, DataObjDefQo> implements DataObjDefService {

    @Autowired
    private DataObjDefDao dataObjDefDao ;

    @Override
    public List< DataObjDef > findByInBundleId(String inSvcBundleId, String dataKind) {

        return dataObjDefDao.findByBundleId(inSvcBundleId, "in", dataKind);
    }

    @Override
    public List< DataObjDef > findByOutBundleId(String outSvcBundleId, String dataKind) {

        return dataObjDefDao.findByBundleId(outSvcBundleId, "out", dataKind);
    }

    @Override
    public List<DataObjDef> getDataObjDefByOutsvcId(String outBoundSvcId) {
        return dataObjDefDao.getDataObjDefByOutsvcId(outBoundSvcId);
    }

    @Override
    public List<DataObjDef> getDataObjDefByInsvcId(String inBoundSvcId) {
        return dataObjDefDao.getDataObjDefByInsvcId(inBoundSvcId);
    }

}
