package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.AccountAttributesCodeEnums;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary(code = "accountAttributesCodeMapper",name = "账户属性映射",expression = "(accountAttributesCodeMapper\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "accountAttributesCodeMapper()",hasProperty = true)
@Component
public class AccountAttributesCodeMapperFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        return AccountAttributesCodeEnums.getMapperNameByCode(params);
    }
}
