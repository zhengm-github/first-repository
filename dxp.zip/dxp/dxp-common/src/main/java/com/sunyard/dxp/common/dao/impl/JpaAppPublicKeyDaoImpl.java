package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.AppPublicKeyDao;
import com.sunyard.dxp.common.entity.AppPublicKey;
import com.sunyard.dxp.common.qo.AppPublicKeyQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;


/**
 * 应用公钥 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:44 CST 2019
 */
@Repository
public class JpaAppPublicKeyDaoImpl extends JpaBaseDaoImpl< AppPublicKey, String, AppPublicKeyQo > implements AppPublicKeyDao {


    @Override
    public AppPublicKey findByKey(String publicKey) {
        AppPublicKey appPublicKey = null;
        if (StringUtils.isNotBlank(publicKey)) {
            appPublicKey = findBySingle(getMainQuery() + " where obj.publicKey = ?", publicKey);
        }
        return appPublicKey;
    }
}
