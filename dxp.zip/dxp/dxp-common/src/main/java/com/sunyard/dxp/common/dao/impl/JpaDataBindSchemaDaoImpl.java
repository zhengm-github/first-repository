package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.DataBindSchemaDao;
import com.sunyard.dxp.common.entity.DataBindSchema;
import com.sunyard.dxp.common.qo.DataBindSchemaQo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 数据绑定模式 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:05 CST 2019
 */
@Repository
public class JpaDataBindSchemaDaoImpl extends JpaBaseDaoImpl< DataBindSchema, String, DataBindSchemaQo > implements DataBindSchemaDao {

    @Override
    public List< DataBindSchema > findByOutBoundSvcIds(String... outBoundSvcIds) {

        if (outBoundSvcIds instanceof String[]) {
            StringBuilder whereBuilder = new StringBuilder(" where obj.outBoundSvc.outBoundSvcId in( ");
            for (String str : outBoundSvcIds) {
                whereBuilder.append("'").append(str).append("',");
            }
            whereBuilder.append("'none'");
            return findByQueryString(whereBuilder.toString());
        } else {
            return findByQueryString(getMainQuery() + " where obj.outBoundSvc.outBoundSvcId = ?", outBoundSvcIds);
        }
    }

    @Override
    public List< DataBindSchema > findDataBindSchemaByIbsIdAndObSId(String ibsId, String obsId) {
        return find("select obj from DataBindSchema as obj , InSvcBindRela as RELAOBJ WHERE\n" +
                "obj.dataMapSchemaId=RELAOBJ.dataMapSchemaId and obj.outBoundSvc.outBoundSvcId=?\n" +
                "and RELAOBJ.inBoundSvcId in (?)", obsId, ibsId);
    }

    @Override
    public DataBindSchema findDataBindSchemaByOutBoundSvcId(String id) {
        String hql = getMainQuery() + " where obj.outBoundSvc.outBoundSvcId=?";
        return findBySingle(hql, id);
    }

    @Override
    public void deleteByObsId(String obsId) {
        if (StringUtils.isNotBlank(obsId)) {
            this.executeUpdate(
                    " delete from DataBindSchema as obj where obj.outBoundSvc.outBoundSvcId= ? ", obsId);
        }
    }
}
