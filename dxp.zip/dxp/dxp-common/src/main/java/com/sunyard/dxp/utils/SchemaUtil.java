package com.sunyard.dxp.utils;

import cn.hutool.core.util.StrUtil;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Element;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * schema 校验工具
 */
public class SchemaUtil {

    private static final Logger loger = LoggerFactory.getLogger(SchemaUtil.class);

    /**
     * 检查全国平台报文（发送至全过平台之前 ）
     *
     * @param messageBody
     * @return
     */
    public static boolean checkXmlByXsd(String messageBody, String configPath) {

        String xmlBody = "";  // 需要校验的xml
        try {

            // 获取schema 校验文件名
            byte[] messageBytes = messageBody.getBytes(StandardCharsets.UTF_8);
            String xsdName = new String(messageBytes, 70, 15, StandardCharsets.UTF_8).trim();
            xmlBody = new String(messageBytes, 148, messageBytes.length - 148, StandardCharsets.UTF_8).trim();
            // 加载模板文件
            xmlBody = XmlUtil.removeSign(xmlBody);

            String xsdPath = configPath + File.separator + "common" + File.separator
                    + "xsd" + File.separator + xsdName.toLowerCase() + ".xsd";
            loger.info("加载xsd文件:[{}]", xsdPath);
            // 如果文件不存在则直接通过
            File xsdFile = new File(xsdPath) ;
            if(!xsdFile.exists()){
                loger.info("xsd文件不存在,通过...");
                return true ;
            }

            XmlUtil xmlDocument =
                    XmlUtil.Create(XmlUtil.FROM_BUFF, xmlBody);
            String errXml = XmlUtil.validateXMLByXSD(xmlDocument.getDocument(), xsdPath);
            if (StrUtil.isNotBlank(errXml)) {
                loger.info("校验的xml串：[\r\n{}]", xmlBody);
                loger.info("schema校验不通过原因:[\n{}]", errXml);
                return false;
            }
            loger.info("校验Xml串成功！");
            return true;
        } catch (Exception e) {
            loger.error("报文schema检查异常！", e.getMessage());
            loger.info("校验的xml串：[\r\n{}]", xmlBody);
            return false;
        }
    }

    /**
     * 处理900 特殊处理的交易之后报文体内容
     *
     * @param ibsCode
     * @param headMsg
     * @param valueMap
     * @param configPath
     * @param encode
     * @return
     * @throws Exception
     */
    public static String dealSpecial(String ibsCode, String headMsg, Map< String, String > valueMap,
                                     String configPath, String encode) throws Exception {

        // 读取对应转换配置文件
        XmlUtil xmlUtil = XmlUtil.Create(XmlUtil.FROM_FILE,
                configPath + File.separator +
                        "webapp" + File.separator + "transfer_900" + File.separator +
                        String.format("900_%s.xml", ibsCode.replaceAll("_.*", "")));
        // 定长报文头
        String needUpdate = xmlUtil.getNodeContent("/root/needUpdate");
        String[] fields = needUpdate.split(",");
        Element e = null;
        int start = 0, len = 0;
        for (String field : fields) {
            e = (Element) (xmlUtil.getDocument().selectSingleNode("/root/" + field));
            start = Integer.parseInt(e.attribute("start").getValue());
            len = Integer.parseInt(e.attribute("len").getValue());
            headMsg = headMsg.substring(0, start)
                    + StringUtil.formatStr(e.getTextTrim(), len, " ", false)
                    + headMsg.substring(start + len);
        }
        // xml报文
        Element x = (Element) xmlUtil.getDocument().selectSingleNode("/root/message");
        String message = ((Element) x.elements().get(0)).asXML();
        XmlUtil ibsXml = XmlUtil.Create(XmlUtil.FROM_BUFF, message);  // 目标xml（报文体）
        XmlUtil.setElementList(ibsXml.getDocument().getRootElement(), valueMap); // 赋值

        // 定长部分是否满足 148位 add by zhengm 20200506
        headMsg = StringUtil.formatStr(headMsg, 148, " ", false);
        return headMsg + ibsXml.dumpToBuff(encode);
    }

}
