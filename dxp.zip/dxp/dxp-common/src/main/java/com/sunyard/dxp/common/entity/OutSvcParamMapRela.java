package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
* 接出服务参数映射配置
* Author: Created by code generator
* Date: Tue Dec 24 10:47:38 CST 2019
*/
@Entity
@Table(name = "DXP_OUT_SVC_PARAM_MAP_RELA")
public class OutSvcParamMapRela implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6513995552800257939L;

    /** 接出接口参数定义ID */
    @Id
    @Column( name = "SERVICE_PARAM_DEFINE_ID")
    private String serviceParamDefineId;

    /** 接口参数映射配置ID */
    @Id
    @Column( name = "PARAM_MAP_CONFIG_ID")
    private String paramMapConfigId;

    public String getServiceParamDefineId() {
        return serviceParamDefineId;
    }

    public void setServiceParamDefineId(String serviceParamDefineId) {
        this.serviceParamDefineId = serviceParamDefineId;
    }

    public String getParamMapConfigId() {
        return paramMapConfigId;
    }

    public void setParamMapConfigId(String paramMapConfigId) {
        this.paramMapConfigId = paramMapConfigId;
    }

}
