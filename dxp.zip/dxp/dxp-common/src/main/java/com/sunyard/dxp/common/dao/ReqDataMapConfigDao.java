package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.ReqDataMapConfig;
import com.sunyard.dxp.common.qo.ReqDataMapConfigQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 请求报文映射配置 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:15:01 CST 2020
 */
public interface ReqDataMapConfigDao extends BaseDao<ReqDataMapConfig, String, ReqDataMapConfigQo> {

    /**
     * 根据接入数据属性查询请求报文映射配置
     * @param dataPropertyId
     * @return
     */
    List<ReqDataMapConfig> findReqConfigByInDataPropertyId(String dataPropertyId);

    /**
     * 根据接入数据属性删除请求报文映射配置
     * @param propertyId
     * @return
     */
    void deleteByPropertyId(String propertyId);
}
