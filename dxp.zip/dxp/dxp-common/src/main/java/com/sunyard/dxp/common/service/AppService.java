package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.AddrInfo;
import com.sunyard.dxp.common.entity.App;
import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.dxp.common.qo.AppQo;
import com.sunyard.frameworkset.core.service.BaseService;

/**
 * 应用系统 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:23 CST 2019
 */
public interface AppService extends BaseService< App, String, AppQo > {
    /**
     * 根据应用编号查询应用系统
     *
     * @param code
     * @return
     */
    App findByCode(String code);
}
