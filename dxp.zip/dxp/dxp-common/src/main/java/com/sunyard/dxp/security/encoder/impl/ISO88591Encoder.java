package com.sunyard.dxp.security.encoder.impl;

import com.sunyard.dxp.security.encoder.Encoder;
import com.sunyard.dxp.utils.EncoderLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

import java.nio.charset.StandardCharsets;

/**
 * 编码转换为GBK
 */
@EncoderLibrary( code = "ISO-8859-1", name = "ISO-8859-1编码" )
public class ISO88591Encoder implements Encoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(ISO88591Encoder.class);

    @Override
    public String encode(String content) {
        String clientStr = null;
        try {
            clientStr = new String(content.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.ISO_8859_1);
        } catch (Exception e) {
            LOGGER.error("编码ISO-8859-1失败！");
            throw new FapException("", "编码ISO-8859-1失败！");
        }
        return clientStr;
    }
}
