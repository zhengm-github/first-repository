package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 响应报文绑定配置
* Author: Created by code generator
* Date: Tue Dec 24 10:43:42 CST 2019
*/
@Entity
@Table(name = "DXP_RSP_DATA_BIND_CONFIG")
public class RspDataBindConfig implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8491009762701634416L;

    /** 数据绑定配置ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "DATA_BIND_CONFIG_ID")
    private String dataBindConfigId;

    /** 绑定表达式 */
    @Column( name = "BIND_EXP")
    private String bindExp;

    /** 顺序号 */
    @Column( name = "ORD")
    private Integer ord;

    /** 数据绑定模式 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "DATA_MAP_SCHEMA_ID", referencedColumnName = "DATA_MAP_SCHEMA_ID")
    private DataBindSchema dataBindSchema;

    /** 接出数据属性定义 */
    @OneToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "OUT_DATA_PROPERTY_ID", referencedColumnName = "DATA_PROPERTY_ID")
    private DataPropertyDef outDataPropertyDef;

    /** 接入数据属性定义 */
    @ManyToMany( fetch = FetchType.LAZY, cascade = CascadeType.REFRESH )
    @JoinTable( name = "DXP_DATA_BIND_PROPERTY_DEF_RELA",
            joinColumns = { @JoinColumn( name = "DATA_BIND_CONFIG_ID", referencedColumnName = "DATA_BIND_CONFIG_ID" ) },
            inverseJoinColumns = { @JoinColumn( name = "DATA_PROPERTY_ID", referencedColumnName = "DATA_PROPERTY_ID" ) } )
    private Set< DataPropertyDef > inDataPropertyDefs;

    public String getDataBindConfigId() {
        return dataBindConfigId;
    }

    public void setDataBindConfigId(String dataBindConfigId) {
        this.dataBindConfigId = dataBindConfigId;
    }

    public String getBindExp() {
        return bindExp;
    }

    public void setBindExp(String bindExp) {
        this.bindExp = bindExp;
    }

    public Integer getOrd() {
        return ord;
    }

    public void setOrd(Integer ord) {
        this.ord = ord;
    }

    public DataBindSchema getDataBindSchema() {
        return dataBindSchema;
    }

    public void setDataBindSchema(DataBindSchema dataBindSchema) {
        this.dataBindSchema = dataBindSchema;
    }

    public DataPropertyDef getOutDataPropertyDef() {
        return outDataPropertyDef;
    }

    public void setOutDataPropertyDef(DataPropertyDef outDataPropertyDef) {
        this.outDataPropertyDef = outDataPropertyDef;
    }

    public Set<DataPropertyDef> getInDataPropertyDefs() {
        return inDataPropertyDefs;
    }

    public void setInDataPropertyDefs(Set<DataPropertyDef> inDataPropertyDefs) {
        this.inDataPropertyDefs = inDataPropertyDefs;
    }
}
