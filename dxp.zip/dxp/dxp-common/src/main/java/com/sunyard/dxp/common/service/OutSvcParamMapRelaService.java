package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.OutSvcParamMapRela;
import com.sunyard.dxp.common.qo.OutSvcParamMapRelaQo;

/**
 * 接出服务参数映射配置 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:38 CST 2019
 */
public interface OutSvcParamMapRelaService extends BaseService<OutSvcParamMapRela, String, OutSvcParamMapRelaQo> {
}
