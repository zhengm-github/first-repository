package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.OutSvcParamMapRelaDao;
import com.sunyard.dxp.common.entity.OutSvcParamMapRela;
import com.sunyard.dxp.common.qo.OutSvcParamMapRelaQo;
import org.springframework.stereotype.Repository;

/**
 * 接出服务参数映射配置 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:38 CST 2019
 */
@Repository
public class JpaOutSvcParamMapRelaDaoImpl  extends JpaBaseDaoImpl<OutSvcParamMapRela,String,OutSvcParamMapRelaQo> implements OutSvcParamMapRelaDao{

}
