package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.ReqDataMapConfigQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 请求报文映射配置 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:15:01 CST 2020
 */
public class ReqDataMapConfigQct extends QueryConditionTransfer<ReqDataMapConfigQo> {

    @Override
    public void transNameQuery(ReqDataMapConfigQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(ReqDataMapConfigQo qo, QueryCondition condition) {
        //
    }

}
