package com.sunyard.dxp.security.encrypt.impl;

import com.sunyard.dxp.security.encrypt.Encryption;
import com.sunyard.dxp.utils.EncryptionLibrary;
import org.apache.commons.codec.binary.Base64;

/**
 * BASE64加密
 */
@EncryptionLibrary(code = "Base64Encryption" , name = "base64加密")
public class Base64Encryption implements Encryption {
    @Override
    public String encrypt(String content, String key) {
        return Base64.encodeBase64String((content+key).getBytes());
    }
}
