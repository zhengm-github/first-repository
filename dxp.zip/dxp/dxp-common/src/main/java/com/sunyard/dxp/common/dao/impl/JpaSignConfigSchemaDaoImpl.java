package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.SignConfigSchemaDao;
import com.sunyard.dxp.common.entity.SignConfigSchema;
import com.sunyard.dxp.common.qo.SignConfigSchemaQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 签名配置规划 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:54:44 CST 2020
 */
@Repository
public class JpaSignConfigSchemaDaoImpl  extends JpaBaseDaoImpl<SignConfigSchema,String,SignConfigSchemaQo> implements SignConfigSchemaDao{

    @Override
    public List<SignConfigSchema> getSignConfigSchemaByOutsvcId(String outBoundSvcId) {
        return this.find("Select obj from SignConfigSchema as obj where obj.outBoundSvc.outBoundSvcId = ?", outBoundSvcId);
    }

    @Override
    public List<SignConfigSchema> getSignConfigSchemaByInsvcId(String inBoundSvcId) {
        return this.find("Select obj from SignConfigSchema as obj where obj.inBoundSvc.inBoundSvcId = ?", inBoundSvcId);

    }

    @Override
    public void deleteSignConfigSchemaByOutsvcId(String outBoundSvcId) {
        this.executeUpdate("delete from  SignConfigSchema as obj where obj.outBoundSvc.outBoundSvcId =?",outBoundSvcId);
    }

    @Override
    public void deleteSignConfigSchemaByInsvcId(String inBoundSvcId) {
        this.executeUpdate("delete from  SignConfigSchema as obj where obj.inBoundSvc.inBoundSvcId =?",inBoundSvcId);
    }
}
