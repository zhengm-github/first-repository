package com.sunyard.dxp.message.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunyard.dxp.exception.DxpCommonException;

import java.util.*;

/**
 * @Description Json处理相关工具类
 * @Author zhangxin
 * @Date 2018/6/26 16:41
 * @Version 1.0
 */
public class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private JsonUtils(){}

    /**
     * @author zhangxin
     * @description 对象转JSONString
     * @date 2018/6/26 17:29
     * @params [bean]
     * @return java.lang.String
     **/
    public static final String beanToJsonAsStr(Object bean){
        try {
            return MAPPER.writeValueAsString(bean);
        } catch (JsonProcessingException e) {
            throw new DxpCommonException("bean to jsonStr error", e.getMessage());
        }
    }

    /**
     * @author zhangxin
     * @description JSONString转换为对象
     * @date 2018/6/27 9:09
     * @params [jsonStr, clazz]
     * @return T
     **/
    public static final <T> T jsonStrToBean(String jsonStr, Class<T> clazz){
        try {
            return MAPPER.readValue(jsonStr, clazz);
        } catch (Exception e) {
            throw new DxpCommonException("jsonStr to bean error", e.getMessage());
        }
    }

    /**
     * @author zhangxin
     * @description JSONString转换为JSON对象
     * @date 2018/6/27 8:42
     * @params [jsonData]
     * @return com.alibaba.fastjson.JSONObject
     **/
    public static JSONObject toJson(String jsonData){
        return JSON.parseObject(jsonData);
    }

    /**
     * @author zhangxin
     * @description 将JSON字符串转化为Bean
     * @date 2018/6/27 8:51
     * @params [jsonData, clazz]
     * @return T
     **/
    public static <T> T toBean(String jsonData, Class<T> clazz){
        return JSON.parseObject(jsonData, clazz);
    }

    /**
     * @author zhangxin
     * @description JSONString转换为JSONArray
     * @date 2018/6/27 8:43
     * @params [jsonData]
     * @return com.alibaba.fastjson.JSONArray
     **/
    public static JSONArray toJsonArray(String jsonData){
        return JSON.parseArray(jsonData);
    }

    /**
     * @author zhangxin
     * @description JSONString转换为List<T>
     * @date 2018/6/27 8:48
     * @params [jsonData, clazz]
     * @return java.util.List<T>
     **/
    public static <T> List<T> toList(String jsonData, Class<T> clazz){
        return JSON.parseArray(jsonData, clazz);
    }

    /**
     * @author zhangxin
     * @description map对象转换为JSON对象
     * @date 2018/6/27 8:56
     * @params [map]
     * @return com.alibaba.fastjson.JSONObject
     **/
    @SuppressWarnings("rawtypes")
	public static JSONObject toJson(Map map){
        return (JSONObject) JSON.toJSON(map);
    }

    /**
     * @author zhangxin
     * @description 集合转JSONArray
     * @date 2018/6/27 9:00
     * @params [collection]
     * @return com.alibaba.fastjson.JSONArray
     **/
    @SuppressWarnings("rawtypes")
	public static JSONArray toJsonArray(Collection collection){
        return (JSONArray) JSON.toJSON(collection);
    }

    /**
     * @author zhangxin
     * @description JSON转换为bean
     * @date 2018/6/27 9:03
     * @params [json, clazz]
     * @return T
     **/
    public static <T> T toBean(JSON json, Class<T> clazz){
        return JSON.toJavaObject(json, clazz);
    }

    /**
     * @author zhangxin
     * @description bean转JSONString
     * @date 2018/6/27 9:05
     * @params [object]
     * @return java.lang.String
     **/
    public static String toJsonString(Object object){
        return JSON.toJSONString(object);
    }

    /**
     * 将JSON对象中的属性排序后转换字符串
     * 排序方式首字母增序排列
     * @author zhangxin
     * @date 2018/8/26 15:18
     * @param jsonObject 需要排序的JSON对象
     * @return java.lang.String
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static String sort(JSONObject jsonObject){
        Map<String, Object> sortMap = new TreeMap(new MapKeyComparator());
        sortMap.putAll(jsonObject);
        return toJsonString(sortMap);
    }



    /**
     * list<jsonobject>转换list<String> jsonobject属性按首字母排序
     * @author zhangxin
     * @date 2018/8/28 9:43
     * @param jsonObjectList
     * @return java.util.List<java.lang.String>
     */
    private static List<String> getSortStrList(List<JSONObject> jsonObjectList) {
        List<String> stringList = new ArrayList<>();
        for (JSONObject jsonObject:jsonObjectList) {
            stringList.add(sort(jsonObject));
        }
        return stringList;
    }

    /**
     * bean转json对象
     * @author zhangxin
     * @date 2018/9/9 17:13
     * @param object bean
     * @return com.alibaba.fastjson.JSONObject
     */
    public static JSONObject beanToJson(Object object){
        return (JSONObject) JSON.toJSON(object);
    }
}

class MapKeyComparator implements Comparator<String> {
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
}
