package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.Units;
import com.sunyard.dxp.common.qo.UnitsQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

/**
 * 单位 dao 接口
 *
 * Author: Created by code generator
 * Date: Wed Dec 25 19:35:40 CST 2019
 */
public interface UnitsDao extends BaseDao<Units, String, UnitsQo> {
    /**
     * 根据code查询单位
     * @param code
     * @return
     */
    Units findUnitsByCode(String code);
}
