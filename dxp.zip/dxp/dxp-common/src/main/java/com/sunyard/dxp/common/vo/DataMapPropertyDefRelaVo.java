package com.sunyard.dxp.common.vo;

import java.io.Serializable;

/**
* 请求报文映射配置属性
*
* Author: Created by code generator
* Date: Tue Jan 07 19:25:20 CST 2020
*/
public class DataMapPropertyDefRelaVo implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 9054891212420468639L;

    /** 接口参数映射配置ID */
    private String dataMapConfigId;

    /** 数据属性Id */
    private String dataPropertyId;


    public String getDataMapConfigId() {
    return dataMapConfigId;
    }

    public void setDataMapConfigId(String dataMapConfigId) {
    this.dataMapConfigId = dataMapConfigId;
    }

    public String getDataPropertyId() {
    return dataPropertyId;
    }

    public void setDataPropertyId(String dataPropertyId) {
    this.dataPropertyId = dataPropertyId;
    }

}
