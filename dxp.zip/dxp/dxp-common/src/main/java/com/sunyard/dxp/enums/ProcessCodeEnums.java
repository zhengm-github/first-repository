package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * *
 * User: wuyongzhi
 * Date: 2017/7/11 10:21
 * version $Id: AccessKeyEnum.java, v 0.1 Exp $
 */
public enum ProcessCodeEnums implements EnumAware {
    PR00("PR00","已转发"),
    PR01("PR01","待认证"),
    PR02 ("PR02","已付款"),
    PR03 ("PR03","已轧差"),
    PR05 ("PR05","已成功"),
    PR06 ("PR06","待处理"),
    PR07 ("PR07","已处理"),
    PR08 ("PR08","已撤销"),
    PR09 ("PR09","已拒绝"),
    PR10 ("PR10","已确认"),
    PR11 ("PR11","轧差排队"),
    PR24 ("PR24","NPC未受理"),
    PR25 ("PR25","已部分退回"),
    PR32 ("PR32","已超期（逾期退回）"),
    PR40 ("PR40","扣款成功"),
    PR21 ("PR21","扣款失败"),
    ;

    private String code;

    private String name;

    ProcessCodeEnums(String code, String name) {
        this.code = code;
        this.name = name;
    }
    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return null;
    }


    public static String getMapperNameByCode(String code) {
        for (ProcessCodeEnums enums : ProcessCodeEnums.values()) {
            if (enums.code.equals(code)) {
                return enums.name;
            }
        }
        return code;
    }
}
