package com.sunyard.dxp.security.decrypt.impl;

import com.sunyard.dxp.security.decrypt.Decryption;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;

/**
 * RSA私钥解密
 */
public class RSAPrivateDecryption implements Decryption {
    private static final Logger LOGGER = LoggerFactory.getLogger( RSAPrivateDecryption.class );


    @Override
    public String decrypt(String content, String key) {
        byte[] bytesContent = Base64.decodeBase64(content);
        byte[] bytesKey = Base64.decodeBase64(key);
        try {
            //取得私钥
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(bytesKey);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            //生成私钥
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8KeySpec);
            //数据解密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            return new String(cipher.doFinal(bytesContent));
        }catch (Exception e){
            LOGGER.error("RSA私钥解密失败");
            throw new FapException("","RSA私钥解密失败");
        }
    }
}
