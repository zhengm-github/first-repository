package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary(code = "changeCodeMapper",name = "数据变更类型映射(changeCode)",expression = "(changeCodeMapper\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "changeCodeMapper()",hasProperty = true)
@Component
public class ChangeCodeMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            //表达式参数不准确
            return "" ;
        }

        try {
            String value = ExpMapper.changeCodeMap.get(params);
            if(StringUtils.isBlank(value)){
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
            }
            return value ;
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName()+e);
        }
    }
}
