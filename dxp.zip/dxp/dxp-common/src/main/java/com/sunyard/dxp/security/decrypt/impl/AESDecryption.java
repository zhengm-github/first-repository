package com.sunyard.dxp.security.decrypt.impl;

import com.sunyard.dxp.security.decrypt.Decryption;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;

/**
 * AES解密
 */
public class AESDecryption implements Decryption {

    private static final Logger LOGGER = LoggerFactory.getLogger( AESDecryption.class );


    @Override
    public String decrypt(String content, String key) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            KeyGenerator kg = KeyGenerator.getInstance("AES");
            kg.init(128, new SecureRandom(key.getBytes()));
            SecretKey secretKey = kg.generateKey();
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(secretKey.getEncoded(), "AES"));
            byte[] result = cipher.doFinal(Base64.decodeBase64(content));
            return new String(result, "utf-8");
        } catch (Exception ex) {
            LOGGER.error("对内容进行aes解密密失败");
            throw new FapException("","对内容进行aes解密密失败");

        }
    }
}
