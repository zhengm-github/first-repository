package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.OutSvcParamMapRela;
import com.sunyard.dxp.common.qo.OutSvcParamMapRelaQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

/**
 * 接出服务参数映射配置 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:38 CST 2019
 */
public interface OutSvcParamMapRelaDao extends BaseDao<OutSvcParamMapRela, String, OutSvcParamMapRelaQo> {

}
