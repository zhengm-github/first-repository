package com.sunyard.dxp.utils;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Thud
 * @date 2020/1/3 15:22
 */
public class Calculate {
    private Calculate() {
    }

    private static char add = '+';

    private static char del = '-';

    private static char mul = 'x';

    private static char div = '/';

    public static String calculate(String s) {
        StringBuilder sbMath = new StringBuilder();
        List<String> math = new ArrayList<>();
        List<String> flag = new ArrayList<>();
        List<Integer> mulDiv = new ArrayList<>();
        for (int i = 0; i < s.length(); i++) {
            char temp = s.charAt(i);
            if (temp != add && temp != del && temp != mul && temp != div) {
                sbMath.append(String.valueOf(temp));
            } else {
                if (sbMath.length() == 0 && temp == del) {
                    sbMath.append("0");
                }
                math.add(sbMath.toString());
                sbMath.delete(0, sbMath.length());
                flag.add(String.valueOf(temp));
                if (temp == mul || temp == div) {
                    mulDiv.add(flag.size() - 1);
                }
            }
        }
        math.add(sbMath.toString());
        while (math.size() != 1) {
            boolean needReIndex = false;
            while (CollectionUtils.isNotEmpty(mulDiv)) {
                int index = mulDiv.get(0);
                if (needReIndex) {
                    index = index - 1;
                }
                if(CollectionUtils.isNotEmpty(flag)){
                    Map<String, List<String>> map = loopProcess(index, math, flag);
                    math = map.get("math");
                    flag = map.get("flag");
                    mulDiv = removeList(mulDiv, 0);
                    needReIndex = true;
                }
            }
            while (CollectionUtils.isNotEmpty(flag)) {
                Map<String, List<String>> map = loopProcess(0, math, flag);
                math = map.get("math");
                flag = map.get("flag");
            }
        }
        return math.get(0);
    }

    private static Map<String, List<String>> loopProcess(int index, List<String> math, List<String> flag) {
        Map<String, List<String>> map = new HashMap<>();
        char ch = flag.get(index).charAt(0);
        String result = getResult(math.get(index).trim(), math.get(index + 1).trim(), ch);
        math = removeList(math, index);
        math = removeList(math, index);
        math.add(index, result);
        flag = removeList(flag, index);
        map.put("math", math);
        map.put("flag", flag);
        return map;
    }

    private static <T> List<T> removeList(List<T> list, int index) {
        List<T> listTemp = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (i != index) {
                listTemp.add(list.get(i));
            }
        }
        return listTemp;
    }

    private static String getResult(String b, String e, char flag) {
        boolean isLong = false;
        // 去除空格
        if(StringUtils.isBlank(b) || "".equals(b.trim())) b = "0.00" ;
        if(StringUtils.isBlank(e) || "".equals(e.trim())) e = "0.00" ;
        if (!b.contains(".") && !e.contains(".")) {
            isLong = true;
        }
        if (isLong) {
            if (flag == add) {
                return String.valueOf(Long.valueOf(b) + Long.valueOf(e));
            } else if (flag == del) {
                return String.valueOf(Long.valueOf(b) - Long.valueOf(e));
            } else if (flag == mul) {
                return String.valueOf(Long.valueOf(b) * Long.valueOf(e));
            } else if (flag == div) {
                return String.valueOf((double) Long.valueOf(b) / Long.valueOf(e));
            } else {
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
            }
        } else {
            if (flag == add) {
                return new BigDecimal(b).add(new BigDecimal(e)).toString() ;
            } else if (flag == del) {
                return new BigDecimal(b).subtract(new BigDecimal(e)).toString() ;
            } else if (flag == mul) {
                return new BigDecimal(b).multiply(new BigDecimal(e)).toString() ;
            } else if (flag == div) {
                return new BigDecimal(b).divide(new BigDecimal(e)).toString() ;
            } else {
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
            }
        }
    }
}
