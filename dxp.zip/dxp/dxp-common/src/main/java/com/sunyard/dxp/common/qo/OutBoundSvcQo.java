package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 接出服务接口 QO
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:56:18 CST 2019
 */
public class OutBoundSvcQo extends PagingOrder {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 9120307439048718802L;

    /** 编号 */
    private String code;
    /** 状态 */
    private String status;
    /** 服务ID */
    private String serviceBundleId;
    /** 接出接口ids */
    private String outBoundSvcIds;

    public String getOutBoundSvcIds( ) {
        return outBoundSvcIds;
    }

    public void setOutBoundSvcIds(String outBoundSvcIds) {
        this.outBoundSvcIds = outBoundSvcIds;
    }

    public String getServiceBundleId( ) {
        return serviceBundleId;
    }

    public void setServiceBundleId(String serviceBundleId) {
        this.serviceBundleId = serviceBundleId;
    }

    public String getCode( ) {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStatus( ) {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
