package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 服务模块 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:57:12 CST 2019
   */
public class ServiceBundleQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6306148789758756992L;

    /** 编号 */
    private String code ;

    /** 名称 */
    private String name;
    /** 状态 */
    private String status ;

    /** 创建人 */
    private String creator;

    /** 当前版本 */
    private String currentVersion;

    public String getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(String currentVersion) {
        this.currentVersion = currentVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getCode( ) {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getStatus( ) {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
