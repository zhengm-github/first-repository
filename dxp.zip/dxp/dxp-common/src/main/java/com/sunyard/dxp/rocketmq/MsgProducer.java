package com.sunyard.dxp.rocketmq;


/**
 * Write class comments here
 * User: liulu
 * Date: 2017/11/9 9:46
 * version $Id: ProducerSendMessage.java, v 0.1 Exp $
 */

public interface MsgProducer {
	/**
	 *
	 * 快速通道
	 * 发送消息
	 * @param message 消息主体
	 * @param tag 二级主题用于过滤消息
	 */
	void sendMessage(String message,String tag);


	/**
	 * OBS生产mq数据慢通道
	 * @param message
	 * @param tag
	 */
	void slowSendMessage(String message, String tag) ;
}
