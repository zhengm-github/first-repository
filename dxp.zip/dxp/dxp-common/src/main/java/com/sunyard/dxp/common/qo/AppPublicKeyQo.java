package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 应用公钥 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:44 CST 2019
   */
public class AppPublicKeyQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7593570528458925117L;

    /** 公钥 */
    private String publicKey ;
    /** 应用ID */
    private String appId ;

    public String getAppId( ) {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getPublicKey( ) {
        return publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }
}
