package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.InSvcBindRela;
import com.sunyard.dxp.common.qo.InSvcBindRelaQo;
import com.sunyard.frameworkset.core.service.BaseService;

/**
 * 接入服务数据映射配置 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:55:37 CST 2019
 */
public interface InSvcBindRelaService extends BaseService< InSvcBindRela, String, InSvcBindRelaQo > {

    /**
     * 根据inBoundSvcIds 删除
     * @param inBoundSvcIds
     */
    void deleteByInBoundSvcIds(String... inBoundSvcIds) ;

    /**
     * 根据dataMapSchemaId删除
     * @param dataMapSchemaId
     */
    void deleteByDataMapSchemaId(String dataMapSchemaId) ;

    /**
     * 根据dataMapSchemaId 和 inBoundSvcId删除
     * @param dataMapSchemaId
     * @param inBoundSvcId
     */
    void deleteByDataMapSchemaIdAndInBoundSvcId(String dataMapSchemaId, String inBoundSvcId) ;
}
