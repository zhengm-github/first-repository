package com.sunyard.dxp.common.vo;

import java.io.Serializable;

/**
* 请求报文映射配置
*
* Author: Created by code generator
* Date: Tue Jan 07 19:15:01 CST 2020
*/
public class ReqDataMapConfigVo implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7548152256574082845L;

    /** 接口参数映射配置ID */
    private String paramMapConfigId2;

    /** 接入数据结果属性ID */
    private String inDataPropertyId;

    /** 映射表达式 */
    private String mapExp;

    /**  */
    private Integer ord;


    public String getParamMapConfigId2() {
    return paramMapConfigId2;
    }

    public void setParamMapConfigId2(String paramMapConfigId2) {
    this.paramMapConfigId2 = paramMapConfigId2;
    }

    public String getInDataPropertyId() {
    return inDataPropertyId;
    }

    public void setInDataPropertyId(String inDataPropertyId) {
    this.inDataPropertyId = inDataPropertyId;
    }

    public String getMapExp() {
    return mapExp;
    }

    public void setMapExp(String mapExp) {
    this.mapExp = mapExp;
    }

    public Integer getOrd() {
    return ord;
    }

    public void setOrd(Integer ord) {
    this.ord = ord;
    }

}
