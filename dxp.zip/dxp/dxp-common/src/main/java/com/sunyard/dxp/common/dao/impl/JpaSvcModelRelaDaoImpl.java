package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.SvcModelRelaDao;
import com.sunyard.dxp.common.entity.SvcModelRela;
import com.sunyard.dxp.common.qo.SvcModelRelaQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 接入服务模块关系 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Mon Dec 16 14:26:15 CST 2019
 */
@Repository
public class JpaSvcModelRelaDaoImpl extends JpaBaseDaoImpl< SvcModelRela, String, SvcModelRelaQo > implements SvcModelRelaDao {

    @Override
    public List< SvcModelRela > findByHql(String serviceBundleId) {
        return findByQueryString(" from SvcModelRela obj where obj.serviceBundleId = ?", serviceBundleId);
    }

    @Override
    public List< SvcModelRela > findByInBoundSvcId(String inBoundSvcId) {
        return findByQueryString(" from SvcModelRela obj where obj.inBoundSvcId = ?", inBoundSvcId);
    }

    @Override
    public SvcModelRela findByInBoundSvcIdAndServiceBoundId(String inBoundSvcId, String serviceBoundId) {
        return findBySingle(
                " from SvcModelRela obj where obj.inBoundSvcId = ? and obj.serviceBundleId = ?"
                , inBoundSvcId
                , serviceBoundId);
    }

    @Override
    public void deleteByInBoundSvcId(String inBoundSvcId) {

        if (StringUtils.isNotBlank(inBoundSvcId)) {
            this.executeUpdate(" delete from SvcModelRela as obj where obj.inBoundSvcId = ?", inBoundSvcId);
        }
    }

    @Override
    public void deleteByInBoundSvcIdAndServiceBoundId(String serviceBoundId, String inBoundSvcId) {

        if (StringUtils.isNotBlank(serviceBoundId) && StringUtils.isNotBlank(inBoundSvcId)) {
            this.executeUpdate(
                    " delete from SvcModelRela as obj where obj.inBoundSvcId = ? and obj.serviceBundleId = ?"
                    , inBoundSvcId
                    , serviceBoundId);
        }
    }

    @Override
    public void deleteSvcModelRelaByIds(String... ids) {
        //判空 删除
        if(ArrayUtils.isNotEmpty(ids)){
            for(String id:ids){
                if(StringUtils.isNotBlank(id)){
                    this.executeUpdate(" delete from SvcModelRela as obj where obj.serviceBundleId = ?", id);
                }
            }
        }
    }
}
