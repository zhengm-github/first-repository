package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 请求报文映射配置属性 QO
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:25:20 CST 2020
   */
public class DataMapPropertyDefRelaQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6398268630170016512L;

}
