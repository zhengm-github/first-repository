package com.sunyard.dxp.utils;

import java.io.*;
import java.util.*;

import com.sunyard.dxp.enums.EncoderEnum;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.*;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.dom4j.io.SAXValidator;
import org.dom4j.util.XMLErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

/**
 * XML操作基础类
 */
public class XmlUtil {
    private static final Log loger = LogFactory.getLog("iccs");
    private Document doc = null;
    private Element root = null;
    private OutputFormat fmt = OutputFormat.createCompactFormat();
    private OutputFormat oneLine = OutputFormat.createPrettyPrint();

    public final static int FROM_ROOT = 0;
    public final static int FROM_BUFF = 1;
    public final static int FROM_FILE = 2;
    public final static int FROM_ENCODE = 3;

    public static XmlUtil Create(int fromType, String tmpStr) throws Exception {
        try {
            return new XmlUtil(fromType, tmpStr);
        } catch (Exception e) {
            throw new Exception("创建XmlUtil对象失败！！", e);
            //loger.error("create XmlUtil error!fromType=[" + fromType + "]" + e);
            //return null;
        }
    }

    public XmlUtil setNodeContent(String xpath, String value) {
        loger.debug("set:[" + xpath + "]val=[" + value + "]");
        Node node = doc.selectSingleNode(xpath);
        if (node == null) {
            DocumentHelper.makeElement(doc, xpath);
        }
        if (value != null) {
            // 解决多个空格只显示一个问题
            doc.selectSingleNode(xpath).setText(value);
        }
        return this;
    }

    public XmlUtil setNodeContentTrim(String xpath, String value) {
        loger.debug("set:[" + xpath + "]val=[" + value + "]");
        Node node = doc.selectSingleNode(xpath);
        if (node == null) {
            DocumentHelper.makeElement(doc, xpath);
        }
        if (value != null) {
            // 解决多个空格只显示一个问题
            doc.selectSingleNode(xpath).setText(value.trim());
        }
        return this;
    }

    /**
     * 增加结点 和属性序号
     *
     * @param xpath
     * @param value
     * @return
     */
    public Element addLoopNode(String xpath, String value, int index, boolean haveIndex) {
        loger.debug("set:[" + xpath + "]val=[" + value + "]attr=[ID=" + index + "]");
        String parentPath = xpath.substring(0, xpath.lastIndexOf("/"));
        Node parentNode = doc.selectSingleNode(parentPath);
        if (parentNode == null) {
            DocumentHelper.makeElement(doc, parentPath);
        }
        parentNode = doc.selectSingleNode(parentPath);
        Element e = ((Element) parentNode).addElement(xpath.substring(xpath.lastIndexOf("/") + 1));
        if (haveIndex) {
            e = e.addAttribute("ID", String.valueOf(index));
        }
        e.setText(value.trim());  // 添加循环序号
        return e;
    }

    /**
     * 循环域属性塞值
     *
     * @param xpath
     * @param value
     * @return
     */
    public void addLoopEleNode(String xpath, String value, String loopXpath, Element loopEle) {
        loger.debug("set:[" + xpath + "]val=[" + value + "]");
        String[] eles = xpath.replaceAll(loopXpath + "/", "").split("/");
        for (String str : eles) {

            //判断上一层是否存在
            if (loopEle.element(str) == null) {
                loopEle = loopEle.addElement(str);
            } else {
                loopEle = loopEle.element(str);
            }
        }
        if (Constant.AMT_LIST.contains(loopEle.getName()) || loopEle.getName().endsWith("Amt")) {
            loopEle.addAttribute("Ccy", "CNY").setText(value);
        } else {
            loopEle.setText(value);
        }
    }

    public String getNodeContent(String xpath) {
        String str = null;
        str = doc.selectSingleNode(xpath) != null ? doc.selectSingleNode(xpath).getText() : "";
        loger.debug("get:[" + xpath + "]str=[" + str + "]");
        return str;
    }

    public String getNodeContentTrim(String xpath) {
        String str = null;
        str = doc.selectSingleNode(xpath) != null ? doc.selectSingleNode(xpath).getText() : "";
        loger.debug("get:[" + xpath + "]str=[" + str + "]");
        return str == null ? "" : str.trim();
    }

    public String getNodeContentNotNUll(String xpath) {
        String str = null;
        str = doc.selectSingleNode(xpath) != null ? doc.selectSingleNode(xpath).getText() : "";
        loger.debug("get:[" + xpath + "]str=[" + str + "]");
        return str == null ? "" : str.trim();
    }

    public XmlUtil setNodesContent(String xpath, String value) {
        List nodes = doc.selectNodes(xpath);
        Iterator iter = nodes.iterator();
        while (iter.hasNext())
            ((Element) iter.next()).setText(value);
        return this;
    }

    public String[] getNodesContent(String xpath) {
        int i = 0;
        List nodes = doc.selectNodes(xpath);
        String[] values = new String[ nodes.size() ];
        Iterator iter = nodes.iterator();
        while (iter.hasNext()) {
            values[ i++ ] = ((Node) iter.next()).getText();
        }
        return values;
    }

    public XmlUtil replaceNode(String oldXPath, XmlUtil newDoc, String newXPath) {
        Element oldNode = (Element) (doc.selectNodes(oldXPath).get(0));
        Element newNode = (Element) (newDoc.getDocument().selectNodes(newXPath).get(0));
        oldNode.setContent(newNode.content());
        return this;
    }

    public XmlUtil exchgNodeContent(String xpathA, String xpathB) {
        String tmp = getNodeContent(xpathA);
        setNodeContent(xpathA, getNodeContent(xpathB));
        setNodeContent(xpathB, tmp);
        return this;
    }

    public static XmlUtil copy(XmlUtil doc) throws Exception {
        String root = doc.getDocument().getRootElement().getName();
        XmlUtil tmp = XmlUtil.Create(XmlUtil.FROM_ROOT, root);
        if (tmp == null)
            return null;
        String xpath = "//" + root;
        tmp.replaceNode(xpath, doc, xpath);

        return tmp;
    }

    public XmlUtil setFormat(String encoding, boolean pretty) {
        if (pretty) {
            fmt = OutputFormat.createPrettyPrint();
            fmt.setIndent("    ");
            fmt.setNewlines(true);
        }
        fmt.setNewLineAfterDeclaration(false);
        fmt.setEncoding(encoding);

        return this;
    }

    public int checkValid(String nodesXPath, String attrName) {
        List nodes = doc.selectNodes(nodesXPath + "[@" + attrName + "]");
        Iterator iter = nodes.iterator();
        Element e = null;
        String checkAttr = null;
        String checkValue = null;
        int length = 0;
        int checkLength = 0;
        while (iter.hasNext()) {
            e = ((Element) iter.next());
            checkValue = getNodeContent("//" + e.getText());
            checkAttr = e.attributeValue(attrName);
            length = Integer.parseInt(checkAttr.substring(2));
            checkLength = checkValue.length();
            if (checkAttr.charAt(0) == 'O') {
                if (checkLength == 0)
                    continue;
            } else if (checkAttr.charAt(0) != 'M')
                continue;
            if (checkLength > 0) {
                switch (checkAttr.charAt(1)) {
                    case '=': //必需等于length
                        if (checkLength == length) continue;
                        else break;
                    case '-': //必需小于length
                        if (length > checkLength) continue;
                        else break;
                    case '+': //必需大于length
                        if (checkLength > length) continue;
                        else break;
                }
            }
            loger.error(e.getText() + "元素的值=[" + checkValue + "]不合法!");
            return -1;
        }
        return 0;
    }

    public void changeAmtVal(String amtNodesXPath) {
        List nodes = doc.selectNodes(amtNodesXPath);
        Iterator iter = nodes.iterator();
        String checkValue = null;
        String xpath = null;
        int tmp = 0;
        while (iter.hasNext()) {
            loger.info("处理金额类型数据...");
            xpath = "//BODY/" + ((Element) iter.next()).getText();
            checkValue = getNodeContent(xpath);
            if ((tmp = checkValue.indexOf('.')) != -1)
                setNodeContent(xpath, checkValue.substring(0, tmp));
            loger.info("原值:[" + checkValue + "]新值:[" + getNodeContent(xpath) + "]");
        }
    }

    /**
     * 转储成字符串(UNICODE编码)
     */
    public String toString( ) {
        ByteArrayOutputStream str = new ByteArrayOutputStream();
        try {
            fmt.setEncoding("UTF-8");
            fmt.setTrimText(false);
            fmt.setNewlines(true);
            //fmt.setIndent(true);
            XMLWriter writer = new XMLWriter(str, fmt);
            writer.write(doc);
            writer.close();
        } catch (IOException e) {
            return null;
        }
        return str.toString();
    }

    /**
     * 写出设置编码
     *
     * @param encode
     * @return
     */
    public String dumpToBuff(String encode) {
        ByteArrayOutputStream str = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(str);
        try {
            fmt.setEncoding(encode);
            fmt.setTrimText(false);
            XMLWriter writer = new XMLWriter(pw, fmt);
            writer.write(doc);
            writer.close();
        } catch (IOException e) {
            loger.error("XmlUtil dump to buff error!" + e);
            return null;
        }
        return str.toString().replaceAll("\\\\","");
    }

    public int dumpToFile(String fname) {
        try {
            XMLWriter writer = new XMLWriter(new FileWriter(fname), fmt);
            writer.write(doc);
            writer.close();
        } catch (IOException e) {
            loger.error("XmlUtil dump to " + fname + " error!" + e);
            return -1;
        }
        return 0;
    }

    public XmlUtil(int fromType, String tmpStr) throws DocumentException {
        switch (fromType) {
            case FROM_BUFF:
                doc = DocumentHelper.parseText(tmpStr);
                break;
            case FROM_FILE:
                SAXReader reader = new SAXReader();
                reader.setIgnoreComments(true);
                doc = reader.read(new File(tmpStr));
                break;
            case FROM_ROOT:
                doc = DocumentHelper.createDocument();
                root = DocumentHelper.createElement(tmpStr);
                doc.setRootElement(root);
                //doc.addElement(tmpStr);
                break;
            case FROM_ENCODE:
                doc = new DocumentFactory().createDocument(tmpStr);
                break;
        }
    }

    public XmlUtil addElement(String path, String addEle, List l) throws Exception {
        loger.debug(doc.getName());
        Element e = (Element) this.doc.selectNodes(path).get(0);
        Element add = e.addElement(addEle);
        add.setContent(l);
        return this;
    }

    public XmlUtil getNodes(XmlUtil doc, String path) throws Exception {
        XmlUtil tmp = null;
        List l = null;
        Element node = null;
        l = doc.getDocument().selectNodes(path);
        int size = l.size();
        if ((l == null || size == 0)) {
            return null;
        }
        this.doc = DocumentHelper.createDocument();
        for (int i = 0; i < size; i++) {
            node = (Element) l.get(i);
            //node.
            //this.doc.add(node);
        }
        //tmp = new XmlUtil();
        //tmp = node == null ? null : XmlUtil.Create(XmlUtil.FROM_ROOT, node.getName());
        //if (tmp == null)
        //	return null;
        //tmp.replaceNode(path,doc,path);
        return tmp;
    }

    /**
     * 使用xsd文件检查XML
     *
     * @param xmlDocument
     * @param xsdFileName
     * @return
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws DocumentException
     */
    public static String validateXMLByXSD(Document xmlDocument, String xsdFileName) throws SAXException, ParserConfigurationException, DocumentException {
        // 创建默认的XML错误处理器
        XMLErrorHandler errorHandler = new XMLErrorHandler();

        // 获取基于 SAX 的解析器的实例
        SAXParserFactory factory = SAXParserFactory.newInstance();
        // 解析器在解析时验证 XML 内容。
        factory.setValidating(true);
        // 指定由此代码生成的解析器将提供对 XML 名称空间的支持。
        factory.setNamespaceAware(true);
        // 使用当前配置的工厂参数创建 SAXParser 的一个新实例。
        SAXParser parser = factory.newSAXParser();
        // 获取要校验xml文档实例
        // 设置 XMLReader 的基础实现中的特定属性。核心功能和属性列表可以在 [url]http://sax.sourceforge.net/?selected=get-set[/url] 中找到。
        parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
        parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", xsdFileName);

        XMLReader reader = parser.getXMLReader();
        // 创建一个SAXValidator校验工具，并设置校验工具的属性
        SAXValidator validator = new SAXValidator(reader);
        // 设置校验工具的错误处理器，当发生错误时，可以从处理器对象中得到错误信息。
        validator.setErrorHandler(errorHandler);

        // 校验
        validator.validate(xmlDocument);
        // 如果错误信息不为空，说明校验失败，打印错误信息
        if (errorHandler.getErrors().hasContent()) {
            return errorHandler.getErrors().asXML();
        }
        return null;
    }

    public Document getDocument( ) {
        return this.doc;
    }

    public Element getElementRoot( ) {
        return this.root;
    }

    /**
     * 循环读取某个节点下所有属性的值
     *
     * @param path
     * @return List<String [ ]>
     */
    public List< Map< String, String > > getXmlObj(String path) {
        List< Map< String, String > > list = new ArrayList< Map< String, String > >();
        List< Node > nodeList = doc.selectNodes(path);  // 获取
        Map< String, String > temp = null;
        for (int i = 0; i < nodeList.size(); i++) {
            Element ele = (Element) nodeList.get(i);
            List< Element > eleList = ele.elements();
            temp = new HashMap< String, String >();
            for (int j = 0; j < eleList.size(); j++) {
                Element e = eleList.get(j);
                temp.put(e.getName(), e.getTextTrim());
            }
            list.add(temp);
        }
        return list;
    }

    /**
     * @param befPath
     * @param n
     * @param aftPath
     * @return
     */
    public List< Map< String, String > > getXmlObj2(String befPath, int n, String aftPath) {
        List< Map< String, String > > list = new ArrayList< Map< String, String > >();
        List< Node > nodeList = doc.selectNodes(befPath);  // 获取
        Element e = (Element) nodeList.get(n);  // 获取第n个父元素
        List< Element > es = e.elements(aftPath);
        Map< String, String > temp = null;
        for (Element x : es) {
            List< Element > eleList = x.elements();
            temp = new HashMap< String, String >();
            for (int j = 0; j < eleList.size(); j++) {
                Element a = eleList.get(j);
                temp.put(a.getName(), a.getTextTrim());
            }
            list.add(temp);
        }
        return list;
    }

    /**
     * @param str    未格式化的xml串
     * @param encode 编码
     * @return
     */
    public static String formatxml(String str, String encode) {
        Document doc = null;
        SAXReader reader = new SAXReader();

        //注释：创建一个串的字符输入流
        StringReader in = new StringReader(str);
        try {
            doc = reader.read(in);
        } catch (DocumentException e) {
            e.printStackTrace();
        }

        //注释：创建输出格式
        OutputFormat formater = OutputFormat.createPrettyPrint();

        formater.setIndent("    ");
        formater.setNewlines(true);
        formater.setNewLineAfterDeclaration(false);
        formater.setEncoding(encode);

        //注释：创建输出(目标)
        StringWriter out = new StringWriter();

        //注释：创建输出流
        XMLWriter writer = new XMLWriter(out, formater);

        //注释：输出格式化的串到目标中，执行后。格式化后的串保存在out中。
        try {
            writer.write(doc);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //注释：返回我们格式化后的结果
        return out.toString();
    }

    /**
     * 递归遍历叶子节点
     *
     * @param element
     * @param reMap
     * @return
     */
    public static void getElementList(Element element, Map< String, String > reMap) {
        List elements = element.elements();
        if (elements.size() == 0) {
            //没有子元素
            String xpath = element.getPath();
            String value = element.getTextTrim();
            reMap.put(xpath, value);
        } else {
            //有子元素
            Iterator it = elements.iterator();
            while (it.hasNext()) {
                Element elem = (Element) it.next();
                //递归遍历
                getElementList(elem, reMap);

            }
        }
    }

    /**
     * 递归遍历叶子节点, 根据valueMap 给每个子节点赋值
     *
     * @param element
     * @param valueMap
     * @return
     */
    public static void setElementList(Element element, Map< String, String > valueMap) {
        List elements = element.elements();
        if (elements.size() == 0) {
            StringBuilder textBuff = new StringBuilder();
            String valueXpath = element.getTextTrim();
            //可能一个标签中有多个值(, 分割)
            if (valueXpath.contains(",")) {
                String[] valueXPathArr = valueXpath.split(",");
                for (String path : valueXPathArr) {
                    textBuff.append(valueMap.getOrDefault(path, "")); // // 如果map中找不到则赋值 空串
                }
            } else {
                textBuff.append(valueMap.getOrDefault(valueXpath, ""));
            }
            element.setText(textBuff.toString());
        } else {
            //有子元素
            Iterator it = elements.iterator();
            while (it.hasNext()) {
                Element elem = (Element) it.next();
                //递归遍历
                setElementList(elem, valueMap);
            }
        }
    }

    /**
     * 去除报文里面的命名空间
     *
     * @param message
     * @param field
     * @return
     */
    public static String removeNameSpace(String message, String field) {

        if (message.contains(field)) {
            String tail = message.substring(message.indexOf(">", message.indexOf(field)));
            message = message.substring(0, message.indexOf(field) + field.length() + 1) + tail;
        }
        return message;
    }

    /**
     * 去除报文中的签名域部分 {S: }\r\n
     *
     * @param message
     * @return
     */
    public static String removeSign(String message) {

        return message.replaceAll("\\{S:.+\\}\r\n", "");

    }

    public static void main(String[] args) throws Exception {

//        XmlUtil xmlUtil = XmlUtil.Create(XmlUtil.FROM_ROOT, "X");
//        Element e = (Element) xmlUtil.getDocument().selectSingleNode("//X");
//        xmlUtil.addLoopEleNode("/X/A/B", "111", "/X", e);
//        xmlUtil.addLoopEleNode("/X/A/C", "222", "/X", e);

        String x = "{S:qwrwrrweqwerewrq}\r\n hello";
        System.out.println(XmlUtil.removeSign(x));
    }
}
