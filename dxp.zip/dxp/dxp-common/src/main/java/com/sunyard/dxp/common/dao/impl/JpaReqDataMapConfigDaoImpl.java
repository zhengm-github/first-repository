package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.ReqDataMapConfigDao;
import com.sunyard.dxp.common.entity.ReqDataMapConfig;
import com.sunyard.dxp.common.qo.ReqDataMapConfigQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 请求报文映射配置 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:15:01 CST 2020
 */
@Repository
public class JpaReqDataMapConfigDaoImpl  extends JpaBaseDaoImpl<ReqDataMapConfig,String,ReqDataMapConfigQo> implements ReqDataMapConfigDao{

    @Override
    public List<ReqDataMapConfig> findReqConfigByInDataPropertyId(String dataPropertyId) {
        return this.find("Select obj from ReqDataMapConfig as obj where obj.inDataPropertyDef.dataPropertyId = ?", dataPropertyId);
    }

    @Override
    public void deleteByPropertyId(String propertyId) {
        this.executeUpdate("delete from  ReqDataMapConfig as obj where obj.inDataPropertyDef.dataPropertyId =?",propertyId);
    }
}
