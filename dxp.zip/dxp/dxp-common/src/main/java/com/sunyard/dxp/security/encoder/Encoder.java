package com.sunyard.dxp.security.encoder;

public interface Encoder {
    String encode(String content);

}
