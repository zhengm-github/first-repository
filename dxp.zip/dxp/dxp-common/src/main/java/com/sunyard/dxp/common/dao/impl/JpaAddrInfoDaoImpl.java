package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.AddrInfoDao;
import com.sunyard.dxp.common.entity.AddrInfo;
import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.frameworkset.util.DateUtil;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * 地址信息管理 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Thu Jun 11 16:10:14 CST 2020
 */
@Repository
public class JpaAddrInfoDaoImpl  extends JpaBaseDaoImpl< AddrInfo,String, AddrInfoQo > implements AddrInfoDao {

    @Override
    public List< AddrInfo > findByDirectAndType(String sendDirect, String busiType) {

        return find(getMainQuery()
                + " where obj.sendDirect = ? and obj.busiType = ? and obj.status = '1' order by obj.callTime ASC", sendDirect, busiType);
    }
}
