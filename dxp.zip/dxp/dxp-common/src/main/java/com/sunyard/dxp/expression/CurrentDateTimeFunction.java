package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author Thud
 * @date 2020/1/3 14:55
 */
@FunctionLibrary( code = "currentDateTime", name = "生成当前日期时间(pattern)", expression = "(currentDateTime\\()([A-Za-z\\-\\:]+)(\\))", exp = "currentDateTime(yyyy-MM-ddTHH:mm:ss)" )
@Component
public class CurrentDateTimeFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        StringBuilder stringBuilder = new StringBuilder();

        // 默认格式
        if (StringUtils.isBlank(params)) {
            return stringBuilder.append(DateFormatUtils.format(new Date(), "yyyy-MM-dd"))
                    .append("T").append(DateFormatUtils.format(new Date(), "HH:mm:ss")).toString();
        }
        // 判断参数位数
        if (params.length() < 14) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        if (params.contains("T")) {
            String[] paramArr = params.split("T");
            // 必须有两个参数
            if (ArrayUtils.isEmpty(paramArr) || paramArr.length < 2) {
                //表达式参数不准确
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
            }
            stringBuilder.append(DateFormatUtils.format(new Date(), paramArr[ 0 ]))
                    .append("T")
                    .append(DateFormatUtils.format(new Date(), paramArr[ 1 ]));
        } else {

            stringBuilder.append(DateFormatUtils.format(new Date(), params));
        }

        return stringBuilder.toString();
    }
}
