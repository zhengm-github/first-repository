package com.sunyard.dxp.utils;

import com.sunyard.dxp.message.manager.OutMessageManager;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.util.Iterator;
import java.util.Properties;

/**
 * 自定义 prop工具
 *
 * @author zhengm
 */
public class PropUtil {

    private static final Logger log = LoggerFactory.getLogger(PropUtil.class);

    /**
     * 获取 properties 对象
     * @param fileName
     * @param encode
     * @return
     * @throws Exception
     */
    public static Properties getProperties(String fileName, String encode) throws Exception {

        InputStreamReader isr = null ;
        if(fileName.contains("classpath")){
            ResourceLoader loader = new DefaultResourceLoader();
            Resource resource = loader.getResource( fileName);
            isr = new InputStreamReader(resource.getInputStream(), encode);
        }else{
            isr = new InputStreamReader(
                    new FileInputStream(ResourceUtils.getFile(fileName)),encode) ;
        }

        Properties p = new Properties();
        p.load(isr);
        isr.close();
        return p;
    }

    /**
     * 获取环境中指定文件 指定key的值
     *
     * @param fileName
     * @param key
     * @return
     */
    public static String getValue(String fileName, String key) throws Exception {

        Properties p = getProperties(fileName, "UTF-8");
        if (p.containsKey(key)) {
            return p.get(key).toString();
        }
        return key;
    }

    /**
     * 获取环境中指定文件 模糊匹配 key
     *
     * @param fileName
     * @param key
     * @return
     */
    public static String getValueLike(String fileName, String key) throws Exception {

        Properties p = getProperties(fileName, "UTF-8");
        // 先精确匹配
        if(p.containsKey(key)){
            return p.getProperty(key) ;
        }
        Iterator<String> it = p.stringPropertyNames().iterator();
        String itKey = "" ;
        while (it.hasNext()) {
            itKey = it.next() ;
            if(key.contains(itKey)){
                return p.getProperty(itKey) ;
            }
        }
        return key;
    }



}
