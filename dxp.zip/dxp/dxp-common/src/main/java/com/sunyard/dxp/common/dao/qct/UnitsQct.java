package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.UnitsQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 单位 Qct转化类
 *
 * Author: Created by code generator
 * Date: Wed Dec 25 19:35:40 CST 2019
 */
public class UnitsQct extends QueryConditionTransfer<UnitsQo> {

    @Override
    public void transNameQuery(UnitsQo qo, QueryCondition condition) {
        if(StringUtils.isNotEmpty(qo.getKeyword())){
            condition.add(" And (obj.code like :code", "code", qo.getBlurKeyword());
            condition.add(" OR obj.name like :name)", "name", qo.getBlurKeyword());
        }
    }

    @Override
    public void transQuery(UnitsQo qo, QueryCondition condition) {
        //
    }

}
