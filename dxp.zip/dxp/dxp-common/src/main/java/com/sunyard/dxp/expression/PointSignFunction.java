package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 通过点分割各个属性值
 */
@FunctionLibrary(code = "pointSign",name = "拼接（用 . 分割） ",expression = "(.*)(pointSign)(.*)",type = "all" ,isRelation = true,exp = "pointSign")
@Component
public class PointSignFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        return params.replaceAll("pointSign",".");
    }
}
