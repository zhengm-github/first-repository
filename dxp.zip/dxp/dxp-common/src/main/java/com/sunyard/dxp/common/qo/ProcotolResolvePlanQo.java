package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 协议解析规划 QO
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:25 CST 2020
   */
public class ProcotolResolvePlanQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8046321935016538412L;

    /** 名称*/
    private String name ;

    /** 备注*/
    private String memo ;

    /** 接入接口Id*/
    private String inBoundSvcId ;

    /** 接出接口Id*/
    private String outBoundSvcId ;

    /** 数据类型*/
    private String dataKind ;

    public String getInBoundSvcId( ) {
        return inBoundSvcId;
    }

    public void setInBoundSvcId(String inBoundSvcId) {
        this.inBoundSvcId = inBoundSvcId;
    }

    public String getOutBoundSvcId( ) {
        return outBoundSvcId;
    }

    public void setOutBoundSvcId(String outBoundSvcId) {
        this.outBoundSvcId = outBoundSvcId;
    }

    public String getDataKind( ) {
        return dataKind;
    }

    public void setDataKind(String dataKind) {
        this.dataKind = dataKind;
    }

    public String getName( ) {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo( ) {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
