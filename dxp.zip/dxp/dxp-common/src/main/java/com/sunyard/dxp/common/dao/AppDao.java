package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.App;
import com.sunyard.dxp.common.qo.AppQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

/**
 * 应用系统 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:23 CST 2019
 */
public interface AppDao extends BaseDao< App, String, AppQo > {
    /**
     * 根据应用编号查询应用系统
     *
     * @param code
     * @return
     */
    App findByCode(String code);

}
