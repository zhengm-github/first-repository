package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.InBoundSvcQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 接入服务接口 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:54:51 CST 2019
 */
public class InBoundSvcQct extends QueryConditionTransfer< InBoundSvcQo > {

    @Override
    public void transNameQuery(InBoundSvcQo qo, QueryCondition condition) {
        if (qo != null) {
            /*关键字模糊查询, code 不支持同时两种匹配*/
            if (StringUtils.isNoneBlank(qo.getCode())) {
                condition.add(" and obj.code =:code", "code", qo.getCode());
                if (StringUtils.isNotBlank(qo.getKeyword())) {
                    condition.add(" and ( obj.name like :name", "name", qo.getBlurKeyword());
                    condition.add(" or obj.url like :url ) ", "url", qo.getTailBlurKeyword());
                }
            }else{
                if (StringUtils.isNotBlank(qo.getKeyword())) {
                    condition.add(" and ( obj.code like :code", "code", qo.getTailBlurKeyword());
                    condition.add(" or obj.name like :name", "name", qo.getBlurKeyword());
                    condition.add(" or obj.url like :url ) ", "url", qo.getTailBlurKeyword());
                }
            }
            if (StringUtils.isNoneBlank(qo.getKind())) {
                condition.add(" and obj.kind =:kind", "kind", qo.getKind());
            }
            if (StringUtils.isNoneBlank(qo.getStatus())) {
                condition.add(" and obj.status =:status", "status", qo.getStatus());
            }
            if (StringUtils.isNoneBlank(qo.getInBoundSvcType())) {
                condition.add(" and obj.inBoundSvcType =:inBoundSvcType", "inBoundSvcType", qo.getInBoundSvcType());
            }


            if (StringUtils.isNotEmpty(qo.getInBoundSvcIds())) {
                condition.append("And obj.inBoundSvcId in (");
                String[] ids = qo.getInBoundSvcIds().split(",");
                for (int i = 0; i < ids.length; ++i) {
                    condition.add(" :inBoundSvcId" + i + ", ", "inBoundSvcId" + i, ids[ i ]);
                }
                condition.append(" 'none' ) )");
            }
        }
    }
    @Override
    public void transQuery(InBoundSvcQo qo, QueryCondition condition) {
        //
    }
}
