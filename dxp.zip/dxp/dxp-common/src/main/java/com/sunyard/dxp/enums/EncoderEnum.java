package com.sunyard.dxp.enums;

import com.sunyard.dxp.security.encoder.Encoder;
import com.sunyard.dxp.security.encoder.impl.GB18030Encoder;
import com.sunyard.dxp.security.encoder.impl.GBKEncoder;
import com.sunyard.dxp.security.encoder.impl.ISO88591Encoder;
import com.sunyard.dxp.security.encoder.impl.UTF8Encoder;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * @author Thud
 * @date 2019/12/25 15:50
 */
public enum EncoderEnum implements EnumAware {
    GBK("GBK","GBK",new GBKEncoder()),
    UTF8("UTF-8","UTF8",new UTF8Encoder()),
    ISO88591("ISO-8859-1","ISO-8859-1编码",new ISO88591Encoder()),
    GB18030("GB18030","GB18030",new GB18030Encoder()),
    ;

    private final String code;
    private final String name;
    private final Encoder encoder;

    EncoderEnum(String code, String name, Encoder encoder) {
        this.code = code;
        this.name = name;
        this.encoder = encoder;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return this.getName();
    }
    public static Encoder getEncoderStrategy (String code) {
        for (EncoderEnum handler : EncoderEnum.values ()) {
            if (handler.code.equals (code)) {
                return handler.encoder;
            }
        }
        return null;
    }
}
