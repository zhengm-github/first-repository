package com.sunyard.dxp.security.encrypt.impl;

import com.sunyard.dxp.security.encrypt.Encryption;
import com.sunyard.dxp.utils.EncryptionLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;

/**
 * RSA公钥加密
 */
@EncryptionLibrary(code = "RSAPublicEncryption" , name = "RSA公钥加密")
public class RSAPublicEncryption implements Encryption {
    private static final Logger LOGGER = LoggerFactory.getLogger( RSAPublicEncryption.class );

    @Override
    public String encrypt(String content, String key) {
        byte[] bytesContent = content.getBytes();
        byte[] bytesKey = Base64.decodeBase64(key);
        try {
            //实例化密钥工厂
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            //初始化公钥
            //密钥材料转换
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(bytesKey);
            //产生公钥
            PublicKey pubKey = keyFactory.generatePublic(x509KeySpec);

            //数据加密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, pubKey);
            return Base64.encodeBase64String(cipher.doFinal(bytesContent));
        }catch (Exception e){
            LOGGER.error("RSA公钥加密失败");
            throw new FapException("","RSA公钥加密失败");
        }
    }
}

