package com.sunyard.dxp.common.client;

import com.alibaba.fastjson.JSON;
import com.sunyard.dxp.common.client.channel.Channel;
import com.sunyard.dxp.common.entity.DxpRequest;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.handler.DxpClientDataHandler;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.dxp.utils.SchemaUtil;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2016/12/15.
 */
@Component
public class DxpClient {

    private static Logger logger = LoggerFactory.getLogger(DxpClient.class);

    private static String strstmRequestTime = "gmtRequest";
    //信道
    private Channel channel;
    //前置后置
    private DxpClientDataHandler handler;

    /**
     * 接出接口调用发送
     *
     * @param url
     * @param params
     * @return
     */
    public Map< String, Object > send(String url, Map< String, Object > params, boolean send2Center,String configPath) {
        Map< String, Object > result = new HashMap<>();
        Map< String, Object > response = new HashMap<>();
        try {
            if (null == channel) {
                logger.error("未获取到URL冒号前部分或是冒号前部分(http/https不完整或是有空格)");
                throw new DxpCommonException(DxpCommonEnums.CHANNEL_ERROR_MSG_002);
            }

            response.put(strstmRequestTime, new Date());
            if(send2Center){
                // 发送给中心之前先 检查xsd
                logger.info("对发送报文进行本地schema校验....");
                boolean isPass = SchemaUtil.checkXmlByXsd(params.get("package").toString(),configPath) ;
                if(!isPass){
                    logger.info("本地校验不过");
                    throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL);
                }
            }
            result = channel.send(url, params, send2Center);
            //判断请求结果 获取请求的状态码(基本类型的布尔值默认值为false此处只设置了true)
            //判断请求结果 获取请求的状态码(基本类型的布尔值默认值为false此处只设置了true)
            if (result.size() > 0) {
                if ((Integer) result.get("statusCode") == 200) {
                    response.put(MsgKeys.REQ_STATUS, true);
                } else {
                    logger.info("HTTP 接收响应状态为:statusCode = [{}]", result.get("statusCode")) ;
                    logger.error("请求中心状态错误开始记录错误信息,{}", DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL.getName());
                    throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL);
                }
            }
            return response;
        } catch (Exception e) {
            logger.error("DxpClient send error: " + e.getMessage());
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL);
        }
    }

    /**
     * 接入接口调用
     *
     * @param url
     * @param params
     * @param dxpRequest
     * @param responseMap
     * @return
     */
    public Map< String, Object > send(String url, Map< String, String > params, DxpRequest dxpRequest, Map< String, Object > responseMap, String configPath) {
        Map< String, Object > result = null;
        Map< String, Object > response = responseMap;
        Map<String, String> extraParams = dxpRequest.getExtraParams();
        String reqPackMessage = "" ;  // 原报文内容，避免一次通讯失败修改了
        try {
            if (null == channel) {
                logger.error("未获取到URL冒号前部分或是冒号前部分未实现");
                throw new DxpCommonException(DxpCommonEnums.CHANNEL_ERROR_MSG_002);
            }
            reqPackMessage = params.get("package") ;
            //handler 前置 后置处理
            if (handler != null) {
                //前置执行
                boolean send2Center = false;
                if (dxpRequest.getInBoundSvc().getCode().startsWith("inS.cbsp")) { // 表示发送至中心
                    send2Center = true;
                }
                logger.info("执行报文前置处理...");
                if(send2Center) {
                    // 发送到中心需要前置处理 , 例 312 加压处理
                    String packageMessage = handler.beforeHandle(params, extraParams).toString();

                    // 发送给中心之前先 检查xsd
                    boolean isPass = SchemaUtil.checkXmlByXsd(packageMessage,configPath) ;
                    if(!isPass){
                        logger.info("本地校验不过");
                        throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL);
                    }

                    params.put("package", packageMessage) ;
                }
                response.put(strstmRequestTime, new Date());
                result = channel.send(url, params, send2Center);
                //后置执行
                logger.info("执行报文后置处理......");
                // 判断是否需要回执( 只有发到中心才会有后置处理)
                if(send2Center){

                    // 发送到中心需要后置处理 , 例 实时http响应
                    handler.afterHandle(result, extraParams);
                }
            } else {
                response.put(strstmRequestTime, new Date());
                boolean send2Center = false;
                if (dxpRequest.getInBoundSvc().getCode().startsWith("inS.cbsp")) { // 表示发送至中心
                    send2Center = true;
                }
                result = channel.send(url, params, send2Center);
            }
            //判断请求结果 获取请求的状态码(基本类型的布尔值默认值为false此处只设置了true)
            if (result.size() > 0) {
                if ((Integer) result.get("statusCode") == 200) {
                    response.put(MsgKeys.REQ_STATUS, true);
                } else {
                    params.put("package", reqPackMessage) ; // 避免前置处理做了修改
                    logger.info("HTTP 接收响应状态为:statusCode = [{}]", result.get("statusCode")) ;
                    logger.error("请求中心状态错误开始记录错误信息,{}", DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL.getName());
                    throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL);
                }
            }
            return response;
        } catch (Exception e) {
            params.put("package", reqPackMessage) ;// 避免前置处理做了修改
            responseMap.put(MsgKeys.ERROR_INFO, "请求外部失败，请检查配置");
            logger.error("请求外部失败，{}。报文内容：{} ",
                    DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL.getName() + e.getMessage(), JSON.toJSONString(params));
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_REQUEST_FAIL);
        }
    }

    public void setHandler(DxpClientDataHandler handler) {
        this.handler = handler;
    }


    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    public DxpClientDataHandler getHandler( ) {
        return handler;
    }


}
