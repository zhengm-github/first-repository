package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 起始标识函数库
 */
@FunctionLibrary(code = "startSign",name = "起始标识符",expression = "(startSign\\()(\\))" ,type = "String",exp = "startSign()")
@Component
public class StartSignFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        return "{H:";
    }
}
