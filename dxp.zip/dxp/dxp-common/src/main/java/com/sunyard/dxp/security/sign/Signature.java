package com.sunyard.dxp.security.sign;

public interface Signature {

     String sign(String src, String key);

}
