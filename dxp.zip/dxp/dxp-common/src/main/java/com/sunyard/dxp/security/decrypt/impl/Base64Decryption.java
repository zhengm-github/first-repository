package com.sunyard.dxp.security.decrypt.impl;

import com.sunyard.dxp.security.decrypt.Decryption;
import org.apache.commons.codec.binary.Base64;

/**
 * BASE64解密
 */
public class Base64Decryption implements Decryption {

    @Override
    public String decrypt(String content, String key) {
        return new String(Base64.decodeBase64(content+key));
    }
}
