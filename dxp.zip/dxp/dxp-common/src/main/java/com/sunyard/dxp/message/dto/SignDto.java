package com.sunyard.dxp.message.dto;

/**
 * 签名专用参数集(有可能加密)
 * @author zhengm
 */
public class SignDto {

    /**
     * 签名算法
     */
    private String signAlgol ;

    /**
     * 加密key
     */
    private String signPrivateKey ;

    public SignDto(String signAlgol, String signPrivateKey) {
        this.signAlgol = signAlgol;
        this.signPrivateKey = signPrivateKey;
    }

    public String getSignAlgol( ) {
        return signAlgol;
    }

    public void setSignAlgol(String signAlgol) {
        this.signAlgol = signAlgol;
    }

    public String getSignPrivateKey( ) {
        return signPrivateKey;
    }

    public void setSignPrivateKey(String signPrivateKey) {
        this.signPrivateKey = signPrivateKey;
    }
}
