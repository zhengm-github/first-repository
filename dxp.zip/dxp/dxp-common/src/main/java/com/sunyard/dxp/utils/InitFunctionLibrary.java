package com.sunyard.dxp.utils;

import com.sunyard.dxp.common.entity.ExpData;
import org.reflections.Reflections;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author Thud
 * @date 2020/2/24 15:36
 * 用来初始化函数库放入内存
 */
@Configuration
public class InitFunctionLibrary {

    @Bean
    public Map<String, ExpData> init() {
        Reflections f = new Reflections("com.sunyard.dxp.expression");
        Set<Class<?>> set = f.getTypesAnnotatedWith(FunctionLibrary.class);
        Map<String,ExpData> function = new HashMap<>();
        for (Class<?> c : set) {
            FunctionLibrary annotation = c.getAnnotation(FunctionLibrary.class);
            ExpData e = new ExpData();
            e.setExpName(annotation.name());
            e.setRelation(annotation.isRelation());
            e.setType(annotation.type());
            e.setExpression(annotation.expression());
            e.setExp(annotation.exp());
            e.setHasProperty(annotation.hasProperty());
            function.put(annotation.code(),e);
        }
        function.put("addSign",add());
        function.put("cutSign",cut());
        function.put("rideSign",ride());
        function.put("exceptSign",except());
        function.put("data()",data());
        function.put("oriReqData()",oriReqData());
        return function;
    }

    private ExpData add(){
        ExpData e = new ExpData();
        e.setExpression("(addSign)");
        e.setExpName("+(加法)");
        e.setExpCode("addSign");
        e.setExp("addSign");
        e.setRelation(true);
        e.setHasProperty(false);
        return e;
    }
    private ExpData cut(){
        ExpData e = new ExpData();
        e.setExpression("(cutSign)");
        e.setExpName("-(减法)");
        e.setExpCode("cutSign");
        e.setExp("cutSign");
        e.setRelation(true);
        e.setHasProperty(false);
        return e;
    }
    private ExpData ride(){
        ExpData e = new ExpData();
        e.setExpression("(rideSign)");
        e.setExpName("x(乘法)");
        e.setExpCode("rideSign");
        e.setExp("rideSign");
        e.setHasProperty(false);
        e.setRelation(true);
        return e;
    }
    private ExpData except(){
        ExpData e = new ExpData();
        e.setExpression("(exceptSign)");
        e.setExpName("/(除法)");
        e.setExpCode("exceptSign");
        e.setExp("exceptSign");
        e.setHasProperty(false);
        e.setRelation(true);
        return e;
    }

    private ExpData data(){
        ExpData e = new ExpData();
        e.setExpression("(data\\()([\\d\\s\\w\\{\\}\\:\\.\\，\\_\\-\\\\\\u4e00-\\u9fa5]+)(\\))");
        e.setExpName("常量方法");
        e.setExpCode("data()");
        e.setExp("data()");
        e.setHasProperty(false);
        e.setRelation(false);
        return e;
    }


    // 获取原请求交易对应的属性值
    private ExpData oriReqData(){
        ExpData e = new ExpData();
        e.setExpression("(oriReqData\\()(.+)(\\))");
        e.setExpName("取原请求报文方法(全路径)");
        e.setExpCode("oriReqData()");
        e.setExp("oriReqData()");
        e.setHasProperty(true);
        e.setRelation(false);
        return e;
    }
}
