package com.sunyard.dxp.common.client.factory;

import com.sunyard.dxp.common.client.DxpClient;
import com.sunyard.dxp.handler.DxpClientDataHandler;
import org.apache.commons.lang3.StringUtils;
import com.sunyard.frameworkset.log.LoggerFactory;
import com.sunyard.frameworkset.log.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by tangjiejie on 2018/3/1.
 */
@Component
public class ClientFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientFactory.class);
    private static Map<String, DxpClient> clientMap = new HashMap<>();

    @Value("${dxp.handler.classUrl:}")
    private String handlerClassUrl;

    @Autowired
    private ChannelFactory channelFactory;

    public DxpClient getClientByData(Map<String, String> clientData) {
        try {
            String handleClass = clientData.get("handleClass");
            DxpClient client = new DxpClient();
            if (StringUtils.isNotEmpty(handleClass)) {
                //具体前置类名根据单位编号+Handler
                String classUrl = handlerClassUrl + handleClass+"Handler";
                DxpClientDataHandler clientDataHandler;
                try{
                    //根据连接找到Handler类
                    clientDataHandler = (DxpClientDataHandler) Class.forName(classUrl).newInstance();
                }catch (Exception e){
                    //找不到对应Handler使用默认Handler
                    clientDataHandler = (DxpClientDataHandler) Class.forName(handlerClassUrl +"DefaultHandler").newInstance();
                }
                client.setHandler(clientDataHandler);
            }
            client.setChannel(channelFactory.getChannel(clientData.get("channel")));
            clientMap.put(handleClass, client);
            return client;
        } catch (Exception e) {
            LOGGER.error("ClientFactory getClient error:" + e.getMessage());
            return null;
        }
    }

}
