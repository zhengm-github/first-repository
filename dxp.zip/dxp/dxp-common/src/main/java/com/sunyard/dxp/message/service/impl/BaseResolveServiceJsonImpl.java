package com.sunyard.dxp.message.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.service.BaseResolveService;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description JSON报文解析
 * @Author zhangxin
 * @Date 2020/1/9 11:02
 * @Version 1.0
 */
@Service( "baseResolveServiceJson" )
public class BaseResolveServiceJsonImpl implements BaseResolveService {
    @Override
    public Map< String, Object > execute(List< ParamRule > rules, String message, String... resolveParam) {
        return JSON.parseObject(message);
    }

    @Override
    public Map< String, Object > mapExecute(List< ParamRule > rules, Map< String, Object > map, String... resolveParam) {
        Map< String, Object > jsonMap = new HashMap<>();
        if (map.isEmpty()) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_011);
        }
        String jsonMaps = JSONObject.toJSONString(map);
        jsonMap.put("package", jsonMaps);
        return jsonMap;
    }
}
