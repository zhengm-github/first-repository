package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * *
 * User: wuyongzhi
 * Date: 2017/7/11 10:21
 * version $Id: AccessKeyEnum.java, v 0.1 Exp $
 */
public enum RejectCodeEnums implements EnumAware {
    RJ01 ("RJ01","账号不存在"),
    RJ02 ("RJ02","账号、户名不符"),
    RJ03 ("RJ03","账户余额不足支付"),
    RJ04 ("RJ04","当日业务累计金额超过规定金额"),
    RJ05 ("RJ05","业务检查错"),
    RJ06 ("RJ06","指定协议不存在"),
    RJ07 ("RJ07","超过协议授权范围"),
    RJ08 ("RJ08","账户类型非法"),
    RJ09 ("RJ09","退票"),
    RJ10 ("RJ10","账户密码错误"),
    RJ11 ("RJ11","账户状态异常"),
    RJ12 ("RJ12","核验身份错误"),
    RJ13 ("RJ13","重复签约"),
    RJ19 ("RJ19","参与机构为非营业状态"),
    RJ20 ("RJ20","业务已撤销（冲正或止付）"),
    RJ29 ("RJ29","重复提示付款"),
    RJ35 ("RJ35","核数字签名错"),
    RJ41 ("RJ41","收款人名称不符"),
    RJ44 ("RJ44","金额不符"),
    RJ88 ("RJ88","已圈存"),
    RJ89 ("RJ89","圈存申请匹配不符"),
    RJ90 ("RJ90","其他"),
    RJ91 ("RJ91","CNAPS2-NPC检查发起业务错"),
    RJ92 ("RJ92","付款清算行检查错拒绝"),
    RJ93 ("RJ93","CNAPS2-NPC检查付款清算行回执错拒绝"),
    RJ94 ("RJ94","轧差额度不足拒绝"),
    RJ95 ("RJ95","收款清算行检查错拒绝"),
    RJ96 ("RJ96","CNAPS2-NPC检查收款清算行回执错拒绝"),
    RJ97 ("RJ97","接收参与机构检查错拒绝"),
    RJ98 ("RJ98","CNAPS2-NPC检查接收参与机构回执错"),
    RJ99 ("RJ98","日终自动退回"),
    ;



    private String code;

    private String name;

    RejectCodeEnums(String code, String name) {
        this.code = code;
        this.name = name;
    }
    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return null;
    }


    public static String getMapperNameByCode(String code) {
        for (RejectCodeEnums enums : RejectCodeEnums.values()) {
            if (enums.code.equals(code)) {
                return enums.name;
            }
        }
        return code;
    }
}
