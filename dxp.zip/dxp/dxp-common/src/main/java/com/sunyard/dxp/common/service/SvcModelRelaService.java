package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.SvcModelRela;
import com.sunyard.dxp.common.qo.SvcModelRelaQo;
import com.sunyard.frameworkset.core.service.BaseService;

import java.util.List;

/**
 * 接入服务模块关系 service 接口
 *
 * Author: Created by code generator
 * Date: Mon Dec 16 14:26:15 CST 2019
 */
public interface SvcModelRelaService extends BaseService< SvcModelRela, String, SvcModelRelaQo > {

    /**
     * 根据服务模块id查询
     * @param serviceBundleId
     * @return
     */
    List<SvcModelRela> findByHql(String serviceBundleId);

    /**
     * 根据接入接口id查询
     * @param inBoundSvcId
     * @return
     */
    List<SvcModelRela> findByInBoundSvcId(String inBoundSvcId) ;

    /**
     * 根据接入接口id和 serviceBoundId查询
     * @param inBoundSvcId
     * @param serviceBoundId
     * @return
     */
    SvcModelRela findByInBoundSvcIdAndServiceBoundId(String inBoundSvcId, String serviceBoundId) ;

    /**
     * 根据接入接口id删除
     * @param inBoundSvcIds
     */
    void deleteByInBoundSvcIds(String... inBoundSvcIds) ;

    /**
     * 根据接入接口id 和 ServiceBoundId删除
     * @param serviceBoundId
     * @param inBoundSvcId
     */
    void deleteByInBoundSvcIdAndServiceBoundId(String serviceBoundId, String inBoundSvcId) ;

    /**
     * 删除服务模块的
     * @param ids
     */
    void deleteSvcModelRelaByIds(String... ids);
}
