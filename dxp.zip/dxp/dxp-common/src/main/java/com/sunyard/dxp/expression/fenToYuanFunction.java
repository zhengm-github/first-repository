package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * 金额 分 转成 元
 */
@FunctionLibrary( code = "fenToYuan", name = "金额转换（分 --> 元)", expression = "(fenToYuan\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "fenToYuan()", hasProperty = true )
@Component
public class fenToYuanFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if(StringUtils.isBlank(params) || "".equals(params.trim())){
            return "0.00" ;
        }
        String afterMoney =
                new BigDecimal(params.trim()).divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_CEILING).toString();
        return afterMoney;

    }
}
