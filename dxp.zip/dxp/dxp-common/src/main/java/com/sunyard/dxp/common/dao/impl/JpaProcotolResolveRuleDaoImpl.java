package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.ProcotolResolveRuleDao;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.common.qo.ProcotolResolveRuleQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 协议解析规则 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:59 CST 2020
 */
@Repository
public class JpaProcotolResolveRuleDaoImpl  extends JpaBaseDaoImpl<ProcotolResolveRule,String,ProcotolResolveRuleQo> implements ProcotolResolveRuleDao{

    @Override
    public ProcotolResolveRule findByName(String name) {
        return findBySingle(getMainQuery() + " where obj.name = ?", name);
    }

    @Override
    public ProcotolResolveRule findByDetailName(String detailName) {
        return findBySingle(getMainQuery() + " where obj.detailName = ? ", detailName);
    }

    @Override
    public List<ProcotolResolveRule> findByPlanId(String planId) {
        return this.find("Select obj from ProcotolResolveRule as obj where obj.procotolResolvePlan.procotolResolvePlanId = ? order by obj.beginIndex", planId);
    }

    @Override
    public List<ProcotolResolveRule> findByParentId(String parentId) {
        return this.find("Select obj from ProcotolResolveRule as obj where obj.parent.procotolResolveRuleId = ?", parentId);
    }

    @Override
    public List<ProcotolResolveRule> findChildRule(String id){
        return this.find("Select obj from ProcotolResolveRule as obj where obj.parent.procotolResolveRuleId = ?", id);
    }

}
