package com.sunyard.dxp.message.utils;

import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @Description
 * <ul>
 * <li><b>createId</b> - 利用UUID生成唯一编号</li>
 * <li><b>isEmpty</b> - 判断字符串是否为空</li>
 * <li><b>isNotEmpty</b> - 判断字符串是否不为空</li>
 * <li><b>equals</b> - 判断两个字符串是否相等(null-safe)</li>
 * <li><b>startsWith</b> - 判断字符串是否以指定开头( null-safe)</li>
 * <li><b>endsWith</b> - 判断字符串是否以指定的结尾( null-safe)</li>
 * <li><b>upperCase</b> - 字符都转换为大写( null-safe)</li>
 * <li><b>lowerCase</b> - 字符串转换为小写( null-safe)</li>
 * <li><b>swapCase</b> - 大小写字符互转( null-safe)</li>
 * <li><b>capitalize</b> - 首字母转大写( null-safe)</li>
 * <li><b>uncapitalize</b> - 首字母转小写( null-safe)</li>
 * <li><b>countMatches</b> - 匹配计数( null-safe)</li>
 * <li><b>trim</b> - 去空( null-safe)</li>
 * <li><b>isAlpha</b> - 判断是否字符( null-safe)</li>
 * <li><b>isNumeric</b> - 判断是否数字( null-safe)</li>
 * <li><b>isWhitespace</b> - 判断是否空白( null-safe)</li>
 * <li><b>isAsciiPrintable</b> - 判断是否Ascii可见字符( null-safe)</li>
 * <li><b>defaultString</b> - 避免为null</li>
 * <li><b>reverse</b> - 反转字符串( null-safe)</li>
 * <li><b>reverseDelimited</b> - 分隔字符反转字符串( null-safe)</li>
 * </ul>
 * @Author zhangxin
 * @Date 2018/6/25 15:44
 * @Version 1.0
 */
public class StringUtils {

    private static final Logger log = LoggerFactory.getLogger(StringUtils.class);

    private StringUtils(){}

   /**
    * 使用UUID生成序号
    * @author zhangxin
    * @date 2018/8/2 16:59
    * @return java.lang.String
    */
    public static synchronized String createId(){
        String result = UUID.randomUUID().toString().replace("-","");
        int len = 32;
        if(result.length() > len){
            result = result.substring(0,31);
        }
        return result;
    }

    /**
     * 判断字符串为空
     * @author zhangxin
     * @date 2018/8/2 16:59
     * @param str 需校验的字符串
     * @return boolean 字符串为空返回true
     */
    public static boolean isEmpty(final String str){
        return org.springframework.util.StringUtils.isEmpty(str);
    }

    /**
     * 判断字符串不为空
     * @author zhangxin
     * @date 2018/8/2 17:00
     * @param str 被校验字符串
     * @return boolean
     */
    public  static boolean isNotEmpty(final String str){
        return !isEmpty(str);
    }

    /**
     * 判断两个字符串是否相等
     * @author zhangxin
     * @date 2018/8/2 17:00
     * @param str1
     * @param str2
     * @return boolean
     */
    public static boolean equals(final String str1, final String str2){
        return str1 == null ? str2 == null : str1.equals(str2);
    }

    /**
     * 判断字符串是否以指定开头
     * @author zhangxin
     * @date 2018/8/2 17:01
     * @param str
     * @param prefix
     * @return boolean
     */
    public static boolean startsWith(final String str, final String prefix){
        if(str == null || prefix == null){
            return str == null && prefix == null;
        }
        return str.startsWith(prefix);
    }

    /**
     * 判断字符串是否以指定的结尾
     * @author zhangxin
     * @date 2018/8/2 17:01
     * @param str
     * @param suffix
     * @return boolean
     */
    public static boolean endsWith(final String str, final String suffix){
        if (str == null || suffix == null) {
            return str == null && suffix == null;
        }
        return str.endsWith(suffix);
    }

    /**
     * 使用默认语言环境的规则将此 String 中的所有字符都转换为大写
     * @author zhangxin
     * @date 2018/8/2 17:01
     * @param str
     * @return java.lang.String
     */
    public static String upperCase(final String str) {
        if (str == null) {
            return null;
        }
        return str.toUpperCase();
    }

    /**
     * 使用给定 Locale 的规则将此 String 中的所有字符都转换为大写
     * @author zhangxin
     * @date 2018/8/2 17:02
     * @param str
     * @param locale
     * @return java.lang.String
     */
    public static String upperCase(final String str, final Locale locale) {
        if (str == null) {
            return null;
        }
        return str.toUpperCase(locale);
    }

    /**
     * 使用默认语言环境的规则将此 String 中的所有字符都转换为小写
     * @author zhangxin
     * @date 2018/8/2 17:02
     * @param str
     * @return java.lang.String
     */
    public static String lowerCase(final String str) {
        if (str == null) {
            return null;
        }
        return str.toLowerCase();
    }

    /**
     * 使用给定 Locale 的规则将此 String 中的所有字符都转换为小写
     * @author zhangxin
     * @date 2018/8/2 17:02
     * @param str
     * @param locale
     * @return java.lang.String
     */
    public static String lowerCase(final String str, final Locale locale) {
        if (str == null) {
            return null;
        }
        return str.toLowerCase(locale);
    }

    /**
     * 大小写互转
     * @author zhangxin
     * @date 2018/8/2 17:02
     * @param str
     * @return java.lang.String
     */
    public static String swapCase(final String str) {
        if (StringUtils.isEmpty(str)) {
            return str;
        }
        final char[] buffer = str.toCharArray();
        for (int i = 0; i < buffer.length; i++) {
            final char ch = buffer[i];
            if (Character.isUpperCase(ch)) {
                buffer[i] = Character.toLowerCase(ch);
            }else if (Character.isLowerCase(ch)) {
                buffer[i] = Character.toUpperCase(ch);
            }
        }
        return new String(buffer);
    }

    /**
     * 首字母转大写
     * @author zhangxin
     * @date 2018/8/2 17:03
     * @param str
     * @return java.lang.String
     */
    public static String capitalize(final String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return str;
        }
        char firstChar = str.charAt(0);
        if (Character.isTitleCase(firstChar)) {
            return str;
        }
        return new StringBuilder(strLen)
                .append(Character.toTitleCase(firstChar))
                .append(str.substring(1))
                .toString();
    }

    /**
     * 首字母转小写
     * @author zhangxin
     * @date 2018/8/2 17:03
     * @param str
     * @return java.lang.String
     */
    public static String uncapitalize(final String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return str;
        }
        char firstChar = str.charAt(0);
        if (Character.isLowerCase(firstChar)) {
            return str;
        }
        return new StringBuilder(strLen)
                .append(Character.toLowerCase(firstChar))
                .append(str.substring(1))
                .toString();
    }

    /**
     * 匹配计数
     * @author zhangxin
     * @date 2018/8/2 17:03
     * @param str
     * @param sub
     * @return int
     */
    public static int countMatches(final String str, final String sub) {
        if (isEmpty(str) || isEmpty(sub)) {
            return 0;
        }
        int count = 0;
        int idx = 0;
        while ((idx = str.indexOf(sub, idx)) != -1) {
            count++;
            idx += sub.length();
        }
        return count;
    }

    /**
     * 去空
     * @author zhangxin
     * @date 2018/8/2 17:04
     * @param str
     * @return java.lang.String
     */
    public static String trim(final String str) {
        return str == null ? null : str.trim();
    }

    /**
     * 判断是否字符
     * @author zhangxin
     * @date 2018/8/2 17:04
     * @param str
     * @return boolean
     */
    public static boolean isAlpha(final String str) {
        if (isEmpty(str)) {
            return false;
        }
        final int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (!Character.isLetter(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断是否数字
     * @author zhangxin
     * @date 2018/8/2 17:04
     * @param str
     * @return boolean
     */
    public static boolean isNumeric(final String str) {
        if (isEmpty(str)) {
            return false;
        }
        final int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断是否空白
     * @author zhangxin
     * @date 2018/8/2 17:04
     * @param str
     * @return boolean
     */
    public static boolean isWhitespace(final String str) {
        if (str == null) {
            return false;
        }
        final int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 是否Ascii可见字符
     * @author zhangxin
     * @date 2018/8/2 17:04
     * @param str
     * @return boolean
     */
    public static boolean isAsciiPrintable(final String str) {
        if (str == null) {
            return false;
        }
        final int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (!isAsciiPrintable(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断是否Ascii
     * @author zhangxin
     * @date 2018/8/2 17:05
     * @param ch
     * @return boolean
     */
    public static boolean isAsciiPrintable(final char ch) {
        return ch >= 32 && ch < 127;
    }

    /**
     * 默认避免为null，字符处理
     * @author zhangxin
     * @date 2018/8/2 17:05
     * @param str
     * @return java.lang.String
     */
    public static String defaultString(final String str) {
        return str == null ? "" : str;
    }

    /**
     * 翻转字符串
     * @author zhangxin
     * @date 2018/8/2 17:05
     * @param str
     * @return java.lang.String
     */
    public static String reverse(final String str) {
        if (str == null) {
            return null;
        }
        return new StringBuilder(str).reverse().toString();
    }

    /**
     * 分隔字符串反转
     * @author zhangxin
     * @date 2018/8/2 17:06
     * @param str
     * @param separatorChar
     * @return java.lang.String
     */
    public static String reverseDelimited(final String str, final char separatorChar) {
        if (str == null) {
            return null;
        }
        final String[] strs = split(str, separatorChar);
        reverse(strs);
        return join(strs, separatorChar);
    }

    public static String[] split(final String str, final char separatorChar) {
        return splitWorker(str, separatorChar, false);
    }

    /**
     * 分隔字符串
     * @author zhangxin
     * @date 2018/8/2 17:06
     * @param str
     * @param separator
     * @return java.lang.String[]
     */
    public static String[] split(final String str, final String separator){
        if (isEmpty(str)){
            return new String[0];
        }
        if (isEmpty(separator)){
            return new String[]{str};
        }
        return str.split(separator);
    }

    public static String join(final Object[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }

    public static String join(final Object[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int noOfItems = endIndex - startIndex;
        if (noOfItems <= 0) {
            return "";
        }
        final StringBuilder buf = new StringBuilder(noOfItems * 16);
        for (int i = startIndex; i < endIndex; i++) {
            if (i > startIndex) {
                buf.append(separator);
            }
            if (array[i] != null) {
                buf.append(array[i]);
            }
        }
        return buf.toString();
    }

    private static String[] splitWorker(final String str, final char separatorChar, final boolean preserveAllTokens) {
        if (str == null) {
            return  new String[0];
        }
        final int len = str.length();
        if (len == 0) {
            return new String[0];
        }
        final List<String> list = new ArrayList<>();
        int i = 0;
        int start = 0;
        boolean match = false;
        boolean lastMatch = false;
        while (i < len) {
            if (str.charAt(i) == separatorChar) {
                if (match || preserveAllTokens) {
                    list.add(str.substring(start, i));
                    match = false;
                    lastMatch = true;
                }
                start = ++i;
                continue;
            }
            lastMatch = false;
            match = true;
            i++;
        }
        boolean findLast = match || preserveAllTokens && lastMatch;
        if (findLast) {
            list.add(str.substring(start, i));
        }
        return list.toArray(new String[list.size()]);
    }

    public static void reverse(final Object[] array) {
        if (array == null) {
            return;
        }
        reverse(array, 0, array.length);
    }

    public static void reverse(final Object[] array, int startIndexInclusive, int endIndexExclusive) {
        if (array == null) {
            return;
        }
        int i = startIndexInclusive < 0 ? 0 : startIndexInclusive;
        int j = Math.min(array.length, endIndexExclusive) - 1;
        Object tmp;
        while (j > i) {
            tmp = array[j];
            array[j] = array[i];
            array[i] = tmp;
            j--;
            i++;
        }
    }

    /**
     * 查找字符在字符串中的位置
     * @author zhangxin
     * @date 2018/8/2 17:06
     * @param str
     * @param searchStr
     * @return int
     */
    public static int indexOf(String str, String searchStr) {
        return org.apache.commons.lang.StringUtils.indexOf(str, searchStr);
    }

    /**
     * 截取字符串
     * @author zhangxin
     * @date 2018/8/2 17:07
     * @param str
     * @param start
     * @param end
     * @return java.lang.String
     */
    public static String substring(String str, int start, int end) {
        return org.apache.commons.lang.StringUtils.substring(str, start, end);
    }

    /**
     * 截取字符串
     * @author zhangxin
     * @date 2018/8/2 17:07
     * @param str
     * @param start
     * @return java.lang.String
     */
    public static String substring(String str, int start) {
        return org.apache.commons.lang.StringUtils.substring(str, start);
    }

    /**
     * 字符替换
     * @author zhangxin
     * @date 2018/8/2 17:07
     * @param text
     * @param searchString
     * @param replacement
     * @return java.lang.String
     */
    public static String replace(String text, String searchString, String replacement) {
        return org.apache.commons.lang.StringUtils.replace(text, searchString, replacement);
    }

    /**
     * 忽略大小写判断是否相等
     * @author zhangxin
     * @date 2018/8/2 17:08
     * @param str1
     * @param str2
     * @return boolean
     */
    public static boolean equalsIgnoreCase(String str1, String str2) {
        return org.apache.commons.lang.StringUtils.equalsIgnoreCase(str1, str2);
    }

    /**
     * 获取字符串的字节长度
     * @author zhangxin
     * @date 2018/9/10 14:27
     * @param str
     * @return int
     */
    public static int getByteLength(String str){
        if(isEmpty(str)){
            return 0;
        }
        // 该正则表达式表示双字节字符，用来匹配汉字
        String regex = "[^\\x00-\\xff]";
        // 遇到汉字替换为
        String replaceTo = "**";
        return str.replaceAll(regex, replaceTo).length();
    }
    /**
     * 字段补全
     * @param s
     * @param placeholder
     * @param length
     * @return
     */
    public static String complete(String s, String placeholder, int length){
    	int currentLength = 0;
    	// 获取处理字段的长度
    	if(StringUtils.isEmpty(s)){
    		s = "";
    	}
    	currentLength = s.length();
    	// 获取占位长度
    	int placeLength = length - currentLength;
    	if(placeLength <= 0){
    		return s;
    	}
    	return append(s, placeholder, placeLength);
    }
    
    
    public static String specialComplete(String s, String placeholder, int length){
    	int currentLength = specialLenth(s);
    	int placeLength = length - currentLength;
    	if(placeLength <= 0){
    		return s;
    	}
    	return append(s, placeholder, placeLength);
    }
    
    public static int specialLenth(String value){
    	int valueLength = 0;
    	if (value != null) {
    		for (int i=0; i<value.length(); i++) {
    			String temp = value.substring(i, i + 1);
    			if (temp.matches("[\u0391-\uFFE5]")) {
    				valueLength += 2;
    			} else {
    				valueLength += 1;
    			}
    		}
    	}
    	return valueLength;
    }
    
    
    /**
     * 填充字段
     * @param s 待填充的字符|串
     * @param placeholder 填充物 例如0,空格或其他[长度为1的字符]
     * @param length 填充后达到的长度
     * @param direction 填充方向, true-向前填充, false-向后填充
     * @return 填充后的字符串
     */
    public static String complete(String s, String placeholder, int length, boolean direction){
    	int currentLength = 0;
    	// 获取处理字段的长度
    	if(StringUtils.isEmpty(s)){
    		s = "";
    	}
    	currentLength = specialLenth(s);
    	// 获取占位长度
    	int placeLength = length - currentLength;
    	if(placeLength <= 0){
    		return s;
    	}
    	
    	StringBuilder ph = new StringBuilder();
    	for (int i=0; i<placeLength; i++) {
    		ph.append(placeholder);
    	}
    	
    	return direction ? ph + s : s + ph;
    }
    
    /**
     * 填充字段
     * @param s 待填充的字符|串
     * @param placeholder 填充物 例如0,空格或其他[长度为1的字符]
     * @param length 填充后达到的长度
     * @param direction 填充方向, true-向前填充, false-向后填充
     * @return 填充后的字符串
     */
    public static String completeCard(String s, String placeholder, int length, boolean direction){
    	int currentLength = 0;
    	// 获取处理字段的长度
    	if(StringUtils.isEmpty(s)){
    		s = "";
    	}
    	currentLength = specialLenthCard(s);
    	// 获取占位长度
    	int placeLength = length - currentLength;
    	if(placeLength <= 0){
    		return s;
    	}
    	
    	StringBuilder ph = new StringBuilder();
    	for (int i=0; i<placeLength; i++) {
    		ph.append(placeholder);
    	}
    	
    	return direction ? ph + s : s + ph;
    }
    
    public static int specialLenthCard(String value){
    	int valueLength = 0;
    	String val = value.replaceAll("[^\\x00-\\xff]", "**");
    	try {
			valueLength = val.getBytes(StandardCharsets.UTF_8).length;
		} catch (Exception e) {
			log.error("中文长度计算出现错误", e);
		}
    	return valueLength;
    }
    
    /**
     * 添加占位符
     * @param s
     * @param placeholder
     * @param length
     * @return
     */
    public static String append(String s, String placeholder, int length){
    	if (StringUtils.isEmpty(s)){
    		s = "";
    	} 
    	for (int i = 0; i < length; i++) {
			s = s+placeholder;
		}
    	return s;
    }
    
    public static String nullToString(Object s){
    	return nullToString(s,"");
    }
    
    public static String nullToString(Object s, String defaults){
    	return s == null || "".equals(s.toString()) ? defaults : s.toString().trim();
    }

    /**
     *  去掉字符串左侧的0
     * @param value
     * @return
     */
    public static String trimZeroLeft(String value){
        if(isEmpty(value)){
            return "";
        }
        return value.replaceAll("^(0+)", "");
    }
    
    /**
     * 判断字符串是否包含中文
     * @param content 待校验字符串
     * @return 是否为中文
     * @warn 不能校验是否为中文标点符号
     * @author zhulei
     * @date 2019/11/5 16:27
     */
    public static boolean isChinese(String content){
    	if(StringUtils.isEmpty(content)){
    		return false;
    	}
    	Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
    	Matcher isNum = p.matcher(content);
    	return isNum.find();
    }
}
