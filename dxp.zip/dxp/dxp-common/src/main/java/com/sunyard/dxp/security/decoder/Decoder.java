package com.sunyard.dxp.security.decoder;

public interface Decoder {
    String decode(String content);

}
