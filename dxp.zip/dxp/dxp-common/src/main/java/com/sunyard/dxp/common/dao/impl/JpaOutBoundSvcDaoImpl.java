package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.OutBoundSvcDao;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.qo.OutBoundSvcQo;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * 接出服务接口 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:06 CST 2019
 */
@Repository
public class JpaOutBoundSvcDaoImpl extends JpaBaseDaoImpl< OutBoundSvc, String, OutBoundSvcQo > implements OutBoundSvcDao {

    @Override
    public List<OutBoundSvc> findOutBoundSvcByCode(String outBoundSvcCode) {
        return find(getMainQuery() + " where obj.code = ? and obj.status='1'", outBoundSvcCode);
    }

    @Override
    public OutBoundSvc findOutBoundSvcByCodeAndSvcBundle(String outBoundSvcCode, String svcBundleCode){
        return findBySingle(getMainQuery() + " where obj.code = ? and obj.serviceBundle.code = ?" , outBoundSvcCode, svcBundleCode);
    }

    @Override
    public List< OutBoundSvc > findByOutBoundSvcIds(String[] outBoundSvcIds) {

        List< OutBoundSvc > outBoundSvcs = new ArrayList<>();
        if (ArrayUtils.isNotEmpty(outBoundSvcIds)) {
            StringBuilder whereBuilder = new StringBuilder(" where obj.outBoundSvcId in (");
            for (String str : outBoundSvcIds) {
                whereBuilder.append("'").append(str).append("'").append(",");
            }
            whereBuilder.append("'none')");
            outBoundSvcs = find(getMainQuery() + whereBuilder.toString());
        }
        return outBoundSvcs;
    }

    @Override
    public List< OutBoundSvc > findOutBoundSvcBySvcId(String serviceBoundId) {
        return find(getMainQuery() + " where obj.serviceBundle.serviceBundleId = ?", serviceBoundId);
    }

}
