package com.sunyard.dxp.security.sign.impl;


import com.sunyard.dxp.security.sign.Signature;
import com.sunyard.dxp.utils.SignatureLibrary;

/**
 * 对全报文进行核押
 */
@SignatureLibrary(code = "MYJ_ALLSignature" , name = "密押机全报文核押")
public class MYJ_ALLSignature implements Signature {

    /**
     *
     * @param src
     * @param key
     * @return  0 成功 1 失败
     */
    @Override
    public String sign(String src,String key){

        return new MYJ_PartSignature().sign(src, key) ;
    }
}
