package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.qo.OutBoundSvcQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 接出服务接口 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:06 CST 2019
 */
public interface OutBoundSvcDao extends BaseDao<OutBoundSvc, String, OutBoundSvcQo> {

    /**
     * 通过code获取接出服务
     * @param outBoundSvcCode
     * @return 一个接出code 只能在 servicebound中唯一
     */
    List<OutBoundSvc> findOutBoundSvcByCode(String outBoundSvcCode);

    /**
     * 通过code和服务模块code获取接出服务
     * @param outBoundSvcCode
     * @return
     */
    OutBoundSvc findOutBoundSvcByCodeAndSvcBundle(String outBoundSvcCode, String svcBundleCode);

    /**
     * 根据outBoundSvcIds 组sql查询
     * @param outBoundSvcIds
     * @return
     */
    List<OutBoundSvc> findByOutBoundSvcIds(String[] outBoundSvcIds) ;

    /**
     * 根据服务模块id查询接出服务
     * @param serviceBoundId
     * @return
     */
    List<OutBoundSvc> findOutBoundSvcBySvcId(String serviceBoundId);
}
