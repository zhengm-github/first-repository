package com.sunyard.dxp.common.client.factory;

import com.sunyard.dxp.common.client.channel.Channel;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by tangjiejie on 2018/3/1.
 */
@Component
public class ChannelFactory {

    private static Map<String, Channel> channelMap = new HashMap<>();

    @Resource(name = "httpChannel")
    private Channel httpChannel;

    @Resource(name = "httpsChannel")
    private Channel httpsChannel;

    @PostConstruct
    public void init() {
        //初始化时将channel统一存入
        channelMap.put("http",httpChannel);
        channelMap.put("https",httpsChannel);

    }

    public Channel getChannel(String clientType){
        return channelMap.get(clientType);
    }
}
