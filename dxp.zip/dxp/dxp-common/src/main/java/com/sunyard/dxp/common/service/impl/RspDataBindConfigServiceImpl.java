package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.RspDataBindConfigDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.RspDataBindConfigService;
import com.sunyard.dxp.common.entity.RspDataBindConfig;
import com.sunyard.dxp.common.qo.RspDataBindConfigQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 数据绑定配置 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:43:42 CST 2019
 */
@Service
public class RspDataBindConfigServiceImpl extends BaseServiceImpl<RspDataBindConfig, String, RspDataBindConfigQo> implements RspDataBindConfigService {

    @Autowired
    private RspDataBindConfigDao dataBindConfigDao;

    @Override
    public List<RspDataBindConfig> findDataBindConfigByOutProId(String outDataPropertyId) {
        return dataBindConfigDao.findDataBindConfigByOutProId(outDataPropertyId);
    }

    @Override
    public void deleteByPropertyId(String propertyId) {
        dataBindConfigDao.deleteByPropertyId(propertyId);
    }
}
