package com.sunyard.dxp.message.service.impl;

import cn.hutool.core.codec.Base64;
import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.utils.FileUtils;
import com.sunyard.dxp.utils.*;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.xml.sax.InputSource;

import java.io.*;
import java.util.*;


/**
 * @Description xml解析基础服务
 * @Author zhangxin
 * @Date 2020/1/9 9:54
 * @Version 1.0
 */
@Service( "baseResolveServiceXml" )
public class BaseResolveServiceXmlImpl implements BaseResolveService {

    private static final Logger log = LoggerFactory.getLogger(BaseResolveServiceXmlImpl.class);
    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveServiceFixed;

    @Value( "${config.path}" )
    private String configPath;

    @Override
    public Map< String, Object > execute(List< ParamRule > rules, String message, String... resolveParam) {
        // 获取编码
        String encoding = resolveParam[ 0 ];
        // xml 循环区域detail保存的key (filebody / xmldetail)
        String detailKey = MsgKeys.FILE_BODY_DETAIL;
        String msgType = "pack"; // 默认处理的是String , pack-string/file-文件名
        if (resolveParam.length > 2) {
            detailKey = resolveParam[ 2 ];
            msgType = resolveParam[ 1 ];  // 读取的是 file/pack
        }


        // 此时读取的message 可能是文件名
        Document document = readXml(message, encoding, msgType);
        // 区分是xml文案还是报文中的 明细
        Map< String, Object > reMap = resolve(rules, document, encoding);
        if (reMap != null) {
            Object fileBodyDetailObj = reMap.get(MsgKeys.FILE_BODY_DETAIL);
            if (fileBodyDetailObj != null && !detailKey.equals(MsgKeys.FILE_BODY_DETAIL)) {
                reMap.put(detailKey, fileBodyDetailObj);
                reMap.remove(MsgKeys.FILE_BODY_DETAIL);
            }
        }
        return reMap;
    }

    private Map< String, Object > resolve(List< ParamRule > rules, Document document, String encoding) {
        if (CollectionUtils.isEmpty(rules)) {
            log.warn("XML报文解析规则为空");
            return null;
        }
        Map< String, Object > result = new HashMap<>();
        // 执行解析
        // xml中的明细信息
        String detailParentXpath = "";
        List< Map< String, String > > xmlDetailList = new ArrayList<>();
        for (ParamRule paramRule : rules) {
            // 判断数据类型
            if (!paramRule.isArray()) {
                //可能xml有定长的明细
                if (StringUtils.isNotBlank(paramRule.getDetailName())) {
                    // xml中某个字段中有定长明细
                    detailParentXpath = paramRule.getXpath();  // detailName 就是loop结点
                    Node detailNode = document.selectSingleNode(detailParentXpath);
                    // 没有循环域的时候 不处理此字段
                    if (detailNode == null) {
                        continue;
                    }
                    // 读取某个字段里面的明细
                    readFixedInXmlParam(result, paramRule, document, encoding, detailNode.getText());
                } else {
                    readText(result, paramRule, document);
                }
            } else {
                readArray(result, paramRule, document);
                // 将明细汇总之后，对应的原明细就删除
                xmlDetailList.addAll((List< Map< String, String > >) result.get(paramRule.getXpath()));  // 所有的明细相加
                result.remove(paramRule.getXpath()); // 避免再写入库。
            }
        }
        // 多个循环直接全部放在一起!!
        if (!CollectionUtils.isEmpty(xmlDetailList)) {
            result.put(MsgKeys.FILE_BODY_DETAIL, xmlDetailList);
        }

        return result;
    }

    /**
     * 读取xml中某个字段的循环域部分明细
     *
     * @param result
     * @param paramRule
     * @param document
     * @param encoding
     */
    private void readFixedInXmlParam(Map< String, Object > result,
                                     ParamRule paramRule, Document document,
                                     String encoding, String detailParentText) {

        // 解析明细之前 判断明细是否GZIP 加压, 取报文中 DtlZpFlg
        Node dtlZpFlgNode = document.selectSingleNode("//DtlZpFlg");
        List< Map< String, String > > detailList = null;  // 最终的明细结果
        Map< String, String > rowDetailMap = null;  // 单行明细
        if (dtlZpFlgNode != null && Constant.USE_GZIP_FLAG.equals(dtlZpFlgNode.getText())) {

            log.info("[DtlZpFlg] 标志为 ：{}, 需要解压.", Constant.USE_GZIP_FLAG);
            // 将明细写到文件中
            String gzipInFileName =
                    DateFormatUtils.format(new Date(), "HHmmss")
                            + Thread.currentThread().getName() + "_" + UUIDUtils.getUUID32() + "_cbspFixed";
            try {
                GzipAndMd5Util.unzipFileNoMd5(Constant.TEMP_FILES_PATH + File.separator + "files",
                        gzipInFileName, detailParentText.getBytes());


                // 看下解析完成的文件存不存在
                String inFile = Constant.TEMP_FILES_PATH + File.separator + "files" + File.separator + gzipInFileName;
                File gzipFile = new File(inFile);
                if (!gzipFile.exists()) {
                    log.info("解压之后的文件不存在，报文不继续处理");
                    throw new DxpCommonException(
                            DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002.getCode(), "解压之后的文件不存在，报文不继续处理");
                }
                log.info("GZIP解压之后明文文件名：[{}]", gzipInFileName);
//            try {
//                detailParentText = GzipAndMd5Util.ungzipByteArr(detailParentText.getBytes(), encoding);
//            } catch (Exception e) {
//                log.info("对xml中明细区域gzip解压失败！DtlZpFlg=[{}], encode=[{}], [{}]",
//                        dtlZpFlgNode.getText(), encoding, e);
//            }
                // 对文件循环处理
                // 将xml中明细解析到xml_detail中
                if (!":LST:".equals(paramRule.getColumnSeparator())) {
                    log.info("明细分割符界面配置不是 :LST:，不继续处理明细");
                    throw new DxpCommonException(
                            DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002.getCode(), "明细分割符界面配置不是 :LST:，不继续处理明细");
                }

                detailList = new ArrayList<>();
                String row = "";
                SplitFileReader splitFileReader = new SplitFileReader(inFile, 10240); // 默认单条数据不超过 10kb
                while (!splitFileReader.END.equals(row = splitFileReader.readLSTLine(encoding))) {
                    if (StringUtils.isNotBlank(row)) {
                        rowDetailMap = readFixArray(paramRule.getDetailRules(), row, encoding);
                        detailList.add(rowDetailMap);
                    }
                }
                splitFileReader.close();  // 关闭文件流
            } catch (Exception e) {
                log.info("对xml中明细区域gzip解压失败！DtlZpFlg=[{}], encode=[{}], [{}]",
                        dtlZpFlgNode.getText(), encoding, e);
            }
        } else {

            // 没有加压则进行循环处理
            log.info("定长部分明细:[{}]", detailParentText);
            // 将xml中明细解析到xml_detail中
            if (StringUtils.isNotBlank(detailParentText)) {
                detailList = new ArrayList<>();
                String[] rowDetails = detailParentText.split(paramRule.getColumnSeparator());  // 分割符 由界面配置 (:LST:)
                for (String rowDetail : rowDetails) {
                    if (StringUtils.isNotBlank(rowDetail)) {
                        rowDetailMap = readFixArray(paramRule.getDetailRules(), rowDetail, encoding);
                        detailList.add(rowDetailMap);
                    }
                }
            }
        }

        result.put(MsgKeys.XML_DETAIL, detailList);  //用list<map> 保存明细信息
    }

    /**
     * 读取明细数据
     *
     * @param result
     * @param paramRule
     * @param document
     */
    private void readArray(Map< String, Object > result, ParamRule paramRule, Document document) {
        List< Node > nodes = document.selectNodes(paramRule.getXpath());
        if (CollectionUtils.isEmpty(nodes)) {
            // 无明细不解析
            result.put(paramRule.getXpath(), new ArrayList<>());
            return;
        }
        // xpath 作为key避免重复
        result.put(paramRule.getXpath(), readArray(nodes, paramRule.getDetailRules()));
    }

    private List< Map< String, String > > readArray(List< Node > nodes, List< ParamRule > detailRules) {
        List< Map< String, String > > detailsList = new ArrayList<>();
        Element parentE = null;
        for (Node node : nodes) {
            // 此处一个node为一笔明细数据
            Map< String, String > detail = readDetail(node, detailRules);

            // 如果循环有index ，则保存起来
            parentE = (Element) node;
            if (StringUtils.isNotBlank(parentE.attributeValue("ID"))) {
                detail.put(MsgKeys.ARRAY_ID, parentE.attributeValue("ID"));
            }
            detailsList.add(detail);
        }
        return detailsList;
    }

    private Map< String, String > readDetail(Node node, List< ParamRule > detailRules) {
        Map< String, String > result = new HashMap<>();
        for (ParamRule paramRule : detailRules) {
            Element e = (Element) node;
            String[] str = paramRule.getXpath().replaceAll(".*" + e.getName() + "/", "").split("/");
            String value = "";
            for (int i = 0; i < str.length; i++) {
                if (StringUtils.isNotEmpty(str[ i ]) && e != null) {
                    e = e.element(str[ i ]);
                }
            }
            if (e != null) value = e.getText();
            result.put(paramRule.getXpath(), value);
        }
        return result;
    }

    /**
     * 读取并解析xml中定长明细(解析一行)
     *
     * @param paramRules
     * @param rowDetailText
     * @param encode        定义编码
     * @return key = "filebody"/name, value = 具体的值
     */
    private Map< String, String > readFixArray(List< ParamRule > paramRules, String rowDetailText, String encode) {

        Map< String, Object > rowDetailMap =
                baseResolveServiceFixed.execute(paramRules, rowDetailText, new String[] { encode, "", "", "char" });
        Map< String, String > reMap = new HashMap<>();
        Object objValue = null;
        for (String keyXpath : rowDetailMap.keySet()) {
            objValue = rowDetailMap.get(keyXpath);
            if (objValue != null) {
                // 将xpath作为 key
                reMap.put(keyXpath, objValue.toString());
            }
        }
        return reMap;
    }

    private void readText(Map< String, Object > result, ParamRule paramRule, Document document) {
        Node node = document.selectSingleNode(paramRule.getXpath());
        if (node == null) {
            return;
        }
        // xpath 避免标签重复
        result.put(paramRule.getXpath(), node.getText());
    }

    /**
     * @param bodyMessage
     * @param encoding
     * @param msgType     (file-bodymessage 为对应的xml文件地址 / pack- 处理的就是xml本体)
     * @return
     */
    private Document readXml(String bodyMessage, String encoding, String msgType) {
        SAXReader reader = new SAXReader();

        // 解析的时候不加命名空间,暂时简单处理
        InputSource source = null;
        if ("file".equals(msgType)) {
            // 文件处理
            try {
                source = new InputSource(new FileInputStream(new File(bodyMessage)));
            } catch (FileNotFoundException e) {
                log.info("读取xml模式为 file, 但是文件 [{}] 不存在，处理中断...", bodyMessage);
                throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_001);
            }
        } else {
            // 普通小报文处理
            source = new InputSource(
                    new StringReader(XmlUtil.removeNameSpace(bodyMessage, "Document")));
        }
        source.setEncoding(encoding);
        try {
            return reader.read(source);
        } catch (DocumentException e) {
            log.info("XML报文格式错误:[{}], [{}]", bodyMessage, e);
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_001);
        }
    }

    @Override
    public Map< String, Object > mapExecute(List< ParamRule > rules, Map< String, Object > map, String... resolveParam) {
        Map< String, Object > xmlMap = new HashMap<>();
        XmlUtil xmlReqDoc = null;
        if (!rules.isEmpty()) {
            ParamRule rule = rules.get(0);
        }

        String fileParantXPath = "";  // detailName处理时 需要loop的结点
        String reqXmlStr = "";
        List< ParamRule > detailRuleList = null;  // detailName 处理时候 loop结点的子节点
        String columnSep = "#x000D;#x000A;"; // 行分隔符， 默认\r\n
        try {

            // map参数中key是 xpath ，所以不需要根 （这里的 Iso 特殊处理）
            xmlReqDoc = XmlUtil.Create(XmlUtil.FROM_ENCODE, resolveParam[ 0 ]);
            if (!rules.isEmpty()) {
                Element e = null;
                for (ParamRule paramRule : rules) {
                    // 组装时 name没有的规则则为明细文件
                    if (StringUtils.isNotBlank(paramRule.getName())) {
                        Object mapObj = map.get(paramRule.getXpath());
                        // xml 中没有值的时候 不加这个标签
                        if (mapObj == null || "".equals(mapObj.toString())) {
                            continue;
                        }
                        // 添加属性(后期可能要配置), 金额要转成 小数两位
                        if (Constant.AMT_LIST.contains(paramRule.getName()) || paramRule.getName().endsWith("Amt")) {
                            // 金额格式化让函数完成
                            xmlReqDoc.setNodeContentTrim(paramRule.getXpath(), mapObj.toString());
                            e = (Element) xmlReqDoc.getDocument().selectSingleNode(paramRule.getXpath());
                            if (e != null) {
                                e.addAttribute("Ccy", "CNY");
                            }
                        } else {
                            xmlReqDoc.setNodeContent(paramRule.getXpath(), mapObj != null ? mapObj.toString() : "");
                        }

                    } else {
                        // xml 放入定长明细
                        List< ParamRule > childRules = paramRule.getDetailRules();
                        if (!CollectionUtils.isEmpty(childRules)) {
                            fileParantXPath = paramRule.getXpath();
                            detailRuleList = childRules;
                            columnSep = paramRule.getColumnSeparator();
                        }
                        // 明细处理(如果有分割符号表示 xml循环域)
                        if (StringUtils.isBlank(paramRule.getColumnSeparator())) {
                            // 将 xml_detail 在file中以xml 格式循环处理， fileParantXPath是需要循环的结点
                            if (map.get(MsgKeys.XML_DETAIL) != null
                                    && StringUtils.isNotBlank((String) map.get(MsgKeys.XML_DETAIL))) {
                                xmlReqDoc = addXmlDetail2Xml(map, detailRuleList, xmlReqDoc, fileParantXPath);
                            } else {
                                // 可能是 单位的文件明细 转成 全国的 xml明细
                                if (map.get(MsgKeys.FILE_BODY_DETAIL) != null
                                        && StringUtils.isNotBlank((String) map.get(MsgKeys.FILE_BODY_DETAIL))) {
                                    xmlReqDoc = addXmlDetail2Xml(map, detailRuleList, xmlReqDoc, fileParantXPath);
                                }
                            }
                            continue;
                        }

                        // 为了xml字段排序 应在循环中处理明细处理
                        // 将file_body中内容 放到xml明细中(只会给平台！！)
                        if (map.get(MsgKeys.FILE_BODY_DETAIL) != null
                                && StringUtils.isNotBlank((String) map.get(MsgKeys.FILE_BODY_DETAIL))) {
                            xmlReqDoc = addFixedDetail2Xml(columnSep, map, detailRuleList, xmlReqDoc, resolveParam);
                        }


                    }
                }
            }

            // 增加命名空间 ，根元素是 Document 时， 增加命名空间
            reqXmlStr = xmlReqDoc.dumpToBuff(resolveParam[ 0 ]);
            Element rootE = xmlReqDoc.getDocument().getRootElement();
            if (rootE != null && rootE.getName().equals("Document")) {
                rootE.addNamespace("xsi", "http://www.w3.org/2001/XMLSchema");
                reqXmlStr = xmlReqDoc.dumpToBuff(resolveParam[ 0 ]);  // 加载命名空间
                reqXmlStr = reqXmlStr.replaceAll("<Document",
                        String.format("<Document xmlns=\"urn:cnaps:std:cbsp:2019:tech:xsd:cbsp.%s.001.01\" "
                                , ObjectUtils.defaultIfNull(map.get("namespace"), "").toString()  // 去除312_1132 这种问题
                                        .replaceAll("_.+", "")));
            }
        } catch (Exception e) {
            log.info("组装xml报文失败!,[{}]", e);
            //组装失败则不继续处理
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_001);
        }

        xmlMap.put("package", convertHtml(reqXmlStr));
        return xmlMap;
    }

    /**
     * 向xml中放入定长明细
     *
     * @param map
     * @param detailRuleList
     * @param xmlReqDoc
     * @param resolveParam
     * @return
     */
    private synchronized XmlUtil addFixedDetail2Xml(String columnSep,
                                                    Map< String, Object > map, List< ParamRule > detailRuleList, XmlUtil xmlReqDoc, String... resolveParam) throws Exception {
        // 处理文件明细(明细部分放到文件中保存)
        String fileParantXPath = "";
        PrintWriter pw = null; // 存储拼接好的明细信息
        BufferedReader br = null;
        String filePath = Constant.TEMP_FILES_PATH + File.separator + "detail_files";
        String fileName = String.format("fixdetail_%s_%s_%s",
                DateFormatUtils.format(new Date(), "HHmmss"), Thread.currentThread().getName(), UUIDUtils.getUUID32());

        StringBuilder rowSb = null;
        Object rowValue = "";
        Map< Integer, String > sortMap = null;
        try {
            String inDetailFileName = (String) map.get(MsgKeys.FILE_BODY_DETAIL);
            if (StringUtils.isNotBlank(inDetailFileName)) {
                File detailFilePath = new File(filePath);
                if (!detailFilePath.exists()) {
                    detailFilePath.mkdirs();
                }
                // 保存明细明文信息
                pw = new PrintWriter(
                        new File(filePath + File.separator + fileName));

                log.info("准备分析、拼接明细数据...");
                br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(
                                        new File(inDetailFileName)), "UTF-8"));
                String rowStr = "";
                String[] headArr = null;
                String[] bodyArr = null;
                Map< String, Object > rowDetailMap = null;
                int index = 0;
                while (StringUtils.isNotEmpty(rowStr = br.readLine())) {
                    if (index == 0) {
                        headArr = rowStr.split("\\$&\\$");  // 头里面一定不能有空格
                    } else {
                        rowDetailMap = new HashMap<>();
                        bodyArr = rowStr.split("\\$&\\$", -1);
                        for (int i = 0; i < headArr.length; i++) {
                            rowDetailMap.put(headArr[ i ], bodyArr.length >= (i + 1) ? bodyArr[ i ] : "");
                        }

                        // 组装新的报文到文件中
                        sortMap = new TreeMap<>(
                                new Comparator< Integer >() {
                                    public int compare(Integer obj1, Integer obj2) {
                                        // 升序排序
                                        return obj1.compareTo(obj2);
                                    }
                                });
                        rowSb = new StringBuilder();
                        for (ParamRule paramRule : detailRuleList) {
                            if (StringUtils.isBlank(fileParantXPath)) {
                                fileParantXPath = paramRule.getXpath().substring(0, paramRule.getXpath().lastIndexOf("/"));
                            }
                            // 避免 null
                            rowValue = StringUtil.getDefaultStr(rowDetailMap.get(paramRule.getXpath()), "");
                            // 如果是金额则转换为 CNY0000000000123.99
                            if (Constant.AMT_LIST.contains(paramRule.getName())
                                    || paramRule.getName().endsWith("Amt")) {
                                try {
                                    // 金额格式化 交给 函数
                                    rowValue = "CNY" + StringUtil.formatStr(rowValue.toString(), 16, "0", true);
                                } catch (Exception e) {
                                    log.info("明细金额转换异常，参数xpath=[{}],value = [{}],[{}] ",
                                            paramRule.getXpath(), rowValue, e);
                                }
                            }
                            //需要按照位置填写
                            sortMap.put(paramRule.getStart(),
                                    StringUtil.formatStr(rowValue.toString(), paramRule.getLength(), " ", false));
                        }
                        // 在这里排序, 写一行的值
                        Set< Integer > keySet = sortMap.keySet();
                        Iterator< Integer > iter = keySet.iterator();
                        while (iter.hasNext()) {
                            rowSb.append(sortMap.get(iter.next()));
                        }
                        // 跟回车 (&#x000D;)换行符&#x000A;
                        pw.print(columnSep);
                        pw.print(rowSb);
                        pw.flush();

                    }
                    index++;
                }

                log.info("准备加压明细报文...");
                //加压标识
                Node zpFlagNode = xmlReqDoc.getDocument().selectSingleNode("//DtlZpFlg");
                String gzipDetail = "";
                if (zpFlagNode.getText().equals(Constant.USE_GZIP_FLAG)) {
                    // gzip + base64
                    GzipAndMd5Result gzipAndMd5Result =
                            GzipAndMd5Util.zipFile(filePath, fileName);
                    gzipDetail = gzipAndMd5Result.getGzipStr();
                } else {
                    // base64
                    byte[] detailData =
                            FileUtils.readInputStream(new FileInputStream(new File(filePath + File.separator + fileName)));
                    gzipDetail = Base64.encode(detailData);
                }
                log.info("将明细放入xml中...");
                xmlReqDoc.setNodeContent(fileParantXPath, gzipDetail);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pw.close();  // 关闭输入流
            //删除临时文件
            File file = new File(filePath + File.separator + fileName);
            if (file.exists()) {
                log.info("删除临时明细文件[{}]...", fileName);
                boolean x = file.delete();
                if (x) {
                    log.info("文件：[{}] 删除成功！", fileName);
                }
            }
        }
        return xmlReqDoc;
    }

    /**
     * 向xml中放入xml明细 （具体循环利用detailName的上级结点）
     *
     * @param map
     * @param rules
     * @param xmlReqDoc
     * @param fileParantXPath // 外围固定 loop的标签, 可能多一层 filebody标签！！
     * @return
     */
    private XmlUtil addXmlDetail2Xml(Map< String, Object > map, List< ParamRule > rules,
                                     XmlUtil xmlReqDoc, String fileParantXPath) {
        // 处理文件明细
        Object rowValue = "";
        boolean haveIndex = true;
        BufferedReader br = null;
        String inDetailFileName = (String) map.get(MsgKeys.XML_DETAIL);

        // 可能是 单位那边的明细转成 全国这边的 xml明细
        if (StringUtils.isBlank(inDetailFileName)) {
            inDetailFileName = (String) map.get(MsgKeys.FILE_BODY_DETAIL);
            haveIndex = false;  // 全国报文不需要序号
        }
        try {
            if (StringUtils.isNotBlank(inDetailFileName)) {
                Element rowElement = null;
                br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(
                                        new File(inDetailFileName)), "UTF-8"));
                String rowStr = "";
                String[] headArr = null;
                String[] bodyArr = null;
                Map< String, Object > rowDetailMap = null;
                int index = 0;
                while (StringUtils.isNotEmpty(rowStr = br.readLine())) {
                    if (index == 0) {
                        headArr = rowStr.split("\\$&\\$");  // 头里面一定不能有空格
                    } else {
                        rowDetailMap = new HashMap<>();
                        bodyArr = rowStr.split("\\$&\\$", -1);
                        for (int i = 0; i < headArr.length; i++) {
                            rowDetailMap.put(headArr[ i ], bodyArr.length >= (i + 1) ? bodyArr[ i ] : "");
                        }
                        rowElement = xmlReqDoc.addLoopNode(fileParantXPath, "", index, haveIndex);
                        for (ParamRule paramRule : rules) {
                            rowValue = rowDetailMap.get(paramRule.getXpath());
                            // 明细中 如果没有值则不打印标签
                            if (rowValue == null || "".equals(rowValue.toString())) {
                                continue;
                            }
                            xmlReqDoc.addLoopEleNode(
                                    paramRule.getXpath(), rowValue.toString(), fileParantXPath, rowElement);
                        }
                    }
                    index++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return xmlReqDoc;
    }

    /**
     * 格式化 xml字符串
     *
     * @param html
     * @return
     */
    private static String convertHtml(String html) {
        return html == null ? "" : html.replaceAll("&gt;", ">")
                .replaceAll("&lt;", "<")
                .replaceAll("#x000D;#x000A;", "\r\n")  // 换行
                .replaceAll("#x0020;", " "); // 空格
    }

}
