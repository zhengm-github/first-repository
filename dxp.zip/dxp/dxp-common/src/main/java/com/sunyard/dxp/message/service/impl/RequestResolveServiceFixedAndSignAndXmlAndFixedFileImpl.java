package com.sunyard.dxp.message.service.impl;

import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import com.sunyard.dxp.utils.Constant;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.*;
import java.util.*;

/**
 * @Description 定长报文头+签名域+XML报文+定长文件
 * <p>
 * 文件内容保存到临时文件
 * @Author zhangxin
 * @Date 2020/1/10 17:46
 * @Version 1.0
 */
@Service( "fixedAndSignAndXmlAndFixedFileResolve" )
@AgreementLibrary( code = "fixedAndSignAndXmlAndFixedFile", name = "定长报文头+签名域+XML报文+定长文件" )
public class RequestResolveServiceFixedAndSignAndXmlAndFixedFileImpl implements RequestResolveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestResolveServiceFixedAndSignAndXmlAndFixedFileImpl.class);

    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Autowired
    @Qualifier( "regionSign" )
    private SignService regionSignService;

    @Value( "${config.path}" )
    private String configPath;

    @Autowired
    private RequestResolveServiceFixedAndSignAndXmlImpl requestResolveServiceFixedAndSignAndXml;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 5) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
        if (StringUtils.isEmpty(requestResolveDto.getFileMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_014);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        // 拆分报文
        String[] splitMessage = requestResolveServiceFixedAndSignAndXml.splitMessage(requestResolveDto.getMessage(), requestResolveDto.getEncoding(), ruleList);

        // 解析之前先校验sign
        String xmlBody = regionSignService.validateSign(signDto, splitMessage[ 1 ], "");

        // 定长报文规则
        List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(ruleList.get(0).getChildRules());
        // xml报文规则
        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(ruleList.get(2).getChildRules());
        Map< String, Object > head = baseResolveService.execute(headRules, splitMessage[ 0 ], requestResolveDto.getEncoding());
        Map< String, Object > body = baseResolveXmlService.execute(bodyRules, xmlBody, requestResolveDto.getEncoding());

        body.putAll(head);
        ProcotolResolveRule fileHeadRule = null;
        ProcotolResolveRule fileBodyRule = null;
        // 解析文件
        if (ruleList.get(3).getLinNum() == 1) {
            fileHeadRule = ruleList.get(3);
            fileBodyRule = ruleList.get(4);
        } else {
            fileHeadRule = ruleList.get(4);
            fileBodyRule = ruleList.get(3);
        }
        readFile(fileHeadRule, fileBodyRule, requestResolveDto.getFileMessage(), body, requestResolveDto.getEncoding());
        return body;
    }

    private void readFile(ProcotolResolveRule fileHeadRule, ProcotolResolveRule fileBodyRule, String fileMessage, Map< String, Object > result, String encoding) {
        List< ParamRule > fileHeadRules = RuleConvertUtils.convertFixedRules(fileHeadRule.getChildRules());
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertFixedRules(fileBodyRule.getChildRules());
        // 分隔文件
        String[] rows = fileMessage.split(fileHeadRule.getSeparatorChar());
        List< Map< String, Object > > details = new ArrayList<>();
        for (int i = 0; i < rows.length; i++) {
            String row = rows[ i ];
            if (i == 0) {
                Map< String, Object > head = baseResolveService.execute(fileHeadRules, row, new String[] { encoding, "", "", "char" });
                result.put(fileHeadRule.getName(), head);
                continue;
            }
            Map< String, Object > body = baseResolveService.execute(fileBodyRules, row, new String[] { encoding, "", "", "char" });
            details.add(body);
        }
        result.put(fileBodyRule.getName(), details);
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();

        List< ProcotolResolveRule > packRuleList = new ArrayList<>();
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if (("pack").equals(procotolResolveRule.getRuleType())) {
                packRuleList.add(procotolResolveRule);
            } else if ("file".equals(procotolResolveRule.getRuleType())) {
                fileRuleList.add(procotolResolveRule);
            }
        }

        List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(packRuleList.get(0).getChildRules());

        // 签名规则
        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(packRuleList.get(2).getChildRules());
        Map< String, Object > resultMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        Map< String, Object > headResult = baseResolveService.mapExecute(headRules, map, "");
        Map< String, Object > bodyResult = baseResolveXmlService.mapExecute(bodyRules, map, "");

        String fileName = getDetailFile(ruleList, map, requestResolveDto.getEncoding());
        // 计算签名(根据xml体计算签名)
        String xmlBody = bodyResult.get(MsgKeys.PACKAGE).toString();

        // 组装签名部分
        Map< String, String > dataMap = regionSignService.makeSign(signDto, xmlBody);
        sb.append(headResult.get(MsgKeys.PACKAGE))
                .append(dataMap.get("xmlBody"));
        resultMap.put(MsgKeys.PACKAGE, sb.toString());
        resultMap.put("file", fileName);
        return resultMap;
    }


    /**
     * 定长文件报文头报文体组装
     *
     * @param ruleList
     * @param map
     * @return
     */
    private String getDetailFile(List< ProcotolResolveRule > ruleList, Map< String, Object > map, String encode) {
        List< ProcotolResolveRule > list = new ArrayList<>();
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if (("file").equals(procotolResolveRule.getRuleType())) {
                list.add(procotolResolveRule);
            }
        }
        if (CollectionUtils.isEmpty(list) || list.size() < 1) {
            return "";
        }
        int a = 0;
        int b = 1;
        if (list.get(0).getBeginIndex() > list.get(1).getBeginIndex()) {
            a = 1;
            b = 0;
        }
        List< ParamRule > fileHeadRules = RuleConvertUtils.convertFixedRules(list.get(a).getChildRules());
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertFixedRules(list.get(b).getChildRules());

        // 临时文件
        PrintWriter pw = null; // 存储拼接好的明细信息
        BufferedReader br = null;
        String filePath = Constant.TEMP_FILES_PATH + File.separator + "detail_files";
        String fileName = String.format("fixdetail_%s_%s_%s",
                DateFormatUtils.format(new Date(), "HHmmss"), Thread.currentThread().getName(), UUIDUtils.getUUID32());
        try {
            // 保存明细明文信息
            // 满足通讯适配器Gzip
            String pwGZIPEncode = encode;
            if (EncoderEnum.ISO88591.getCode().equals(pwGZIPEncode)) {
                pwGZIPEncode = "GB18030";
            }
            pw = new PrintWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(
                                    new File(filePath + File.separator + fileName)),
                            pwGZIPEncode));

            Map< String, Object > fileHeadMap = baseResolveService.mapExecute(fileHeadRules, map, "");
            pw.print(fileHeadMap.get(MsgKeys.PACKAGE));
            pw.print("\n");
            pw.flush();

            String inDetailFileName = (String) map.get(fileBodyRules.get(0).getName());  // 转换之后的键值对文件

            if (StringUtils.isNotBlank(inDetailFileName)) {
                br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(
                                        new File(inDetailFileName)), "UTF-8"));
                String rowStr = "";
                String[] headArr = null;
                String[] bodyArr = null;
                Map< String, Object > rowDetailMap = null;
                int index = 0;
                while (StringUtils.isNotEmpty(rowStr = br.readLine())) {
                    if (index == 0) {
                        headArr = rowStr.split("\\$&\\$");  // 头里面一定不能有空格
                    } else {
                        rowDetailMap = new HashMap<>();
                        bodyArr = rowStr.split("\\$&\\$", -1);
                        for (int i = 0; i < headArr.length; i++) {
                            rowDetailMap.put(headArr[ i ], bodyArr.length >= (i + 1) ? bodyArr[ i ] : "");
                        }

                        Map< String, Object > fileBodyMap =
                                baseResolveService.mapExecute(fileBodyRules, rowDetailMap, "");
                        pw.print(fileBodyMap.get(MsgKeys.PACKAGE));
                        pw.print("\n");
                        pw.flush();
                    }
                    index++;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pw.close();
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return fileName;
    }
}
