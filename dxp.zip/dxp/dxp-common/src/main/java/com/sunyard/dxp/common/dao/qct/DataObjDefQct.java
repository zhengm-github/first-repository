package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.DataObjDefQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 数据对象定义 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:27 CST 2019
 */
public class DataObjDefQct extends QueryConditionTransfer<DataObjDefQo> {

    @Override
    public void transNameQuery(DataObjDefQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(DataObjDefQo qo, QueryCondition condition) {
        //
    }

}
