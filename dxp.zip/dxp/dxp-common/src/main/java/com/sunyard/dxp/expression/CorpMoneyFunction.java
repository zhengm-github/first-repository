package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 转金额为 CNY0000000000123.99为 123.99
 */
@FunctionLibrary( code = "corpMoney", name = "单位金额处理(#0.00)", expression = "(corpMoney\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "corpMoney()", hasProperty = true )
@Component
public class CorpMoneyFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if(StringUtils.isBlank(params) || "".equals(params.trim())){
            return "0.00" ;
        }
        BigDecimal beforeMoney = new BigDecimal(params.replaceAll("[CNY]", "").trim());
        String afterMoney =
                beforeMoney.setScale(2, RoundingMode.HALF_UP).toString();
        return afterMoney;
    }
}
