package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 通过竖线分割各个属性值
 */
@FunctionLibrary(code = "verticalSign",name = "拼接（用 | 分割） ",expression = "(.*)(verticalSign)(.*)",type = "all" ,isRelation = true,exp = "verticalSign")
@Component
public class VerticalSignFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        return params.replaceAll("verticalSign","|");
    }
}
