package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.RspDataBindConfigDao;
import com.sunyard.dxp.common.entity.RspDataBindConfig;
import com.sunyard.dxp.common.qo.RspDataBindConfigQo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 数据绑定配置 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:43:42 CST 2019
 */
@Repository
public class JpaRspDataBindConfigDaoImpl extends JpaBaseDaoImpl<RspDataBindConfig,String, RspDataBindConfigQo> implements RspDataBindConfigDao {

    @Override
    public List<RspDataBindConfig> findDataBindConfigByOutProId(String outDataPropertyId) {
        return this.find("Select obj from RspDataBindConfig as obj where obj.outDataPropertyDef.dataPropertyId = ? ", outDataPropertyId);
    }

    @Override
    public void deleteByPropertyId(String propertyId) {
        this.executeUpdate("delete from  RspDataBindConfig as obj where obj.outDataPropertyDef.dataPropertyId =?",propertyId);
    }
}
