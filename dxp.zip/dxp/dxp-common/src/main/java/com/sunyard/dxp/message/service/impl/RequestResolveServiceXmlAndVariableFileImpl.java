package com.sunyard.dxp.message.service.impl;

import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import com.sunyard.dxp.utils.Constant;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.dxp.utils.StringUtil;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.*;

/**
 * @Description XML报文+变长文件
 * 文件内容保存到临时文件
 * @Author yubao
 * @Date 2020/1/10 17:46
 * @Version 1.0
 */
@Service( "XmlAndVariableFileResolve" )
@AgreementLibrary( code = "XmlAndVariableFile", name = "XML报文+变长文件" )
public class RequestResolveServiceXmlAndVariableFileImpl implements RequestResolveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestResolveServiceXmlAndVariableFileImpl.class);

    @Autowired
    @Qualifier( "baseResolveServiceVariable" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "regionSign" )
    private SignService regionSignService;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Value( "${config.path}" )
    private String configPath;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 5) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
        if (StringUtils.isEmpty(requestResolveDto.getFileMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_014);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();

        List< ProcotolResolveRule > packRuleList = new ArrayList<>();
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if ("pack".equals(procotolResolveRule.getRuleType())) {
                packRuleList.add(procotolResolveRule);
            } else {
                fileRuleList.add(procotolResolveRule);
            }
        }
        // xml报文规则
        List< ParamRule > packRules = RuleConvertUtils.convertXmlRules(packRuleList.get(0).getChildRules());
        Map< String, Object > pack =
                baseResolveXmlService.execute(packRules, requestResolveDto.getMessage(), requestResolveDto.getEncoding());
        regionSignService.getSign(pack);
        ProcotolResolveRule fileHeadRule = null;
        ProcotolResolveRule fileBodyRule = null;

        // 如果没有文件区域 表示不解析文件
        if (CollectionUtils.isNotEmpty(fileRuleList)) {
            if (fileRuleList.size() > 1) {
                fileHeadRule = fileRuleList.get(0);
                fileBodyRule = fileRuleList.get(1);
            } else {
                fileBodyRule = fileRuleList.get(0);
            }
            readFile(fileHeadRule, fileBodyRule, requestResolveDto.getFileMessage(), pack, requestResolveDto.getEncoding());
        }

        return pack;
    }

    /**
     * 根据文件规则解析变长文件
     *
     * @param fileHeadRule
     * @param fileBodyRule
     * @param fileMessage
     * @param result
     * @param encoding
     */
    private void readFile(ProcotolResolveRule fileHeadRule, ProcotolResolveRule fileBodyRule, String fileMessage, Map< String, Object > result, String encoding) {

        List< ParamRule > fileHeadRules = null;
        // 可能没有文件头存在
        if (fileHeadRule != null) {
            fileHeadRules = RuleConvertUtils.convertVariableRules(fileHeadRule.getChildRules());
        }
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertVariableRules(fileBodyRule.getChildRules());
        // 分隔文件 （\r\n）
        String[] rows = fileMessage.split(fileBodyRule.getSeparatorChar());  // 父级配的分隔符
        List< Map< String, Object > > details = new ArrayList<>();
        for (int i = 0; i < rows.length; i++) {
            // 空行不处理
            if (StringUtils.isEmpty(rows[ i ])) {
                continue;
            }
            String row = rows[ i ];
            // 存在文件头则解析， 不存在则不解析
            if (fileHeadRules != null && i == 0) {
                Map< String, Object > head = baseResolveService.execute(fileHeadRules, row, encoding);
                result.put(fileHeadRule.getName(), head);
                continue;
            }
            Map< String, Object > body =
                    baseResolveService.execute(fileBodyRules, row, new String[] { encoding, fileBodyRules.get(0).getDetailSeparator() });
            details.add(body);
        }
        result.put(MsgKeys.FILE_BODY_DETAIL, details);
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {

        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();

        List< ProcotolResolveRule > packRuleList = new ArrayList<>();  // 报文
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();  // 文件
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if ("pack".equals(procotolResolveRule.getRuleType())) {
                packRuleList.add(procotolResolveRule);
            } else if ("file".equals(procotolResolveRule.getRuleType())) {
                fileRuleList.add(procotolResolveRule);
            }
        }

        // 报文提
        List< ParamRule > packBodyRules = RuleConvertUtils.convertXmlRules(packRuleList.get(0).getChildRules());
        Map< String, Object > resultMap = new HashMap<>();

        //对文件进行操作
        String fileContent = "";
        if (CollectionUtils.isNotEmpty(fileRuleList) && fileRuleList.size() > 0) {
            fileContent = getDetailFile(fileRuleList, map, requestResolveDto.getEncoding());
        }

        // 明细处理的时候，xml中不处理
        map.put(MsgKeys.XML_DETAIL, null);

        // 获取对应的接出或者接入接口
        OutBoundSvc outBoundSvc = packRuleList.get(0).getProcotolResolvePlan().getOutBoundSvc();
        InBoundSvc inBoundSvc = packRuleList.get(0).getProcotolResolvePlan().getInBoundSvc();
        // 添加sign值（1 表示实时业务）
        regionSignService.setSign(
                map, outBoundSvc == null ? inBoundSvc : outBoundSvc, signDto, "2", fileContent);
        Map< String, Object > bodyResult = baseResolveXmlService.mapExecute(packBodyRules, map, requestResolveDto.getEncoding());

        resultMap.put("package", bodyResult.get("package"));  // 报文
        resultMap.put("file", fileContent);   // 文件内容
        return resultMap;
    }

    /**
     * 文件处理
     *
     * @param fileRuleList
     * @param map
     * @return
     */
    private String getDetailFile(List< ProcotolResolveRule > fileRuleList, Map< String, Object > map, String encode) {

        // 默认 fileRuleList 只有一个文件体（写在detailName中）
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertVariableRules(fileRuleList.get(0).getChildRules());

        // 临时文件
        PrintWriter pw = null; // 存储拼接好的明细信息
        BufferedReader br = null;  // 读取转换之后的键值对文件
        String filePath = Constant.TEMP_FILES_PATH + File.separator + "detail_files";
        String fileName = String.format("vardetail_%s_%s_%s",
                DateFormatUtils.format(new Date(), "HHmmss"), Thread.currentThread().getName(), UUIDUtils.getUUID32());
        try {

            // Gzip 要求
            String pwGZIPEncode = encode;
            if (EncoderEnum.ISO88591.getCode().equals(pwGZIPEncode)) {
                pwGZIPEncode = "GB18030";
            }
            pw = new PrintWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(
                                    new File(filePath + File.separator + fileName)),
                            pwGZIPEncode));


            String inDetailFileName = (String) map.get(MsgKeys.XML_DETAIL);  // 转换之后的键值对文件
            Map< Integer, String > sortMap = new TreeMap<>(
                    new Comparator< Integer >() {
                        public int compare(Integer obj1, Integer obj2) {
                            // 升序排序
                            return obj1.compareTo(obj2);
                        }
                    });
            String separator = fileBodyRules.get(0).getDetailSeparator();
            if (StringUtils.isNotBlank(inDetailFileName)) {
                String rowValue = "";

                br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(
                                        new File(inDetailFileName)), "UTF-8"));
                String rowStr = "";
                String[] headArr = null;
                String[] bodyArr = null;
                Map< String, String > rowDetailMap = null;
                int index = 0;
                while (StringUtils.isNotEmpty(rowStr = br.readLine())) {
                    if (index == 0) {
                        headArr = rowStr.split("\\$&\\$");  // 头里面一定不能有空格
                    } else {
                        rowDetailMap = new HashMap<>();
                        bodyArr = rowStr.split("\\$&\\$", -1);
                        for (int i = 0; i < headArr.length; i++) {
                            rowDetailMap.put(headArr[ i ], bodyArr.length >= (i + 1) ? bodyArr[ i ] : "");
                        }
                        for (ParamRule paramRule : fileBodyRules) {
                            if (!StringUtils.isEmpty(paramRule.getName())) {
                                rowValue = rowDetailMap.get(paramRule.getName());
                                //需要按照位置填写
                                sortMap.put(paramRule.getStart(), StringUtil.getDefaultStr(rowValue, ""));
                            }
                        }
                        // 将sortMap 读取成字符串
                        for (Integer key : sortMap.keySet()) {
                            pw.print(sortMap.get(key));
                            pw.print(separator);
                        }
                        pw.print("\n");
                        pw.flush();

                    }
                    index++;
                }
            }
        } catch (Exception e) {
            LOGGER.info("组装明细文件内容失败！[{}]", e);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            pw.close();
        }
        return fileName;
    }
}
