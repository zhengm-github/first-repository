package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 去除换行方法
 */
@FunctionLibrary(code = "strTrim",name = "去除左右空格",expression = "(strTrim\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "all" ,isRelation = false,exp = "strTrim()")
@Component
public class StrTrimFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        return params.trim();
    }
}
