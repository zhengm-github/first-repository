package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.BusiRecordDao;
import com.sunyard.dxp.common.entity.BusiRecord;
import com.sunyard.dxp.common.qo.BusiRecordQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 记录业务信息（请求和响应） jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Jun 09 17:17:29 CST 2020
 */
@Repository
public class JpaBusiRecordDaoImpl extends JpaBaseDaoImpl< BusiRecord, String, BusiRecordQo > implements BusiRecordDao {

    @Override
    public BusiRecord findBySvcCodeAndMsgId(String svcCode, String msgTranId) {

        return findBySingle(getMainQuery() + " where obj.svcCode = ? and obj.msgTranId = ?", svcCode, msgTranId);
    }

    @Override
    public int deleteBySvcCodeAndMsgId(String svcCode, String msgTranId) {

        return executeUpdate(
                "delete from BusiRecord obj where obj.svcCode = ? and obj.msgTranId = ?", svcCode, msgTranId);
    }

    @Override
    public int deleteBySvcRspMsgId(String svcRspMsgId) {
        return executeUpdate(
                "delete from BusiRecord obj where obj.SvcRspMsgId = ? ", svcRspMsgId);
    }

    @Override
    public List< BusiRecord > findByMsgId(String msgTranId) {
        return find(getMainQuery() + " where obj.msgTranId = ?", msgTranId);
    }
}
