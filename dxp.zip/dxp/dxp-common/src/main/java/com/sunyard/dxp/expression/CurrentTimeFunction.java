package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author Thud
 * @date 2020/1/3 14:54
 */
@FunctionLibrary(code = "currentTime",name = "生成当前时间(pattern)",expression = "(currentTime\\()([A-Za-z:]+)(\\))",exp = "currentTime(HHmmss)")
@Component
public class CurrentTimeFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if(params.length()< 6){
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        return DateFormatUtils.format(new Date(), params);
    }
}
