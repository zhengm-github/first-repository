package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 请求报文映射配置 QO
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:15:01 CST 2020
   */
public class ReqDataMapConfigQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6445809292083663924L;

}
