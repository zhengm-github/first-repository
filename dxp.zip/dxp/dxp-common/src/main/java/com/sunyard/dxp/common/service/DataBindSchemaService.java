package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.DataBindSchema;
import com.sunyard.dxp.common.qo.DataBindSchemaQo;
import com.sunyard.frameworkset.core.service.BaseService;

import java.util.List;

/**
 * 数据绑定模式 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:53 CST 2019
 */
public interface DataBindSchemaService extends BaseService< DataBindSchema, String, DataBindSchemaQo > {

    /**
     * 根据outBoundSvcIds 查询
     * @param outBoundSvcIds
     * @return
     */
    List<DataBindSchema> findByOutBoundSvcIds(String... outBoundSvcIds) ;

    /**
     * 根据outBoundSvcId 查找绑定模式
     * @param id
     * @return
     */
    DataBindSchema findDataBindSchemaByOutBoundSvcId(String id);

    /**
     * 获取绑定模式
     * @param ibsId
     * @param obsId
     * @return
     */
    List<DataBindSchema> findDataBindSchemaByIbsIdAndObSId(String ibsId,String obsId);

    /**
     * 根据接出模块删除
     * @param obsId
     */
    void deleteByObsId(String obsId) ;
}
