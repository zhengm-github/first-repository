package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 代码类型转换
 *
 * @author zhengm
 * @Date 20200507
 */
@FunctionLibrary( code = "codeTypeMapper", name = "代码类型转换（全国 -> 单位）", expression = "(codeTypeMapper\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "codeTypeMapper()", hasProperty = true )
@Component
public class CodeTypeMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            //表达式参数不准确
            return "";
        }
        try {
            String value = ExpMapper.codeTypeMap.get(params);
            if (StringUtils.isBlank(value)) {
                value = ExpMapper.codeTypeMap.get("default") ;
                if(StringUtils.isBlank(value)){
                    throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
                }
            }
            return value;
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                    DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
        }

    }
}
