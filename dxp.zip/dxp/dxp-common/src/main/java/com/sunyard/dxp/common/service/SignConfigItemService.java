package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.dxp.common.qo.SignConfigItemQo;

/**
 * 签名配置项 service 接口
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:49:49 CST 2020
 */
public interface SignConfigItemService extends BaseService<SignConfigItem, String, SignConfigItemQo> {

    /**
     * 按照dataPropertyId删除
     * @param dataPropertyId
     */
    void deleteByDataPropertyId(String dataPropertyId);

    /**
     * 获取库中最大的ord
     * @param dataObjDefId
     */
    int getMaxOrd(String dataObjDefId);
}
