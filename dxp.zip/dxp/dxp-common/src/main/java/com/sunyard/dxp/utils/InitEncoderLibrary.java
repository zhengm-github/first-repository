package com.sunyard.dxp.utils;

import com.sunyard.dxp.common.entity.Encoder;
import org.reflections.Reflections;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Thud
 * @date 2020/2/26 13:36
 * 编码初始化
 */
@Configuration
public class InitEncoderLibrary {

    @Bean("encoders")
    public List<Encoder> init() {
        Reflections f = new Reflections("com.sunyard.dxp.security.encoder.impl");
        Set<Class<?>> set = f.getTypesAnnotatedWith(EncoderLibrary.class);
        List<Encoder> list = new ArrayList<>();
        for (Class<?> c : set) {
            EncoderLibrary encoderlibrary = c.getAnnotation(EncoderLibrary.class);
            Encoder encoder = new Encoder();
            encoder.setCode(encoderlibrary.code());
            encoder.setName(encoderlibrary.name());
            list.add(encoder);
        }
        return list;
    }
}
