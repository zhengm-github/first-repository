package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.InBoundSvcDao;
import com.sunyard.dxp.common.entity.DataPropertyDef;
import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.dxp.common.entity.SignConfigSchema;
import com.sunyard.dxp.common.qo.InBoundSvcQo;
import com.sunyard.dxp.common.service.InBoundSvcService;
import com.sunyard.dxp.expression.ParamExpression;
import com.sunyard.dxp.message.factory.ServiceFactory;
import com.sunyard.dxp.utils.StringUtil;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 接入服务接口 service
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:54:51 CST 2019
 */
@Service
public class InBoundSvcServiceImpl extends BaseServiceImpl< InBoundSvc, String, InBoundSvcQo > implements InBoundSvcService {

    @Autowired
    private InBoundSvcDao inBoundSvcDao;

    @Override
    public List< InBoundSvc > inBoundsQueryBySvcBoundId(String serviceBundleId) {

        InBoundSvcQo inBoundSvcQo = new InBoundSvcQo() ;
        inBoundSvcQo.setServiceBundleId(serviceBundleId);
        inBoundSvcQo.setBind(true);  // 绑定
        return inBoundSvcDao.findPartInBound(inBoundSvcQo) ;
    }

    @Override
    public List< InBoundSvc > findPartInBound(InBoundSvcQo inBoundSvcQo) {
        return inBoundSvcDao.findPartInBound(inBoundSvcQo) ;
    }

    @Override
    public InBoundSvc findByCode(String code) {
        return inBoundSvcDao.findByCode(code);
    }

    @Override
    public String packSignData(InBoundSvc inBoundSvc, Map< String, Object > resolve) {
        SignConfigSchema inSignConfigSchema = inBoundSvc.getInSignConfigSchema();
        if (inSignConfigSchema == null) {
            return "";
        }
        String connector = inSignConfigSchema.getConnector();
        //1.排序
        Set< SignConfigItem > signConfigItemSet = inSignConfigSchema.getSignConfigItems();
        List< SignConfigItem > signConfigItemList = new ArrayList<>(signConfigItemSet);
        Collections.sort(signConfigItemList, (o1, o2) -> o1.getOrd() > o2.getOrd() ? 1 : -1);

        StringBuilder signSrc = new StringBuilder();
        StringBuilder propertyXpath = null;
        for (int i = 0; i < signConfigItemList.size(); i++) {
            SignConfigItem signItem = signConfigItemList.get(i);
            DataPropertyDef dataPropertyDef = signItem.getDataPropertyDef();
            //2.获取签名属性值  (使用全路径)
            // 父级就是 filebody 和 fileheader / header / body 的不加 /
            propertyXpath = new StringBuilder(dataPropertyDef.getName());
            if (dataPropertyDef.getParent() != null
                    && !("filebody".equals(dataPropertyDef.getParent().getName())
                    || "fileheader".equals(dataPropertyDef.getParent().getName())
                    || "header".equals(dataPropertyDef.getParent().getName())
                    || "body".equals(dataPropertyDef.getParent().getName()))) {  // 有定长情况
                propertyXpath.insert(0, "/");
                while (dataPropertyDef.getParent() != null) {
                    propertyXpath.insert(0, "/" + dataPropertyDef.getParent().getName());
                    dataPropertyDef = dataPropertyDef.getParent();
                }
            }

            String singValue = StringUtil.getDefaultStr(resolve.get(propertyXpath.toString()), "");
            String expSrc = signItem.getExp();
            String computeValue = "";
            if (StringUtils.isNotEmpty(expSrc)) {
                //3.根据表达式计算属性值

                // 表达式可能有参数
                String expParam = StringUtils.isNotBlank(signItem.getParam()) ? (signItem.getParam() + ",") : "";
                computeValue = ServiceFactory.getBeanStatic(expSrc + "Function", ParamExpression.class).
                        expCompute(expParam + singValue);
            } else {
                computeValue = singValue;
            }
            //4.拼接
            if (i == signConfigItemList.size() - 1) {
                signSrc.append(computeValue);
            } else {
                signSrc.append(computeValue).append(connector);
            }
        }
        return signSrc.toString();
    }
}
