package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.*;
import com.sunyard.dxp.common.entity.ReqDataMapConfig;
import com.sunyard.dxp.common.entity.RspDataBindConfig;
import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.DataPropertyDefService;
import com.sunyard.dxp.common.entity.DataPropertyDef;
import com.sunyard.dxp.common.qo.DataPropertyDefQo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 数据属性定义 service
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:55 CST 2019
 */
@Service
public class DataPropertyDefServiceImpl extends BaseServiceImpl< DataPropertyDef, String, DataPropertyDefQo > implements DataPropertyDefService {

    @Autowired
    private DataPropertyDefDao dataPropertyDefDao;

    @Autowired
    private SignConfigItemDao signConfigItemDao ;

    @Autowired
    private DataMapPropertyDefRelaDao dataMapPropertyDefRelaDao ;

    @Autowired
    private DataBindPropertyDefRelaDao dataBindPropertyDefRelaDao ;

    @Autowired
    private ReqDataMapConfigDao reqDataMapConfigDao ;

    @Autowired
    private RspDataBindConfigDao rspDataBindConfigDao ;

    @Override
    public DataPropertyDef mergeDataPropertyDef(DataPropertyDef data, DataPropertyDef temp) {

        data.setParent(temp.getParent());
        data.setDataType(temp.getDataType());
        data.setName(temp.getName());
        data.setMemo(temp.getMemo());
        data.setOptional(temp.getOptional());
        data.setSignConfigItems(temp.getSignConfigItems());  // 签名项
        return data;
    }


    @Override
    public List< DataPropertyDef > findPropertyDefByResultDefId(String dataObjDefId) {
        return dataPropertyDefDao.findPropertyDefByResultDefId(dataObjDefId);
    }

    @Override
    public DataPropertyDef findByName(String name, String dataObjDefId,String parentId) {
        return dataPropertyDefDao.findByName(name, dataObjDefId, parentId);
    }

    @Override
    public List< DataPropertyDef > findBySvcId(String dataKind, String svcId, String svcType) {
        return dataPropertyDefDao.findBySvcId(dataKind, svcId, svcType);
    }

    @Override
    public List< DataPropertyDef > findPropertyDefByObjDefId(String dataObjDefId) {
        return dataPropertyDefDao.findPropertyDefByObjDefId(dataObjDefId);
    }

    @Override
    public void deletePropertyDefByDataObjDefIds(String... dataObjDefIds) {
        if (StringUtils.isNoneBlank(dataObjDefIds)) {
            for (String id : dataObjDefIds) {
                dataPropertyDefDao.deletePropertyDefByObjDefId(id);
            }
        }
    }

    @Override
    public void deletePropertyDefAllNodeByParentIds(boolean isOut, String... propertyIds) {
        try {
            for (String id : propertyIds) {
                DataPropertyDef dataPropertyDef = dataPropertyDefDao.findById(id);
                if (dataPropertyDef!=null && CollectionUtils.isNotEmpty(dataPropertyDef.getChildProperties())) {
                    for (DataPropertyDef obj : dataPropertyDef.getChildProperties()) {
                        deletePropertyDefAllNodeByParentIds(isOut, obj.getDataPropertyId());
                    }
                }
                deleteProperties(dataPropertyDef,isOut);
                dataPropertyDefDao.flush();  // 循环批量删除数据库可能锁表
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void deleteProperties(DataPropertyDef dataPropertyDef, boolean isOut) {
        if (dataPropertyDef != null && CollectionUtils.isNotEmpty(dataPropertyDef.getSignConfigItems())) {
            // 先删除item
            for (SignConfigItem item : dataPropertyDef.getSignConfigItems()) {
                signConfigItemDao.delete(item);
            }
        }
        //Set<ReqDataMapConfig> reqDataMapConfigs = dataPropertyDef.getOutReqDataMapConfigs();
        Set<ReqDataMapConfig> reqDataMapConfigs = isOut==true?dataPropertyDef.getOutReqDataMapConfigs():dataPropertyDef.getInReqDataMapConfigs();
        if (CollectionUtils.isNotEmpty(reqDataMapConfigs)) {
            for (ReqDataMapConfig reqDataMapConfig : reqDataMapConfigs) {
                dataMapPropertyDefRelaDao.deleteByConfig(reqDataMapConfig.getDataMapConfigId());
                reqDataMapConfigDao.delete(reqDataMapConfig);
                reqDataMapConfigDao.flush();  // 循环批量删除数据库可能锁表
            }
        }
        Set<RspDataBindConfig> rspDataBindConfigs = dataPropertyDef.getInRspDataBindConfigs();
        if (CollectionUtils.isNotEmpty(rspDataBindConfigs)) {
            for (RspDataBindConfig rspDataBindConfig : rspDataBindConfigs) {
                dataBindPropertyDefRelaDao.findByDataBindConfigId(rspDataBindConfig.getDataBindConfigId());
                rspDataBindConfigDao.delete(rspDataBindConfig);
                rspDataBindConfigDao.flush();  // 循环批量删除数据库可能锁表
            }
        }

        dataPropertyDefDao.delete(dataPropertyDef);
    }

    @Override
    public List< DataPropertyDef > findInPropByObs(String obsId) {
        return dataPropertyDefDao.findInPropByObs(obsId);
    }

    @Override
    public List< DataPropertyDef > findInConfigPropByIbs(String ibsId, String dataKind) {
        List< DataPropertyDef > dataPropertyDefs = dataPropertyDefDao.findInPropByIbs(ibsId, dataKind);
        dataPropertyDefs = findConfigProp(dataPropertyDefs);
        return dataPropertyDefs;
    }

    @Override
    public List< DataPropertyDef > findOutConfigPropByObs(String obsId, String dataKind) {
        List< DataPropertyDef > dataPropertyDefs = dataPropertyDefDao.findOutPropByObs(obsId, dataKind);
        dataPropertyDefs = findConfigProp(dataPropertyDefs);
        return dataPropertyDefs;
    }

    private List< DataPropertyDef > findConfigProp(List< DataPropertyDef > dataPropertyDefs) {
        List< DataPropertyDef > configDataPropertyDefs = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(dataPropertyDefs)) {
            for (DataPropertyDef dataPropertyDef : dataPropertyDefs) {
                if (dataPropertyDef != null) {
                    List<DataPropertyDef> dataPropertyDefList = dataPropertyDefDao.findChild(dataPropertyDef.getDataPropertyId());
                    if (CollectionUtils.isNotEmpty(dataPropertyDefList)) {
                        configDataPropertyDefs.addAll(findConfigProp(dataPropertyDefList));
                    } else {
                        configDataPropertyDefs.add(dataPropertyDef);
                    }
                }
            }
        }
        return configDataPropertyDefs;
    }
}
