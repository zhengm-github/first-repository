package com.sunyard.dxp.security.sign.impl;


import com.sunyard.dxp.security.sign.Signature;
import com.sunyard.dxp.utils.SignatureLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@SignatureLibrary(code = "MD5Signature" , name = "MD5签名")
public class MD5Signature implements Signature {
    private static final Logger LOGGER = LoggerFactory.getLogger( MD5Signature.class );


    @Override
    public String sign(String src,String key){
        StringBuilder buf = new StringBuilder("");
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update((src+key).getBytes(StandardCharsets.UTF_8));
            byte[] b = md.digest();
            int i;
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
        } catch (Exception e) {
            LOGGER.error("MD5签名失败");
            throw new FapException("","MD5签名失败");
        }
        return buf.toString();
    }
}
