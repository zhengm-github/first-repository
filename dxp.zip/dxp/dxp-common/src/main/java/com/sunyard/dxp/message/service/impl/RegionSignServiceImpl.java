package com.sunyard.dxp.message.service.impl;

import cn.hutool.core.codec.Base64;
import com.alibaba.fastjson.JSONObject;
import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.service.InBoundSvcService;
import com.sunyard.dxp.common.service.OutBoundSvcService;
import com.sunyard.dxp.constants.CommonConstants;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.SignEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.security.sign.Signature;
import com.sunyard.dxp.utils.*;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.pqc.math.linearalgebra.ByteUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * 解析和组装签名域
 *
 * @author zhengm
 */
@Service( "regionSign" )
public class RegionSignServiceImpl implements SignService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RegionSignServiceImpl.class);

    @Value( "${unit.code}" )
    private String unitCode;

    @Value( "${config.path}" )
    private String configPath;

    @Autowired
    private OutBoundSvcService outBoundSvcService;

    @Autowired
    private InBoundSvcService inBoundSvcService;

    private String encode = "UTF-8";

    private String apiType = "newAPI";  // 调用密押机的哪个api

    @Override
    public String getSign(Map< String, Object > dataMap) {

        // 根据不同区域解析出 对应的sign
        Iterator< String > it = dataMap.keySet().iterator();

        String sign = "";
        String batchSign = "";
        String myjOrg = "";
        String key = "";
        String macFlag = ""; // 判断是单笔还是批量业务核押
        while (it.hasNext()) {
            key = it.next();
            if (key.endsWith("PayKey")) {
                sign = dataMap.get(key).toString();
                macFlag = "1";
            } else if (key.endsWith("FileMac")) {
                batchSign = dataMap.get(key).toString();
                macFlag = "2";
            } else if (key.endsWith("MsgHdrRq/Originator")) {
                myjOrg = dataMap.get(key).toString();
            }
        }
        if ("1".equals(macFlag)) {
            dataMap.put(CommonConstants.SIGN, sign);
        } else if ("2".equals(macFlag)) {
            dataMap.put(CommonConstants.BATCHSIGN, batchSign);
        }
        dataMap.put(CommonConstants.MYJ_ORG, myjOrg);

        return "";
    }

    @Override
    public String setSign(Map< String, Object > dataMap, Object objSvc, SignDto signDto, String macFlag, String fileName) {

        if (!"1".equals(Constant.NEED_ENCRYPT) || StringUtils.isBlank(signDto.getSignAlgol())) {
            LOGGER.info("无需编押处理...");
            return "";  // 密押机没有配置，不调用密押机
        }

        String srcStr = "";  //需要核押的串
        String key = "";  //循环使用的key
        String signKey = "";  // 实时业务sign保存的key
        String batchSignKey = "";  // 批量业务sign保存的key
        String mac = "";  // 最终的sign
        // 可能是接入也可能是接出
        if ("1".equals(macFlag)) {
            if (objSvc instanceof OutBoundSvc) {
                OutBoundSvc outBoundSvc = (OutBoundSvc) objSvc;
                srcStr = outBoundSvcService.packSignData(outBoundSvc, dataMap);
            } else if (objSvc instanceof InBoundSvc) {
                InBoundSvc inBoundSvc = (InBoundSvc) objSvc;
                srcStr = inBoundSvcService.packSignData(inBoundSvc, dataMap);
            }
        } else if ("2".equals(macFlag)) {

            // 批量是计算文件内容的MD5值对应的Mac
//            srcStr = MD5Util.update(fileContent);
            srcStr = MD5Util.getFileMD5(Constant.TEMP_FILES_PATH + File.separator + "detail_files", fileName) ;
        }

        mac = getMIYA(signDto, srcStr);
        // 根据不同区域解析出 对应的sign
        Iterator< String > it = dataMap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            if (key.endsWith("PayKey")) {
                signKey = key;
                break;
            } else if (key.endsWith("FileMac")) {
                batchSignKey = key;
                break;
            }
        }
        // 给map赋数据
        if ("1".equals(macFlag)) {
            dataMap.put(signKey, mac);
        } else if ("2".equals(macFlag)) {
            dataMap.put(batchSignKey, mac);
        }

        return "";
    }

    @Override
    public String validateSign(SignDto signDto, String xmlBody, String pacSign) {

        // 没有配置则不校验
        if (StringUtils.isEmpty(signDto.getSignAlgol()) || !"1".equals(Constant.NEED_ENCRYPT)) {
            LOGGER.info("无需核押...");
            return xmlBody;
        }

        try {

            // 通过密押机获取到 key
            String key = Base64.encode(getMIYA(signDto, xmlBody)).substring(0, 16);// 截取前16位
            //  再base处理一次
            key = Base64.encode(key);
            LOGGER.info("解密使用的最终key 为： [{}]", key);

            // 先对xml部分解密
            String baseXml = SM4Util.base64Decode(xmlBody); // 先base处理
            String showXml = SM4Util.decryptEcb01(key, baseXml);  // sign +xml, 解密结果是 16进制
            LOGGER.info("解密之后的十六进制报文：[{}]", showXml);

            String xml = new String(ByteUtils.fromHexString(showXml.substring(64)), "GBK").trim() + "\n";
            // 截取xml部分
            pacSign = showXml.substring(0, 64);  // 请求报文的 sign部分, 16进制
            // 再对xml部分核押
            boolean validate = pacSign.toUpperCase().equals(SM3Util.encryptTo16(xml + key).toUpperCase()); // 基本算法
            if (validate) {
                LOGGER.info("解密之后的明文内容：[{}]", xml);
                return xml;
            } else {
                LOGGER.error("报文解密或核押失败！pacSign=[{}], xml=[{}]", pacSign, xml);
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_VALIDATE_FAIL);
            }
        } catch (UnsupportedEncodingException e) {
            LOGGER.info("核押失败！，[{}]", e);
        } catch (Exception e) {
            LOGGER.info("核押失败！，[{}]", e);
        }
        return "";
    }

    @Override
    public Map< String, String > makeSign(SignDto signDto, String xmlBody) {
        // 没有配置则产生空的串
        Map< String, String > dataMap = new HashMap<>();
        if (StringUtils.isEmpty(signDto.getSignAlgol()) || !"1".equals(Constant.NEED_ENCRYPT)) {
            dataMap.put(CommonConstants.SIGN, "");
            dataMap.put("xmlBody", xmlBody);
            return dataMap;
        }

//        步骤：
//        1.对 节点号 调用密押机计算MAC，并base64编码，作为key。sm3算法。
//        2.第1步计算出的key，和xml报文一起计算押。使用sm3软算法。
//        3.第二步计算出的押，和xml报文， 使用第一步计算的key，进行加密。sm4软加密。
        try {

            LOGGER.info("加密之前的报文内容为： [{}]", xmlBody);
            // 通过密押机获取到 key
            String key = Base64.encode(getMIYA(signDto, xmlBody)).substring(0, 16);// 截取前16位
            //  再base处理一次
            key = Base64.encode(key);

            LOGGER.info("加密使用的最终key为： [{}]", key);

            // 先对xml部分编押
            String baseSign = SM3Util.encryptTo16(xmlBody + key).toUpperCase();
            xmlBody = StringUtil.addTo16(xmlBody, "GBK");  // 加押之后补位
            byte[] signByte = ByteUtils.fromHexString(baseSign);
            byte[] xmlByte = xmlBody.getBytes("GBK");
            byte[] xByte = new byte[ signByte.length + xmlByte.length ];
            System.arraycopy(signByte, 0, xByte, 0, signByte.length);
            System.arraycopy(xmlByte, 0, xByte, signByte.length, xmlByte.length);
            LOGGER.info("全报文十六进制：[{}]", ByteUtils.toHexString(xByte));

            // 再对xml部分加密 (sign 和 xml 一起加密)
            String encodeXml = SM4Util.encryptEcb01(key, xByte);
            dataMap.put("xmlBody", SM4Util.base64Encode(encodeXml));

        } catch (UnsupportedEncodingException e) {
            LOGGER.info("编押失败！，[{}]", e);
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_VALIDATE_FAIL);
        } catch (Exception e) {
            LOGGER.info("编押失败！，[{}]", e);
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_VALIDATE_FAIL);
        }
        return dataMap;
    }

    /**
     * 调用密押机获取编押需要的key
     *
     * @param signDto 核押方式
     * @param srcStr  加密部分内容
     * @return
     */
    private String getMIYA(SignDto signDto, String srcStr) {

        Signature signature = SignEnum.getSignatureStrategy(signDto.getSignAlgol());

        Properties prop = null;
        String myjRegion = "310000";  //默认
        String myjVersion = "";
        String myjAlgorithm = "";
        String myjNodecode = "";
        try {
            prop = PropUtil.getProperties(
                    configPath + File.separator + "common" + File.separator + "myj-region.properties", encode);
            myjRegion = prop.getProperty(MsgKeys.MYJ_REGION, "310000");
            myjVersion = prop.getProperty(MsgKeys.MYJ_VERSION, "008");
            myjAlgorithm = prop.getProperty(MsgKeys.MYJ_ALGORITHM, "1");
            myjNodecode = prop.getProperty(MsgKeys.MYJ_NODECODE);

        } catch (Exception e) {
            LOGGER.error("报文获取sign失败.(读取密押机配置文件失败 , common/myj-region.properties)");
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_VALIDATE_FAIL);
        }

        LOGGER.info("密押机参数:[region={}, encode={}, version={} , nodecode={}, algorithm={}]",
                myjRegion, encode, myjVersion, myjNodecode, myjAlgorithm);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(MsgKeys.MYJ_REGION, myjRegion);
        jsonObject.put(MsgKeys.MYJ_ENCODE, encode);
        jsonObject.put(MsgKeys.MYJ_VERSION, myjVersion);
        jsonObject.put(MsgKeys.MYJ_ALGORITHM, myjAlgorithm);

        // 根据不同地区区分加押什么内容
        switch (unitCode) {
            case "nb":
                jsonObject.put(MsgKeys.MYJ_MESSAGE, myjNodecode);  // 使用节点号 计算出对应的key
                jsonObject.put(apiType, "1");  // 是否使用新版密押机接口1
                break;
            case "nn":
                jsonObject.put(MsgKeys.MYJ_MESSAGE, srcStr);
                jsonObject.put(apiType, "2");  // 是否使用新版密押机接口2
                break;
            case "sz":
                jsonObject.put(MsgKeys.MYJ_MESSAGE, srcStr);
                jsonObject.put(apiType, "3");  // 是否使用新版密押机接口2
                break;
            default:
                jsonObject.put(MsgKeys.MYJ_MESSAGE, srcStr);
                break;

        }

        String mac = signature.sign(jsonObject.toJSONString(), signDto.getSignPrivateKey());
        if (StringUtils.isBlank(mac)) {
            LOGGER.info("密押机调用失败！");
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_VALIDATE_FAIL);
        }
        return mac;

    }
}
