package com.sunyard.dxp.message.service.impl;

import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import com.sunyard.dxp.utils.Constant;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.*;
import java.util.*;

/**
 * @Description XML报文+定长文件
 * <p>
 * 文件内容保存到临时文件
 * @Author zhangxin
 * @Date 2020/1/10 17:46
 * @Version 1.0
 */
@Service( "XmlAndFixedFileResolve" )
@AgreementLibrary( code = "XmlAndFixedFile", name = "XML报文+定长文件" )
public class RequestResolveServiceXmlAndFixedFileImpl implements RequestResolveService {


    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Value( "${config.path}" )
    private String configPath;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 5) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
        if (StringUtils.isEmpty(requestResolveDto.getFileMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_014);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        // xml报文规则
        List< ParamRule > packRules = RuleConvertUtils.convertXmlRules(ruleList.get(0).getChildRules());
        Map< String, Object > pack = baseResolveXmlService.execute(packRules, requestResolveDto.getMessage(), requestResolveDto.getEncoding());
        ProcotolResolveRule fileHeadRule = null;
        ProcotolResolveRule fileBodyRule = null;
        // 解析文件
        if (ruleList.get(1).getLinNum() == 1) {   // 文件头和body都存在
            fileHeadRule = ruleList.get(1);
            fileBodyRule = ruleList.get(2);
        } else if (ruleList.get(1).getLinNum() == 0) {  // 文件头不存在
            fileBodyRule = ruleList.get(1);
        } else {
            fileHeadRule = ruleList.get(2);
            fileBodyRule = ruleList.get(1);
        }
        readFile(fileHeadRule, fileBodyRule, requestResolveDto.getFileMessage(), pack, requestResolveDto.getEncoding());
        return pack;
    }

    /**
     * 文件部分读取
     *
     * @param fileHeadRule
     * @param fileBodyRule
     * @param fileMessage
     * @param result
     * @param encoding
     */
    private void readFile(ProcotolResolveRule fileHeadRule, ProcotolResolveRule fileBodyRule, String fileMessage, Map< String, Object > result, String encoding) {

        List< ParamRule > fileHeadRules = null;
        // 可能没有文件头存在
        if (fileHeadRule != null) {
            fileHeadRules = RuleConvertUtils.convertFixedRules(fileHeadRule.getChildRules());
        }
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertFixedRules(fileBodyRule.getChildRules());
        // 分隔文件
        String[] rows = fileMessage.split(fileBodyRule.getSeparatorChar());
        List< Map< String, Object > > details = new ArrayList<>();
        for (int i = 0; i < rows.length; i++) {
            // 空行不处理
            if (StringUtils.isEmpty(rows[ i ])) {
                continue;
            }
            // 存在文件头则解析， 不存在则不解析
            if (fileHeadRules != null && i == 0) {
                Map< String, Object > head = baseResolveService.execute(fileHeadRules, rows[ i ], new String[] { encoding, "", "", "char" });
                result.put(fileHeadRule.getName(), head);
                continue;
            }
            Map< String, Object > body = baseResolveService.execute(fileBodyRules, rows[ i ], new String[] { encoding, "", "", "char" });
            details.add(body);
        }
        result.put(fileBodyRule.getName(), details);
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        List< ProcotolResolveRule > list = new ArrayList<>();  // 只保存报文的
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if (("pack").equals(procotolResolveRule.getRuleType())) {
                list.add(procotolResolveRule);
            }
        }
        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(list.get(0).getChildRules());
        Map< String, Object > resultMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();

        //文件信息 单独处理
        String fileContent = getDetailFile(ruleList, map, requestResolveDto.getEncoding());
        map.put(MsgKeys.XML_DETAIL, null);
        Map< String, Object > bodyResult = baseResolveXmlService.mapExecute(bodyRules, map, requestResolveDto.getEncoding());

        sb.append(bodyResult.get("package"));
        resultMap.put("package", sb.toString());
        resultMap.put("file", fileContent);
        return resultMap;
    }


    /**
     * 文件处理
     *
     * @param ruleList
     * @param map
     * @return
     */
    private String getDetailFile(List< ProcotolResolveRule > ruleList, Map< String, Object > map, String encode) {
        List< ProcotolResolveRule > list = new ArrayList<>(); // 只保存文件的
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if (("file").equals(procotolResolveRule.getRuleType())) {
                list.add(procotolResolveRule);
            }
        }
        if (CollectionUtils.isEmpty(list) || list.size() < 1) {
            return "";
        }

        List< ParamRule > fileBodyRules = RuleConvertUtils.convertFixedRules(list.get(0).getChildRules());

        String colSep = list.get(0).getSeparatorChar();
        // 下面的逻辑没有生成文件头！！！
//        StringBuilder fileBuff = new StringBuilder();
        // 临时文件
        PrintWriter pw = null; // 存储拼接好的明细信息
        BufferedReader br = null;  // 读取转换之后的键值对文件
        String filePath = Constant.TEMP_FILES_PATH + File.separator + "detail_files";
        String fileName = String.format("fixdetail_%s_%s_%s",
                DateFormatUtils.format(new Date(), "HHmmss"), Thread.currentThread().getName(), UUIDUtils.getUUID32());
        try {

            // Gzip 要求
            String pwGZIPEncode = encode;
            if (EncoderEnum.ISO88591.getCode().equals(pwGZIPEncode)) {
                pwGZIPEncode = "GB18030";
            }
            pw = new PrintWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(
                                    new File(filePath + File.separator + fileName)),
                            pwGZIPEncode));

            String inDetailFileName = (String) map.get(MsgKeys.XML_DETAIL);
            if (StringUtils.isNotBlank(inDetailFileName)) {
                // 按照指定规则写到file中(确保 父级配置时一定是filebody)
                Map< Integer, String > sortMap = new TreeMap<>(
                        new Comparator< Integer >() {
                            public int compare(Integer obj1, Integer obj2) {
                                // 升序排序
                                return obj1.compareTo(obj2);
                            }
                        });

                String rowValue = "";
                br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(
                                        new File(inDetailFileName)), "UTF-8"));
                String rowStr = "";
                String[] headArr = null;
                String[] bodyArr = null;
                Map< String, String > rowDetailMap = null;
                int index = 0;
                while (StringUtils.isNotEmpty(rowStr = br.readLine())) {
                    if (index == 0) {
                        headArr = rowStr.split("\\$&\\$");  // 头里面一定不能有空格
                    } else {
                        rowDetailMap = new HashMap<>();
                        bodyArr = rowStr.split("\\$&\\$", -1);
                        for (int i = 0; i < headArr.length; i++) {
                            rowDetailMap.put(headArr[ i ], bodyArr.length >= (i + 1) ? bodyArr[ i ] : "");
                        }
                        for (ParamRule paramRule : fileBodyRules) {
                            if (!StringUtils.isEmpty(paramRule.getDetailName())) {
                                rowValue = rowDetailMap.get(paramRule.getXpath());
                                if (rowValue != null) {
                                    //需要按照位置填写
                                    sortMap.put(paramRule.getStart(),
                                            StringUtil.formatStr(rowValue, paramRule.getLength(), " ", false));
                                }
                            }
                        }
                        // 将sortMap 读取成字符串
                        for (Integer key : sortMap.keySet()) {
                            pw.print(sortMap.get(key));
                        }
                        pw.print(colSep);
                        pw.flush();
                    }
                    index++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pw.close();
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return fileName;
    }
}
