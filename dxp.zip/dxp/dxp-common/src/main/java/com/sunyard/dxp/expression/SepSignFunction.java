package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 *
 * 按照位置对函数进行分割， 并使用下划线拼接(a 为前面结束位置)
 * @author Thud
 * @date 2020/1/2 16:06
 */
@FunctionLibrary(code = "sepSign",name = "分割拼接(a_b)",expression = "(sepSign\\()([_\\@0-9\\,]+\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "sepSign(8@_)",hasProperty = true)
@Component
public class SepSignFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        //sepSign(1@_,123)  --> 1_23
        String[] param = params.split("@");
        if(param.length!=2){
            return "" ;
        }
        String[] property = param[1].split(",",-1);
        if(property.length!=2){
            return "" ;
        }
        String startStr = property[1].substring(0, Integer.parseInt(param[0])) ;
        String endStr = property[1].substring(Integer.parseInt(param[0])) ;

        return startStr + property[0] + endStr ;
    }
}
