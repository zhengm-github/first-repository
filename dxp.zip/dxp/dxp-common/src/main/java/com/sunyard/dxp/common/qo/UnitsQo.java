package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 单位 QO
 *
 * Author: Created by code generator
 * Date: Wed Dec 25 19:35:40 CST 2019
   */
public class UnitsQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7858456048605042408L;

    /** 单位代码 */
    private String code;

    /** 单位名称 */
    private String name;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
