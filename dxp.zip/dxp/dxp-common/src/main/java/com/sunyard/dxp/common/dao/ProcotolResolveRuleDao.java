package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.common.qo.ProcotolResolveRuleQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 协议解析规则 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:59 CST 2020
 */
public interface ProcotolResolveRuleDao extends BaseDao<ProcotolResolveRule, String, ProcotolResolveRuleQo> {

    /**
     * 根据name查询
     * @param name
     * @return
     */
    ProcotolResolveRule findByName(String name) ;

    /**
     * 根据detailName
     * @param detailName
     * @return
     */
    ProcotolResolveRule findByDetailName(String detailName) ;
    /**
     * 根据协议解析计划ID查询协议解析规则
     * @param planId
     * @return
     */
    List<ProcotolResolveRule> findByPlanId(String planId);

    /**
     * 根据父ID查询协议解析规则
     * @param parentId
     * @return
     */
    List<ProcotolResolveRule> findByParentId(String parentId);

    /**
     * 根据id查询子级解析规则
     * @param id
     * @return
     */
    List<ProcotolResolveRule> findChildRule(String id);

}
