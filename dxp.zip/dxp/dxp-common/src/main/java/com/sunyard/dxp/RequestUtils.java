package com.sunyard.dxp;

import com.alibaba.fastjson.JSONObject;
import com.sunyard.dxp.constants.CommonConstants;
import com.sunyard.dxp.utils.JSONUtil;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.collections.MapUtils;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Thud
 * @date 2019/12/16 15:03
 */
public class RequestUtils {

    private static final Logger log = LoggerFactory.getLogger(RequestUtils.class);

    public RequestUtils( ) {
    }

    private static class TrustAnyTrustManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public X509Certificate[] getAcceptedIssuers( ) {
            return new X509Certificate[] { };
        }
    }

    private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    public static String doGet(String url) {
        CloseableHttpResponse response = null;
        String result = "";
        // 通过址默认配置创建一个httpClient实例
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // 创建httpGet远程连接实例
            HttpGet httpGet = new HttpGet(url);
            // 为httpGet实例设置配置
            RequestConfig requestConfig = RequestConfig.custom()
                    .setSocketTimeout(30 * 60 * 1000)
                    .setConnectTimeout(30 * 1000)
                    .setConnectionRequestTimeout(10 * 1000)
                    .build();
            httpGet.setConfig(requestConfig);
            // 执行get请求得到返回对象
            response = httpClient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            result = EntityUtils.toString(entity);
        } catch (IOException e) {
            throw new FapException("", "Get请求失败");
        }
        return result;
    }


    /**
     * 发送键值对
     *
     * @param url
     * @param param
     * @return
     */
    public static Map< String, Object > doPost(String url, Map< String, Object > param) {
        CloseableHttpResponse response = null;
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);
            // 设置 http参数
            RequestConfig requestConfig = RequestConfig.custom()
                    .setSocketTimeout(30 * 60 * 1000)
                    .setConnectTimeout(30 * 1000)
                    .setConnectionRequestTimeout(10 * 1000)
                    .build();
            httpPost.setConfig(requestConfig);
            httpPost.addHeader("Accept", "application/json");
            httpPost.addHeader("Content-Type", "application/json");
            //设置业务参数
            if (MapUtils.isNotEmpty(param)) {
                JSONObject jsonObject = new JSONObject(param);
                log.info("doPost 请求报文至[{}]: \r\n[{}]", url, jsonObject.toString());
                httpPost.setEntity(new StringEntity(jsonObject.toString(), "UTF-8"));
            }
            response = httpClient.execute(httpPost);
            Map< String, Object > responseData = new HashMap<>();
            StatusLine statusLine = response.getStatusLine();
            if (statusLine != null) {
                responseData.put("statusCode", statusLine.getStatusCode());
            }
            HttpEntity entity = response.getEntity();
            responseData.put("responseResult", EntityUtils.toString(entity));
            log.info("dopost 结果： [{}]", responseData.toString());
            return responseData;
        } catch (UnsupportedEncodingException e) {
            throw new FapException("", "编码转换失败");
        } catch (IOException e) {
            throw new FapException("", "POST请求过程中IO异常， e=[{}]", e);
        }
    }

    /**
     * 发送字符串(发送到中心)
     *
     * @param url
     * @param param
     * @param isJson
     * @param accessToken
     * @return
     */
    public static Map< String, Object > doPost2Center(String url, String param, Boolean isJson, String accessToken) {
        CloseableHttpResponse response = null;
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);
            // 设置http参数
            RequestConfig requestConfig = RequestConfig.custom()
                    .setSocketTimeout(30 * 60 * 1000)
                    .setConnectTimeout(30 * 1000)
                    .setConnectionRequestTimeout(10 * 1000)
                    .build();
            httpPost.setConfig(requestConfig);
            if (isJson) {
                httpPost.addHeader("Accept", "application/json");
                httpPost.addHeader("Content-Type", "application/json");
            } else {
                httpPost.addHeader("Content-Type", "text/plain");
            }
            // 发送给中心的报文 增加token 认证
            httpPost.addHeader(CommonConstants.COOKIE,
                    String.format("%s=%s", CommonConstants.ACCESS_TOKEN, accessToken));
            log.info("doPost 请求至[{}], \n header:(Cookie):[{}]报文数据: \r\n[{}]",
                    url, httpPost.getFirstHeader(CommonConstants.COOKIE).getValue(), param);
            httpPost.setEntity(new StringEntity(param, "UTF-8"));
            response = httpClient.execute(httpPost);
            Map< String, Object > responseData = new HashMap<>();
            StatusLine statusLine = response.getStatusLine();
            if (statusLine != null) {
                responseData.put("statusCode", statusLine.getStatusCode());
            }
            HttpEntity entity = response.getEntity();
            responseData.put("responseResult", EntityUtils.toString(entity));
            log.info("dopost 结果： [{}]", responseData.toString());
            return responseData;

        } catch (UnsupportedEncodingException e) {
            throw new FapException("", "编码转换失败");
        } catch (IOException e) {
            throw new FapException("", "Post请求失败");
        }
    }

    /**
     * post方式请求服务器(https协议)
     *
     * @param url              请求地址
     * @param message(可以是json) 参数
     * @return
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @throws IOException
     */
    public static String sendHttpsPost(String url, String message) throws
            NoSuchAlgorithmException, KeyManagementException, IOException {
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, new TrustManager[] { new RequestUtils.TrustAnyTrustManager() },
                new java.security.SecureRandom());

        URL console = new URL(url);
        HttpsURLConnection conn = (HttpsURLConnection) console.openConnection();
        conn.setSSLSocketFactory(sc.getSocketFactory());
        conn.setHostnameVerifier(new RequestUtils.TrustAnyHostnameVerifier());
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("Accept", "application/json; charset=utf-8");
        conn.setRequestProperty("Connection", "Keep-Alive");
        conn.setRequestProperty("Content-Length", String.valueOf(message.length()));
        conn.setRequestMethod("POST");
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setConnectTimeout(30 * 1000);
        conn.setReadTimeout(30 * 60 * 1000);
        log.info("url[{}] sendhttps message=\n[{}]", url, message);
        conn.connect();
        DataOutputStream out = new DataOutputStream(conn.getOutputStream());
        out.write(message.getBytes("UTF-8"));
        log.info("https status=[{}]", conn.getResponseCode());
        // 刷新、关闭
        out.flush();
        out.close();
        InputStream is = conn.getInputStream();
        if (is != null) {
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[ 1024 ];
            int len = 0;
            while ((len = is.read(buffer)) != -1) {
                outStream.write(buffer, 0, len);
            }
            is.close();
            log.info("响应报文:[\n{}\n]", JSONUtil.formatJson(outStream.toString()));
            return (outStream.toString());

        }
        return (null);
    }
}
