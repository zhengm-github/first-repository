package com.sunyard.dxp.message.utils;

import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.message.dto.ParamRule;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @Description 报文规则转换工具
 * @Author zhangxin
 * @Date 2020/1/10 9:58
 * @Version 1.0
 */
public class RuleConvertUtils {

    private RuleConvertUtils( ) {
    }

    /**
     * 转换XML报文为统一格式
     *
     * @param xmlRules xml报文解析规则
     * @return java.util.List<com.sunyard.dxp.message.dto.ParamRule>
     * @author zhangxin
     * @date 2020/1/10 9:53
     */
    public static List< ParamRule > convertXmlRules(Collection< ProcotolResolveRule > xmlRules) {
        String root = "/";
        List< ParamRule > result = new ArrayList<>();
        convertXmlRules(root, result, xmlRules);
        return result;
    }

    private static void convertXmlRules(String node, List< ParamRule > result, Collection< ProcotolResolveRule > xmlRules) {

        // 排序(按照beginindex 升序)
        TreeSet< ProcotolResolveRule > ts = new TreeSet< ProcotolResolveRule >(new Comparator< ProcotolResolveRule >() {
            @Override
            public int compare(ProcotolResolveRule r1, ProcotolResolveRule r2) {
                if (r1.getBeginIndex() > r2.getBeginIndex()) {
                    return 1;
                }
                return -1;
            }
        });
        ts.addAll(xmlRules);

        for (ProcotolResolveRule procotolResolveRule : ts) {

            // 如果是集合(只有循环结点是detailName)
            //只有在定长明细的时候需要这个 length
            int start = procotolResolveRule.getBeginIndex();
            int length = procotolResolveRule.getEndIndex() + 1 - start;
            if (!StringUtils.isEmpty(procotolResolveRule.getDetailName())) {

                String currentNode = node + procotolResolveRule.getDetailName();

                // 获取loop下面所有的 循环字段标签
                List< ParamRule > detailList = new ArrayList<>();
                convertXmlRules(currentNode + "/", detailList, procotolResolveRule.getChildRules());

                ParamRule paramRule = null;
                // 当有分隔符或者是 结束位置时，表明是定长或者变成（非xml 明细） 目前暂定xml中
                //定长和变长明细的  isArray=false, xml 循环域则 isArray=true
                if (StringUtils.isNotEmpty(procotolResolveRule.getSeparatorChar())) {
                    paramRule =
                            new ParamRule(procotolResolveRule.getName(), currentNode,
                                    false, procotolResolveRule.getDetailName(), detailList, start, length);
                    paramRule.setColumnSeparator(procotolResolveRule.getSeparatorChar()); // 变长和定长的明细需要的 行分隔符！
                } else {
                    // 如果是xml 循环区域的话 ，detailList 就是对应的循环域里面 的字段
                    paramRule = new ParamRule(procotolResolveRule.getName(), currentNode, true,
                            procotolResolveRule.getDetailName(), detailList, start, length);
                }
                result.add(paramRule);
                continue;
            }
            // Text
            // 无子集 叶子节点
            if (CollectionUtils.isEmpty(procotolResolveRule.getChildRules())) {
                String currentNode = node + procotolResolveRule.getName();
                ParamRule paramRule = new ParamRule(
                        procotolResolveRule.getName(), currentNode, false, null, null);
                paramRule.setStart(start);
                paramRule.setLength(length);
                result.add(paramRule);
            } else {
                // 继续下一层查找
                convertXmlRules(node + procotolResolveRule.getName() + "/", result, procotolResolveRule.getChildRules());
            }
        }
    }

    /**
     * 转换定长规则为统一格式
     *
     * @param procotolResolveRules 定长报文解析参数
     * @return java.util.List<com.sunyard.dxp.message.dto.ParamRule>
     * @author zhangxin
     * @date 2020/1/10 17:04
     */
    public static List< ParamRule > convertFixedRules(Collection< ProcotolResolveRule > procotolResolveRules) {
        List< ParamRule > paramRules = new ArrayList<>();
        for (ProcotolResolveRule procotolResolveRule : procotolResolveRules) {
            ParamRule paramRule = convertRule(procotolResolveRule);
            paramRules.add(paramRule);
        }
        return paramRules;
    }

    /**
     * 转换统一规则（所有的detailName处 都要判断是否有detailName）
     *
     * @param procotolResolveRule
     * @return
     */
    private static ParamRule convertRule(ProcotolResolveRule procotolResolveRule) {
        int start = procotolResolveRule.getBeginIndex();
        int length = procotolResolveRule.getEndIndex() + 1 - start;

        // 如果detailName 存在则认为是 loop结点，；所有的detailName 都不是叶子节点
        if (!StringUtils.isEmpty(procotolResolveRule.getDetailName())) {
            ProcotolResolveRule rowRule = procotolResolveRule;
            // 明细的总长度
            int detailLength = Integer.valueOf(rowRule.getEndIndex()) + 1 - Integer.valueOf(rowRule.getBeginIndex());
            List< ParamRule > detailRules = convertFixedRules(rowRule.getChildRules());
            return new ParamRule(procotolResolveRule.getDetailName(), start, length, true, detailRules, detailLength);
        }
        // 不是明细循环loop结点的情况，叶子节点
        ParamRule paramRule =
                new ParamRule(procotolResolveRule.getName(), start, length, false, null, null);
        paramRule.setXpath(procotolResolveRule.getName()); //定长的时候 ，name就是他的xpath
        return paramRule;
    }

    /**
     * detailName  只会出现在 loop中，不会出现在 叶子节点中
     *
     * @param procotolResolveRules
     * @return
     */
    public static List< ParamRule > convertVariableRules(Collection< ProcotolResolveRule > procotolResolveRules) {
        List< ParamRule > paramRules = new ArrayList<>();
        int index = 0;
        // 先按照beginIndex排序，为变长考虑
        List< ProcotolResolveRule > procotolResolveRuleList = new ArrayList<>(procotolResolveRules);
        Collections.sort(procotolResolveRuleList, (o1, o2) ->o1.getBeginIndex() > o2.getBeginIndex() ? 1 : -1);
        for (ProcotolResolveRule procotolResolveRule : procotolResolveRuleList) {
//            ParamRule paramRule = convertVariableRule(Integer.parseInt(procotolResolveRule.getBeginIndex()), procotolResolveRule);
            ParamRule paramRule = convertVariableRule(index++, procotolResolveRule);
            paramRules.add(paramRule);
        }
        return paramRules;
    }

    /**
     * 根据具体的规则处理（变长肯定是没有子集的）
     *
     * @param index
     * @param procotolResolveRule
     * @return
     */
    private static ParamRule convertVariableRule(int index, ProcotolResolveRule procotolResolveRule) {
        // 明细
//        if (StringUtils.isNotEmpty(procotolResolveRule.getDetailName())) {
        //先判断是否有孩子
//            Set< ProcotolResolveRule > procotolResolveRuleChilds = procotolResolveRule.getChildRules();
//            if (!CollectionUtils.isEmpty(procotolResolveRuleChilds)) {
//                ProcotolResolveRule rowRule = new ArrayList<>(procotolResolveRuleChilds).get(0);
//                List< ParamRule > detailRules = convertVariableRules(rowRule.getChildRules());
//                return new ParamRule(procotolResolveRule.getDetailName(), index, true, detailRules, procotolResolveRule.getSeparatorChar(), rowRule.getSeparatorChar());
//            }
        ParamRule paramRule = new ParamRule(procotolResolveRule.getName(), procotolResolveRule.getName(),
                false, null, null, procotolResolveRule.getBeginIndex(), 0);
        paramRule.setDetailSeparator(procotolResolveRule.getSeparatorChar());
        paramRule.setColumnSeparator("\r\n");  // 不可用
        paramRule.setIndex(index);
        return paramRule;
//        }
//        // 文本
//        return new ParamRule(procotolResolveRule.getName(), index, false, null, procotolResolveRule.getSeparatorChar(), "\r\n");
    }
}
