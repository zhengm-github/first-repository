package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.DataMapPropertyDefRelaDao;
import com.sunyard.dxp.common.entity.DataMapPropertyDefRela;
import com.sunyard.dxp.common.qo.DataMapPropertyDefRelaQo;
import org.springframework.stereotype.Repository;

/**
 * 请求报文映射配置属性 jdbc实现类
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:25:20 CST 2020
 */
@Repository
public class JpaDataMapPropertyDefRelaDaoImpl  extends JpaBaseDaoImpl<DataMapPropertyDefRela,String,DataMapPropertyDefRelaQo> implements DataMapPropertyDefRelaDao{

    @Override
    public void deleteByPropertyId(String propertyId) {
        this.executeUpdate("delete from DataMapPropertyDefRela as obj where obj.dataPropertyId = ?", propertyId);
    }

    @Override
    public void deleteByPropertyIdAndConfig(String propertyId, String configId) {
        this.executeUpdate(
                "delete from DataMapPropertyDefRela as obj where obj.dataPropertyId = ? and obj.dataMapConfigId = ?"
                , propertyId, configId);
    }

    @Override
    public void deleteByConfig( String configId) {
        this.executeUpdate(
                "delete from DataMapPropertyDefRela as obj where obj.dataMapConfigId = ?", configId);
    }
}
