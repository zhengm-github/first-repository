package com.sunyard.dxp.enums;

import com.sunyard.dxp.security.decoder.Decoder;
import com.sunyard.dxp.security.decoder.impl.GBKDecoder;
import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * 其他编码转换UTF-8
 */
public enum DecoderEnum implements EnumAware {
    UTF_8("UTF_8","UTF_8",new GBKDecoder());

    private final String code;
    private final String name;
    private final Decoder decoder;

    DecoderEnum(String code, String name, Decoder decoder) {
        this.code = code;
        this.name = name;
        this.decoder = decoder;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return this.getName();
    }
    public static Decoder getDecoderStrategy (String code) {
        for (DecoderEnum handler : DecoderEnum.values ()) {
            if (handler.code.equals (code)) {
                return handler.decoder;
            }
        }
        return null;
    }
}
