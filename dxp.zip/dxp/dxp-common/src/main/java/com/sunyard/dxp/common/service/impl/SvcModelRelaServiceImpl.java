package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.SvcModelRelaDao;
import com.sunyard.dxp.common.entity.SvcModelRela;
import com.sunyard.dxp.common.qo.SvcModelRelaQo;
import com.sunyard.dxp.common.service.SvcModelRelaService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 接入服务模块关系 service
 * <p>
 * Author: Created by code generator
 * Date: Mon Dec 16 14:26:15 CST 2019
 */
@Service
public class SvcModelRelaServiceImpl extends BaseServiceImpl< SvcModelRela, String, SvcModelRelaQo > implements SvcModelRelaService {
    @Autowired
    private SvcModelRelaDao svcModelRelaDao;

    @Override
    public List<SvcModelRela> findByHql(String serviceBundleId) {
        return svcModelRelaDao.findByHql(serviceBundleId);
    }

    @Override
    public List< SvcModelRela > findByInBoundSvcId(String inBoundSvcId) {
        return svcModelRelaDao.findByInBoundSvcId(inBoundSvcId);
    }

    @Override
    public SvcModelRela findByInBoundSvcIdAndServiceBoundId(String inBoundSvcId, String serviceBoundId) {
        return svcModelRelaDao.findByInBoundSvcIdAndServiceBoundId(inBoundSvcId, serviceBoundId);
    }

    @Override
    public void deleteByInBoundSvcIds(String... inBoundSvcIds) {

        if(StringUtils.isNoneBlank(inBoundSvcIds)){
            for(String id: inBoundSvcIds){
                svcModelRelaDao.deleteByInBoundSvcId(id);
            }
        }
    }

    @Override
    public void deleteByInBoundSvcIdAndServiceBoundId(String serviceBoundId, String inBoundSvcId) {
        svcModelRelaDao.deleteByInBoundSvcIdAndServiceBoundId(serviceBoundId, inBoundSvcId);
    }

    @Override
    public void deleteSvcModelRelaByIds(String... ids) {
        svcModelRelaDao.deleteSvcModelRelaByIds(ids);
    }
}
