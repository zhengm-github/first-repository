package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.InSvcBindRelaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 接入服务数据映射配置 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:55:37 CST 2019
 */
public class InSvcBindRelaQct extends QueryConditionTransfer< InSvcBindRelaQo > {

    @Override
    public void transNameQuery(InSvcBindRelaQo qo, QueryCondition condition) {

        if (qo != null && StringUtils.isNotBlank(qo.getInBoundSvcId())) {
            condition.add(" and obj.inBoundSvcId = :inBoundSvcId", "inBoundSvcId", qo.getInBoundSvcId());
        }
    }

    @Override
    public void transQuery(InSvcBindRelaQo qo, QueryCondition condition) {
        //
    }

}
