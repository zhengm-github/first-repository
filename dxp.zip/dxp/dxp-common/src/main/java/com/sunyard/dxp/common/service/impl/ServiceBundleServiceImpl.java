package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.ServiceBundleDao;
import com.sunyard.dxp.common.entity.ServiceBundle;
import com.sunyard.dxp.common.qo.ServiceBundleQo;
import com.sunyard.dxp.common.service.ServiceBundleService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 服务模块 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:57:12 CST 2019
 */
@Service
public class ServiceBundleServiceImpl extends BaseServiceImpl< ServiceBundle, String, ServiceBundleQo > implements ServiceBundleService {

    @Autowired
    private ServiceBundleDao serviceBundleDao;

    @Override
    public void deleteSvcBundleById(String serviceBundleId) {
        serviceBundleDao.deleteSvcBundleById(serviceBundleId);
    }

    @Override
    public ServiceBundle findSvcbundleByCode(String code) {
       return serviceBundleDao.findSvcbundleByCode(code);
    }
}
