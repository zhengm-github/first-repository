package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.AccessKeyDao;
import com.sunyard.dxp.common.entity.AccessKey;
import com.sunyard.dxp.common.qo.AccessKeyQo;
import com.sunyard.dxp.common.service.AccessKeyService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

/**
 * 统一服务授权key service
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:26:00 CST 2019
 */
@Service
public class AccessKeyServiceImpl extends BaseServiceImpl< AccessKey, String, AccessKeyQo > implements AccessKeyService {

    @Autowired
    private AccessKeyDao accessKeyDao;


    @Override
    public AccessKey findByIpGroup(String ip) {
        return accessKeyDao.findByIpGroup(ip);
    }

    @Override
    public List<AccessKey> findByCode(String code) {
        return accessKeyDao.findByCode(code);
    }

    @Override
    public AccessKey findByAccessKey(String accessKey) {
        return accessKeyDao.findByAccessKey(accessKey);
    }

    @Override
    public String getAccessKey( ) {

        AccessKey accessKey;
        String key ;
        // 重复性检查
        while (true) {
            key = getKey(6);
            accessKey = this.findByAccessKey(key);
            if (accessKey == null) {
                return key ;
            }
        }
    }


    /**
     * 生成随机编码
     * @param len
     * @return
     */
    private static String getKey( int len) {
        String key = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < len; i++) {
            stringBuilder.append(key.charAt(random.nextInt(key.length())));
        }
        return stringBuilder.toString();
    }
}
