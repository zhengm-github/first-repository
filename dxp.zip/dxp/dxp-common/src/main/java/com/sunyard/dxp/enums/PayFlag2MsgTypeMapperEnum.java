package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * 根据payFlag映射msgType（1-381、2-380）
 *
 * @author zhengm
 */
public enum PayFlag2MsgTypeMapperEnum implements EnumAware {
    P_1_382("1","382"),
    P_2_380("2","380");

    private final String code;
    private final String name;

    PayFlag2MsgTypeMapperEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return getName();
    }



    public static String getMapperNameByCode(String code) {
        for (PayFlag2MsgTypeMapperEnum handler : PayFlag2MsgTypeMapperEnum.values()) {
            if (handler.code.equals(code)) {
                return handler.name;
            }
        }
        return code;
    }
}
