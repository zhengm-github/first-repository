package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;

/**
* 应用公钥
* Author: Created by code generator
* Date: Tue Dec 24 10:42:58 CST 2019
*/
@Entity
@Table(name = "DXP_APP_PUBLIC_KEY")
public class AppPublicKey implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 4881064447945270589L;

    /** 应用公钥ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "APP_PUBLIC_KEY_ID")
    private String appPublicKeyId;

    /** 公钥 */
    @Column( name = "PUBLIC_KEY")
    private String publicKey;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** 应用 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "APP_ID", referencedColumnName = "APP_ID")
    private App app;

    public String getAppPublicKeyId() {
        return appPublicKeyId;
    }

    public void setAppPublicKeyId(String appPublicKeyId) {
        this.appPublicKeyId = appPublicKeyId;
    }

    public String getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public App getApp() {
        return app;
    }

    public void setApp(App app) {
        this.app = app;
    }
}
