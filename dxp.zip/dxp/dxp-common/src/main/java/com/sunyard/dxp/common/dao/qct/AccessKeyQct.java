package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.AccessKeyQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 统一服务授权key Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:26:00 CST 2019
 */
public class AccessKeyQct extends QueryConditionTransfer< AccessKeyQo > {

    @Override
    public void transNameQuery(AccessKeyQo qo, QueryCondition condition) {

        if (qo != null) {
            if (StringUtils.isNotBlank(qo.getAccessKey())) {
                condition.add(" and obj.accessKey = :accessKey", "accessKey", qo.getAccessKey());
            }
            /*关键字模糊查询*/
            if (StringUtils.isNotBlank(qo.getKeyword())) {
                condition.add(" and ( obj.accessKey like :accessKey", "accessKey", qo.getTailBlurKeyword());
                condition.add(" or obj.accessIpGroup like :accessIpGroup", "accessIpGroup", qo.getBlurKeyword());
                condition.add(" or obj.appCode like :appCode ) ", "appCode", qo.getBlurKeyword());
            }
        }
    }

    @Override
    public void transQuery(AccessKeyQo qo, QueryCondition condition) {
        //
    }

}
