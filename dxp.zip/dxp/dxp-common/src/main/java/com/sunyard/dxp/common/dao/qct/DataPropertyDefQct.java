package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.DataPropertyDefQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 数据属性定义 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:55 CST 2019
 */
public class DataPropertyDefQct extends QueryConditionTransfer< DataPropertyDefQo > {

    @Override
    public void transNameQuery(DataPropertyDefQo qo, QueryCondition condition) {
        if (StringUtils.isNoneBlank(qo.getName())) {
            condition.add(" and obj.name =:name", "name", qo.getName());
        }
        if (StringUtils.isNoneBlank(qo.getMemo())) {
            condition.add(" and obj.memo =:memo", "memo", qo.getMemo());
        }
        if (StringUtils.isNoneBlank(qo.getInSvcBundleId())) {
            condition.add(" and obj.dataObjDef.inBoundSvc.inBoundSvcId =:inBoundSvcId", "inBoundSvcId", qo.getInSvcBundleId());
        }
        if (StringUtils.isNoneBlank(qo.getOutSvcBundleId())) {
            condition.add(" and obj.dataObjDef.outBoundSvc.outBoundSvcId =:outBoundSvcId", "outBoundSvcId", qo.getOutSvcBundleId());
        }
        if (StringUtils.isNoneBlank(qo.getDataKind())) {
            condition.add(" and obj.dataObjDef.dataKind =:dataKind", "dataKind", qo.getDataKind());
        }
        /*关键字模糊查询*/
        if (StringUtils.isNotBlank(qo.getKeyword())) {
            condition.add(" and ( obj.name like :name", "name", qo.getBlurKeyword());
            condition.add(" or obj.memo like :memo ) ", "memo", qo.getBlurKeyword());
        }

    }

    @Override
    public void transQuery(DataPropertyDefQo qo, QueryCondition condition) {
        //
    }

}
