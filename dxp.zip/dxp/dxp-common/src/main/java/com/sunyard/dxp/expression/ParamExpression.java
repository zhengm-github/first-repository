package com.sunyard.dxp.expression;

/**
 * @author Thud
 * 表达式接口
 * @date 2020/1/2 11:35
 */
public interface ParamExpression {
    /**
     * 扩展函数库方法
     * @param params
     * @return
     */
    String expCompute(String params);
}
