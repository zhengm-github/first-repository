package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.DataPropertyDef;
import com.sunyard.dxp.common.qo.DataPropertyDefQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 数据属性定义 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:55 CST 2019
 */
public interface DataPropertyDefDao extends BaseDao<DataPropertyDef, String, DataPropertyDefQo> {

    /**
     * 根据数据结果定义id查询数据属性定义表
     * @param dataResultDefId
     * @return
     */
    List<DataPropertyDef> findPropertyDefByResultDefId(String dataResultDefId);

    /**
     * 根据name查找参数
     * @param name
     * @param dataObjDefId
     * @param parentId
     * @return
     */
    DataPropertyDef findByName(String name, String dataObjDefId, String parentId);

    /**
     * 根据接入接出接口Id 查询请求报文或者响应结果列表
     * @param dataKind  （req/rsp）
     * @param svcId
     * @param svcType  (接入或者接出)
     * @return
     */
    List<DataPropertyDef> findBySvcId(String dataKind, String svcId, String svcType);

    /**
     * 根据数据对象定义id查询数据属性定义
     * @param dataObjDefId
     * @return
     */
    List<DataPropertyDef> findPropertyDefByObjDefId(String dataObjDefId);

    /**
     * 根据数据对象定义ID删除数据属性定义
     * @param dataObjDefId
     * @return
     */
    void deletePropertyDefByObjDefId(String dataObjDefId);
    /**
     * 根据父ID获取数据属性定义
     * @param parentId
     * @return
     */
    List<DataPropertyDef> findPropertyDefByParentId(String parentId);

    /**
     *
     * 根据接出接口Id查询接入接口对应的属性列表
     *
     * @param obsId
     * @return
     */
    List<DataPropertyDef> findInPropByObs(String obsId) ;

    /**
     *
     * 根据接入接口Id查询接入接口对应的属性列表
     *
     * @param ibsId
     * @param dataKind
     *
     * @return
     */
    List<DataPropertyDef> findInPropByIbs(String ibsId, String dataKind);

    /**
     *
     * 根据接入接口Id查询接入接口对应的属性列表
     *
     * @param obsId
     * @param dataKind
     *
     * @return
     */
    List<DataPropertyDef> findOutPropByObs(String obsId, String dataKind);

    /**
     *
     * 根据接入接口Id查询接入接口对应的属性列表
     *
     *
     * @return
     */
    List<DataPropertyDef> findChild(String id);
}
