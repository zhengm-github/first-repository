package com.sunyard.dxp.message.dto;

import java.util.List;

/**
 * @Description 参数规则
 * @Author zhangxin
 * @Date 2020/1/7 14:56
 * @Version 1.0
 */
public class ParamRule {

    /**
     * 参数名
     */
    private String name;

    /**
     * xml报文中的xpath
     */
    private String xpath;

    /**
     * 定长报文中的起始下标
     */
    private Integer start;

    /**
     * 定长报文中的字段长度
     */
    private Integer length;

    /**
     * 变长报文中的字段下标
     */
    private Integer index;

    /**
     * 字段数据类型是否明细
     */
    private boolean isArray;

    /**
     * 字段数据类型为明细时,必须给出明细的解析规则
     */
    private List<ParamRule> detailRules;

    /**
     * 字段数据类型为明细时， 定长报文必须给出
     */
    private Integer detailLength;

    /**
     * 明细分隔符 变长报文
     */
    private String detailSeparator;

    /**
     * 明细字段分隔符 变长报文
     */
    private String columnSeparator;

    /**
     *    明细为定长报文
     *      */
    private String detailName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public boolean isArray() {
        return isArray;
    }

    public void setArray(boolean array) {
        isArray = array;
    }

    public List<ParamRule> getDetailRules() {
        return detailRules;
    }

    public void setDetailRules(List<ParamRule> detailRules) {
        this.detailRules = detailRules;
    }

    public Integer getDetailLength() {
        return detailLength;
    }

    public void setDetailLength(Integer detailLength) {
        this.detailLength = detailLength;
    }

    public String getDetailSeparator() {
        return detailSeparator;
    }

    public void setDetailSeparator(String detailSeparator) {
        this.detailSeparator = detailSeparator;
    }

    public String getColumnSeparator() {
        return columnSeparator;
    }

    public void setColumnSeparator(String columnSeparator) {
        this.columnSeparator = columnSeparator;
    }

    public String getDetailName() {
        return detailName;
    }

    public void setDetailName(String detailName) {
        this.detailName = detailName;
    }

    /**
     * xml报文解析规则
     *
     * @param name        参数名
     * @param xpath       参数获取xpath
     * @param isArray     是否集合
     * @param detailRules 集合解析规则
     * @return
     * @author zhangxin
     * @date 2020/1/10 16:36
     */
    public ParamRule(String name, String xpath, boolean isArray,String detailName, List<ParamRule> detailRules) {
        this.name = name;
        this.xpath = xpath;
        this.isArray = isArray;
        this.detailRules = detailRules;
        this.detailName = detailName;
    }

    public ParamRule(String name, String xpath, boolean isArray,String detailName, List<ParamRule> detailRules,Integer start, Integer length) {
        this.name = name;
        this.xpath = xpath;
        this.isArray = isArray;
        this.detailRules = detailRules;
        this.detailName = detailName;
        this.start = start;
        this.length = length;
    }
    public ParamRule() {
    }

    /**
     * 定长报文解析规则
     *
     * @param name         参数名
     * @param start        开始下标
     * @param length       长度
     * @param isArray      是否明细
     * @param detailRules  明细规则
     * @param detailLength 明细长度
     * @return
     * @author zhangxin
     * @date 2020/1/10 16:56
     */
    public ParamRule(String name, Integer start, Integer length, boolean isArray, List<ParamRule> detailRules, Integer detailLength) {
        this.name = name;
        this.start = start;
        this.length = length;
        this.isArray = isArray;
        this.detailRules = detailRules;
        this.detailLength = detailLength;
    }

    /**
     * 变长报文解析规则
     *
     * @param name            参数名
     * @param index           数组下标
     * @param isArray         是否明细
     * @param detailRules     明细规则
     * @param detailSeparator 明细行分隔符
     * @param columnSeparator 明细字段分隔符
     * @return
     * @author zhangxin
     * @date 2020/1/10 17:10
     */
    public ParamRule(String name, Integer index, boolean isArray, List<ParamRule> detailRules, String detailSeparator, String columnSeparator) {
        this.name = name;
        this.index = index;
        this.isArray = isArray;
        this.detailRules = detailRules;
        this.detailSeparator = detailSeparator;
        this.columnSeparator = columnSeparator;
    }
}
