package com.sunyard.dxp.common.entity;

/**
 * @author Thud
 * @date 2020/2/26 13:39
 */
public class Encoder {

    private String code;

    private String name ;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
