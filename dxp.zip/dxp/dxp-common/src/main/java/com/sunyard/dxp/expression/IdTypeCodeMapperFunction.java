package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 *
 * 全国到单位
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary(code = "idTypeCodeMapper",name = "证件类型映射(全国到单位)",expression = "(idTypeCodeMapper\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "idTypeCodeMapper()",hasProperty = true)
@Component
public class IdTypeCodeMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            //表达式参数不准确
            return "" ;
        }
        try {
            return ExpMapper.idTypeCodeMap.getOrDefault(params, "0");
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
    }
}
