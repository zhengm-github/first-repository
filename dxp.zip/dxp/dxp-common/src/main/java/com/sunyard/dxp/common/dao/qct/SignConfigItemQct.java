package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.SignConfigItemQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 签名配置项 Qct转化类
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:49:49 CST 2020
 */
public class SignConfigItemQct extends QueryConditionTransfer<SignConfigItemQo> {

    @Override
    public void transNameQuery(SignConfigItemQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(SignConfigItemQo qo, QueryCondition condition) {
        //
    }

}
