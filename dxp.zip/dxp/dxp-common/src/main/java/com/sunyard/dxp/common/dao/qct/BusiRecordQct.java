package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.BusiRecordQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 记录业务信息（请求和响应） Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Jun 09 17:17:29 CST 2020
 */
public class BusiRecordQct extends QueryConditionTransfer< BusiRecordQo > {

    @Override
    public void transNameQuery(BusiRecordQo qo, QueryCondition condition) {

    }

    @Override
    public void transQuery(BusiRecordQo qo, QueryCondition condition) {

    }

}
