package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.OutBoundSvcDao;
import com.sunyard.dxp.common.entity.DataPropertyDef;
import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.dxp.common.entity.SignConfigSchema;
import com.sunyard.dxp.expression.ParamExpression;
import com.sunyard.dxp.message.factory.ServiceFactory;
import com.sunyard.dxp.utils.StringUtil;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.OutBoundSvcService;
import com.sunyard.dxp.common.entity.OutBoundSvc;
import com.sunyard.dxp.common.qo.OutBoundSvcQo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 接出服务接口 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:06 CST 2019
 */
@Service
public class OutBoundSvcServiceImpl extends BaseServiceImpl<OutBoundSvc, String, OutBoundSvcQo> implements OutBoundSvcService {

    @Autowired
    protected OutBoundSvcDao outBoundSvcDao;

    @Override
    public List<OutBoundSvc> findOutBoundSvcByCode(String outBoundSvcCode) {
        return outBoundSvcDao.findOutBoundSvcByCode(outBoundSvcCode);
    }

    @Override
    public OutBoundSvc findOutBoundSvcByCodeAndSvcBundle(String outBoundSvcCode, String svcBundleCode){
        return outBoundSvcDao.findOutBoundSvcByCodeAndSvcBundle(outBoundSvcCode, svcBundleCode);
    }

    @Override
    public List< OutBoundSvc > findByOutBoundSvcIds(String[] outBoundSvcIds) {
        return outBoundSvcDao.findByOutBoundSvcIds(outBoundSvcIds);
    }

    @Override
    public List<OutBoundSvc> findOutBoundSvcBySvcId(String serviceBoundId) {
        return outBoundSvcDao.findOutBoundSvcBySvcId(serviceBoundId);
    }

    @Override
    public String packSignData(OutBoundSvc outBoundSvc, Map< String, Object > resolve) {
        SignConfigSchema outSignConfigSchema = outBoundSvc.getOutSignConfigSchema();
        if (outSignConfigSchema == null) {
            return "";
        }
        String connector = outSignConfigSchema.getConnector();
        //1.排序
        Set< SignConfigItem > signConfigItemSet = outSignConfigSchema.getSignConfigItems();
        List< SignConfigItem > signConfigItemList = new ArrayList<>(signConfigItemSet);
        Collections.sort(signConfigItemList, (o1, o2) -> o1.getOrd() > o2.getOrd() ? 1 : -1);

        StringBuilder signSrc = new StringBuilder();
        StringBuilder propertyXpath = null;
        for (int i = 0; i < signConfigItemList.size(); i++) {
            SignConfigItem signItem = signConfigItemList.get(i);
            DataPropertyDef dataPropertyDef = signItem.getDataPropertyDef();
            //2.获取签名属性值  (使用全路径)
            // 父级就是 filebody 和 fileheader / header / body 的不加 /
            propertyXpath = new StringBuilder(dataPropertyDef.getName());
            if (dataPropertyDef.getParent() != null
                    && !("filebody".equals(dataPropertyDef.getParent().getName())
                    || "fileheader".equals(dataPropertyDef.getParent().getName())
                    || "header".equals(dataPropertyDef.getParent().getName())
                    || "body".equals(dataPropertyDef.getParent().getName()))) {  // 有定长情况
                propertyXpath.insert(0, "/");
                while (dataPropertyDef.getParent() != null) {
                    propertyXpath.insert(0, "/" + dataPropertyDef.getParent().getName());
                    dataPropertyDef = dataPropertyDef.getParent();
                }
            }

            String singValue = StringUtil.getDefaultStr(resolve.get(propertyXpath.toString()), "");
            String expSrc = signItem.getExp();
            String computeValue = "";
            if (StringUtils.isNotEmpty(expSrc)) {
                //3.根据表达式计算属性值

                // 表达式可能有参数
                String expParam = StringUtils.isNotBlank(signItem.getParam()) ? (signItem.getParam() + ",") : "";
                computeValue = ServiceFactory.getBeanStatic(expSrc + "Function", ParamExpression.class).
                        expCompute(expParam + singValue);
            } else {
                computeValue = singValue;
            }
            //4.拼接
            if (i == signConfigItemList.size() - 1) {
                signSrc.append(computeValue);
            } else {
                signSrc.append(computeValue).append(connector);
            }
        }
        return signSrc.toString();
    }
}
