package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/1/3 9:45
 */
@FunctionLibrary(code = "merge",name = "合并",expression = "(.*)(merge)(.*)",type = "all" ,isRelation = true,exp = "merge")
@Component
public class MergeFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        return params.replaceAll("merge","");
    }
}
