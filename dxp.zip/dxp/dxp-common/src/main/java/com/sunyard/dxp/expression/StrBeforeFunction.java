package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 *字符串前补0成8位
 */
@FunctionLibrary(code = "strBefore",name = "字符串前补0成8位",expression = "(strBefore\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "strBefore()",hasProperty = true)
@Component
public class StrBeforeFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            params = "" ;
        }

        return StringUtil.formatStr(params,8,"0", true) ;
    }
}
