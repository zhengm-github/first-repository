package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.AccessKey;
import com.sunyard.dxp.common.qo.AccessKeyQo;
import com.sunyard.frameworkset.core.service.BaseService;

import java.util.List;

/**
 * 统一服务授权key service 接口
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:26:00 CST 2019
 */
public interface AccessKeyService extends BaseService< AccessKey, String, AccessKeyQo > {

    /**
     * 根据授权ip查询服务授权码
     *
     * @param ip
     * @return
     */
    AccessKey findByIpGroup(String ip);

    /**
     * 根据应用编号查询服务授权码
     *
     * @param code
     * @return
     */
    List<AccessKey> findByCode(String code);

    /**
     * 根据授权key查询服务授权码
     *
     * @param accessKey
     * @return
     */
    AccessKey findByAccessKey(String accessKey);

    /**
     * 生成授权Key
     * @return
     */
    String getAccessKey() ;

}
