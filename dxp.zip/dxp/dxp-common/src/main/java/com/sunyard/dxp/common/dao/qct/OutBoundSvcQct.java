package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.OutBoundSvcQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 接出服务接口 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:56:18 CST 2019
 */
public class OutBoundSvcQct extends QueryConditionTransfer< OutBoundSvcQo > {

    @Override
    public void transNameQuery(OutBoundSvcQo qo, QueryCondition condition) {

        if (qo != null) {
            if (StringUtils.isNotBlank(qo.getCode())) {
                condition.add(" and obj.code = :code", "code", qo.getCode());
            }
            if (StringUtils.isNotBlank(qo.getStatus())) {
                condition.add(" and obj.status = :status", "status", qo.getStatus());
            }
            if (StringUtils.isNotBlank(qo.getServiceBundleId())) {
                condition.add(
                        " and obj.serviceBundle.serviceBundleId = :serviceBundleId", "serviceBundleId", qo.getServiceBundleId());
            }

            /*关键字模糊查询*/
            if (StringUtils.isNotBlank(qo.getKeyword())) {
                condition.add(" and ( obj.code like :code", "code", qo.getTailBlurKeyword());
                condition.add(" or obj.name like :name ) ", "name", qo.getBlurKeyword());
            }

            if (StringUtils.isNotEmpty(qo.getOutBoundSvcIds())) {
                condition.append("And obj.outBoundSvcId in (");
                String[] ids = qo.getOutBoundSvcIds().split(",");
                for (int i = 0; i < ids.length; ++i) {
                    condition.add(" :outBoundSvcId" + i + ", ", "outBoundSvcId" + i, ids[ i ]);
                }
                condition.append(" 'none' ) )");
            }
        }
    }

    @Override
    public void transQuery(OutBoundSvcQo qo, QueryCondition condition) {
        //
    }

}
