package com.sunyard.dxp.utils;

/**
 * Created by zhourangji on 2018/4/2.
 */
public class SocketClientPubDef {

    private SocketClientPubDef(){}

    public static final String  ATTRIBUTEKEY_CHANNEL_POOL="channel_pool";
    public static final String  ATTRIBUTEKEY_CHANNEL_REQUESTMSG="channel_request_ms";
}
