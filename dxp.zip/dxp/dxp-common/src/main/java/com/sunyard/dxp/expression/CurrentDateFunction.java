package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.frameworkset.util.DateUtil;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author Thud
 * @date 2020/1/3 14:52
 */
@FunctionLibrary(code = "currentDate",name = "生成当前日期(pattern)",expression = "(currentDate\\()([A-Za-z-]+)(\\))",exp = "currentDate(yyyyMMdd)")
@Component
public class CurrentDateFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if(params.length()< 8){
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }

        return DateUtil.date2Str(new Date(),params);
    }
}
