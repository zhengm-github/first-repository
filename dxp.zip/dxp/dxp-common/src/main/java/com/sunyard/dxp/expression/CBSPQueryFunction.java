package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 查询类交易使用的特殊状态映射
 */
@FunctionLibrary( code = "CBSPQuery", name = "交易处理码特殊处理(prosts-prccd)", expression = "(\\$\\{[\\s\\w]+\\})(CBSPQuery)(\\$\\{[\\s\\w]+\\})", type = "all", isRelation = true, exp = "CBSPQuery" )
@Component
public class CBSPQueryFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {

        if (StringUtils.isNotBlank(params)) {
            String[] paramArr = params.split("CBSPQuery");
            if (paramArr.length < 2) {
                return params;
            } else if (StringUtils.isBlank(paramArr[ 0 ])) {
                return "3010";// 原交易找不到时
            }
            try {

                String value = ExpMapper.cbspQueryCodeMap.get(paramArr[ 0 ] + "-" + paramArr[ 1 ]);
                if (StringUtils.isNotBlank(value)) {
                    return value;
                }
                value = ExpMapper.cbspResultMap.get(paramArr[ 0 ]);
                if (StringUtils.isNotBlank(value)) {
                    return value.split(",", -1)[ 0 ];
                }
                return "9999";
            } catch (Exception e) {
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                        DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
            }
        }
        return params;
    }
}
