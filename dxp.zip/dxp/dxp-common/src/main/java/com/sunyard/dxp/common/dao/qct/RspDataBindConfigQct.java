package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.RspDataBindConfigQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 数据绑定配置 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:43:42 CST 2019
 */
public class RspDataBindConfigQct extends QueryConditionTransfer<RspDataBindConfigQo> {

    @Override
    public void transNameQuery(RspDataBindConfigQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(RspDataBindConfigQo qo, QueryCondition condition) {
        //
    }

}
