package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.ReqDataMapConfig;
import com.sunyard.dxp.common.qo.ReqDataMapConfigQo;

import java.util.List;

/**
 * 请求报文映射配置 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:15:01 CST 2020
 */
public interface ReqDataMapConfigService extends BaseService<ReqDataMapConfig, String, ReqDataMapConfigQo> {

    /**
     * 根据接入数据属性id查询请求报文映射配置
     * @param inDataPropertyId
     * @return
     */
    List<ReqDataMapConfig> findReqConfigByInDataPropertyId(String inDataPropertyId);

    /**
     * 根据接入数据属性id删除请求报文映射配置
     * @param propertyId
     * @return
     */
    void deleteByPropertyId(String propertyId);
}
