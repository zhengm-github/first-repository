package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.DataBindPropertyDefRelaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 接出数据属性绑定配置 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:44:42 CST 2019
 */
public class DataBindPropertyDefRelaQct extends QueryConditionTransfer<DataBindPropertyDefRelaQo> {

    @Override
    public void transNameQuery(DataBindPropertyDefRelaQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(DataBindPropertyDefRelaQo qo, QueryCondition condition) {
        //
    }

}
