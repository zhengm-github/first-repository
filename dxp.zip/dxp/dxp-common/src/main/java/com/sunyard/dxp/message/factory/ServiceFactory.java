package com.sunyard.dxp.message.factory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class ServiceFactory implements ApplicationContextAware {

	private static ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext arg0){
		this.applicationContext = arg0;
	}

	public <T> T getBean(String serviceId, Class<T> c){
		return applicationContext.getBean(serviceId, c);
	}

	public static <T> T getBeanStatic(String serviceId, Class<T> c){
		return applicationContext.getBean(serviceId, c);
	}
}
