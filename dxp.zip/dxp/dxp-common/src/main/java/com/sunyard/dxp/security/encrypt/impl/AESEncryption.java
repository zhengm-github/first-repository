package com.sunyard.dxp.security.encrypt.impl;

import com.sunyard.dxp.security.encrypt.Encryption;
import com.sunyard.dxp.utils.EncryptionLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;

/**
 * AES加密
 */
@EncryptionLibrary(code = "AESEncryption" , name = "AES加密")
public class AESEncryption implements Encryption {
    private static final Logger LOGGER = LoggerFactory.getLogger( AESEncryption.class );


    @Override
    public String encrypt(String content, String key) {
        try {
            Cipher cipher = Cipher.getInstance("AES");// 创建密码器
            byte[] byteContent = content.getBytes("utf-8");
            KeyGenerator kg  = KeyGenerator.getInstance("AES");
            kg.init(128, new SecureRandom(key.getBytes()));
            SecretKey secretKey = kg.generateKey();
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(secretKey.getEncoded(), "AES"));// 初始化为加密模式的密码器
            byte[] result = cipher.doFinal(byteContent);// 加密
            return Base64.encodeBase64String(result);//通过Base64转码返回
        } catch (Exception ex) {
            LOGGER.error("对内容进行aes加密失败");
            throw new FapException("","对内容进行aes加密失败！");
        }
    }
}
