package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 转金额为 CNY0000000000123.99
 */
@FunctionLibrary( code = "CBSPMoney", name = "全国金额处理(CNY*16)", expression = "(CBSPMoney\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "CBSPMoney()", hasProperty = true )
@Component
public class CBSPMoneyFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if (StringUtils.isBlank(params) || "".equals(params.trim())) {
            return "CNY0000000000000.00";
        }
        String afterMoney =
                new BigDecimal(params.trim()).setScale(2, RoundingMode.HALF_UP).toString();
        return "CNY" + StringUtil.formatStr(afterMoney, 16, "0", true);
    }
}
