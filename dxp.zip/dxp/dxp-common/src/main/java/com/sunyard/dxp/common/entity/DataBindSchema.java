package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 数据绑定模式
* Author: Created by code generator
* Date: Tue Dec 24 10:45:05 CST 2019
*/
@Entity
@Table(name = "DXP_DATA_BIND_SCHEMA")
public class DataBindSchema implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8706056836505147546L;

    /** 数据映射配置规划ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "DATA_MAP_SCHEMA_ID")
    private String dataMapSchemaId;

    /** 接出服务接口 */
    @OneToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "OUT_BOUND_SVC_ID", referencedColumnName = "OUT_BOUND_SVC_ID")
    private OutBoundSvc outBoundSvc;

    /** 响应报文绑定配置 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "dataBindSchema")
    private Set<RspDataBindConfig> dataBindConfigs;

    /** 请求报文映射配置 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "dataBindSchema")
    private Set<ReqDataMapConfig> reqDataMapConfigs;

    /** 接入服务接口 */
    @ManyToMany( fetch = FetchType.EAGER, cascade = CascadeType.REFRESH )
    @JoinTable( name = "DXP_IN_SVC_BIND_RELA",
            joinColumns = { @JoinColumn( name = "DATA_MAP_SCHEMA_ID", referencedColumnName = "DATA_MAP_SCHEMA_ID" ) },
            inverseJoinColumns = { @JoinColumn( name = "IN_BOUND_SVC_ID", referencedColumnName = "IN_BOUND_SVC_ID" ) } )
    private Set< InBoundSvc > inBoundServices;


    public String getDataMapSchemaId() {
        return dataMapSchemaId;
    }

    public void setDataMapSchemaId(String dataMapSchemaId) {
        this.dataMapSchemaId = dataMapSchemaId;
    }

    public OutBoundSvc getOutBoundSvc( ) {
        return outBoundSvc;
    }

    public void setOutBoundSvc(OutBoundSvc outBoundSvc) {
        this.outBoundSvc = outBoundSvc;
    }

    public Set<RspDataBindConfig> getDataBindConfigs() {
        return dataBindConfigs;
    }

    public void setDataBindConfigs(Set<RspDataBindConfig> dataBindConfigs) {
        this.dataBindConfigs = dataBindConfigs;
    }

    public Set<ReqDataMapConfig> getReqDataMapConfigs() {
        return reqDataMapConfigs;
    }

    public void setReqDataMapConfigs(Set<ReqDataMapConfig> reqDataMapConfigs) {
        this.reqDataMapConfigs = reqDataMapConfigs;
    }

    public Set<InBoundSvc> getInBoundServices() {
        return inBoundServices;
    }

    public void setInBoundServices(Set<InBoundSvc> inBoundServices) {
        this.inBoundServices = inBoundServices;
    }

}
