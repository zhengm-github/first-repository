package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * User: liulu
 * Date: 2017/12/4 14:36
 * version $Id: UdisResponseStatusEnum.java, v 0.1 Exp $
 */

public enum DxpResponseStatusEnum implements EnumAware {
	CW0I0000("CW0I0000","受理成功"),
	CW0O0101("CW0O0101","报文无法解析"),
	CW0O0102("CW0O0102","业务类型未知（请求或响应）"),// 响应单位的
	CW0S2018("CW0S2018","设置报头结构错误"),
	CW0S9007("CW0S9007","系统调用失败")
	;

	private String code;

	private String name;

	DxpResponseStatusEnum(String code, String name) {
		this.code = code;
		this.name = name;
	}
	@Override
	public String getCode() {
		return code;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getSimpleName() {
		return null;
	}


	public static String getRspMsg (String code) {
		for (DxpResponseStatusEnum handler : DxpResponseStatusEnum.values ()) {
			if (handler.getCode().equals (code)) {
				return handler.getName();
			}
		}
		return code;
	}
}
