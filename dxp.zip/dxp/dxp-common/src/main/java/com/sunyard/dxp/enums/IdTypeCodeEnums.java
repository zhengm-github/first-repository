package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * *
 * User: wuyongzhi
 * Date: 2017/7/11 10:21
 * version $Id: AccessKeyEnum.java, v 0.1 Exp $
 */
public enum IdTypeCodeEnums implements EnumAware {
    IC00 ("IC00","身份证"),
    IC01 ("IC01","护照"),
    IC02 ("IC02","军官证"),
    IC03 ("IC03","士兵证"),
    IC04 ("IC04","港澳台往来通行证"),
    IC05 ("IC05","临时身份证"),
    IC06 ("IC06","户口簿"),
    IC07 ("IC07","警官证"),
    IC08 ("IC08","外国人永久居留证"),
    IC09 ("IC09","边民出入境通行证"),
    IC10 ("IC10","组织机构代码证"),
    IC11 ("IC11","营业执照"),
    IC12 ("IC12","企业名称核准书"),
    IC13 ("IC13","政府机构/公共机构批文"),
    IC14 ("IC14","香港商业登记证"),
    IC15 ("IC15","开户证明"),
    IC16 ("IC16","军队开户许可证"),
    IC17 ("IC17","社会团体证"),
    IC18 ("IC18","非法人组织机构代码证"),
    IC19 ("IC19","统一社会信用码"),
    IC20 ("IC20","港澳台居民居住证"),
    IC21 ("IC21","港澳居民来往内地通行证"),
    IC22 ("IC22","台湾居民来往大陆通行证"),
    ;

    private String code;

    private String name;

    IdTypeCodeEnums(String code, String name) {
        this.code = code;
        this.name = name;
    }
    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return null;
    }


    public static String getMapperNameByCode(String code) {
        for (IdTypeCodeEnums enums : IdTypeCodeEnums.values()) {
            if (enums.code.equals(code)) {
                return enums.name;
            }
        }
        return null;
    }
}
