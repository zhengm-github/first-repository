package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;

/**
* 单位
* Author: Created by code generator
* Date: Wed Dec 25 19:35:40 CST 2019
*/
@Entity
@Table(name = "DXP_UNITS")
public class Units implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5805333576399657600L;

    /** 单位ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "UNITS_ID")
    private String unitsId;

    /** 单位代码 */
    @Column( name = "CODE")
    private String code;

    /** 单位名称 */
    @Column( name = "NAME")
    private String name;

    /** 签名公钥路径 */
    @Column( name = "SIGN_PUBLIC_KEY_URL")
    private String signPublicKeyUrl;

    /** 加密公钥路径 */
    @Column( name = "ENCRY_PUBLIC_KEY_URL")
    private String encryPublicKeyUrl;

    public String getUnitsId() {
        return unitsId;
    }

    public void setUnitsId(String unitsId) {
        this.unitsId = unitsId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSignPublicKeyUrl() {
        return signPublicKeyUrl;
    }

    public void setSignPublicKeyUrl(String signPublicKeyUrl) {
        this.signPublicKeyUrl = signPublicKeyUrl;
    }

    public String getEncryPublicKeyUrl() {
        return encryPublicKeyUrl;
    }

    public void setEncryPublicKeyUrl(String encryPublicKeyUrl) {
        this.encryPublicKeyUrl = encryPublicKeyUrl;
    }

}
