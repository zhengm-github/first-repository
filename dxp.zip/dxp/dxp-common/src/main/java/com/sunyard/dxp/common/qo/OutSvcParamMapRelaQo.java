package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 接出服务参数映射配置 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:38 CST 2019
   */
public class OutSvcParamMapRelaQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6447043826543703561L;

}
