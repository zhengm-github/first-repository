package com.sunyard.dxp.message.template;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

import java.util.List;

@XStreamAlias("root")
@Data
public class Root {

	/**
	 * 报文类型
	 */
	@XStreamAlias("messageType")
	private String messageType;

	/**
	 * 报文类型
	 */
	@XStreamAlias("fileType")
	private String fileType;
	/**
	 * 分隔符
	 */
	@XStreamAlias("separator")
	private String separator;

	@XStreamAlias("message")
	private List<Column> msgColumns;

	@XStreamAlias("detail")
	private List<Column> detailColumns;
	
	@XStreamAlias("head")
	private List<Column> head;

	@XStreamAlias("headIndex")
	private int headIndex;

	@XStreamAlias("body")
	private List<Column> body;

	@XStreamAlias("bodyStart")
	private int bodyStart;

	@XStreamAlias("charset")
	private String charset;

	@XStreamAlias("rootNode")
	private String rootNode;

	@XStreamAlias("detailNode")
	private String detailNode;
}
