package com.sunyard.dxp.utils;

import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import java.io.*;

/**
 * Created by Administrator on 2018-1-29.
 */
public class Base64Utils {

    private static final Logger logger = LoggerFactory.getLogger( Base64Utils.class );


    /**
     * 文件读取缓存区大小
     */
    private static final int CACHE_SIZE = 1024;

    private Base64Utils() {
        //
    }

    /**
     * BASE64字符串解码为二进制数据
     */
    public static byte[] decode(String base64) {
        return Base64.decodeBase64(base64);
    }

    /**
     * 二进制数据编码为BASE64字符串
     */
    public static String encode(byte[] bytes){
        return Base64.encodeBase64String(bytes);
    }


    /**
     * 将文件编码为BASE64字符串
     * @param filePath  文件路径
     * @return
     * @throws IOException
     */
    public static String encodeFile(String filePath) throws IOException {
        return fileToByte(filePath);
    }

    /**
     * BASE64字符串转回到文件
     * @param filePath  文件路径
     * @param base64    BASE64字符串
     * @throws IOException
     */
    public static void decodeToFile(String filePath ,String base64) throws IOException{
        byte[] bytes = decode(base64);
        byteArrayToFile(bytes,filePath);
    }


    /**
     * 文件转换为二进制数组
     *
     * @param filePath 文件路径
     * @return
     * @throws Exception
     */
    public static String fileToByte(String filePath) throws IOException {
        String data ="";
        File file = new File(filePath);
        if (file.exists()) {
            try (FileInputStream in = new FileInputStream(file);
                 ByteArrayOutputStream out = new ByteArrayOutputStream(2048)) {
                byte[] cache = new byte[CACHE_SIZE];
                int nRead = 0;
                while ((nRead = in.read(cache)) != -1) {
                    out.write(cache, 0, nRead);
                    out.flush();
                    data = out.toString();
                }
            }
        }
        return data;
    }


    /**
     * 二进制数据写文件
     * @param bytes  二进制数据
     * @param filePath  文件生成目录
     * @throws Exception
     */
    public static void byteArrayToFile(byte[] bytes, String filePath) throws IOException {
        InputStream in = new ByteArrayInputStream(bytes);
        File destFile = new File(filePath);
        if (!destFile.getParentFile().exists()) {
            destFile.getParentFile().mkdirs();
        }
        if(destFile.createNewFile()) {
            try (OutputStream out = new FileOutputStream(destFile)) {
                byte[] cache = new byte[CACHE_SIZE];
                int nRead = 0;
                while ((nRead = in.read(cache)) != -1) {
                    out.write(cache, 0, nRead);
                    out.flush();
                }
            }
        }
        in.close();
    }


    /**
     * 字符串输出 encode
     *
     * @param str
     * @return
     */
    public static String base64Encode(String str) {
        if (StringUtils.isBlank(str)) return "";
        try {
            return encode(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            logger.error("" , e);
        }
        return "";
    }

    /**
     * 字符串输出 decode
     *
     * @param str
     * @return
     */
    public static String base64Decode(String str) {
        if (StringUtils.isBlank(str)) return "";
        try {
            return new String(decode(str), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("" , e);
        }
        return "";
    }

    /**
     * 二进制数组转16进制
     *
     * @param byteArray
     * @return
     */
    public static String toHexString(byte[] byteArray) {
        String str = null;
        if (byteArray != null && byteArray.length > 0) {
            StringBuilder stringBuilder = new StringBuilder(byteArray.length);
            for (byte byteChar : byteArray) {
                stringBuilder.append(String.format("%02X", byteChar));
            }
            str = stringBuilder.toString();
        }
        return str;
    }

    /**
     * 16进制转二进制数组
     *
     * @param hexString
     * @return
     */
    public static byte[] toByteArray(String hexString) {
        String hex = hexString.toLowerCase();
        final byte[] byteArray = new byte[ hex.length() / 2 ];
        int k = 0;
        for (int i = 0; i < byteArray.length; i++) {// 因为是16进制，最多只会占用4位，转换成字节需要两个16进制的字符，高位在先
            byte high = (byte) (Character.digit(hex.charAt(k), 16) & 0xff);
            byte low = (byte) (Character.digit(hex.charAt(k + 1), 16) & 0xff);
            byteArray[ i ] = (byte) (high << 4 | (low & 0xff));
            k += 2;
        }
        return byteArray;
    }


}
