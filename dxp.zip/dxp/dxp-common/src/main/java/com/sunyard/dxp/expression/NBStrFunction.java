package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 19981001-19981031要解析成999999， 其他的区间或者日期都 截取前6位 (宁波专用)
 */
@FunctionLibrary( code = "NBStr", name = "宁波查询日期特殊处理", expression = "(NBStr\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "NBStr()", hasProperty = true )
@Component
public class NBStrFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if (StringUtils.isBlank(params)) {
            return "";
        }
        if ("19981001-19981031".equals(params.trim())) {
            return "999999";
        } else {
            return StringUtil.formatStr(params, 6, " ", true);
        }
    }
}
