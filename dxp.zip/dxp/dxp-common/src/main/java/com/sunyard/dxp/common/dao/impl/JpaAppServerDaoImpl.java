package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.AppServerDao;
import com.sunyard.dxp.common.entity.AppServer;
import com.sunyard.dxp.common.qo.AppServerQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.springframework.stereotype.Repository;


/**
 * 应用服务 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:07 CST 2019
 */
@Repository
public class JpaAppServerDaoImpl extends JpaBaseDaoImpl<AppServer, String, AppServerQo > implements AppServerDao {


    @Override
    public AppServer findByCode(String code) {
        return findBySingle(getMainQuery() + " where obj.code= ? ",code);
    }
}
