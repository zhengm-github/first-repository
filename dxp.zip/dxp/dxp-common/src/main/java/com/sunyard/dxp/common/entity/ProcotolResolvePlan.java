package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 协议解析规划
* Author: Created by code generator
* Date: Tue Jan 07 19:22:25 CST 2020
*/
@Entity
@Table(name = "DXP_PROCOTOL_RESOLVE_PLAN")
public class ProcotolResolvePlan implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7450626168778947440L;

    /** 协议解析规划ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "PROCOTOL_RESOLVE_PLAN_ID")
    private String procotolResolvePlanId;

    /** 分隔符 */
    @Column( name = "SEPARATOR_CHAR")
    private String separatorChar;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** 备注 */
    @Column( name = "MEMO")
    private String memo;

    /** 起始位置 */
    @Column( name = "BEGIN_INDEX")
    private String beginIndex;

    /** 结束位置 */
    @Column( name = "END_INDEX")
    private String endIndex;

    /** 数据类型:RSP,响应报文，REQ：请求报文 */
    @Column( name = "DATA_KIND")
    private String dataKind;

    /** 数据对象定义 */
    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "procotolResolvePlan")
    private Set<ProcotolResolveRule> procotolResolveRules;

    /** 接出服务接口 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "OUT_BOUND_SVC_ID", referencedColumnName = "OUT_BOUND_SVC_ID")
    private OutBoundSvc outBoundSvc;

    /** 接入服务接口 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "IN_BOUND_SVC_ID", referencedColumnName = "IN_BOUND_SVC_ID")
    private InBoundSvc inBoundSvc;

    public String getProcotolResolvePlanId() {
        return procotolResolvePlanId;
    }

    public void setProcotolResolvePlanId(String procotolResolvePlanId) {
        this.procotolResolvePlanId = procotolResolvePlanId;
    }

    public String getSeparatorChar() {
        return separatorChar;
    }

    public void setSeparatorChar(String separatorChar) {
        this.separatorChar = separatorChar;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getBeginIndex() {
        return beginIndex;
    }

    public void setBeginIndex(String beginIndex) {
        this.beginIndex = beginIndex;
    }

    public String getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(String endIndex) {
        this.endIndex = endIndex;
    }

    public String getDataKind() {
        return dataKind;
    }

    public void setDataKind(String dataKind) {
        this.dataKind = dataKind;
    }

    public Set<ProcotolResolveRule> getProcotolResolveRules() {
        return procotolResolveRules;
    }

    public void setProcotolResolveRules(Set<ProcotolResolveRule> procotolResolveRules) {
        this.procotolResolveRules = procotolResolveRules;
    }

    public OutBoundSvc getOutBoundSvc() {
        return outBoundSvc;
    }

    public void setOutBoundSvc(OutBoundSvc outBoundSvc) {
        this.outBoundSvc = outBoundSvc;
    }

    public InBoundSvc getInBoundSvc() {
        return inBoundSvc;
    }

    public void setInBoundSvc(InBoundSvc inBoundSvc) {
        this.inBoundSvc = inBoundSvc;
    }
}
