package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/1/2 16:06
 */
@FunctionLibrary( code = "sub", name = "截取", expression = "(sub\\()([\\s\\w,|]+\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "sub(x|y)", hasProperty = true )
@Component
public class SubFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        //sub(1|2,123)
        // 先逗号分割， 再其他
        String[] str2 = params.split(",", -1);
        String[] indexArr = str2[ 0 ].split("\\|");

        String valStr = params.substring(params.indexOf(",") + 1);

        //再次分割  2,  123
        int start;
        int end;
        int len;
        try {
            start = Integer.parseInt(indexArr[ 0 ]);
            end = Integer.parseInt(indexArr[ 1 ]);
            //结束位置超过总长度的时候，只需要截取到字符串的末尾就可以了。
            len = valStr.length();
            end = end > len ? len : end;
            return StringUtils.isNotBlank(valStr) ? valStr.substring(start, end) : "";
        } catch (Exception e) {
            // 截取失败时，返回原串
            return valStr;
        }

    }
}
