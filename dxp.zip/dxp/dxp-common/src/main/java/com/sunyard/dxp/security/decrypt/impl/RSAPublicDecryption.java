package com.sunyard.dxp.security.decrypt.impl;

import com.sunyard.dxp.security.decrypt.Decryption;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;

/**
 * RSA公钥解密
 */
public class RSAPublicDecryption implements Decryption {
    private static final Logger LOGGER = LoggerFactory.getLogger( RSAPublicDecryption.class );

    @Override
    public String decrypt(String content, String key) {
        byte[] bytesContent = Base64.decodeBase64(content);
        byte[] bytesKey = Base64.decodeBase64(key);
        try {
            //实例化密钥工厂
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            //初始化公钥
            //密钥材料转换
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(bytesKey);
            //产生公钥
            PublicKey pubKey = keyFactory.generatePublic(x509KeySpec);
            //数据解密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, pubKey);
            return new String(cipher.doFinal(bytesContent));
        }catch (Exception e){
            LOGGER.error("RSA公钥解密失败");
            throw new FapException("","RSA公钥解密失败");
        }
    }
}