package com.sunyard.dxp.constants;

/**
 * @Description 公共常量
 * @Author zhangxin
 * @Date 2020/1/10 17:27
 * @Version 1.0
 */
public class CommonConstants {

    private CommonConstants() {
    }

    /**
     * 单笔签名域
     */
    public static final String SIGN = "sign";

    /**
     * 批量签名域
     */
    public static final String  BATCHSIGN = "batch_sign";

    /**
     * 核押需要的机构号
     */
    public static final String MYJ_ORG = "myj_org";

    /**
     * 发送报文到中心 accessToken 认证 key
     */
    public static final String ACCESS_TOKEN = "access_token";
    /**
     * 发送报文到中心 Cookie 认证 key
     */
    public static final String COOKIE = "Cookie";

}
