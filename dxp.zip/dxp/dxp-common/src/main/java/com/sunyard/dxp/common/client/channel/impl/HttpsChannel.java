package com.sunyard.dxp.common.client.channel.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sunyard.dxp.RequestUtils;
import com.sunyard.dxp.common.client.channel.Channel;
import com.sunyard.frameworkset.core.exception.FapException;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 发送 https 请求
 */
@Component( "httpsChannel" )
public class HttpsChannel implements Channel {
    @Override
    public Map< String, Object > send(String url, Object requestBody, boolean send2Center) {
        Map< String, Object > request = (Map< String, Object >) requestBody;

        String rspMessage = "" ;
        try {
            rspMessage = RequestUtils.sendHttpsPost(url, JSONObject.toJSONString(request));
            return JSON.parseObject(rspMessage);
        } catch (Exception e) {
            throw new FapException("", "httpspost 请求失败["+url+"]"+ e);
        }
    }
}
