package com.sunyard.dxp.security.decoder.impl;

import com.sunyard.dxp.security.decoder.Decoder;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

import java.nio.charset.StandardCharsets;

/**
 * 编码转换为UTF-8
 */
public class GBKDecoder implements Decoder {

    private static final Logger LOGGER = LoggerFactory.getLogger( GBKDecoder.class );


    @Override
    public String decode(String content) {
        String clientStr = null;
        try {
            clientStr = new String(content.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        }catch (Exception e){
            LOGGER.error("解码失败！");
            throw new FapException("","解码失败！");
        }
        return clientStr;
    }
}
