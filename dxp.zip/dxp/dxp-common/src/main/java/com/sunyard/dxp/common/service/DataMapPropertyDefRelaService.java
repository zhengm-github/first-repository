package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.DataMapPropertyDefRela;
import com.sunyard.dxp.common.qo.DataMapPropertyDefRelaQo;

/**
 * 请求报文映射配置属性 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:25:20 CST 2020
 */
public interface DataMapPropertyDefRelaService extends BaseService<DataMapPropertyDefRela, String, DataMapPropertyDefRelaQo> {
    /**
     * 根据数据属性id删除请求报文映射配置
     * @param propertyId
     * @return
     */
    void deleteByPropertyId(String propertyId);

    /**
     * 根据数据属性id 和 configId删除请求报文映射配置
     * @param propertyId
     * @param configId
     * @return
     */
    void deleteByPropertyIdAndConfig(String propertyId, String configId);
}
