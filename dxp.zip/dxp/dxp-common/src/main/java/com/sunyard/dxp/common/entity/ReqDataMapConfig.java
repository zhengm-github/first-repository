package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 请求报文映射配置
* Author: Created by code generator
* Date: Tue Jan 07 19:15:01 CST 2020
*/
@Entity
@Table(name = "DXP_REQ_DATA_MAP_CONFIG")
public class ReqDataMapConfig implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6932817554925709736L;

    /** 请求报文映射配置ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "DATA_MAP_CONFIG_ID")
    private String dataMapConfigId;

    /** 映射表达式 */
    @Column( name = "MAP_EXP")
    private String mapExp;

    /** 顺序号 */
    @Column( name = "ORD")
    private Integer ord;

    /** 数据绑定模式 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "DATA_MAP_SCHEMA_ID", referencedColumnName = "DATA_MAP_SCHEMA_ID")
    private DataBindSchema dataBindSchema;

    /** 接出请求报文属性 */
    @ManyToMany( fetch = FetchType.EAGER, cascade = CascadeType.REFRESH )
    @JoinTable( name = "DXP_DATA_MAP_PROPERTY_DEF_RELA",
            joinColumns = { @JoinColumn( name = "DATA_MAP_CONFIG_ID", referencedColumnName = "DATA_MAP_CONFIG_ID" ) },
            inverseJoinColumns = { @JoinColumn( name = "DATA_PROPERTY_ID", referencedColumnName = "DATA_PROPERTY_ID" ) } )
    private Set< DataPropertyDef > outDataPropertyDefs;

    /** 接入请求报文属性 */
    @ManyToOne(fetch = FetchType.EAGER, optional = true )
    @JoinColumn(name = "IN_DATA_PROPERTY_ID", referencedColumnName = "DATA_PROPERTY_ID")
    private DataPropertyDef inDataPropertyDef;

    public String getDataMapConfigId() {
        return dataMapConfigId;
    }

    public void setDataMapConfigId(String dataMapConfigId) {
        this.dataMapConfigId = dataMapConfigId;
    }

    public String getMapExp() {
        return mapExp;
    }

    public void setMapExp(String mapExp) {
        this.mapExp = mapExp;
    }

    public Integer getOrd() {
        return ord;
    }

    public void setOrd(Integer ord) {
        this.ord = ord;
    }

    public DataBindSchema getDataBindSchema() {
        return dataBindSchema;
    }

    public void setDataBindSchema(DataBindSchema dataBindSchema) {
        this.dataBindSchema = dataBindSchema;
    }

    public Set<DataPropertyDef> getOutDataPropertyDefs() {
        return outDataPropertyDefs;
    }

    public void setOutDataPropertyDefs(Set<DataPropertyDef> outDataPropertyDefs) {
        this.outDataPropertyDefs = outDataPropertyDefs;
    }

    public DataPropertyDef getInDataPropertyDef() {
        return inDataPropertyDef;
    }

    public void setInDataPropertyDef(DataPropertyDef inDataPropertyDef) {
        this.inDataPropertyDef = inDataPropertyDef;
    }

}
