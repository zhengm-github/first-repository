package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.UnitsDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.UnitsService;
import com.sunyard.dxp.common.entity.Units;
import com.sunyard.dxp.common.qo.UnitsQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 单位 service
 *
 * Author: Created by code generator
 * Date: Wed Dec 25 19:35:40 CST 2019
 */
@Service
public class UnitsServiceImpl extends BaseServiceImpl<Units, String, UnitsQo> implements UnitsService {
    @Autowired
    private UnitsDao unitsDao;

    @Override
    public Units findUnitsByCode(String code) {
        return unitsDao.findUnitsByCode(code);
    }
}
