package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.DataBindSchemaQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 数据绑定模式 Qct转化类
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:53 CST 2019
 */
public class DataBindSchemaQct extends QueryConditionTransfer< DataBindSchemaQo > {

    @Override
    public void transNameQuery(DataBindSchemaQo qo, QueryCondition condition) {
        //
    }

    @Override
    public void transQuery(DataBindSchemaQo qo, QueryCondition condition) {
        //
    }

}
