package com.sunyard.dxp.message.dto;

import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.EncoderEnum;

import java.util.List;

/**
 * @Description 解析报文所有参数
 * @Author zhangxin
 * @Date 2020/1/9 9:29
 * @Version 1.0
 */
public class RequestResolveDto {

    public RequestResolveDto() {
    }

    public RequestResolveDto(String msgProtocol, List<ProcotolResolveRule> procotolResolveRules, String encoding, String message, String fileMessage) {
        this.msgProtocol = msgProtocol;
        this.procotolResolveRules = procotolResolveRules;
        this.encoding = encoding;
        this.message = message;
        this.fileMessage = fileMessage;
    }

    /**
     * 报文协议
     */
    private String msgProtocol;

    /**
     * 协议解析规则
     */
    private List<ProcotolResolveRule> procotolResolveRules;

    /**
     * 编码
     */
    private String encoding;

    /**
     * 被解析报文
     */
    private String message;

    /**
     * 被解析文件报文
     */
    private String fileMessage;


    public String getMsgProtocol() {
        return msgProtocol;
    }

    public void setMsgProtocol(String msgProtocol) {
        this.msgProtocol = msgProtocol;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFileMessage() {
        return fileMessage;
    }

    public void setFileMessage(String fileMessage) {
        this.fileMessage = fileMessage;
    }

    public List<ProcotolResolveRule> getProcotolResolveRules() {
        return procotolResolveRules;
    }

    public void setProcotolResolveRules(List<ProcotolResolveRule> procotolResolveRules) {
        this.procotolResolveRules = procotolResolveRules;
    }
}
