package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.AppPublicKeyDao;
import com.sunyard.dxp.common.entity.AppPublicKey;
import com.sunyard.dxp.common.qo.AppPublicKeyQo;
import com.sunyard.dxp.common.service.AppPublicKeyService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 应用公钥 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:44 CST 2019
 */
@Service
public class AppPublicKeyServiceImpl extends BaseServiceImpl< AppPublicKey, String, AppPublicKeyQo > implements AppPublicKeyService {
    @Autowired
    private AppPublicKeyDao appPublicKeyDao;
    @Override
    public AppPublicKey findByKey(String publicKey) {
        return appPublicKeyDao.findByKey(publicKey);
    }
}
