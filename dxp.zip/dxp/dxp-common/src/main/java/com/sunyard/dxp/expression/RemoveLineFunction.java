package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 去除换行方法( 去除左右空格、英文逗号)
 */
@FunctionLibrary(code = "removeLine",name = "去除换行",expression = "(removeLine\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "all" ,isRelation = false,exp = "removeLine()")
@Component
public class RemoveLineFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        return params.replaceAll("\n"," ").replaceAll(","," ").trim();
    }
}
