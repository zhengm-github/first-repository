package com.sunyard.dxp.security.sign.impl;

import com.sunyard.dxp.security.sign.Signature;
import com.sunyard.dxp.utils.SignatureLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;

@SignatureLibrary(code = "SHA1WithRSASignature" , name = "SHA1WithRSA签名")
public class SHA1WithRSASignature implements Signature {
    private static final Logger LOGGER = LoggerFactory.getLogger( SHA1WithRSASignature.class );

    @Override
    public String sign(String src,String key) {
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(key));

            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey priKey = keyf.generatePrivate(priPKCS8);

            java.security.Signature signature = java.security.Signature.getInstance("SHA1WithRSA");

            signature.initSign(priKey);
            signature.update(src.getBytes(StandardCharsets.UTF_8));

            byte[] signed = signature.sign();

            return Base64.encodeBase64URLSafeString(signed);
        } catch (Exception e) {
            LOGGER.error("SHA1WithRSA签名失败");
            throw new FapException("","SHA1WithRSA签名失败");
        }
    }
}
