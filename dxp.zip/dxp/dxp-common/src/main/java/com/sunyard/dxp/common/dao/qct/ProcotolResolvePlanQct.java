package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.ProcotolResolvePlanQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;
import org.apache.commons.lang3.StringUtils;

/**
 * 协议解析规划 Qct转化类
 * <p>
 * Author: Created by code generator
 * Date: Tue Jan 07 19:22:25 CST 2020
 */
public class ProcotolResolvePlanQct extends QueryConditionTransfer< ProcotolResolvePlanQo > {

    @Override
    public void transNameQuery(ProcotolResolvePlanQo qo, QueryCondition condition) {
        if (qo != null) {
            if (StringUtils.isNotBlank(qo.getName())) {
                condition.add(" and obj.name = :name", "name", qo.getName());
            }
            if (StringUtils.isNotBlank(qo.getMemo())) {
                condition.add(" and obj.memo = :memo", "memo", qo.getMemo());
            }
            /*关键字模糊查询*/
            if (StringUtils.isNotBlank(qo.getKeyword())) {
                condition.add(" and ( obj.memo like :memo", "memo", qo.getBlurKeyword());
                condition.add(" or obj.name like :name ) ", "name", qo.getBlurKeyword());
            }
        }
    }

    @Override
    public void transQuery(ProcotolResolvePlanQo qo, QueryCondition condition) {
        //
    }

}
