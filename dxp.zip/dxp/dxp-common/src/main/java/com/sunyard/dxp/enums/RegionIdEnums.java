package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * Write class comments here
 * *
 * User: wuyongzhi
 * Date: 2017/7/11 10:21
 * version $Id: AccessKeyEnum.java, v 0.1 Exp $
 */
public enum RegionIdEnums implements EnumAware {
    BEIJING ("110000","北京"),
    CHANGZHOU ("320400","常州"),
    CHENGDU ("510100","成都"),
    GUANGZHOU ("440100","广州"),
    HANGZHOU ("330100","杭州"),
    KUNMING ("530100","昆明"),
    NANJING ("320100","南京"),
    NANNING ("450100","南宁"),
    NINGBO ("330200","宁波"),
    SHANGHAI ("310000","上海"),
    SHENZHENG ("440300","深圳"),
    SUZHOU ("320500","苏州"),
    WUHAN ("420100","武汉"),
    XIAN ("610100","西安"),
    ;

    private String code;

    private String name;

    RegionIdEnums(String code, String name) {
        this.code = code;
        this.name = name;
    }
    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return null;
    }


    public static String getMapperNameByCode(String code) {
        for (RegionIdEnums enums : RegionIdEnums.values()) {
            if (enums.code.equals(code)) {
                return enums.name;
            }
        }
        return code;
    }
}
