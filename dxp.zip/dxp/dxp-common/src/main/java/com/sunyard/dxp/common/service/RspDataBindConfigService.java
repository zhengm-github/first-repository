package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.RspDataBindConfig;
import com.sunyard.dxp.common.qo.RspDataBindConfigQo;

import java.util.List;

/**
 * 数据绑定配置 service 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:43:42 CST 2019
 */
public interface RspDataBindConfigService extends BaseService<RspDataBindConfig, String, RspDataBindConfigQo> {

    /**
     * 根据接出数据结果属性id查询数据绑定配置
     * @param outDataPropertyId
     * @return
     */
    List<RspDataBindConfig> findDataBindConfigByOutProId(String outDataPropertyId);

    /**
     * 根据接入数据属性id删除响应数据绑定配置
     * @param propertyId
     * @return
     */
    void deleteByPropertyId(String propertyId);
}
