package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 通过竖线分割各个属性值
 */
@FunctionLibrary( code = "NBCBSP", name = "根据业务类型 转换 处理码为 单位码 ", expression = "(\\$\\{[\\s\\w]+\\})(NBCBSP)(\\$\\{[\\s\\w]+\\})", type = "all", isRelation = true, exp = "NBCBSP" )
@Component
public class NBCBSPFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {

        if (StringUtils.isNotBlank(params) && params.contains("NBCBSP")) {
            String[] paramArr = params.split("NBCBSP");
            if (paramArr.length < 2) {
                return "";  // 原交易没有状态 则保持原样
            }
            try {

                String value = ExpMapper.NBcbspMap.get(paramArr[ 0 ] + "-" + paramArr[ 1 ]);

                if (value != null && value.contains(",")) {
                    return value.split(",", -1)[ 0 ];
                }
                return "";
            } catch (Exception e) {
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                        DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
            }
        }
        return params;
    }
}
