package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 数据属性定义
* Author: Created by code generator
* Date: Tue Dec 24 10:45:55 CST 2019
*/
@Entity
@Table(name = "DXP_DATA_PROPERTY_DEF")
public class DataPropertyDef implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7165387379978496936L;

    /** 数据结果属性Id */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "DATA_PROPERTY_ID")
    private String dataPropertyId;

    /** 名称 */
    @Column( name = "NAME")
    private String name;

    /** 备注 */
    @Column( name = "MEMO")
    private String memo;

    /** 可选 */
    @Column( name = "OPTIONAL")
    private Boolean optional;

    /** 值类型 */
    @Column( name = "DATA_TYPE")
    private String dataType;

    /** 父级属性 */
    @ManyToOne(fetch = FetchType.EAGER, optional = true )
    @JoinColumn(name = "PARENT_ID")
    private DataPropertyDef parent;

    /** 子级属性 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REFRESH}, mappedBy = "parent")
    private Set<DataPropertyDef> childProperties;

    /** 数据对象定义 */
    @ManyToOne(fetch = FetchType.EAGER, optional = true )
    @JoinColumn(name = "DATA_OBJ_DEF_ID", referencedColumnName = "DATA_OBJ_DEF_ID")
    private DataObjDef dataObjDef;

    /** 接出响应报文绑定 */
    @OneToOne(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "outDataPropertyDef")
    private RspDataBindConfig outRspDataBindConfig;

    /** 接入响应报文绑定 */
    @ManyToMany( fetch = FetchType.EAGER,  cascade = CascadeType.REFRESH, mappedBy = "inDataPropertyDefs" )
    private Set<RspDataBindConfig> inRspDataBindConfigs;

    /** 接入请求报文映射 */
    @OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.REFRESH}, mappedBy = "inDataPropertyDef")
    private Set<ReqDataMapConfig> inReqDataMapConfigs;

    /** 接出请求报文映射 */
    @ManyToMany( fetch = FetchType.EAGER,  cascade = CascadeType.REFRESH, mappedBy = "outDataPropertyDefs" )
    private Set<ReqDataMapConfig> outReqDataMapConfigs;

    /** 签名配置项 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REFRESH}, mappedBy = "dataPropertyDef")
    private Set<SignConfigItem> signConfigItems;

    public String getDataPropertyId() {
        return dataPropertyId;
    }

    public void setDataPropertyId(String dataPropertyId) {
        this.dataPropertyId = dataPropertyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Boolean getOptional() {
        return optional;
    }

    public void setOptional(Boolean optional) {
        this.optional = optional;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public DataPropertyDef getParent() {
        return parent;
    }

    public void setParent(DataPropertyDef parent) {
        this.parent = parent;
    }

    public Set<DataPropertyDef> getChildProperties() {
        return childProperties;
    }

    public void setChildProperties(Set<DataPropertyDef> childProperties) {
        this.childProperties = childProperties;
    }

    public DataObjDef getDataObjDef() {
        return dataObjDef;
    }

    public void setDataObjDef(DataObjDef dataObjDef) {
        this.dataObjDef = dataObjDef;
    }

    public RspDataBindConfig getOutRspDataBindConfig() {
        return outRspDataBindConfig;
    }

    public void setOutRspDataBindConfig(RspDataBindConfig outRspDataBindConfig) {
        this.outRspDataBindConfig = outRspDataBindConfig;
    }

    public Set<RspDataBindConfig> getInRspDataBindConfigs() {
        return inRspDataBindConfigs;
    }

    public void setInRspDataBindConfigs(Set<RspDataBindConfig> inRspDataBindConfigs) {
        this.inRspDataBindConfigs = inRspDataBindConfigs;
    }

    public Set<ReqDataMapConfig> getInReqDataMapConfigs() {
        return inReqDataMapConfigs;
    }

    public void setInReqDataMapConfigs(Set<ReqDataMapConfig> inReqDataMapConfigs) {
        this.inReqDataMapConfigs = inReqDataMapConfigs;
    }

    public Set<ReqDataMapConfig> getOutReqDataMapConfigs() {
        return outReqDataMapConfigs;
    }

    public void setOutReqDataMapConfigs(Set<ReqDataMapConfig> outReqDataMapConfigs) {
        this.outReqDataMapConfigs = outReqDataMapConfigs;
    }

    public Set<SignConfigItem> getSignConfigItems() {
        return signConfigItems;
    }

    public void setSignConfigItems(Set<SignConfigItem> signConfigItems) {
        this.signConfigItems = signConfigItems;
    }
}
