package com.sunyard.dxp.message.service.impl;

import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import com.sunyard.dxp.utils.Constant;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.*;

/**
 * 定长报文头+签名域+XML报文+xml明细文件
 * <p>
 * 文件内容保存到临时文件
 */
@Service( "fixedAndSignAndXmlAndXmlFileResolve" )
@AgreementLibrary( code = "fixedAndSignAndXmlAndXmlFile", name = "定长报文头+签名域+XML报文+XML文件" )
public class RequestResolveServiceFixedAndSignAndXmlAndXmlFileImpl implements RequestResolveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestResolveServiceFixedAndSignAndXmlAndXmlFileImpl.class);

    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Autowired
    @Qualifier( "regionSign" )
    private SignService regionSignService;

    @Value( "${config.path}" )
    private String configPath;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 5) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
        if (StringUtils.isEmpty(requestResolveDto.getFileMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_014);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        // 将rule 根据类型分为 报文和文件
        List< ProcotolResolveRule > packRuleList = new ArrayList<>();    // 报文规则
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();   // 文件规则
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if ("pack".equals(procotolResolveRule.getRuleType())) {
                packRuleList.add(procotolResolveRule);
            } else if ("file".equals(procotolResolveRule.getRuleType())) {
                fileRuleList.add(procotolResolveRule);
            }
        }
        // 先处理报文， 后处理文件
        // 拆分报文内容 （1、报文头， 2、sign， 3、报文体）
        String[] splitPackMessage = splitMessage(requestResolveDto.getMessage(), requestResolveDto.getEncoding(), packRuleList);

        // 解析之前先校验sign
        String xmlBody = regionSignService.validateSign(signDto, splitPackMessage[ 1 ], "");

        //1、 定长报文头数据解析 （签名域无需处理）
        List< ParamRule > packHeadRules = RuleConvertUtils.convertFixedRules(packRuleList.get(0).getChildRules());
        Map< String, Object > packHead =
                baseResolveService.execute(packHeadRules, splitPackMessage[ 0 ], requestResolveDto.getEncoding());
        // 2、xml报文数据解析
        List< ParamRule > packBodyRules = RuleConvertUtils.convertXmlRules(packRuleList.get(2).getChildRules());
        Map< String, Object > packBody =
                baseResolveXmlService.execute(packBodyRules, xmlBody, requestResolveDto.getEncoding());

        packBody.putAll(packHead);

        // xml文件处理（没有文件头），可能包含 detail明细域
        resolveFile(fileRuleList, requestResolveDto.getFileMessage(), packBody, requestResolveDto.getEncoding());
        return packBody;
    }

    /**
     * 分割内容
     *
     * @param message
     * @param encoding
     * @param ruleList
     * @return
     */
    public String[] splitMessage(String message, String encoding, List< ProcotolResolveRule > ruleList) {
        String[] result = new String[ 3 ];
        ProcotolResolveRule fixedRule = ruleList.get(0);
        ProcotolResolveRule signRule = ruleList.get(1);
        try {
            if (EncoderEnum.ISO88591.getCode().equals(encoding)) {
                encoding = "GB18030";
            }
            byte[] messageBytes = message.getBytes(encoding);
            int fixedStart = fixedRule.getBeginIndex();
            int fixedLength = fixedRule.getEndIndex() - fixedStart + 1;
            // 定长报文头
            result[ 0 ] = new String(messageBytes, fixedStart, fixedLength, encoding).trim();

            // sign
            int signStart = signRule.getBeginIndex();
            int signLength = messageBytes.length - signStart;
            result[ 1 ] = new String(messageBytes, signStart, signLength, encoding).trim();

        } catch (UnsupportedEncodingException e) {
            LOGGER.info("解析数据失败！message=[{}], e=[{}]", message, e);
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_002);
        }
        return result;
    }

    /**
     * 专门处理 xml 文件解析，包含 detail明细(xml 不存在报文头)
     *
     * @param fileMessage
     * @param result      存放解析结果
     * @param encoding
     */
    private void resolveFile(List< ProcotolResolveRule > fileParentRuleList, String fileMessage, Map< String, Object > result, String encoding) {

        //fileParentRuleList 可能有文件头
        ProcotolResolveRule bodyRule = null;
        // 可能没有文件规则！！
        if (CollectionUtils.isEmpty(fileParentRuleList)) {
            return;
        }
        if (fileParentRuleList.size() > 1) {
            bodyRule = fileParentRuleList.get(1);
        } else {
            bodyRule = fileParentRuleList.get(0);
        }
        // 对文件体进行处理
        List< ParamRule > fileBodyParamList = RuleConvertUtils.convertXmlRules(bodyRule.getChildRules());
        Map< String, Object > fileBody =
                baseResolveXmlService.execute(fileBodyParamList, fileMessage, encoding);
        result.putAll(fileBody);
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {

        Map< String, Object > resultMap = new HashMap<>(); // 总结果

        StringBuilder sb = new StringBuilder();  // 报文部分结果
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        // 将rule 根据类型分为 报文和文件
        List< ProcotolResolveRule > packRuleList = new ArrayList<>();    // 报文规则
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();   // 文件规则
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if ("pack".equals(procotolResolveRule.getRuleType())) {
                packRuleList.add(procotolResolveRule);
            } else if ("file".equals(procotolResolveRule.getRuleType())) {
                fileRuleList.add(procotolResolveRule);
            }
        }

        // 报文头规则
        List< ParamRule > packHeadRules = RuleConvertUtils.convertFixedRules(packRuleList.get(0).getChildRules());
        Map< String, Object > packHeadMessage =
                baseResolveService.mapExecute(packHeadRules, map, requestResolveDto.getEncoding());

        // 组装文件内容
        String fileBodyMessage = "";
        if (CollectionUtils.isNotEmpty(fileRuleList) && fileRuleList.size() > 0) {
            fileBodyMessage = getXmlFileMessage(fileRuleList.get(0), map, requestResolveDto);
        }

        map.put(MsgKeys.XML_DETAIL, null);  // 避免报文处理的时候对明细处理了
        // 报文体规则
        List< ParamRule > packBodyRules = RuleConvertUtils.convertXmlRules(packRuleList.get(2).getChildRules());
        Map< String, Object > bodyResult =
                baseResolveXmlService.mapExecute(packBodyRules, map, requestResolveDto.getEncoding());

        String xmlBody = bodyResult.get(MsgKeys.PACKAGE).toString();

        // 组装签名部分
        Map< String, String > dataMap = regionSignService.makeSign(signDto, xmlBody);
        sb.append(packHeadMessage.get(MsgKeys.PACKAGE))
                .append(dataMap.get("xmlBody"));
        resultMap.put(MsgKeys.PACKAGE, sb.toString());
        resultMap.put("file", fileBodyMessage);
        return resultMap;
    }

    /**
     * 文件处理（ 可能包含detail部分）
     *
     * @param fileRule
     * @param map
     * @return
     */
    private String getXmlFileMessage(
            ProcotolResolveRule fileRule, Map< String, Object > map, RequestResolveDto requestResolveDto) {


        List< ParamRule > fileBodyRules = RuleConvertUtils.convertXmlRules(fileRule.getChildRules());

        // 临时文件
        PrintWriter pw = null; // 存储拼接好的明细信息
        String filePath = Constant.TEMP_FILES_PATH + File.separator + "detail_files";
        String fileName = String.format("xmldetail_%s_%s_%s",
                DateFormatUtils.format(new Date(), "HHmmss"), Thread.currentThread().getName(), UUIDUtils.getUUID32());

        // 第二个参数要保证是 loop的父级结点。
        Map< String, Object > xmlMap =
                baseResolveXmlService.mapExecute(fileBodyRules, map, requestResolveDto.getEncoding());
        // 保存明细明文信息
        try {
            // 满足通讯适配器Gzip
            String pwGZIPEncode = requestResolveDto.getEncoding();
            if (EncoderEnum.ISO88591.getCode().equals(pwGZIPEncode)) {
                pwGZIPEncode = "GB18030";
            }
            pw = new PrintWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(
                                    new File(filePath + File.separator + fileName)),
                            pwGZIPEncode));
            pw.print(xmlMap.get(MsgKeys.PACKAGE).toString());
            pw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pw.close();
        }
        return fileName;// 处理xml_file中包含明细数据
    }
}
