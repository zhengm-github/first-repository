package com.sunyard.dxp.utils;

import com.alibaba.fastjson.JSON;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Created by Administrator on 2017/11/17.
 */
public class RequestUtil {

    private static final Logger logger = LoggerFactory.getLogger( RequestUtil.class );

    public static Map<String, String> analysis(HttpServletRequest request) {
        Map<String, String> params = null;
        InputStream input = null;
        try {
             input = request.getInputStream();
             params = JSON.parseObject(getParamFromInputStream(input), Map.class);
        } catch (Exception e) {
            logger.error("" , e);
            return null;
        }finally {
            try {
                if (input != null) {
                    input.close();
                }
            } catch (IOException e) {
                logger.error("" , e);
            }
        }
        return params;
    }

    public static Map<String, Object> analysisRequest(HttpServletRequest request) {
        Map<String, Object> params = null;
        InputStream input = null;
        try {
            input = request.getInputStream();
            params = JSON.parseObject(getParamFromInputStream(input), Map.class);

        } catch (Exception e) {
            logger.error("" , e);
            return null;
        } finally {
            try {
                if (input != null) {
                    input.close();
                }
            } catch (IOException e) {
                logger.error("" , e);
            }
        }
        return params;
    }


    public static String getParamFromInputStream(InputStream input) {
        String str = null;
        StringBuilder sb = null;
        try(BufferedReader rd = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            sb = new StringBuilder();
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            str = sb.toString();
        } catch (Exception e) {
            return null;
        }
        return str;
    }

    private RequestUtil(){}

}
