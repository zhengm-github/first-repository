package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.SvcModelRela;
import com.sunyard.dxp.common.qo.SvcModelRelaQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 接入服务模块关系 dao 接口
 *
 * Author: Created by code generator
 * Date: Mon Dec 16 14:26:15 CST 2019
 */
public interface SvcModelRelaDao extends BaseDao< SvcModelRela, String, SvcModelRelaQo > {

    /**
     * 根据serviceBundleId 查询
     * @param serviceBundleId
     * @return
     */
    List<SvcModelRela> findByHql(String serviceBundleId) ;

    /**
     * 根据接入接口id查询
     * @param inBoundSvcId
     * @return
     */
    List<SvcModelRela> findByInBoundSvcId(String inBoundSvcId) ;

    /**
     * 根据接入接口id和 serviceBoundId查询
     * @param inBoundSvcId
     * @param serviceBoundId
     * @return
     */
    SvcModelRela findByInBoundSvcIdAndServiceBoundId(String inBoundSvcId, String serviceBoundId) ;

    /**
     * 根据接入接口id删除
     * @param inBoundSvcId
     */
    void deleteByInBoundSvcId(String inBoundSvcId) ;

    /**
     * 根据接入接口id 和 ServiceBoundId删除
     * @param serviceBoundId
     * @param inBoundSvcId
     */
    void deleteByInBoundSvcIdAndServiceBoundId(String serviceBoundId, String inBoundSvcId) ;

    /**
     * 根据id删除服务
     * @param ids
     */
    void deleteSvcModelRelaByIds(String... ids);
}
