package com.sunyard.dxp.common.entity;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/11/20.
 */
public class DxpRequest {

    String tranId;

    /** 接入请求路径 */
    List<AddrInfo> url;

    /** 服务接口类型 */
    String serviceType;

    /** 服务模块id */
    String bundleId;

    /**接入服务*/
    InBoundSvc inBoundSvc ;

    /**接出服务*/
    OutBoundSvc outBoundSvc ;

//    /** 接入服务id */
//    String inServiceId;
//
//    /** 接出服务id */
//    String outServiceId;

    /** 应用编号 */
    String appCode;

    /** 应用名称 */
    String appName;

    /** 服务模块编号 */
    String bundleCode;

    /** 服务模块名称 */
    String bundleName;

//    /** 接入服务编号 */
//    String inServiceCode;
//
//    /** 接入服务名称 */
//    String inServiceName;

    /** 接入服务类型 */
    String inServiceTypeCode;

    /** 参数内容 */
    Map<String, Object> param;

    /** 附加参数 */
    Map<String, String> extraParams ;

    /**单位code*/
    String code;

    //请求报文信息
    String reqMessage;

    String callBackUrl;

    Map<String, Object> body;

    /**
     *  业务Id
     */
    String msgTranId ;
    /**
     * 原业务Id
     */
    String oriMsgTranId ;
    /**
     * 文件明细
     */
    List<Map<String, Object>> fileBody ;

    /**
     * xml中定长明细
     */
    List<Map<String, Object>> xmlDetail ;

    String corpId ;

    public InBoundSvc getInBoundSvc( ) {
        return inBoundSvc;
    }

    public void setInBoundSvc(InBoundSvc inBoundSvc) {
        this.inBoundSvc = inBoundSvc;
    }

    public OutBoundSvc getOutBoundSvc( ) {
        return outBoundSvc;
    }

    public void setOutBoundSvc(OutBoundSvc outBoundSvc) {
        this.outBoundSvc = outBoundSvc;
    }

    public String getCorpId( ) {
        return corpId;
    }

    public void setCorpId(String corpId) {
        this.corpId = corpId;
    }

    public List< Map< String, Object > > getXmlDetail( ) {
        return xmlDetail;
    }

    public void setXmlDetail(List< Map< String, Object > > xmlDetail) {
        this.xmlDetail = xmlDetail;
    }

    public List< Map< String, Object > > getFileBody( ) {
        return fileBody;
    }

    public void setFileBody(List< Map< String, Object > > fileBody) {
        this.fileBody = fileBody;
    }

    public String getMsgTranId( ) {
        return msgTranId;
    }

    public void setMsgTranId(String msgTranId) {
        this.msgTranId = msgTranId;
    }

    public String getOriMsgTranId( ) {
        return oriMsgTranId;
    }

    public void setOriMsgTranId(String oriMsgTranId) {
        this.oriMsgTranId = oriMsgTranId;
    }

    public String getCallBackUrl() {
        return callBackUrl;
    }

    public void setCallBackUrl(String callBackUrl) {
        this.callBackUrl = callBackUrl;
    }

    public String getTranId() {
        return tranId;
    }

    public void setTranId(String tranId) {
        this.tranId = tranId;
    }

    public String getReqMessage() {
        return reqMessage;
    }

    public void setReqMessage(String reqMessage) {
        this.reqMessage = reqMessage;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List< AddrInfo > getUrl( ) {
        return url;
    }

    public void setUrl(List< AddrInfo > url) {
        this.url = url;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getBundleCode() {
        return bundleCode;
    }

    public void setBundleCode(String bundleCode) {
        this.bundleCode = bundleCode;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public Map< String, Object > getParam( ) {
        return param;
    }

    public void setParam(Map< String, Object > param) {
        this.param = param;
    }

    public Map< String, Object > getBody( ) {
        return body;
    }

    public void setBody(Map< String, Object > body) {
        this.body = body;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getInServiceTypeCode() {
        return inServiceTypeCode;
    }

    public void setInServiceTypeCode(String inServiceTypeCode) {
        this.inServiceTypeCode = inServiceTypeCode;
    }

    public Map< String, String > getExtraParams( ) {
        return extraParams;
    }

    public void setExtraParams(Map< String, String > extraParams) {
        this.extraParams = extraParams;
    }
}
