package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 结束标识函数库
 */
@FunctionLibrary(code = "endSign",name = "结束标识符",expression = "(endSign\\()(\\))" ,type = "String",exp = "endSign()")
@Component
public class EndSignFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        return "}\r\n";
    }
}
