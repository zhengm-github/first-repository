package com.sunyard.dxp.message.template;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;

@Data
@XStreamAlias("column")
public class Column {

	/**
	 * 属性名
	 */
	@XStreamAsAttribute
	private String name;

	/**
	 * (xml报文)
	 * 属性值所在的xpath
	 */
	@XStreamAsAttribute
	private String xpath;

	/**
	 * 属性值的数据类型
	 */
	@XStreamAsAttribute
	private String dataType;

	/**
	 * 开始位置
	 */
	@XStreamAsAttribute
	private int start;
	/**
	 * (定长)
	 * 属性值的长度
	 */
	@XStreamAsAttribute
	private int length;

	/**
	 * 明细分隔符
	 */
	@XStreamAsAttribute
	private String separator;

	/**
	 * 明细字段分隔符
	 */
	@XStreamAsAttribute
	private String subSeparator;
}
