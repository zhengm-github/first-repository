package com.sunyard.dxp.message.service.impl;

import com.dexcoder.commons.utils.UUIDUtils;
import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.enums.EncoderEnum;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.service.SignService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import com.sunyard.dxp.utils.Constant;
import com.sunyard.dxp.utils.MsgKeys;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.math.BigDecimal;
import java.util.*;

/**
 * 定长报文头+签名域+XML报文+变长文件头+变长文件体 （VVFile — VariableAndVariableFile）
 * <p>
 * 文件内容保存到临时文件
 *
 * @author zhengm
 */
@Service( "fixedAndSignAndXmlAndVVFileResolve" )
@AgreementLibrary( code = "fixedAndSignAndXmlAndVVFile", name = "定长报文头+签名域+XML报文+变长文件头+变长文件体" )
public class fixedAndSignAndXmlAndVVFileImpl implements RequestResolveService {

    private static final Logger log = LoggerFactory.getLogger(fixedAndSignAndXmlAndVVFileImpl.class);

    @Autowired
    @Qualifier( "baseResolveServiceFixed" )
    private BaseResolveService baseResolveService;

    @Autowired
    @Qualifier( "baseResolveServiceVariable" )
    private BaseResolveService baseResolveServiceVariable;

    @Autowired
    @Qualifier( "baseResolveServiceXml" )
    private BaseResolveService baseResolveXmlService;

    @Autowired
    @Qualifier( "regionSign" )
    private SignService regionSignService;

    @Autowired
    private RequestResolveServiceFixedAndSignAndXmlImpl requestResolveServiceFixedAndSignAndXml;

    @Value( "${config.path}" )
    private String configPath;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 5) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
        if (StringUtils.isEmpty(requestResolveDto.getFileMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_014);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        List< ProcotolResolveRule > packRuleList = new ArrayList<>();
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();
        for (ProcotolResolveRule rule : ruleList) {
            if ("pack".equals(rule.getRuleType())) {
                packRuleList.add(rule);
            } else if ("file".equals(rule.getRuleType())) {
                fileRuleList.add(rule);
            }
        }

        // 拆分报文
        String[] splitMessage = requestResolveServiceFixedAndSignAndXml.splitMessage(requestResolveDto.getMessage(), requestResolveDto.getEncoding(), packRuleList);

        // 解析之前先校验sign (sign 和 xml在一起)
        String xmlBody = regionSignService.validateSign(signDto, splitMessage[ 1 ], "");

        // 定长报文规则
        List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(packRuleList.get(0).getChildRules());
        // xml报文规则
        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(packRuleList.get(2).getChildRules());
        Map< String, Object > head = baseResolveService.execute(headRules, splitMessage[ 0 ], requestResolveDto.getEncoding());
        Map< String, Object > body = baseResolveXmlService.execute(bodyRules, xmlBody, requestResolveDto.getEncoding());

        body.putAll(head);
        ProcotolResolveRule fileHeadRule = null;
        ProcotolResolveRule fileBodyRule = null;
        // 解析文件（定长文件头和 变长文件体， 肯定有）
        fileHeadRule = fileRuleList.get(0);
        fileBodyRule = fileRuleList.get(1);
        resolveFile(fileHeadRule, fileBodyRule, requestResolveDto.getFileMessage(), body, requestResolveDto.getEncoding());
        return body;
    }

    /**
     * 解析文件部分(变长文件头 + 变长文件体)
     *
     * @param fileHeadRule
     * @param fileBodyRule
     * @param fileMessage
     * @param result
     * @param encoding
     */
    private void resolveFile(
            ProcotolResolveRule fileHeadRule, ProcotolResolveRule fileBodyRule,
            String fileMessage, Map< String, Object > result, String encoding) {
        List< ParamRule > fileHeadRules = RuleConvertUtils.convertVariableRules(fileHeadRule.getChildRules());
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertVariableRules(fileBodyRule.getChildRules());
        // 处理变长文件体 ， 分隔文件 （\r\n）
        String[] rows = fileMessage.split(fileBodyRule.getSeparatorChar());  // 父级配的分隔符
        List< Map< String, Object > > details = new ArrayList<>();
        // 变长报文头在 文件解析的第一行
        Map< String, Object > head =
                baseResolveServiceVariable.execute(fileHeadRules, rows[ 0 ], new String[] { encoding, fileBodyRules.get(0).getDetailSeparator() });
        result.putAll(head);
        // 以下全是明细
        for (int i = 1; i < rows.length; i++) {
            // 空行不处理
            if (StringUtils.isEmpty(rows[ i ])) {
                continue;
            }
            String row = rows[ i ];
            Map< String, Object > body =
                    baseResolveServiceVariable.execute(fileBodyRules, row, new String[] { encoding, fileBodyRules.get(0).getDetailSeparator() });
            details.add(body);
        }
        result.put(MsgKeys.FILE_BODY_DETAIL, details);
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > ruleList = requestResolveDto.getProcotolResolveRules();
        List< ProcotolResolveRule > packRuleList = new ArrayList<>();
        List< ProcotolResolveRule > fileRuleList = new ArrayList<>();
        for (ProcotolResolveRule procotolResolveRule : ruleList) {
            if (("pack").equals(procotolResolveRule.getRuleType())) {
                packRuleList.add(procotolResolveRule);
            } else if ("file".equals(procotolResolveRule.getRuleType())) {
                fileRuleList.add(procotolResolveRule);
            }
        }
        // 报文部分
        List< ParamRule > headRules = RuleConvertUtils.convertFixedRules(packRuleList.get(0).getChildRules());

        List< ParamRule > bodyRules = RuleConvertUtils.convertXmlRules(packRuleList.get(2).getChildRules());
        Map< String, Object > resultMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        Map< String, Object > headResult =
                baseResolveService.mapExecute(headRules, map, new String[] { requestResolveDto.getEncoding() });
        Map< String, Object > bodyResult =
                baseResolveXmlService.mapExecute(bodyRules, map, new String[] { requestResolveDto.getEncoding() });

        String fileName = "";
        if (CollectionUtils.isNotEmpty(fileRuleList) && fileRuleList.size() > 0) {
            fileName = getDetailFile(fileRuleList, map, requestResolveDto.getEncoding());
        }

        String xmlBody = bodyResult.get(MsgKeys.PACKAGE).toString();
        // 组装签名部分
        Map< String, String > dataMap = regionSignService.makeSign(signDto, xmlBody);
        sb.append(headResult.get(MsgKeys.PACKAGE))
                .append(dataMap.get("xmlBody"));
        resultMap.put(MsgKeys.PACKAGE, sb.toString());
        resultMap.put("file", fileName);
        return resultMap;
    }

    /**
     * 定长文件头和 变长文件体 组装
     *
     * @param fileRuleList
     * @param map
     * @param encode
     * @return
     */
    private String getDetailFile(List< ProcotolResolveRule > fileRuleList, Map< String, Object > map, String encode) {

        List< ParamRule > fileHeadRules = RuleConvertUtils.convertVariableRules(fileRuleList.get(0).getChildRules());
        List< ParamRule > fileBodyRules = RuleConvertUtils.convertVariableRules(fileRuleList.get(1).getChildRules());

        // 临时文件
        PrintWriter pw = null; // 存储拼接好的明细信息
        BufferedReader br = null;  // 读取转换之后的键值对文件

        String filePath = Constant.TEMP_FILES_PATH + File.separator + "detail_files";
        String fileName = String.format("vardetail_%s_%s_%s",
                DateFormatUtils.format(new Date(), "HHmmss"), Thread.currentThread().getName(), UUIDUtils.getUUID32());
        try {
            // 满足通讯适配器Gzip
            String pwGZIPEncode = encode;
            if (EncoderEnum.ISO88591.getCode().equals(pwGZIPEncode)) {
                pwGZIPEncode = "GB18030";
            }
            pw = new PrintWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(
                                    new File(filePath + File.separator + fileName)),
                            pwGZIPEncode));
            // 变长文件头处理
            Map< String, Object > fileHeadMap =
                    baseResolveServiceVariable.mapExecute(fileHeadRules, map, new String[] { encode, fileHeadRules.get(0).getDetailSeparator() });
            pw.print(fileHeadMap.get(MsgKeys.PACKAGE).toString());
            pw.print(fileHeadRules.get(0).getColumnSeparator());
            pw.flush();

            // 变长文件提处理, 对文件进行处理
            String inDetailFileName = (String) map.get(MsgKeys.XML_DETAIL);
            Map< Integer, String > sortMap = new TreeMap<>(
                    new Comparator< Integer >() {
                        public int compare(Integer obj1, Integer obj2) {
                            // 升序排序
                            return obj1.compareTo(obj2);
                        }
                    });
            String separator = fileBodyRules.get(0).getDetailSeparator();

            if (StringUtils.isNotBlank(inDetailFileName)) {
                String rowValue = "";
                br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(
                                        new File(inDetailFileName)), "UTF-8"));
                String rowStr = "";
                String[] headArr = null;
                String[] bodyArr = null;
                Map< String, String > rowDetailMap = null;
                int index = 0;
                while (StringUtils.isNotEmpty(rowStr = br.readLine())) {
                    if (index == 0) {
                        headArr = rowStr.split("\\$&\\$");  // 头里面一定不能有空格
                    } else {
                        rowDetailMap = new HashMap<>();
                        bodyArr = rowStr.split("\\$&\\$", -1);
                        for (int i = 0; i < headArr.length; i++) {
                            rowDetailMap.put(headArr[ i ], bodyArr.length >= (i + 1) ? bodyArr[ i ] : "");
                        }
                        for (ParamRule paramRule : fileBodyRules) {
                            if (!StringUtils.isEmpty(paramRule.getName())) {
                                rowValue = rowDetailMap.get(paramRule.getName());
                                if (Constant.AMT_LIST.contains(paramRule.getName())
                                        || paramRule.getName().endsWith("Amt")) {
                                    BigDecimal a = null;
                                    try {
                                        a = new BigDecimal(rowValue.replaceAll("CNY", ""))
                                                .setScale(2, BigDecimal.ROUND_HALF_UP);
                                        rowValue = a.toString();
                                    } catch (Exception e) {
                                        log.info("金额转换异常,[{}]", e);
                                        rowValue = "0";  // 金额默认是0
                                    }
                                }

                                if (rowValue != null) {
                                    //需要按照位置填写
                                    sortMap.put(paramRule.getStart(), rowValue);
                                }
                            }
                        }
                        // 将sortMap 读取成字符串
                        for (Integer key : sortMap.keySet()) {
                            pw.print(sortMap.get(key));
                            pw.print(separator);
                        }
                        pw.print("\n");
                        pw.flush();
                    }
                    index ++ ;
                }
            }
        } catch (Exception e) {
            log.info("明细读取失败！,[{}]", e);
        } finally {
            pw.close();  // 关闭写入流
            try {
                if(br!=null){
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return fileName;  // 返回文件名
    }
}
