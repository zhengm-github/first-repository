package com.sunyard.dxp.common.service.impl;

import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.OutSvcParamMapRelaService;
import com.sunyard.dxp.common.entity.OutSvcParamMapRela;
import com.sunyard.dxp.common.qo.OutSvcParamMapRelaQo;
import org.springframework.stereotype.Service;

/**
 * 接出服务参数映射配置 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:47:38 CST 2019
 */
@Service
public class OutSvcParamMapRelaServiceImpl extends BaseServiceImpl<OutSvcParamMapRela, String, OutSvcParamMapRelaQo> implements OutSvcParamMapRelaService {
}
