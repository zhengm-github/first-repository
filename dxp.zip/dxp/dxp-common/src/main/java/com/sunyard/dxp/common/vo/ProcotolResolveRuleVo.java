package com.sunyard.dxp.common.vo;

import java.io.Serializable;
import java.util.Set;

/**
* 协议解析规则
*
* Author: Created by code generator
* Date: Tue Jan 07 19:22:59 CST 2020
*/
public class ProcotolResolveRuleVo implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8478831862948882252L;

    /** 协议解析规则ID */
    private String procotolResolveRuleId;

    /** 协议解析规划ID */
    private String procotolResolvePlanId;

    /** 父级id */
    private String parentId;

    /** 名称 */
    private String name;

    /** 备注 */
    private String memo;

    /** 分隔符 */
    private String separatorChar;

    /** 起始位置 */
    private String beginIndex;

    /** 结束位置 */
    private String endIndex;

    /** 行数 */
    private String lineNum;

    /** 明细名称 */
    private String detailName;

    /** 规则类型 */
    private String ruleType;

    /** 子集*/
    private Set< ProcotolResolveRuleVo > childRules;

    public String getBeginIndex( ) {
        return beginIndex;
    }

    public Set< ProcotolResolveRuleVo > getChildRules( ) {
        return childRules;
    }

    public void setChildRules(Set< ProcotolResolveRuleVo > childRules) {
        this.childRules = childRules;
    }

    public void setBeginIndex(String beginIndex) {
        this.beginIndex = beginIndex;
    }

    public String getEndIndex( ) {
        return endIndex;
    }

    public void setEndIndex(String endIndex) {
        this.endIndex = endIndex;
    }

    public String getLineNum( ) {
        return lineNum;
    }

    public void setLineNum(String lineNum) {
        this.lineNum = lineNum;
    }

    public String getRuleType( ) {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    public String getProcotolResolveRuleId() {
    return procotolResolveRuleId;
    }

    public void setProcotolResolveRuleId(String procotolResolveRuleId) {
    this.procotolResolveRuleId = procotolResolveRuleId;
    }

    public String getProcotolResolvePlanId() {
    return procotolResolvePlanId;
    }

    public void setProcotolResolvePlanId(String procotolResolvePlanId) {
    this.procotolResolvePlanId = procotolResolvePlanId;
    }

    public String getParentId() {
    return parentId;
    }

    public void setParentId(String parentId) {
    this.parentId = parentId;
    }

    public String getName() {
    return name;
    }

    public void setName(String name) {
    this.name = name;
    }

    public String getMemo() {
    return memo;
    }

    public void setMemo(String memo) {
    this.memo = memo;
    }

    public String getSeparatorChar() {
    return separatorChar;
    }

    public void setSeparatorChar(String separatorChar) {
    this.separatorChar = separatorChar;
    }

    public String getDetailName() {
    return detailName;
    }

    public void setDetailName(String detailName) {
    this.detailName = detailName;
    }

}
