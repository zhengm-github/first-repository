package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

import org.hibernate.annotations.GenericGenerator;

/**
* 数据对象定义
* Author: Created by code generator
* Date: Tue Dec 24 10:45:27 CST 2019
*/
@Entity
@Table(name = "DXP_DATA_OBJ_DEF")
public class DataObjDef implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5616072856403866870L;

    /** 数据结果定义ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "DATA_OBJ_DEF_ID")
    private String dataObjDefId;

    /** 数据类型:RSP,响应报文，REQ：请求报文 */
    @Column( name = "DATA_KIND")
    private String dataKind;

    /** 接出服务接口 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "OUT_BOUND_SVC_ID", referencedColumnName = "OUT_BOUND_SVC_ID")
    private OutBoundSvc outBoundSvc;

    /** 接入服务接口 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "IN_BOUND_SVC_ID", referencedColumnName = "IN_BOUND_SVC_ID")
    private InBoundSvc inBoundSvc;

    /** 数据属性定义 */
    @OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH}, mappedBy = "dataObjDef")
    private Set<DataPropertyDef> dataPropertyDefs;

    public String getDataObjDefId() {
        return dataObjDefId;
    }

    public void setDataObjDefId(String dataObjDefId) {
        this.dataObjDefId = dataObjDefId;
    }

    public String getDataKind() {
        return dataKind;
    }

    public void setDataKind(String dataKind) {
        this.dataKind = dataKind;
    }

    public OutBoundSvc getOutBoundSvc() {
        return outBoundSvc;
    }

    public void setOutBoundSvc(OutBoundSvc outBoundSvc) {
        this.outBoundSvc = outBoundSvc;
    }

    public InBoundSvc getInBoundSvc() {
        return inBoundSvc;
    }

    public void setInBoundSvc(InBoundSvc inBoundSvc) {
        this.inBoundSvc = inBoundSvc;
    }

    public Set<DataPropertyDef> getDataPropertyDefs() {
        return dataPropertyDefs;
    }

    public void setDataPropertyDefs(Set<DataPropertyDef> dataPropertyDefs) {
        this.dataPropertyDefs = dataPropertyDefs;
    }
}
