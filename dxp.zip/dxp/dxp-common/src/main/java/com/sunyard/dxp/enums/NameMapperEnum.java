package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * @author Thud
 * @date 2020/1/3 9:34
 */
public enum NameMapperEnum implements EnumAware {
    TEST("TEST","测试");

    private final String code;
    private final String name;

    NameMapperEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return getName();
    }

    public static String getMapperCodeByName(String name) {
        for (NameMapperEnum handler : NameMapperEnum.values()) {
            if (handler.name.equals(name)) {
                return handler.code;
            }
        }
        return name;
    }
}
