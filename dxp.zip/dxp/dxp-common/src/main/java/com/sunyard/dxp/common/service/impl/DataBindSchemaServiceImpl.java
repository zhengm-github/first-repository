package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.DataBindSchemaDao;
import com.sunyard.dxp.common.entity.DataBindSchema;
import com.sunyard.dxp.common.qo.DataBindSchemaQo;
import com.sunyard.dxp.common.service.DataBindSchemaService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 数据绑定模式 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:53 CST 2019
 */
@Service
public class DataBindSchemaServiceImpl extends BaseServiceImpl< DataBindSchema, String, DataBindSchemaQo > implements DataBindSchemaService {

    @Autowired
    private DataBindSchemaDao dataBindSchemaDao ;
    @Override
    public List< DataBindSchema > findByOutBoundSvcIds(String... outBoundSvcIds) {

        return dataBindSchemaDao.findByOutBoundSvcIds(outBoundSvcIds);
    }

    @Override
    public List<DataBindSchema> findDataBindSchemaByIbsIdAndObSId(String ibsId, String obsId) {
        return dataBindSchemaDao.findDataBindSchemaByIbsIdAndObSId(ibsId,obsId);
    }

    @Override
    public void deleteByObsId(String obsId) {
        dataBindSchemaDao.deleteByObsId(obsId);
    }

    @Override
    public DataBindSchema findDataBindSchemaByOutBoundSvcId(String id) {
        return dataBindSchemaDao.findDataBindSchemaByOutBoundSvcId(id);
    }
}
