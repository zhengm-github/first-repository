package com.sunyard.dxp.utils;

import cn.hutool.core.codec.Base64;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.bouncycastle.crypto.digests.SM3Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.pqc.math.linearalgebra.ByteUtils;

import java.io.UnsupportedEncodingException;
import java.security.Security;
import java.util.Arrays;

/**
 * 不可逆算法
 */
public class SM3Util {

    private static final String ENCODING = "GBK";

    private static final Logger log = LoggerFactory.getLogger(SM3Util.class);

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    /**
     * sm3算法加密
     *
     * @param paramStr 待加密字符串
     * @return 返回加密后，固定长度=32的16进制字符串
     * @explain
     */
    public static String encryptTo16(String paramStr) {
        // 将返回的hash值转换成16进制字符串
        String resultHexString = "";
        try {
            // 将字符串转换成byte数组
            byte[] srcData = paramStr.getBytes(ENCODING);
            // 调用hash()
            byte[] resultHash = hash(srcData);
            // 将返回的hash值转换成16进制字符串

            resultHexString = ByteUtils.toHexString(resultHash);
        } catch (UnsupportedEncodingException e) {
            log.info("加密成十六进制密文失败！,[{}]", e);
        }
        return resultHexString;
    }

    /**
     * sm3算法加密
     *
     * @param paramStr 待加密字符串
     * @return 返回加密后， base处理的内容
     * @explain
     */
    public static String encryptToBase(String paramStr) {
        // 将返回的hash值转换成16进制字符串
        String resultHexString = "";
        try {
            // 将字符串转换成byte数组
            byte[] srcData = paramStr.getBytes(ENCODING);
            // 调用hash()
            byte[] resultHash = hash(srcData);
            // 将返回的hash值转换成16进制字符串

            log.info("输出 base处理：" + Base64.encode(resultHash));
            resultHexString = ByteUtils.toHexString(resultHash);
        } catch (UnsupportedEncodingException e) {
            log.info("加密成base码失败！[{}]", e);
        }
        return resultHexString;
    }

    /**
     * 返回长度=32的byte数组
     *
     * @param srcData
     * @return
     * @explain 生成对应的hash值
     */
    public static byte[] hash(byte[] srcData) {
        SM3Digest digest = new SM3Digest();
        digest.update(srcData, 0, srcData.length);
        byte[] hash = new byte[ digest.getDigestSize() ];
        digest.doFinal(hash, 0);
        return hash;
    }

    /**
     * 通过密钥进行加密
     *
     * @param key     密钥
     * @param srcData 被加密的byte数组
     * @return
     * @explain 指定密钥进行加密
     */
    public static byte[] hmac(byte[] key, byte[] srcData) {
        KeyParameter keyParameter = new KeyParameter(key);
        SM3Digest digest = new SM3Digest();
        HMac mac = new HMac(digest);
        mac.init(keyParameter);
        mac.update(srcData, 0, srcData.length);
        byte[] result = new byte[ mac.getMacSize() ];
        mac.doFinal(result, 0);
        return result;
    }

    /**
     * 判断源数据与加密数据是否一致
     *
     * @param srcStr       原字符串
     * @param sm3HexString 16进制字符串
     * @return 校验结果
     * @explain 通过验证原数组和生成的hash数组是否为同一数组，验证2者是否为同一数据
     */
    public static boolean verify(String srcStr, String sm3HexString) {
        boolean flag = false;
        try {
            byte[] srcData = srcStr.getBytes(ENCODING);
            byte[] sm3Hash = ByteUtils.fromHexString(sm3HexString);
            byte[] newHash = hash(srcData);
            if (Arrays.equals(newHash, sm3Hash))
                flag = true;
        } catch (UnsupportedEncodingException e) {
            log.info("校验失败！[{}]", e);
        }
        return flag;
    }

    public static void main(String[] args) {
        try {
            String xmlBody = "我和你，你还好吗111";

            //1、加密
            String key = "UmtFNE4wVTJSalF5TVVReQ==";

            // 先对xml部分编押
            String baseSign = SM3Util.encryptTo16(xmlBody + key).toUpperCase();
            System.out.println("计算押为：[" + baseSign + "]");

            xmlBody = StringUtil.addTo16(xmlBody, "GBK");
            byte[] signByte = ByteUtils.fromHexString(baseSign);
            String signStr = new String(signByte, "GBK");

            byte[] xmlByte = xmlBody.getBytes("GBk");
            byte[] xByte = new byte[ signByte.length + xmlByte.length ];
            System.arraycopy(signByte, 0, xByte, 0, signByte.length);
            System.arraycopy(xmlByte, 0, xByte, signByte.length, xmlByte.length);
            System.out.println("全报文16进制：" + ByteUtils.toHexString(xByte));

            // 再对xml部分加密 (sign 和 xml 一起加密)
            String encodeXml = SM4Util.encryptEcb01(key, xByte);
            System.out.println("加密后 base 之前为：[" + encodeXml + "]");
            encodeXml = SM4Util.base64Encode(encodeXml);

            // 2、解密
//            String xmlBody = "zAgxKnCML6IGzi3lyHAojiB0qjikfxKzbsT1nZKxP2b2qNPDvim5j/gOYoRWvdG2iSdAGySgiv4/Fvr21Yr7eL/G2tyeZEJvLa4k7Ym8jZWNcxZhK7IACkeodpjhrsngKLiw9TZZtL104O7DH2MEf1KqOb0hQz0jAS/z9eHAQ8aJSOYh3qtugbvQ3jtY/vY+DylLFCcUv7fd372g+H6Smg0IaHYRRnrsPNYu9AGV3mIc9j++eoiLncy8iCsXx8tO3g6pleMl4ON0xE9cUanW+V733sH9xoxmx3KlCyyAWBngFHOgxoniANFLI531QwuoK2fNrQEKvYa5e36w/nSol6hnew5TvfKhJJCwW0C7aa3HXxh+/si6gHtRXEVrz9PDC/mFcyvtVYdckhdlIVvmJ6vNwkMJzADnXSB1yKcgO6U+jxoGWSVXl7H14mvzlx5kunL/rIvKdMvN2GUGk8g5GFjVDs8SSzzqnNUuzlPzVGyk4BMdlUjUY10mfTuEizA0BF/GSC4SJXm+CY2x9Q3RgIjpgzoZecLZt+bUMKaaxH2Xgv4GztFPjo7fGiQ8jYpGH6s1lF6VCLgEbuvCdCZpBd17fl11YxMK46YjcLSdCo2ScHffRQJDnhZJshD4aQmrnIPGFDksiNKmQhcjXCYE88T3Sip/pJc6SCBKZOWS4lkJl6wRDEcB/ua/BU+xnj3TMWZYsrJtAamuRfsdCw/1ynDscsM5YlLQc7+Y4/WOKHkMgYLjJeRgc4X+vZnZEDXxm5HvEonigvVYwR5XCJ4Lt8nJOrUHejUCoDIYwephuMRHZCb7mnGM/9Ka/3hYxnFEnC2pBF5ZcWroPgUj9GSgOg7I1e1N5TR+vJkXyMiamtY3cxWuamLRAZb+pIVLJhefNZogmNg+edUEnV6mC79RiQOsn/IPr6Nd6pngRfCyRWufXDiy3tO/Iud2uzWMUH3KrpOevzICgK8efHgeHLbU0pnQFEhdHv+pHzH27UazKbY=";
//            String xmlBody = "lI6Y+4uTuoJxpqR8rYRzcB3ok1UlWl9fJV/hK46qB67ZOOelW9JhNv5F/ejj3fFnjL+FNtiR+1jx\n" +
//                    "+5kCJXP6U8/q4UP2Z0+704HTlsVCJv37UljxeOQMl63lLinJ333FbLsTj92b1alFKVdbDOOY8rw4\n" +
//                    "81g1ncxXff/RihVHepxoNS9hc9awfs0uObcqY4qM+hjre6+u1VQkbQs9McZUgjUi8HJxMxia9mmz\n" +
//                    "XNs0CHs=";
            xmlBody = encodeXml;

            xmlBody = "KSleTGAhT8UygRKPClnu6epnuBTd+mfa7xP7dD7tUYH2qNPDvim5j/gOYoRWvdG2iSdAGySgiv4/Fvr21Yr7eL/G2tyeZEJvLa4k7Ym8jZWNcxZhK7IACkeodpjhrsngW86Lt96/SW2wkv1vKCe9WFKqOb0hQz0jAS/z9eHAQ8aJSOYh3qtugbvQ3jtY/vY+DylLFCcUv7fd372g+H6SmgSC69dOJDM7dXvEEDXtGIwvuBvsrRCpXWm7JcOVvtPM5N9VtEc9PI9I1sqAumh8QqJyhxlozeQsaBgacR2gbamzQ3n5oOqXXKc6+wIye7M58CKN0OfL0NKA4usObqlWXHRwYGbpl5yEzidMu3mGyINWg7GEvv9mvOl257VLuKBg6s+29HW60VXdPWvTwmLgOJcrZ72ferXjWINkgrpjbvzV/9HfFyRUfmBV0lyKkjyOse6eMO3n0sQ9BM9EAVd8HQnBUtSbBMyztD505MbCVEMRQnuDLulLB1LcTX+WjjZwtzyTUvVVQ1cDo2Q7B8wCfjpe0dJtB+WETiCWr8qN1phqc1w/a34B9xH5sHXQFysKzdtitYCYROpZ+cIMEkctn6fv2GHh1aQMIzFjgGnQlEeaWS+oAigSwHeJvF4GcsyVpgWiogL6IvzFNXIASVAwow==";
            String baseXml = SM4Util.base64Decode(xmlBody); // 先base处理
            String showXml = SM4Util.decryptEcb01(key, baseXml).toUpperCase();
            System.out.println("showXml：[" + showXml + "]");
//            showXml = showXml.replaceAll("0+$", "");  // 去除后面的补位0
//            System.out.println("showXml：[" + showXml + "]");


            String xml = new String(ByteUtils.fromHexString(showXml.substring(64)), "GBK").trim() + "\n";
            System.out.println("xml：[" + xml + "]");

//            xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n" +
//                    "<nbrcs><public><TranCode>400312</TranCode><NodeCode>99933200</NodeCode></public><acct><workdate>20200704</workdate><conc_code>600101</conc_code><customno>4152006171          </customno><bankid>105332000010  </bankid><endate>20200617</endate><en_confdate>20200617</en_confdate><modidate>        </modidate><candate>        </candate><can_confdate>        </can_confdate><payerzip>      </payerzip><payername>建行银行股份有限公司宁波分行</payername><payeraddr></payeraddr><payertel>123456      </payertel><payeridtype>0</payeridtype><payerid>330204000059748   </payerid><username>1</username><useraddr>1</useraddr><usertel>            </usertel></acct></nbrcs>\n" ;
            String pacSign = showXml.substring(0, 64);  // 请求报文的 sign部分, 16进制
            byte[] x = ByteUtils.fromHexString(pacSign);
            System.out.println("pacSign(16进制)：[" + pacSign + "]");
            // 再对xml部分核押
            String sign = SM3Util.encryptTo16(xml + key);
            System.out.println("sign(16进制)：[" + sign + "]");
            boolean validate = pacSign.toUpperCase().equals(sign.toUpperCase()); // 基本算法
            System.out.println("equals 结果：" + validate);
            System.out.println("verify：" + verify(xml + key, pacSign));

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}
