package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 报文类型
 */
@FunctionLibrary(code = "msgType",name = "报文类型(msgType)",expression = "(msgType\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "msgType()",hasProperty = true)
@Component
public class MsgTypeFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
           return "";
        }
        try {
            return ExpMapper.msgTypeMap.get(params) ;
        } catch (Exception e) {throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName()+e);
        }
    }
}
