package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.dxp.common.qo.SignConfigItemQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 签名配置项 dao 接口
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:49:49 CST 2020
 */
public interface SignConfigItemDao extends BaseDao<SignConfigItem, String, SignConfigItemQo> {

    /**
     * 按照dataPropertyId删除
     * @param dataPropertyId
     */
    void deleteByDataPropertyId(String dataPropertyId);

    /**
     * 根据dataObjDefId 查询
     * @param dataObjDefId
     * @return
     */
    List<SignConfigItem> findByDataObjDefId(String dataObjDefId) ;

}
