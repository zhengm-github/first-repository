package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.RspDataBindConfig;
import com.sunyard.dxp.common.qo.RspDataBindConfigQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 数据绑定配置 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:43:42 CST 2019
 */
public interface RspDataBindConfigDao extends BaseDao<RspDataBindConfig, String, RspDataBindConfigQo> {

    /**
     * 根据接出数据结果属性id查询数据绑定配置
     * @param outDataPropertyId
     * @return
     */
    List<RspDataBindConfig> findDataBindConfigByOutProId(String outDataPropertyId);

    /**
     * 根据接入数据属性删除请求报文映射配置
     * @param propertyId
     * @return
     */
    void deleteByPropertyId(String propertyId);
}
