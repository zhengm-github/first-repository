package com.sunyard.dxp.utils;

import com.sunyard.SydApi;
import com.sunyard.frameworkset.util.JsonUtil;
import com.sunyard.inf.SydPledge;
import racal.sunyard.main.SydApi4j;

import java.io.UnsupportedEncodingException;
import java.util.Map;

public class SYDApi {

    /**
     *  编核押
     * @param src
     * @param signKey
     * @return
     */
    public static String getMAC(String src, String signKey) {
        Map< String, Object > msg = JsonUtil.jsonToMap(src);

        // 连接加密机  172.1.21.6
        SydPledge api = new SydApi4j().connect("172.1.21.6", 8889, null, 1000);
        String mac = "";
        try {
            mac = api.GenerateMIYA(msg.get(MsgKeys.MYJ_REGION).toString(), 1, SydApi.NALG_SM4,
                    msg.get(MsgKeys.MYJ_MESSAGE).toString().getBytes(msg.get(MsgKeys.MYJ_ENCODE).toString()));
            System.out.println("MAC = " + mac);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();

        } finally {
            ((SydApi) api).disconnect();
        }

        return mac;
    }


    /**
     * @param args
     */
    public static void main(String[] args) {
        byte[] testData = "1234567812345678".getBytes();
        //testData = new byte[8];

        // 连接加密机  61.164.40.82
        SydPledge api = new SydApi4j().connect("61.164.40.82", 8889, null, 1000);
        try {

            String mac = api.GenerateMIYA("1111111111111111", 1, SydApi.NALG_SM4, testData);
            System.out.println("MAC = " + mac);
            Boolean ret = api.VerifyMIYA("1111111111111111", 1, SydApi.NALG_SM4, mac, testData);
            if (ret) {
                System.out.println("核押通过");
            } else {
                System.out.println("核押不通过");
            }


            // 测试篡改 MAC
            String errMac = "F0BD5669";
            Boolean ret2 = api.VerifyMIYA("310000", 1, SydApi.NALG_SM4, errMac, testData);
            if (ret2) {
                System.out.println("篡改 MAC 未检测到");
            } else {
                System.out.println("篡改 MAC");
            }


        } finally {
            ((SydApi) api).disconnect();
        }
    }
}
