package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.AddrInfo;
import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 地址信息管理 dao 接口
 *
 * Author: Created by code generator
 * Date: Thu Jun 11 16:10:14 CST 2020
 */
public interface AddrInfoDao extends BaseDao< AddrInfo, String, AddrInfoQo > {

    /**
     * 查找列表( 调用时间增序排列)
     * @param sendDirect   发送方向（CORP 、 CBSP）
     * @param busiType  业务类型 （RT-实时， BT- 批量）
     * @return
     */
    List<AddrInfo> findByDirectAndType(String sendDirect, String busiType) ;
}