package com.sunyard.dxp.message.service.impl;

import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.service.BaseResolveService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Description 变长报文解析基础服务
 * @Author zhangxin
 * @Date 2020/1/9 10:24
 * @Version 1.0
 */
@Service( "baseResolveServiceVariable" )
public class BaseResolveServiceVariableImpl implements BaseResolveService {

    @Override
    public Map< String, Object > execute(List< ParamRule > rules, String message, String... resolveParam) {
        // 报文分隔符
        String separator = resolveParam[ 1 ];
        if (StringUtils.isNotBlank(separator)) {
            String[] fbsArr = { "\\", "$", "(", ")", "*", "+", ".", "[", "]", "?", "^", "{", "}", "|" };
            for (String key : fbsArr) {
                if (separator.contains(key)) {
                    separator = separator.replace(key, "\\" + key);
                }
            }
        }
        // 拆分报文
        String[] messageArray = message.split(separator);
        Map< String, Object > result = new HashMap<>();
        String keyName = "";
        for (ParamRule paramRule : rules) {
            // 增加变长明细的读取
            keyName = paramRule.getDetailName();
            if (StringUtils.isNotBlank(paramRule.getName())) {
                keyName = paramRule.getName();
            }
            if (!paramRule.isArray()) {
                if (paramRule.getIndex() < messageArray.length) {
                    result.put(keyName, messageArray[ paramRule.getIndex() ]);
                } else {
                    result.put(keyName, "");
                }
            } else {
                result.put(keyName, readArray(paramRule, messageArray[ paramRule.getIndex() ]));
            }
        }
        return result;
    }

    @Override
    public Map< String, Object > mapExecute(List< ParamRule > rules, Map< String, Object > map, String... resolveParam) {
        // 报文分隔符
        String separator = resolveParam[ 0 ];
        Map< String, Object > variableMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        if (!rules.isEmpty()) {
            Map< String, Object > maps = new HashMap<>();
            for (ParamRule paramRule : rules) {
                String value = String.valueOf(map.get(paramRule.getName()));
                maps.put(String.valueOf(paramRule.getIndex()), value);
            }

            for (int i = 0; i < maps.keySet().size(); i++) {
                sb.append((maps.get(String.valueOf(i)) == null ? "" : maps.get(String.valueOf(i))) + separator);
            }
        }
        variableMap.put("package", sb.toString());
        return variableMap;

    }

    private List< Map< String, Object > > readArray(ParamRule paramRule, String detailsMessage) {
        List< Map< String, Object > > result = new ArrayList<>();
        // 分隔明细
        String[] details = detailsMessage.split(paramRule.getDetailSeparator());
        if (details.length > 0) {
            for (String row : details) {
                Map< String, Object > rowData = execute(paramRule.getDetailRules(), row, "", paramRule.getColumnSeparator());
                result.add(rowData);
            }
        }
        return result;
    }
}

