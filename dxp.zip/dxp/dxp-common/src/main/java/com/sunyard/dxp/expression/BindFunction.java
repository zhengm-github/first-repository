package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;

/**
 * @author Thud
 * @date 2020/1/2 17:17
 */
@FunctionLibrary(code = "bind",name = "绑定",expression = "(bind\\()(\\$\\{[\\s\\w]+\\}\\,\\$\\{[\\s\\w]+\\})(\\))",type = "all",exp = "bind()",hasProperty = true)
@Component
public class BindFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        String[] param = params.split(",");
        if (ArrayUtils.isEmpty(param) || param.length != 2) {
            //表达式参数不准确
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
        StringBuilder sb = new StringBuilder(param[1]);
        return sb.append(param[0]).toString();
    }
}
