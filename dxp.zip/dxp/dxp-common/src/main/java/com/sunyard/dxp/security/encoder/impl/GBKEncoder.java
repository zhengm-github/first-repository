package com.sunyard.dxp.security.encoder.impl;

import com.sunyard.dxp.security.encoder.Encoder;
import com.sunyard.dxp.utils.EncoderLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

/**
 * 编码转换为GBK
 */
@EncoderLibrary(code = "GBK" , name = "GBK编码")
public class GBKEncoder implements Encoder {
    private static final Logger LOGGER = LoggerFactory.getLogger( GBKEncoder.class );

    @Override
    public String encode(String content) {
        String clientStr = null;
        try {
            clientStr = new String(content.getBytes("GBK"), "GBK");
        }catch (Exception e){
            LOGGER.error("编码GBK失败！");
            throw new FapException("","编码GBK失败！");
        }
        return clientStr;
    }
}
