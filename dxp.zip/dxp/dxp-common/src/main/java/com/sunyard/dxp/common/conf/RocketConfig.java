package com.sunyard.dxp.common.conf;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Thud
 * @date 2019/12/18 13:56
 * rocket 配置类
 */
@Configuration
public class RocketConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger( RocketConfig.class );

    @Value("${rocket.namesrvAddr:127.0.0.1:9876}")
    private String namesrvAddr;

    // 快速通道的组
    @Value("${rocket.producerGroup:producer}")
    private String producerGroup;

    @Value("${rocket.consumerGroup:consumer}")
    private String consumerGroup;

    // 慢速通道的组
    @Value("${rocket.producerGroup.slow:producer_slow}")
    private String slowProducerGroup;

    @Value("${rocket.consumerGroup.slow:consumer_slow}")
    private String slowConsumerGroup;

    public RocketConfig(){
        LOGGER.info("SPRING容器初始化.../ RocketMQ 配置执行...");
    }


    @Bean
    public DefaultMQProducer producerConfig(){
        //创建一个生产者
        DefaultMQProducer producer = new DefaultMQProducer(producerGroup);
        producer.setNamesrvAddr(namesrvAddr);
        try {
            producer.start();
        } catch (MQClientException e) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_ERROR_MSG_001);
        }
        return producer;
    }

    @Bean
    public DefaultMQPushConsumer consumerConfig(){
        //声明一个消费者
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(consumerGroup);
        consumer.setNamesrvAddr(namesrvAddr);
        //设置消费策略 此处为默认策略 队列尾部开始消费
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
        return consumer;
    }

    @Bean
    public DefaultMQProducer slowProducerConfig(){
        //创建一个 慢处理生产者
        DefaultMQProducer producer = new DefaultMQProducer(slowProducerGroup);
        producer.setNamesrvAddr(namesrvAddr);
        try {
            producer.start();
        } catch (MQClientException e) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_ERROR_MSG_001);
        }
        return producer;
    }

    @Bean
    public DefaultMQPushConsumer slowConsumerConfig(){
        //声明一个慢处理消费者
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(slowConsumerGroup);
        consumer.setNamesrvAddr(namesrvAddr);
        //设置消费策略 此处为默认策略 队列尾部开始消费
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
        return consumer;
    }
}
