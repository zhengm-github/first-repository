package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * 金额 元 转成 分
 */
@FunctionLibrary( code = "yuanToFen", name = "金额转换（元 --> 分)", expression = "(yuanToFen\\()(\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "yuanToFen()", hasProperty = true )
@Component
public class YuanToFenFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {

        if (StringUtils.isBlank(params) || "".equals(params.trim())) {
            return "0";
        }
        BigDecimal beforeMoney = new BigDecimal(params.replaceAll("CNY", "").trim());
        return beforeMoney.multiply(BigDecimal.valueOf(100)).toBigInteger().toString();
    }
}
