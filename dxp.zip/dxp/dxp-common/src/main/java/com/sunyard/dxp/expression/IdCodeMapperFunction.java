package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 *
 * 单位转全国 idcode
 * @author Thud
 * @date 2020/1/3 9:33
 */
@FunctionLibrary(code = "idCodeMapper",name = "证件类型映射(单位到全国)",expression = "(idCodeMapper\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "idCodeMapper()",hasProperty = true)
@Component
public class IdCodeMapperFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            //表达式参数不准确
            return "" ;
        }
        try {
            return ExpMapper.idCodeMap.get(params);
        } catch (Exception e) {
            throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL);
        }
    }
}
