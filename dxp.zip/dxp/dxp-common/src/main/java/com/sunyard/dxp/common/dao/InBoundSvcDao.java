package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.qo.InBoundSvcQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 接入服务接口 dao 接口
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:54:51 CST 2019
 */
public interface InBoundSvcDao extends BaseDao< InBoundSvc, String, InBoundSvcQo > {

    /**
     * 查询绑定与否的接入接口
     * @param qo
     * @return
     */
    List< InBoundSvc > findPartInBound(InBoundSvcQo qo);

    /**
     *根据code查询
     * @param code
     * @return
     */
    InBoundSvc findByCode(String code) ;

}
