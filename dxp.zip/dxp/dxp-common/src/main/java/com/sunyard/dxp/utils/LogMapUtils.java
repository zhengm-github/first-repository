package com.sunyard.dxp.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yefei on 2018/10/11.
 */
public class LogMapUtils {

    private static String typeLog = "typeLog";

    public static Map<String, Object> getDxpLog(String serviceCode, String serviceType, String serviceName, String reponseMessage) {
        HashMap<String, Object> reain = new HashMap<>();
        reain.put("reponseMessage", reponseMessage);
        reain.put("service_type", serviceType);
        reain.put("service_code", serviceCode);
        reain.put("service_name", serviceName);
        reain.put("date", new Date());
        reain.put(typeLog, "retain");
        return reain;
    }

    public static Map<String, Object> getDxpLog(String appCode, String appName, String bundleCode, String bundleName, String serviceCode,
                                                 String serviceName, String serviceType, String requestMessage,
                                                 String reponseMessage, Date gmtRequest, Date gmtReponse, String status,
                                                 Date stmRequest, Date stmReponse, String cacheKey, String inServiceTypeCode) {
        HashMap<String, Object> udisLog = new HashMap<>();
        udisLog.put("appCode", appCode);
        udisLog.put("appName", appName);
        udisLog.put("bundleCode", bundleCode);
        udisLog.put("bundleName", bundleName);
        udisLog.put("serviceCode", serviceCode);
        udisLog.put("serviceName", serviceName);
        udisLog.put("serviceType", serviceType);
        udisLog.put("requestMessage", requestMessage);
        udisLog.put("gmtRequest", gmtRequest);
        udisLog.put("reponseMessage", reponseMessage);
        udisLog.put("gmtReponse", gmtReponse);
        udisLog.put("status", status);
        udisLog.put("stmRequest", stmRequest);
        udisLog.put("stmReponse", stmReponse);
        udisLog.put("cacheKey", cacheKey);
        udisLog.put("inServiceTypeCode", inServiceTypeCode);
        udisLog.put(typeLog, "uids");
        return udisLog;
    }

    private LogMapUtils(){}
}
