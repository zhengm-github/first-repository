package com.sunyard.dxp.message.service.impl;

import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.ParamRule;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.message.utils.RuleConvertUtils;
import com.sunyard.dxp.utils.AgreementLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * @Description 请求报文为完全变长报文解析
 * @Author zhangxin
 * @Date 2020/1/10 10:51
 * @Version 1.0
 */
@Service( "variableResolve" )
@AgreementLibrary( code = "variable", name = "请求报文为完全变长报文解析" )
public class RequestResolveServiceVariableImpl implements RequestResolveService {

    @Autowired
    @Qualifier( "baseResolveServiceVariable" )
    private BaseResolveService baseResolveService;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (CollectionUtils.isEmpty(requestResolveDto.getProcotolResolveRules())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_010);
        }
        if (requestResolveDto.getProcotolResolveRules().size() != 1) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_012);
        }
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
        if (StringUtils.isEmpty(requestResolveDto.getEncoding())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_007);
        }
    }

    @Override
    public Map< String, Object > resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > rules = requestResolveDto.getProcotolResolveRules();
        List< ParamRule > paramRules = RuleConvertUtils.convertVariableRules(rules.get(0).getChildRules());
        return baseResolveService.execute(paramRules, requestResolveDto.getMessage(), requestResolveDto.getEncoding(), rules.get(0).getSeparatorChar());
    }

    @Override
    public Map< String, Object > mapResolve(Map< String, Object > map, SignDto signDto, RequestResolveDto requestResolveDto) {
        List< ProcotolResolveRule > rules = requestResolveDto.getProcotolResolveRules();
        List< ParamRule > paramRules = RuleConvertUtils.convertVariableRules(rules.get(0).getChildRules());
        return baseResolveService.mapExecute(paramRules, map, rules.get(0).getSeparatorChar());
    }
}
