package com.sunyard.dxp.common.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
* 记录业务信息（请求和响应）
* Author: Created by code generator
* Date: Tue Jun 09 17:17:29 CST 2020
*/
@Entity
@Table(name = "DXP_BUSI_RECORD")
public class BusiRecord implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8471075873587981099L;

    /** uuid主键 */
    @Id
    @Column( name = "BUSI_ID")
    private String busiId;

    /** 接口Code */
    @Column( name = "SVC_CODE")
    private String svcCode;

    /** 接口名称 */
    @Column( name = "SVC_NAME")
    private String svcName;

    /** 业务主键 */
    @Column( name = "MSG_TRAN_ID")
    private String msgTranId;

    /** 通讯级参考号 */
    @Column( name = "PACK_TRAN_ID")
    private String packTranId;

    /** 服务模块code */
    @Column( name = "BUNDLE_CODE")
    private String bundleCode;

    /** 服务模块名称 */
    @Column( name = "BUNDLE_NAME")
    private String bundleName;

    /** 请求报文数据 */
    @Column( name = "REQ_MESSAGE")
    private String reqMessage;

    /** 响应报文数据 */
    @Column( name = "RSP_MESSAGE")
    private String rspMessage;

    /** 响应业务ID */
    @Column( name = "SVC_RSP_MSG_ID")
    private String svcRspMsgId;

    /** 请求时间 */
    @Column( name = "REQ_TIME")
    private String reqTime;

    /** 响应时间 */
    @Column( name = "RSP_TIME")
    private String rspTime;

    /** 请求状态 */
    @Column( name = "REQ_STATUS")
    private String reqStatus;

    /** 响应状态 */
    @Column( name = "RSP_STATUS")
    private String rspStatus;

    /** 接口类型（static/dyna） */
    @Column( name = "SVC_TYPE")
    private String svcType;

    /** 错误信息 */
    @Column( name = "ERR_INFO")
    private String errInfo;

    /** 请求回调的URL */
    @Column( name = "URL")
    private String url;

    /** 请求解析的数据 */
    @Column( name = "Req_Resolve_Data")
    private String reqResolveData;

    public String getReqResolveData( ) {
        return reqResolveData;
    }

    public void setReqResolveData(String reqResolveData) {
        this.reqResolveData = reqResolveData;
    }

    public String getUrl( ) {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getBusiId() {
        return busiId;
    }

    public void setBusiId(String busiId) {
        this.busiId = busiId;
    }

    public String getSvcCode() {
        return svcCode;
    }

    public void setSvcCode(String svcCode) {
        this.svcCode = svcCode;
    }

    public String getSvcName() {
        return svcName;
    }

    public void setSvcName(String svcName) {
        this.svcName = svcName;
    }

    public String getMsgTranId() {
        return msgTranId;
    }

    public void setMsgTranId(String msgTranId) {
        this.msgTranId = msgTranId;
    }

    public String getPackTranId() {
        return packTranId;
    }

    public void setPackTranId(String packTranId) {
        this.packTranId = packTranId;
    }

    public String getBundleCode() {
        return bundleCode;
    }

    public void setBundleCode(String bundleCode) {
        this.bundleCode = bundleCode;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public String getReqMessage() {
        return reqMessage;
    }

    public void setReqMessage(String reqMessage) {
        this.reqMessage = reqMessage;
    }

    public String getRspMessage() {
        return rspMessage;
    }

    public void setRspMessage(String rspMessage) {
        this.rspMessage = rspMessage;
    }

    public String getSvcRspMsgId() {
        return svcRspMsgId;
    }

    public void setSvcRspMsgId(String svcRspMsgId) {
        this.svcRspMsgId = svcRspMsgId;
    }

    public String getReqTime() {
        return reqTime;
    }

    public void setReqTime(String reqTime) {
        this.reqTime = reqTime;
    }

    public String getRspTime() {
        return rspTime;
    }

    public void setRspTime(String rspTime) {
        this.rspTime = rspTime;
    }

    public String getReqStatus() {
        return reqStatus;
    }

    public void setReqStatus(String reqStatus) {
        this.reqStatus = reqStatus;
    }

    public String getRspStatus() {
        return rspStatus;
    }

    public void setRspStatus(String rspStatus) {
        this.rspStatus = rspStatus;
    }

    public String getSvcType() {
        return svcType;
    }

    public void setSvcType(String svcType) {
        this.svcType = svcType;
    }

    public String getErrInfo() {
        return errInfo;
    }

    public void setErrInfo(String errInfo) {
        this.errInfo = errInfo;
    }

}
