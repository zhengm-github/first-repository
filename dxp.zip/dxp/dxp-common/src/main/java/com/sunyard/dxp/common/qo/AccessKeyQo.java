package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 统一服务授权key QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:26:00 CST 2019
   */
public class AccessKeyQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6551542698963895202L;

    /** 授权key */
    private String accessKey ;

    public String getAccessKey( ) {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }
}
