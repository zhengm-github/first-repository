package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
* 请求报文映射配置属性
* Author: Created by code generator
* Date: Tue Jan 07 19:25:20 CST 2020
*/
@Entity
@Table(name = "DXP_DATA_MAP_PROPERTY_DEF_RELA")
public class DataMapPropertyDefRela implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6730047205041454818L;

    /** 接口参数映射配置ID */
    @Id
    @Column( name = "DATA_MAP_CONFIG_ID")
    private String dataMapConfigId;

    /** 数据属性Id */
    @Id
    @Column( name = "DATA_PROPERTY_ID")
    private String dataPropertyId;

    public String getDataMapConfigId() {
        return dataMapConfigId;
    }

    public void setDataMapConfigId(String dataMapConfigId) {
        this.dataMapConfigId = dataMapConfigId;
    }

    public String getDataPropertyId() {
        return dataPropertyId;
    }

    public void setDataPropertyId(String dataPropertyId) {
        this.dataPropertyId = dataPropertyId;
    }

}
