package com.sunyard.dxp.utils;

import com.sunyard.frameworkset.core.exception.FapException;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MD5Util {

    /**
     * 使用Md5 进行签名
     *
     * @param src
     * @return
     */
    public static String update(String src) {
        StringBuilder buf = new StringBuilder("");
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update((src).getBytes("gb18030"));
            byte[] b = md.digest();
            int i;
            for (int offset = 0; offset < b.length; offset++) {
                i = b[ offset ];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
        } catch (Exception e) {
            throw new FapException("", "MD5字符串签名失败");
        }
        return buf.toString().toUpperCase();
    }

    /**
     * 对文件使用Md5 进行签名
     *
     * @param filePath
     * @param fileName
     * @return 大写 16进制
     */
    public static String getFileMD5(String filePath, String fileName) {

        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(
                    new File(filePath + File.separator + fileName));
            return DigestUtils.md5Hex(fileInputStream).toUpperCase() ;
        } catch (FileNotFoundException e) {
            throw new FapException("", "MD5文件签名失败,文件不存在:" + filePath + File.separator + fileName);
        } catch (IOException e) {
            throw new FapException("", "MD5文件签名失败") ;
        }
    }

    public static void main(String[] args) {
        String md5Src = "78ECA9B3FF6EFD57C5849D543496BC96";
        String src = "我和你AA11\n";
        String x = update(src);
        Boolean result = x.equals(md5Src.toLowerCase());
        System.out.println(x);
        System.out.println(result);
    }
}
