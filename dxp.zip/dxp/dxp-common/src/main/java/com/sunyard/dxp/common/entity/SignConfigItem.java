package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;

/**
* 签名配置项
* Author: Created by code generator
* Date: Mon Jan 06 10:49:49 CST 2020
*/
@Entity
@Table(name = "DXP_SIGN_CONFIG_ITEM")
public class SignConfigItem implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6332146979273697230L;

    /** 签名配置项ID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "SIGN_CONFIG_ITEM_ID")
    private String signConfigItemId;

    /** 顺序号 */
    @Column( name = "ORD")
    private Integer ord;

    /** 表达式 */
    @Column( name = "EXP")
    private String exp;

    /** 表达式 参数 */
    @Column( name = "PARAM")
    private String param;

    /** 数据对象属性定义 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "DATA_PROPERTY_ID", referencedColumnName = "DATA_PROPERTY_ID")
    private DataPropertyDef dataPropertyDef;

    /** 签名配置计划 */
    @ManyToOne(fetch = FetchType.LAZY, optional = true )
    @JoinColumn(name = "SIGN_CONFIG_SCHEMA_ID", referencedColumnName = "SIGN_CONFIG_SCHEMA_ID")
    private SignConfigSchema signConfigSchema;

    public String getParam( ) {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }

    public String getSignConfigItemId() {
        return signConfigItemId;
    }

    public SignConfigSchema getSignConfigSchema() {
        return signConfigSchema;
    }

    public void setSignConfigSchema(SignConfigSchema signConfigSchema) {
        this.signConfigSchema = signConfigSchema;
    }

    public void setSignConfigItemId(String signConfigItemId) {
        this.signConfigItemId = signConfigItemId;
    }

    public Integer getOrd() {
        return ord;
    }

    public void setOrd(Integer ord) {
        this.ord = ord;
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public DataPropertyDef getDataPropertyDef() {
        return dataPropertyDef;
    }

    public void setDataPropertyDef(DataPropertyDef dataPropertyDef) {
        this.dataPropertyDef = dataPropertyDef;
    }
}
