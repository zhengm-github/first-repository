package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.PayFlag2MsgTypeMapperEnum;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 根据payFlag映射msgType（1-381、2-380）
 */
@FunctionLibrary(code = "payFlag",name = "根据payFlag映射msgType（1-381、2-380）",expression = "(payFlag\\()(\\$\\{[\\s\\w]+\\})(\\))",type = "string",exp = "payFlag()",hasProperty = true)
@Component
public class PayFlagFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        if(StringUtils.isBlank(params)){
            //表达式参数不准确
            return "" ;
        }
        return PayFlag2MsgTypeMapperEnum.getMapperNameByCode(params);

    }
}
