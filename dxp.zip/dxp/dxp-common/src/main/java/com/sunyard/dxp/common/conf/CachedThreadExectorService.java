package com.sunyard.dxp.common.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by jianr.z on 2018/9/5.
 */
@Configuration
public class CachedThreadExectorService {

    @Bean(name = {"executorService"})
    public ExecutorService executorService(){
        return Executors.newCachedThreadPool();
    }

    @Bean(name = {"dxpExecutorService"})
    public ExecutorService dxpExecutorService(){
        return Executors.newFixedThreadPool(5);
    }
}
