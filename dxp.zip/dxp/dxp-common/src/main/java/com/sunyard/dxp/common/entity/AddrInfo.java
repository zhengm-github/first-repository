package com.sunyard.dxp.common.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
* 地址信息管理
* Author: Created by code generator
* Date: Thu Jun 11 16:10:14 CST 2020
*/
@Entity
@Table(name = "DXP_ADDR_INFO")
public class AddrInfo implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 4652030947285150940L;

    /** uuid */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "ID")
    private String id;

    /** 发送方向（CBSP/CORP） */
    @Column( name = "SEND_DIRECT")
    private String sendDirect;

    /** 业务类型( rt / bt) */
    @Column( name = "BUSI_TYPE")
    private String busiType;

    /** 地址 */
    @Column( name = "URL")
    private String url;

    /** 最后调用时间 */
    @Column( name = "CALL_TIME")
    private String callTime;

    /** 权重 */
    @Column( name = "WEIGHT")
    private String weight;

    /** 状态（1/0） */
    @Column( name = "STATUS")
    private String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSendDirect() {
        return sendDirect;
    }

    public void setSendDirect(String sendDirect) {
        this.sendDirect = sendDirect;
    }

    public String getBusiType() {
        return busiType;
    }

    public void setBusiType(String busiType) {
        this.busiType = busiType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCallTime() {
        return callTime;
    }

    public void setCallTime(String callTime) {
        this.callTime = callTime;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
