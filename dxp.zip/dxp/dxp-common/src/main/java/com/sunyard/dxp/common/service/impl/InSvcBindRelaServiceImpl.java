package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.InSvcBindRelaDao;
import com.sunyard.dxp.common.entity.InSvcBindRela;
import com.sunyard.dxp.common.qo.InSvcBindRelaQo;
import com.sunyard.dxp.common.service.InSvcBindRelaService;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 接入服务数据映射配置 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:55:37 CST 2019
 */
@Service
public class InSvcBindRelaServiceImpl extends BaseServiceImpl< InSvcBindRela, String, InSvcBindRelaQo > implements InSvcBindRelaService {

    @Autowired
    private InSvcBindRelaDao inSvcBindRelaDao ;
    @Override
    public void deleteByInBoundSvcIds(String... inBoundSvcIds) {

        if(StringUtils.isNoneBlank(inBoundSvcIds)){
            for(String id: inBoundSvcIds){
                inSvcBindRelaDao.deleteByInBoundSvcId(id);
            }
        }
    }

    @Override
    public void deleteByDataMapSchemaId(String dataMapSchemaId) {

        inSvcBindRelaDao.deleteByDataMapSchemaId(dataMapSchemaId);
    }

    @Override
    public void deleteByDataMapSchemaIdAndInBoundSvcId(String dataMapSchemaId, String inBoundSvcId) {

        inSvcBindRelaDao.deleteByDataMapSchemaIdAndInBoundSvcId(dataMapSchemaId, inBoundSvcId);
    }
}
