package com.sunyard.dxp.utils;

import org.apache.commons.lang3.StringUtils;

import java.io.UnsupportedEncodingException;

/**
 * 自定义字符串工具类
 *
 * @author zhengm
 */
public class StringUtil {

    /**
     * 对字符串进行长度验证，长度不够进行补全，超出部分进行截取
     *
     * @param str
     * @param length
     * @param setChar   补的字符
     * @param beforeSet 前补
     * @return
     */
    public static String formatStr(String str, int length, String setChar, boolean beforeSet) {
        String value = StringUtils.defaultString(str, "");
        int strLen = value.length();
        if (strLen < length) {
            StringBuilder sb = new StringBuilder(str);
            while (strLen < length) {
                if (beforeSet) {
                    sb.insert(0, setChar);
                } else {
                    sb.append(setChar);
                }
                strLen = sb.length();
            }
            return sb.toString();
        } else {
            return value.substring(0, length);
        }
    }

    /**
     * 转obj 成 String
     *
     * @param obj
     * @param defaultStr
     * @return
     */
    public static String getDefaultStr(Object obj, String defaultStr) {
        if (obj == null) {
            return defaultStr;
        }
        return String.valueOf(obj);
    }

    /**
     * 将str 按照  encode 编码  填补成 16的倍数（包含中文处理） ，处理失败时 返回  ""
     *
     * @param str
     * @param encode
     * @return String
     * @author zhengm
     */
    public static String addTo16(String str, String encode) {

        try {

            byte[] jsonBtye = str.getBytes(encode);

            int len = 16 - jsonBtye.length % 16;

            byte[] desByte = new byte[ jsonBtye.length + len ];

            System.arraycopy(jsonBtye, 0, desByte, 0, jsonBtye.length);

            for (int i = jsonBtye.length + len; i > jsonBtye.length; i--) desByte[ i - 1 ] = (byte) (0x00);

            return new String(desByte, encode);

        } catch (UnsupportedEncodingException e) {
            return "";

        }

    }
}
