package com.sunyard.dxp.enums;

import com.sunyard.frameworkset.util.enums.EnumAware;

/**
 * @author Thud
 * @date 2020/1/3 9:27
 */
public enum CodeMapperEnum implements EnumAware {
    TEST("TEST","测试");

    private final String code;
    private final String name;

    CodeMapperEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSimpleName() {
        return getName();
    }



    public static String getMapperNameByCode(String code) {
        for (CodeMapperEnum handler : CodeMapperEnum.values()) {
            if (handler.code.equals(code)) {
                return handler.name;
            }
        }
        return code;
    }
}
