package com.sunyard.dxp.utils;

/**
 * Write class comments here User: liulu Date: 2017/12/19 10:50 version $Id : MsgKeys.java, v 0.1 Exp $
 */

public class MsgKeys {

    public static final String KEY = "key";

    public static final String URL = "url";

    public static final String IN_BOUND_SVC_ID = "inBoundSvcId";

    public static final String APP_CODE = "appCode";

    public static final String APP_NAME = "appName";

    public static final String SERVICE_BUNDLE_ID = "serviceBundleId";

    public static final String SERVICE_BUNDLE_CODE = "serviceBundleCode";

    public static final String SERVICE_BUNDLE_NAME = "serviceBundleName";

    public static final String OUT_BOUND_SVC_ID = "outBoundSvcId";

    public static final String OUT_BOUND_SVC_CODE = "outBoundSvcCode";

    public static final String OUT_BOUND_SVC_NAME = "outBoundSvcName";

    public static final String SERVICE_TYPE = "serviceType";

    public static final String GMT_REQUEST = "gmtRequest";

    public static final String GMT_RESPONSE = "gmtResponse";

    public static final String REQUEST_MESSAGE = "requestMessage";

    public static final String RESPONSE_MESSAGE = "reponseMessage";

    public static final String TRANID = "packTranId";
    public static final String CORPID = "corpId";

    /**
     * 报文内容
     */
    public static final String PACKAGE = "package";

    /**
     * 报文类型
     */
    public static final String PACKTYPE = "packType";

    /**
     * 报文压缩标志
     */
    public static final String PACKZIPFLAG = "packZipFlag";

    /**
     * 报文校验值
     */
    public static final String PACKMD5 = "packMD5";

    /**
     * 文件内容
     */
    public static final String FILE = "file";
    /**
     * 文件名
     */
    public static final String FILENAME = "fileName";
    /**
     * 文件MD5
     */
    public static final String FILEMD5 = "fileMD5";
    /**
     * 回调url
     */
    public static final String CALL_BACK_URL = "callbackUrl";

    public static final String HEAD = "head";

    public static final String BODY = "body";
    //响应报文ID
    public static final String SVC_RSP_MSG_ID = "svcRspMsgId";
    //服务code
    public static final String SVC_CODE = "svcCode";
    //服务名称
    public static final String SVC_NAME = "svcName";
    //服务类型
    public static final String SVC_TYPE = "svcType";
    //模块code
    public static final String BUNDLE_CODE = "bundleCode";
    //模块名称
    public static final String BUNDLE_NAME = "bundleName";
    //状态（请求成功或失败）
    public static final String REQ_STATUS = "reqStatus";
    //错误信息
    public static final String ERROR_INFO = "errorInfo";
    //报文体
    public static final String REQ_MESSAGE = "reqMessage";
    //报文体
    public static final String RSP_MESSAGE = "rspMessage";
    //响应状态
    public static final String RSP_STATUS = "rspStatus";

    // 业务主键Id（多要素之间使用 _ 分割）
    public static final String MSG_TRANID = "msgTranId";
    // 原业务主键Id（多要素之间使用 _ 分割，用于查询原交易）
    public static final String ORI_MSG_TRANID = "oriMsgTranId";
    // 报文适配器生成的模拟流水号
    public static final String SYS_REFID = "sys-refid";
    // xml 循环部分的序号
    public static final String ARRAY_ID = "array-id";
    // xml 循环部分的序号
    public static final String REQ_RESOLVE_DATA = "reqResolveData";

    //响应报文类查询字段
    public static final String[] queryField = { SVC_RSP_MSG_ID, TRANID, BUNDLE_CODE, BUNDLE_NAME, SVC_CODE
            , SVC_NAME, SVC_TYPE, REQ_MESSAGE, RSP_MESSAGE, GMT_REQUEST, GMT_RESPONSE, REQ_STATUS, RSP_STATUS
            , ERROR_INFO, MSG_TRANID, ORI_MSG_TRANID };

    public static final String SUNYARD = "Sunyard";

    //返回值名称
    public static final String RTN_CODE = "rtncode";

    // 密押机对应字段
    public static final String MYJ_REGION = "region";  // 地区
    public static final String MYJ_MAC = "mac";  // 签名域
    public static final String MYJ_MESSAGE = "message";  // 报文信息
    public static final String MYJ_ENCODE = "encode";  // 编码
    public static final String MYJ_VERSION = "version";  // 版本
    public static final String MYJ_ALGORITHM = "algorithm";  // 算法
    public static final String MYJ_NODECODE = "nodecode";  // 结点

    // 报文转文件，文件转为报文使用同一的key
    public static final String FILE_BODY_DETAIL = "filebody";  // 文件内容作为变长明细，使用的key
    public static final String FILE_BODY_DETAIL_SIZE = "file-loop-size";  // fileBody detail 循环次数
    public static final String XML_DETAIL = "xml_detail";  // xml字段中存在定长明细，使用的key
    public static final String XML_DETAIL_SIZE = "xml-loop-size";  // xml detail 循环的次数

    private MsgKeys( ) {

    }
}
