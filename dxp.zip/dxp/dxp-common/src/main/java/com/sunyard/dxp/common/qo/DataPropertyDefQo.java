package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 数据属性定义 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:55 CST 2019
   */
public class DataPropertyDefQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7551887404585356701L;

    /**名称*/
    private String name ;

    /**备注*/
    private String memo ;

    /** 接入接口Id*/
    private String inSvcBundleId ;

    /** 接出接口Id*/
    private String outSvcBundleId ;

    /** 数据类型*/
    private String dataKind ;

    public String getDataKind( ) {
        return dataKind;
    }

    public void setDataKind(String dataKind) {
        this.dataKind = dataKind;
    }

    public String getInSvcBundleId( ) {
        return inSvcBundleId;
    }

    public void setInSvcBundleId(String inSvcBundleId) {
        this.inSvcBundleId = inSvcBundleId;
    }

    public String getOutSvcBundleId( ) {
        return outSvcBundleId;
    }

    public void setOutSvcBundleId(String outSvcBundleId) {
        this.outSvcBundleId = outSvcBundleId;
    }

    public String getName( ) {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo( ) {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
