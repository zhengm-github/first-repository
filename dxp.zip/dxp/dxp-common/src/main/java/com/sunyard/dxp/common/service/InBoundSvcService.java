package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.qo.InBoundSvcQo;
import com.sunyard.frameworkset.core.service.BaseService;

import java.util.List;
import java.util.Map;

/**
 * 接入服务接口 service 接口
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:54:51 CST 2019
 */
public interface InBoundSvcService extends BaseService< InBoundSvc, String, InBoundSvcQo > {

    /**
     * 根据服务id查询对应的接入单位的列表
     *
     * @param serviceBundleId
     * @return
     */
    List< InBoundSvc > inBoundsQueryBySvcBoundId(String serviceBundleId) ;

    /**
     * 自定义sql查询
     * @param inBoundSvcQo
     * @return
     */
    List<InBoundSvc> findPartInBound(InBoundSvcQo inBoundSvcQo) ;

    /**
     *根据code查询
     * @param code
     * @return
     */
    InBoundSvc findByCode(String code) ;

    /**
     * 签名数据组装
     * @param inBoundSvc
     * @param resolve
     * @return
     */
    String packSignData(InBoundSvc inBoundSvc, Map< String, Object > resolve) ;
}
