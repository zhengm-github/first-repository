package com.sunyard.dxp.security.verify.impl;

import com.sunyard.dxp.security.verify.Verification;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.apache.commons.codec.binary.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;

public class SHA1WithRSAVerification implements Verification {
    private static final Logger LOGGER = LoggerFactory.getLogger( SHA1WithRSAVerification.class );


    @Override
    public boolean verify(String src, String encryptionSrc, String key) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.decodeBase64(key);
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));

            java.security.Signature signature = java.security.Signature.getInstance("SHA1WithRSA");

            signature.initVerify(pubKey);
            signature.update(src.getBytes(StandardCharsets.UTF_8));

            return signature.verify(Base64.decodeBase64(encryptionSrc));

        } catch (Exception e) {
            LOGGER.error("SHA1WithRSA验签失败！");
            throw new FapException("","SHA1WithRSA验签失败！");
        }
    }
}
