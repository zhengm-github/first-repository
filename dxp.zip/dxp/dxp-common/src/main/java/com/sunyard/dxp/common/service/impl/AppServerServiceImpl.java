package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.AppServerDao;
import com.sunyard.dxp.common.entity.AppServer;
import com.sunyard.dxp.common.qo.AppServerQo;
import com.sunyard.dxp.common.service.AppServerService;
import com.sunyard.frameworkset.core.dao.enums.LockModeType;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 应用服务 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:37:07 CST 2019
 */
@Service
public class AppServerServiceImpl extends BaseServiceImpl< AppServer, String, AppServerQo > implements AppServerService {
    @Autowired
    private AppServerDao appServerDao;

    @Override
    public AppServer findByCode(String code) {
        return appServerDao.findByCode(code);
    }

    @Override
    public AppServer findByAppServerId(String id) {
        return appServerDao.findById(id, LockModeType.PESSIMISTIC_WRITE);
    }
}
