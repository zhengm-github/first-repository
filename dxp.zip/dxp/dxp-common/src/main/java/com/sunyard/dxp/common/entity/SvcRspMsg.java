package com.sunyard.dxp.common.entity;

import java.io.Serializable;
import java.util.Date;

/**
* 服务响应报文
* Author: Created by code generator
* Date: Tue Dec 10 19:56:21 CST 2019
*/
public class SvcRspMsg implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5062524609905497954L;

    /** 服务响应报文ID */
    private String svcRspMsgId;

    private String packTranId;

    /** 应用编码 */
    private String appCode;

    /** 应用名称 */
    private String appName;

    /** 模块编码 */
    private String bundleCode;

    /** 模块名称 */
    private String bundleName;

    /** 服务接口编码 */
    private String svcCode;

    /** 服务接口名称 */
    private String svcName;

    /** 服务类型 */
    private String svcType;

    /** 请求报文 */
    private String reqMessage;

    /** 响应报文 */
    private String rspMessage;

    /** 请求时间 */
    private Date gmtRequest;

    /** 响应时间 */
    private Date gmtReponse;
    //请求状态
    private boolean reqStatus;
    //响应状态
    private boolean rspStatus;
    //响应类型
    private String errorInfo;

    // 业务主键Id，方便查询交易查询
    private String msgTranId;

    /*请求时候的回调url*/
    private String callbackUrl ;

    /*请求报文解析的数据*/
    private String reqResolveData ;

    public String getReqResolveData( ) {
        return reqResolveData;
    }

    public void setReqResolveData(String reqResolveData) {
        this.reqResolveData = reqResolveData;
    }

    public String getCallbackUrl( ) {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    public String getMsgTranId( ) {
        return msgTranId;
    }

    public void setMsgTranId(String msgTranId) {
        this.msgTranId = msgTranId;
    }

    public boolean isReqStatus() {
        return reqStatus;
    }

    public void setReqStatus(boolean reqStatus) {
        this.reqStatus = reqStatus;
    }

    public boolean isRspStatus() {
        return rspStatus;
    }

    public void setRspStatus(boolean rspStatus) {
        this.rspStatus = rspStatus;
    }

    public String getErrorInfo() {
        return errorInfo;
    }

    public void setErrorInfo(String errorInfo) {
        this.errorInfo = errorInfo;
    }

    public String getPackTranId() {
        return packTranId;
    }

    public void setPackTranId(String packTranId) {
        this.packTranId = packTranId;
    }

    public String getSvcRspMsgId() {
        return svcRspMsgId;
    }

    public void setSvcRspMsgId(String svcRspMsgId) {
        this.svcRspMsgId = svcRspMsgId;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getBundleCode() {
        return bundleCode;
    }

    public void setBundleCode(String bundleCode) {
        this.bundleCode = bundleCode;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public String getSvcCode() {
        return svcCode;
    }

    public void setSvcCode(String svcCode) {
        this.svcCode = svcCode;
    }

    public String getSvcName() {
        return svcName;
    }

    public void setSvcName(String svcName) {
        this.svcName = svcName;
    }

    public String getSvcType() {
        return svcType;
    }

    public void setSvcType(String svcType) {
        this.svcType = svcType;
    }

    public String getReqMessage() {
        return reqMessage;
    }

    public void setReqMessage(String reqMessage) {
        this.reqMessage = reqMessage;
    }

    public String getRspMessage() {
        return rspMessage;
    }

    public void setRspMessage(String rspMessage) {
        this.rspMessage = rspMessage;
    }

    public Date getGmtRequest() {
        return gmtRequest;
    }

    public void setGmtRequest(Date gmtRequest) {
        this.gmtRequest = gmtRequest;
    }

    public Date getGmtReponse() {
        return gmtReponse;
    }

    public void setGmtReponse(Date gmtReponse) {
        this.gmtReponse = gmtReponse;
    }


}
