package com.sunyard.dxp.message.utils;


import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.XmlFriendlyNameCoder;
import com.thoughtworks.xstream.io.xml.XppDriver;

import java.io.File;

/**
 * 
 * Created by zhangxin
 */
public class XmlUtils {

	private static Logger logger = LoggerFactory.getLogger(XmlUtils.class);

	private XmlUtils() {
	}

	/**
	 * 通过xml文件解析为bean
	 * @param xmlFile
	 * @param cls
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static  <T> T toBean(File xmlFile, Class<T> cls) {
		try {
			XStream xstream = new XStream();
			xstream.ignoreUnknownElements();
			xstream.processAnnotations(cls);
			return (T) xstream.fromXML(xmlFile);
		} catch (Exception e) {
			logger.error("文件解析报错:{}", e.getMessage());
		}
		return null;
	}
	/**
	 * 通过xml字符串解析为bean
	 * @param
	 * @param cls
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static  <T> T toBean(String xmlStr, Class<T> cls) {
		try {
			XStream xstream = new XStream();
			xstream.ignoreUnknownElements();
			xstream.processAnnotations(cls);
			return (T) xstream.fromXML(xmlStr);
		} catch (Exception e) {
			logger.error("字符串解析报错:{}", e.getMessage());
		}
		return null;
	}
	
	/**
	 * 实例转xml字符串
	 * @param t
	 * @return
	 */
	public static <T> String toString(T t){
		XStream xStream = new XStream(new XppDriver(new XmlFriendlyNameCoder("_-", "_")));
		xStream.processAnnotations(t.getClass());
		return "<?xml version=\"1.0\" encoding=\"GBK\" ?>" + FileUtils.LINE_SEPARATOR + xStream.toXML(t);
	}
}