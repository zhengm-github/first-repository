package com.sunyard.dxp.common.dao.impl;

import com.sunyard.dxp.common.dao.InBoundSvcDao;
import com.sunyard.dxp.common.entity.InBoundSvc;
import com.sunyard.dxp.common.qo.InBoundSvcQo;
import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * 接入服务接口 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Tue Dec 10 18:54:51 CST 2019
 */
@Repository
public class JpaInBoundSvcDaoImpl extends JpaBaseDaoImpl< InBoundSvc, String, InBoundSvcQo > implements InBoundSvcDao {

    @Override
    public List< InBoundSvc > findPartInBound(InBoundSvcQo qo) {

        if (qo == null) {
            return new ArrayList<>();
        }
        StringBuilder whereBuff = new StringBuilder(getMainQuery() + " where 1=1 ");
        if (StringUtils.isNoneBlank(qo.getCode())) {
            whereBuff.append(" and obj.code = '").append(qo.getCode()).append("' ");
        }
        if (StringUtils.isNoneBlank(qo.getKind())) {
            whereBuff.append(" and obj.kind = '").append(qo.getKind()).append("' ");
        }
        if (StringUtils.isNoneBlank(qo.getStatus())) {
            whereBuff.append(" and obj.status = '").append(qo.getStatus()).append("' ");
        }
        if (StringUtils.isNoneBlank(qo.getInBoundSvcType())) {
            whereBuff.append(" and obj.inBoundSvcType = '").append(qo.getInBoundSvcType()).append("' ");
        }
        whereBuff.append(" and obj.inBoundSvcId");
        // 是否绑定
        if (BooleanUtils.isTrue(qo.isBind())) {
            whereBuff.append(" in");
        } else {
            whereBuff.append(" not in");
        }
        whereBuff.append("( select s.inBoundSvcId from SvcModelRela s where s.serviceBundleId = ? )");
        return findByQueryString(whereBuff.toString(), qo.getServiceBundleId());
    }

    @Override
    public InBoundSvc findByCode(String code) {
        return findBySingle(getMainQuery() + " where obj.code= ? ", code);
    }
}
