package com.sunyard.dxp.utils;


import com.dexcoder.commons.utils.UUIDUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.io.*;
import java.util.*;

public class TempFileUtil {

    /**
     * 保存临时明细文件
     *
     * @param configPath
     * @param details
     * @param encode
     * @return
     * @throws Exception
     */
    public static String saveDetailFile(
            String configPath, List< Map< String, Object > > details, String encode, String fileName) throws Exception {

        if (CollectionUtils.isEmpty(details) || details.size() < 1) {
            return "";
        }
        // 将明细数据保存到临时文件中, 并将文件名称保存到 Mq
        PrintWriter pw = null;
        String filePath = configPath + File.separator + "files";
        File dirFile = new File(filePath);
        if (!dirFile.exists()) {
            dirFile.mkdirs();
        }
        try {
            pw = new PrintWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(
                                    new File(filePath + File.separator + fileName)), encode));
            // 保存文件头
            List< String > headList = new ArrayList<>();
            Set< String > headSet = details.get(0).keySet();
            Iterator< String > headIt = headSet.iterator();
            String val = "";
            while (headIt.hasNext()) {
                val = headIt.next();
                headList.add(val);
                pw.print(val);
                pw.print("$&$");
            }
            pw.println();
            pw.flush();
            // 写明细内容
            for (Map< String, Object > rowMap : details) {
                for (String keyName : headList) {
                    if (StringUtils.isBlank(keyName)) {
                        break;
                    }
                    pw.print(StringUtil.getDefaultStr(rowMap.get(keyName), "").toString()
                            .replaceAll("\n", "")
                            .replaceAll("\r", ""));
                    pw.print("$&$");
                }
                pw.println();
            }
            pw.flush();
        } catch (FileNotFoundException e) {
            throw e;
        } catch (UnsupportedEncodingException e) {
            throw e;
        } finally {
            pw.close();
        }
        return fileName;
    }

    /**
     * 保存临时明细文件
     *
     * @param configPath
     * @param details
     * @param encode
     * @return
     * @throws Exception
     */
    public static String saveDetailFile(
            String configPath, List< Map< String, Object > > details, String encode) throws Exception {

        // 增肌32位UUId避免重复
        String fileName =
                DateFormatUtils.format(new Date(), "HHmmss") + Thread.currentThread().getName() + "_" + UUIDUtils.getUUID32();
        return saveDetailFile(configPath, details, encode, fileName);
    }
}
