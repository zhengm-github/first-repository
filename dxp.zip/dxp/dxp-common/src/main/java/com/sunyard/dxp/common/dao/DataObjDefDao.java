package com.sunyard.dxp.common.dao;

import com.sunyard.dxp.common.entity.DataObjDef;
import com.sunyard.dxp.common.qo.DataObjDefQo;
import com.sunyard.frameworkset.core.dao.BaseDao;

import java.util.List;

/**
 * 数据对象定义 dao 接口
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:27 CST 2019
 */
public interface DataObjDefDao extends BaseDao<DataObjDef, String, DataObjDefQo> {

    /**
     * 根据Id找结果对象
     * @param bundleId
     * @param flag
     * @param dataKind
     * @return
     */
    List<DataObjDef> findByBundleId(String bundleId, String flag, String dataKind) ;

    /**
     * 根据接出服务id查询数据对象定义表
     * @param outBoundSvcId
     * @return
     */
    List<DataObjDef> getDataObjDefByOutsvcId(String outBoundSvcId);

    /**
     * 根据接入服务id查询数据对象定义表
     * @param inBoundSvcId
     * @return
     */
    List<DataObjDef> getDataObjDefByInsvcId(String inBoundSvcId);

}
