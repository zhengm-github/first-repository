package com.sunyard.dxp.common.entity;

import javax.persistence.*;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;

/**
* 统一服务授权key
* Author: Created by code generator
* Date: Tue Dec 24 10:41:23 CST 2019
*/
@Entity
@Table(name = "DXP_ACCESS_KEY")
public class AccessKey implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 8904645125941333806L;

    /** 授权keyID */
    @Id
    @GeneratedValue( generator = "hibernate-uuid")
    @GenericGenerator ( name = "hibernate-uuid",strategy = "uuid")
    @Column( name = "ACCESS_KEY_ID")
    private String accessKeyId;

    /** 授权key */
    @Column( name = "ACCESS_KEY")
    private String accessKey;

    /** 授权key密文 */
    @Column( name = "ACCESS_KEY_SECRET")
    private String accessKeySecret;

    /** 授权ip */
    @Column( name = "ACCESS_IP_GROUP")
    private String accessIpGroup;

    /** 应用编码 */
    @Column( name = "APP_CODE")
    private String appCode;

    public String getAccessKeyId() {
        return accessKeyId;
    }

    public void setAccessKeyId(String accessKeyId) {
        this.accessKeyId = accessKeyId;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getAccessKeySecret() {
        return accessKeySecret;
    }

    public void setAccessKeySecret(String accessKeySecret) {
        this.accessKeySecret = accessKeySecret;
    }

    public String getAccessIpGroup() {
        return accessIpGroup;
    }

    public void setAccessIpGroup(String accessIpGroup) {
        this.accessIpGroup = accessIpGroup;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

}
