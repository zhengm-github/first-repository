package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.springframework.stereotype.Component;

/**
 * 通过下划线分割各个属性值
 */
@FunctionLibrary(code = "underlineSign",name = "拼接（用 _ 分割） ",expression = "(.*)(underlineSign)(.*)",type = "all" ,isRelation = true,exp = "underlineSign")
@Component
public class UnderlineSignFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        return params.replaceAll("underlineSign","_");
    }
}
