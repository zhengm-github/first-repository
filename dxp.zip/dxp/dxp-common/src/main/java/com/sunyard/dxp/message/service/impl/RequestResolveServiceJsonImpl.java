package com.sunyard.dxp.message.service.impl;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.service.BaseResolveService;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.dxp.utils.AgreementLibrary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Map;

/**
 * @Description JSON格式报文解析
 * @Author zhangxin
 * @Date 2020/1/10 10:57
 * @Version 1.0
 */
@Service("jsonResolve")
@AgreementLibrary(code = "json" , name = "JSON格式报文解析")
public class RequestResolveServiceJsonImpl implements RequestResolveService {

    @Autowired
    @Qualifier("baseResolveServiceJson")
    private BaseResolveService baseResolveService;

    @Override
    public void validate(RequestResolveDto requestResolveDto) {
        if (StringUtils.isEmpty(requestResolveDto.getMessage())) {
            throw new DxpCommonException(DxpCommonEnums.COMMON_RESOLVE_ERROR_MSG_006);
        }
    }

    @Override
    public Map<String, Object> resolve(SignDto signDto, RequestResolveDto requestResolveDto) {
        return baseResolveService.execute(null, requestResolveDto.getMessage());
    }

    @Override
    public Map<String, Object> mapResolve(Map<String, Object> map, SignDto signDto, RequestResolveDto requestResolveDto) {
        return baseResolveService.mapExecute(null,map);
    }
}
