package com.sunyard.dxp.utils;

/**
 * GZIP 工具的结果类
 */
public class GzipAndMd5Result {

    /**
     * gzip 字符串
     */
    private String gzipStr ;

    /**
     * MD5 字符串
     */
    private String md5Str ;

    private byte[] plainBytes ;

    public String getGzipStr( ) {
        return gzipStr;
    }

    public void setGzipStr(String gzipStr) {
        this.gzipStr = gzipStr;
    }

    public String getMd5Str( ) {
        return md5Str;
    }

    public void setMd5Str(String md5Str) {
        this.md5Str = md5Str;
    }

    public byte[] getPlainBytes( ) {
        return plainBytes;
    }

    public void setPlainBytes(byte[] plainBytes) {
        this.plainBytes = plainBytes;
    }
}
