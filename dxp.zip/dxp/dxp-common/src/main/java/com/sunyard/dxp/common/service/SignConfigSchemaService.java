package com.sunyard.dxp.common.service;

import com.sunyard.frameworkset.core.service.BaseService;
import com.sunyard.dxp.common.entity.SignConfigSchema;
import com.sunyard.dxp.common.qo.SignConfigSchemaQo;

import java.util.List;

/**
 * 签名配置规划 service 接口
 *
 * Author: Created by code generator
 * Date: Mon Jan 06 10:54:44 CST 2020
 */
public interface SignConfigSchemaService extends BaseService<SignConfigSchema, String, SignConfigSchemaQo> {

    /**
     * 根据接出服务id查询签名配置规划
     * @param outBoundSvcId
     * @return
     */
    List<SignConfigSchema> getSignConfigSchemaByOutsvcId(String outBoundSvcId);

    /**
     * 根据接入服务id查询签名配置规划
     * @param inBoundSvcId
     * @return
     */
    List<SignConfigSchema> getSignConfigSchemaByInsvcId(String inBoundSvcId);

    /**
     * 根据接出服务id删除签名配置规划
     * @param outBoundSvcIds
     * @return
     */
    void deleteSignConfigSchemaByOutsvcId(String... outBoundSvcIds);

    /**
     * 根据接入服务id删除签名配置规划
     * @param inBoundSvcIds
     * @return
     */
    void deleteSignConfigSchemaByInsvcId(String... inBoundSvcIds);

    /**
     * 签名校验（核对）
     * @param src
     * @param sign
     * @param key
     * @param signAlgol
     * @param documentSrc
     * @param params [1-region, 2-version, 3-algorithm, 4-unitcode]
     * @return
     */
    boolean validateSign(
            String src, String sign, String key, String signAlgol, String documentSrc, String... params) ;
}
