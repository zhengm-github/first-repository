package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.ReqDataMapConfigDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.ReqDataMapConfigService;
import com.sunyard.dxp.common.entity.ReqDataMapConfig;
import com.sunyard.dxp.common.qo.ReqDataMapConfigQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 请求报文映射配置 service
 *
 * Author: Created by code generator
 * Date: Tue Jan 07 19:15:01 CST 2020
 */
@Service
public class ReqDataMapConfigServiceImpl extends BaseServiceImpl<ReqDataMapConfig, String, ReqDataMapConfigQo> implements ReqDataMapConfigService {
    @Autowired
    private ReqDataMapConfigDao reqDataMapConfigDao;

    @Override
    public List<ReqDataMapConfig> findReqConfigByInDataPropertyId(String inDataPropertyId) {
        return reqDataMapConfigDao.findReqConfigByInDataPropertyId(inDataPropertyId);
    }

    @Override
    public void deleteByPropertyId(String propertyId) {
        reqDataMapConfigDao.deleteByPropertyId(propertyId);
    }
}
