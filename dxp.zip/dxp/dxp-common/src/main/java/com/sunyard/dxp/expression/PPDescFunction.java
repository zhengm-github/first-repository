package com.sunyard.dxp.expression;

import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.exp_enums.ExpMapper;
import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 处理状态和处理码 映射单位的处理描述
 */
@FunctionLibrary( code = "PPDesc", name = "Prcsts+Prccd 映射单位处理描述 ", expression = "(\\$\\{[\\s\\w]+\\})(PPDesc)(\\$\\{[\\s\\w]+\\})", type = "all", isRelation = true, exp = "PPDesc" )
@Component
public class PPDescFunction implements ParamExpression {

    @Override
    public String expCompute(String params) {

        if (StringUtils.isNotBlank(params) && params.contains("PPDesc")) {
            String[] paramArr = params.split("PPDesc", -1);
            if (paramArr.length < 2) {
                return "";  
            }
            try {
                // prcsts = PR03||Pr05 表成功
                if("PR03".equals(paramArr[ 0 ]) || "PR05".equals(paramArr[ 0 ])){
                    return "交易成功" ;
                }else if("PR07".equals(paramArr[ 0 ])){
                    return "交易已处理，请查询确认状态" ;
                }else{
                    String value = ExpMapper.prccdCorpMap.get(paramArr[ 1 ]) ;

                    if (value != null && value.contains(",")) {
                        return value.split(",", -1)[ 1 ];
                    }else{
                        return ExpMapper.prccdCorpMap.get("default").split(",")[ 1 ]; // 默认失败的情况
                    }
                }
            } catch (Exception e) {
                throw new DxpCommonException(DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getCode(),
                        DxpCommonEnums.DXP_IN_SERVICE_NUMBERFORMAT_FAIL.getName() + e);
            }
        }
        return params;
    }
}
