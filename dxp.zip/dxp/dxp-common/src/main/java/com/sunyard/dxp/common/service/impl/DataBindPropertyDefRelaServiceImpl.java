package com.sunyard.dxp.common.service.impl;

import com.sunyard.dxp.common.dao.DataBindPropertyDefRelaDao;
import com.sunyard.frameworkset.core.service.BaseServiceImpl;
import com.sunyard.dxp.common.service.DataBindPropertyDefRelaService;
import com.sunyard.dxp.common.entity.DataBindPropertyDefRela;
import com.sunyard.dxp.common.qo.DataBindPropertyDefRelaQo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 接出数据属性绑定配置 service
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:44:42 CST 2019
 */
@Service
public class DataBindPropertyDefRelaServiceImpl extends BaseServiceImpl<DataBindPropertyDefRela, String, DataBindPropertyDefRelaQo> implements DataBindPropertyDefRelaService {
    @Autowired
    private DataBindPropertyDefRelaDao dataBindPropertyDefRelaDao;

    @Override
    public void deleteByPropertyId(String propertyId) {
        dataBindPropertyDefRelaDao.deleteByPropertyId(propertyId);
    }

    @Override
    public void deleteByPropertyIdAndConfig(String propertyId, String configId) {
        dataBindPropertyDefRelaDao.deleteByPropertyIdAndConfig(propertyId, configId);
    }

    @Override
    public List<DataBindPropertyDefRela> findByDataBindConfigId(String dataBindConfigId) {
        return dataBindPropertyDefRelaDao.findByDataBindConfigId(dataBindConfigId);
    }
}
