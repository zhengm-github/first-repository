package com.sunyard.dxp.common.vo;

import java.io.Serializable;
import java.util.Set;

/**
* 协议解析规划
*
* Author: Created by code generator
* Date: Tue Jan 07 19:22:25 CST 2020
*/
public class ProcotolResolvePlanVo implements Serializable {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5316984636893786601L;

    /** 协议解析规划ID */
    private String procotolResolvePlanId;

    /** 分隔符 */
    private String separatorChar;

    /** 名称 */
    private String name;

    /** 备注 */
    private String memo;

    /** 起始位置 */
    private String beginIndex;

    /** 结束位置 */
    private String endIndex;

    /** 数据类型 */
    private String dataKind;

    /** 接入接口Id*/
    private String inBoundSvcId ;

    /** 接出接口Id*/
    private String outBoundSvcId ;

    /** 协议解析规则*/
    private Set< ProcotolResolveRuleVo > procotolResolveRulesVo ;

    public Set< ProcotolResolveRuleVo > getProcotolResolveRulesVo( ) {
        return procotolResolveRulesVo;
    }

    public void setProcotolResolveRulesVo(Set< ProcotolResolveRuleVo > procotolResolveRulesVo) {
        this.procotolResolveRulesVo = procotolResolveRulesVo;
    }

    public String getBeginIndex( ) {
        return beginIndex;
    }

    public void setBeginIndex(String beginIndex) {
        this.beginIndex = beginIndex;
    }

    public String getEndIndex( ) {
        return endIndex;
    }

    public void setEndIndex(String endIndex) {
        this.endIndex = endIndex;
    }

    public String getDataKind( ) {
        return dataKind;
    }

    public void setDataKind(String dataKind) {
        this.dataKind = dataKind;
    }

    public String getInBoundSvcId( ) {
        return inBoundSvcId;
    }

    public void setInBoundSvcId(String inBoundSvcId) {
        this.inBoundSvcId = inBoundSvcId;
    }

    public String getOutBoundSvcId( ) {
        return outBoundSvcId;
    }

    public void setOutBoundSvcId(String outBoundSvcId) {
        this.outBoundSvcId = outBoundSvcId;
    }

    public String getProcotolResolvePlanId() {
    return procotolResolvePlanId;
    }

    public void setProcotolResolvePlanId(String procotolResolvePlanId) {
    this.procotolResolvePlanId = procotolResolvePlanId;
    }

    public String getSeparatorChar() {
    return separatorChar;
    }

    public void setSeparatorChar(String separatorChar) {
    this.separatorChar = separatorChar;
    }

    public String getName() {
    return name;
    }

    public void setName(String name) {
    this.name = name;
    }

    public String getMemo() {
    return memo;
    }

    public void setMemo(String memo) {
    this.memo = memo;
    }

}
