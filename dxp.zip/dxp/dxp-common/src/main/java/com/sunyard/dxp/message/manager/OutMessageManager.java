package com.sunyard.dxp.message.manager;

import com.sunyard.dxp.common.entity.ProcotolResolveRule;
import com.sunyard.dxp.enums.DxpCommonEnums;
import com.sunyard.dxp.exception.DxpCommonException;
import com.sunyard.dxp.message.dto.RequestResolveDto;
import com.sunyard.dxp.message.dto.SignDto;
import com.sunyard.dxp.message.factory.ServiceFactory;
import com.sunyard.dxp.message.service.RequestResolveService;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Description 接出服务报文解析及组装
 * @Author zhangxin
 * @Date 2019/12/31 16:10
 * @Version 1.0
 */
@Service
public class OutMessageManager {

    private static final Logger log = LoggerFactory.getLogger(OutMessageManager.class);

    @Autowired
    private ServiceFactory serviceFactory;

    /**
     * 报文及文件解析
     *
     * @param msgProtocol          报文协议
     * @param procotolResolveRules 解析规则
     * @param encoding             编码
     * @param message              报文
     * @param fileMessage          文件
     * @param signDto          sign 部分校验需要
     * @return java.util.Map<java.lang.String, java.lang.Object>
     * @author zhangxin
     * @date 2020/1/10 15:41
     */
    public Map< String, Object > resolve(String msgProtocol, List< ProcotolResolveRule > procotolResolveRules,
                                         SignDto signDto,String encoding, String message, String fileMessage){
        // spring容器中获取处理该笔交易的服务
        RequestResolveService resolveService =
                serviceFactory.getBean(msgProtocol + "Resolve", RequestResolveService.class);
        RequestResolveDto requestResolveDto =
                new RequestResolveDto(msgProtocol, procotolResolveRules, encoding, message, fileMessage);
        // 执行具体服务获取结果
        if (resolveService == null) {
            throw new DxpCommonException(DxpCommonEnums.MSG_PROTOCOL_NOT_EXIT);
        }
        return resolveService.resolve(signDto, requestResolveDto);
    }

    /**
     *
     * @param map
     * @param msgProtocol
     * @param signDto 签名算法参数集合
     * @param procotolResolveRules
     * @param packParams
     * @return
     * @throws DxpCommonException
     */
    public Map< String, Object > pack(
            Map< String, Object > map, String msgProtocol, SignDto signDto,
            List< ProcotolResolveRule > procotolResolveRules, String... packParams) {
        RequestResolveService resolveService = serviceFactory.getBean(msgProtocol + "Resolve", RequestResolveService.class);
        RequestResolveDto requestResolveDto =
                new RequestResolveDto(msgProtocol, procotolResolveRules, packParams[ 0 ], null, null);
        if (resolveService == null) {
            throw new DxpCommonException(DxpCommonEnums.MSG_PROTOCOL_NOT_EXIT);
        }
        return resolveService.mapResolve(map, signDto, requestResolveDto);
    }

}
