package com.sunyard.dxp.common.dao.qct;

import com.sunyard.dxp.common.qo.AddrInfoQo;
import com.sunyard.frameworkset.core.dao.QueryCondition;
import com.sunyard.frameworkset.core.dao.QueryConditionTransfer;

/**
 * 地址信息管理 Qct转化类
 *
 * Author: Created by code generator
 * Date: Thu Jun 11 16:10:14 CST 2020
 */
public class AddrInfoQct extends QueryConditionTransfer< AddrInfoQo > {

    @Override
    public void transNameQuery(AddrInfoQo qo, QueryCondition condition) {

    }

    @Override
    public void transQuery(AddrInfoQo qo, QueryCondition condition) {

    }

}
