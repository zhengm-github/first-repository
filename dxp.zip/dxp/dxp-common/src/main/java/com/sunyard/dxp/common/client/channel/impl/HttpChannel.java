package com.sunyard.dxp.common.client.channel.impl;

import com.sunyard.dxp.RequestUtils;
import com.sunyard.dxp.common.client.channel.Channel;
import com.sunyard.dxp.constants.CommonConstants;
import com.sunyard.dxp.utils.StringUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @author Thud
 * @date 2019/12/26 15:24
 */
@Component( "httpChannel" )
public class HttpChannel implements Channel {
    @Override
    public Map< String, Object > send(String url, Object requestBody, boolean send2Center) {
        Map< String, Object > request = (Map< String, Object >) requestBody;
        if (send2Center) {
            String accessToken = StringUtil.getDefaultStr(request.get(CommonConstants.ACCESS_TOKEN), "");
            return RequestUtils.doPost2Center(url, request.get("package").toString(), false, accessToken);
        }
        return RequestUtils.doPost(url, request);
    }
}
