package com.sunyard.dxp.utils;

import com.sunyard.dxp.common.entity.ExpData;

import java.util.*;

/**
 * Write class comments here User: liulu Date: 2017/12/20 14:00 version $Id : Constant.java, v 0.1 Exp $
 */

public class Constant {
    public static final String QUEUE_NAME = "rabbit-queue";

    public static final String ROUTING_KEY = "rabbit-key";

    public static final String EXCHANGE = "exchange";

    public static final String ADAPTER_REF_NAME = "adapter_refid";  //适配器针对单位产生的流水

    /**
     * 金额属性名 限制
     */
    public static final List< String > AMT_LIST = Arrays.asList(
            "CycDdctnLmt","CtrlSum","FeSum",
            "OncDdctnLmt",
            "RcvgTtlAmt"
    );

    /**
     * 明细中使用GZIP加压标识
     */
    public static final String USE_GZIP_FLAG = "CPED";

    /**
     * 共用的接入配置
     */
    public static List< String > unitIbsCodes = new ArrayList<>();

    /**
     * 特殊交易中间态
     */
    public static List< String > intermediaStateCodes = new ArrayList<>() ;

    /**
     * 900状态成功需要转至单位的接出
     */
    public static List< String > SPECIAL_SUCC = new ArrayList<>() ;

    /**
     * 密押机(支持多个 ip+port)
     */
    public static String MYJ_Host = "61.164.40.82:8889" ;

    /**
     * 密押机是否在前置使用， 宁波专用  默认需要加密
     */
    public static String NEED_ENCRYPT = "1" ;

    /**
     * 特殊交易中间态
     */
    public static String gzip_312 = "" ;

    /**
     * 系统临时文件夹
     */
    public static String TEMP_FILES_PATH = "" ;


    // 函数使用的集合
    //非关系函数
    public static Map< String, ExpData > notRelation = new HashMap<>();
    //关系函数
    public static Map< String, ExpData > relation = new HashMap<>();
    //四则
    public static Map< String, ExpData > fourList = new HashMap<>();

    // 慢通道交易代码
    public static String SLOW_TOPIC_OUTCODE = "" ;

    // 前置 平台和单位的配置文件
    public static Properties NATION_CENTER_PROP = null ;
    public static Properties NET_ADAPTER_PROP = null ;

    // 定义哪些接出业务对应批量线程池
    public static String BATCH_OUTCODE = "" ;

    private Constant( ) {
        //
    }

}
