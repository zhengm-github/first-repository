package com.sunyard.dxp.expression;

import com.sunyard.dxp.utils.FunctionLibrary;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 截取的时候 去除英文逗号 和换行符, （广西用）
 */
@FunctionLibrary( code = "subTrim", name = "截取(去特殊字符)", expression = "(subTrim\\()([\\s\\w,|]+\\$\\{[\\s\\w]+\\})(\\))", type = "string", exp = "subTrim(x|y)", hasProperty = true )
@Component
public class SubTrimFunction implements ParamExpression {
    @Override
    public String expCompute(String params) {
        //subTrim(1|2,123)
        // 先逗号分割， 再其他
        String[] str2 = params.split(",", -1);
        String[] indexArr = str2[ 0 ].split("\\|");

        String valStr = params.substring(params.indexOf(",") + 1);

        //再次分割  2,  123
        int start;
        int end;
        int len;
        try {
            start = Integer.parseInt(indexArr[ 0 ]);
            end = Integer.parseInt(indexArr[ 1 ]);
            //结束位置超过总长度的时候，只需要截取到字符串的末尾就可以了。
            len = valStr.length();
            end = end > len ? len : end;
            return StringUtils.isNotBlank(valStr) ? valStr.substring(start, end)
                    .replace("\n", " ").replace(",", " ") : "";
        } catch (Exception e) {
            // 截取失败时，返回原串
            return valStr.replace("\n", " ").replace(",", " ");
        }

    }
}
