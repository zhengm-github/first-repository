package com.sunyard.dxp.utils;

import com.sunyard.dxp.common.entity.Signature;
import org.reflections.Reflections;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Thud
 * @date 2020/2/26 13:36
 * 签名初始化
 */
@Configuration
public class InitSignatureLibrary {

    @Bean("signatures")
    public List<Signature> init() {
        Reflections f = new Reflections("com.sunyard.dxp.security.sign.impl");
        Set<Class<?>> set = f.getTypesAnnotatedWith(SignatureLibrary.class);
        List<Signature> list = new ArrayList<>();
        for (Class<?> c : set) {
            SignatureLibrary signaturelibrary = c.getAnnotation(SignatureLibrary.class);
            Signature signature = new Signature();
            signature.setCode(signaturelibrary.code());
            signature.setName(signaturelibrary.name());
            list.add(signature);
        }
        return list;
    }
}
