package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 数据绑定配置 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:43:42 CST 2019
   */
public class RspDataBindConfigQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 6025146039235832226L;

}
