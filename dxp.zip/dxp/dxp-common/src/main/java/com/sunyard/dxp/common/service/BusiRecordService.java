package com.sunyard.dxp.common.service;

import com.sunyard.dxp.common.entity.BusiRecord;
import com.sunyard.dxp.common.entity.SvcRspMsg;
import com.sunyard.dxp.common.qo.BusiRecordQo;
import com.sunyard.frameworkset.core.service.BaseService;

import java.util.List;
import java.util.Map;

/**
 * 记录业务信息（请求和响应） service 接口
 *
 * Author: Created by code generator
 * Date: Tue Jun 09 17:17:29 CST 2020
 */
public interface BusiRecordService extends BaseService< BusiRecord, String, BusiRecordQo > {

    /**
     * 根据msgTranId 和 svcCode 查询记录 （唯一！！）
     * svcCode 可以是 ibsCode 或 obscode
     * @param msgTranId
     * @param svcCode
     * @return
     */
    SvcRspMsg findBySvcCodeAndMsgId(String msgTranId, String svcCode) ;

    /**
     * 根据msgTranId 和 svcCode 删除记录 （唯一！！）
     * svcCode 可以是 ibsCode 或 obscode
     * @param msgTranId
     * @param svcCode
     */
    boolean deleteBySvcCodeAndMsgId(String svcCode, String msgTranId) ;

    /**
     * 根据 svcRspMsgId 删除记录
     * @param svcRspMsgId
     * @return
     */
    boolean deleteBySvcRspMsgId(String svcRspMsgId) ;

    /**
     * 根据msgTranId 查询记录 （不唯一）
     * @param msgTranId
     * @return
     */
    List<SvcRspMsg> findByMsgId(String msgTranId) ;

    /**
     * 保存信息
     * @param dataMap
     * @return
     */
    boolean saveForMap(Map< String, Object > dataMap ) ;

}
