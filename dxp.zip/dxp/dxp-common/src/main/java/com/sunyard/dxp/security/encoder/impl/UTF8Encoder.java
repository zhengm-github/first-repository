package com.sunyard.dxp.security.encoder.impl;

import com.sunyard.dxp.security.encoder.Encoder;
import com.sunyard.dxp.utils.EncoderLibrary;
import com.sunyard.frameworkset.core.exception.FapException;
import com.sunyard.frameworkset.log.Logger;
import com.sunyard.frameworkset.log.LoggerFactory;

import java.nio.charset.StandardCharsets;

/**
 * 编码转换为GBK
 */
@EncoderLibrary( code = "UTF-8", name = "UTF-8编码" )
public class UTF8Encoder implements Encoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(UTF8Encoder.class);

    @Override
    public String encode(String content) {
        String clientStr = null;
        try {
            clientStr = new String(content.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        } catch (Exception e) {
            LOGGER.error("编码GBK失败！");
            throw new FapException("", "编码GBK失败！");
        }
        return clientStr;
    }
}
