package com.sunyard.dxp.common.dao.impl;

import com.sunyard.frameworkset.dao.jpa.JpaBaseDaoImpl;
import com.sunyard.dxp.common.dao.SignConfigItemDao;
import com.sunyard.dxp.common.entity.SignConfigItem;
import com.sunyard.dxp.common.qo.SignConfigItemQo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 签名配置项 jdbc实现类
 * <p>
 * Author: Created by code generator
 * Date: Mon Jan 06 10:49:49 CST 2020
 */
@Repository
public class JpaSignConfigItemDaoImpl extends JpaBaseDaoImpl< SignConfigItem, String, SignConfigItemQo > implements SignConfigItemDao {

    @Override
    public void deleteByDataPropertyId(String dataPropertyId) {
        if (StringUtils.isNotBlank(dataPropertyId)) {
            this.executeUpdate(" delete from SignConfigItem as obj where obj.dataPropertyDef.dataPropertyId = ?", dataPropertyId);
        }
    }

    @Override
    public List< SignConfigItem > findByDataObjDefId(String dataObjDefId) {
        // 根据inSvcBundleId进行分组ord的
        return this.find(
                "Select obj from SignConfigItem as obj where obj.dataPropertyDef.dataObjDef.dataObjDefId = ? order by obj.ord desc "
                , dataObjDefId);
    }
}
