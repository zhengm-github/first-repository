package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 应用系统 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 10 18:35:23 CST 2019
   */
public class AppQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 7607236521540565548L;

    /** 应用编号 */
    private String appCode ;

    public String getAppCode( ) {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }
}
