package com.sunyard.dxp.common.qo;

import com.sunyard.frameworkset.util.pages.PagingOrder;

/**
 * 数据对象定义 QO
 *
 * Author: Created by code generator
 * Date: Tue Dec 24 10:45:27 CST 2019
   */
public class DataObjDefQo extends PagingOrder {

    /** serialVersionUID */
    private static final long         serialVersionUID = 5249899732925486154L;

}
